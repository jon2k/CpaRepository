﻿using TarFoundation.St;
using TarReferenceSource.Oip;

namespace TarReferenceSource.Sard.Throttle.Imit
{
    public class ThrottleImit : IFunctionBlock
    {
        public bool HasOpenCmd;
        public bool HasCloseCmd;
        public float ControlSignal;
        

        public float Position;
        public float PositionElValue;
        public bool Kvo;
        public bool Kvz;
        public bool ModeIsAuto;
        public bool Crash;
        public bool Mvo;
        public bool Mvz;

        public override void Execute()
        {
            Kvo = Position > 99.5;
            if (Kvo && HasOpenCmd)
            {
                ControlSignal = 0;
            }
            Kvz = Position < 0.5;
            if (Kvz && HasCloseCmd)
            {
                ControlSignal = 0;
            }
            PositionElValue = OipElectric.LinearDecoding(Position, new Range {Bottom = 0, Top = 100},
                new Range {Bottom = 4, Top = 20});
        }
    }
}
