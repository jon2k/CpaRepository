﻿using TarFoundation.St;

namespace TarReferenceSource.Oip.TankSpeed
{
    public abstract class TankSpeedIo : IFunctionBlock
    {
        /// <summary>
        /// input Новое входное значение уровня в резервуаре
        /// </summary>
        public float Value;
        /// <summary>
        /// input Время регистрации нового значения уровня в резервуаре
        /// </summary>
        public uint Timestamp;
        /// <summary>
        /// input Флаг недостоверности значения уровня в резервуаре
        /// </summary>
        public bool Ndv;
        /// <summary>
        /// input Плечо
        /// </summary>
        public float THRESHOLD;
        /// <summary>
        /// input Множитель для перевода скорости за 1 цикл работы программы в мм/ч.
        /// </summary>
        public float ScaleFactor = 3600000;
        /// <summary>
        /// input. Максимальный размер буфера, выбирается из расчета за 10 секунд записи каждого цикла работы программы
        /// </summary>
        public ushort CAPACITY = 200;
        public abstract void ResetBuffer();
        /// <summary>
        /// output Среднее значение скорости
        /// </summary>
        public float Result;
    }
}
