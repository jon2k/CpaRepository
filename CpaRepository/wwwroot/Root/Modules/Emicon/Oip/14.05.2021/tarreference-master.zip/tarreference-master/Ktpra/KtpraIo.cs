﻿using TarFoundation.St;

namespace TarReferenceSource.Ktpra
{

    public abstract class KtpraIo:IFunctionBlock
    {
        // in
        /// <summary>
        /// input Массив данных от модуля ProcKtpra
        /// </summary>
        public StArray<ProcKtpraResult> Input;
        /// <summary>
        /// cfg Конфигурация от каждой из защит ProcKtpra 
        /// </summary>
        public StArray<ProcKtpraConfig> Cfg;
        // out
        /// <summary>
        /// output Массив выходных данных в модуль Ktpras
        /// </summary>
        public KtpraResult Result;
        /// <summary>
        /// output Количество агрегатных защит
        /// </summary>
        public int CountAgrProtect => Input.Count;

    }
}
