﻿namespace TarReferenceSource.Kgmpna.Gmpna
{
    /// <summary>
    /// /// <summary>
    /// Выходные даные из модуля Gmpna
    /// </summary>
    /// </summary>
    public class GmpnaResult
    {
        /// <summary>
        /// Флаг наличия готовности
        /// </summary>
        public bool P;
        /// <summary>
        /// Флаг маскирования готовности
        /// </summary>
        public bool M;
        /// <summary>
        /// Флаг наличия параметра готовности
        /// </summary>
        public bool F;
        /// <summary>
        /// Флаг запрета маскирования готовности
        /// </summary>
        public bool NotMasked;
    }
    /// <summary>
    /// Выходные даные из модуля Kgmpna
    /// </summary>
    public class KgmpnaResult
    {
        /// <summary>
        /// Обобщенный флаг наличия готовности НА
        /// </summary>
        public bool P;
        /// <summary>
        /// Обобщенный флаг наличия замаскированной готовности НА
        /// </summary>
        public bool M;
        /// <summary>
        /// Обобщенный флаг наличия параметров готовности НА
        /// </summary>
        public bool F;
    }
    
    public enum GmpnaCmd : ushort
    {
        None = 0,
        Mask = 1,
        UnMask = 2
    }
    /// <summary>
    /// Данные для конфигурации модуля Gmpna
    /// </summary>
    public class GmpnaConfig
    {
        /// <summary>
        /// Флаг запрета маскирования готовности
        /// </summary>
        public bool NotMasked;
    }
}
