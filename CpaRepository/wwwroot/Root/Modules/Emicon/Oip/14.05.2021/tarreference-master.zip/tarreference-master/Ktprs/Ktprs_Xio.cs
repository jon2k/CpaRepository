﻿using System;
using System.Collections.Generic;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;

namespace TarReferenceSource.Ktprs
{
    public abstract class Ktprs_Xio : IFunctionBlock
    {
        public Ktprs_Xio()
        {
            Description.TimerDescriptions = TimerDescriptions;
        }
        /// <summary>
        /// input Флаг наличия предельного параметра
        /// </summary>
        public bool Input;
        /// <summary>
        /// output Флаг необходимости выполнения действий по наличию предельного параметра
        /// </summary>
        public bool P;
        /// <summary>
        /// output Флаг наличия предельного параметра
        /// </summary>
        public bool F;
        /// <summary>
        /// output Флаг нормализации параметра контроля
        /// </summary>
        public bool N;

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {
            {1, new MessageDescription{Text = "ПРЕДЕЛЬНЫЙ ПАРАМЕТР. СНЯТ", Type = MessageType.Neutral} },
            {2, new MessageDescription{Text = "ПРЕДЕЛЬНЫЙ ПАРАМЕТР", Type = MessageType.Attention} },
        };
        protected static Dictionary<int, TimerDescription> TimerDescriptions = new Dictionary<int, TimerDescription>
        {
            {1, new TimerDescription("Время выдержки до формирования флага выполнения действия по наличию предельного параметра", TimeSpan.FromMilliseconds(500)) },
            {2, new TimerDescription("Время выдержки до формирования флага нормализаци предельного параметра", TimeSpan.FromMilliseconds(500)) }
          
        };
    }
}
