﻿using TarFoundation.St;
using TarReferenceSource.Oip;

namespace TarReferenceSource.Sard
{
    public enum SardControlSource : ushort
    {
        panel,
        external,
    }

    public enum SardRegulationMode : ushort
    {
        ByPosition = 0,
        ByPressure = 1,
    }
    /// <summary>
    /// Коррекция для заслонки
    /// </summary>
    public class ThrottleCorrections
    {
        /// <summary>
        /// Флаг необходимости лимитирования скорости
        /// </summary>
        public bool NeedSpeedLimit;
        /// <summary>
        /// Линейная коррекция
        /// </summary>
        public float LinearCorrections;
    }

    public enum ControlLoopZone : ushort
    {
        CloseOutZone			= 0,	// Зона насыщения закрытия
        CloseRegulationZone  	= 1,	// Зона регулирования закрытия
        CloseIntergrationZone	= 2,	// Зона интегрирования закрытия
        OffZone				    = 3,	// Зона нечувствительности
        OpenIntergrationZone	= 4,	// Зона интегрирования открытия
        OpenRegulationZone		= 5,	// Зона регулирования открытия
        OpenOutZone			    = 6,	// Зона насыщения открытия
    }
    /// <summary>
    /// Результат работы моделя ControlLoop
    /// </summary>
    public class ControlLoopOutput
    {
        /// <summary>
        /// Авария
        /// </summary>
        public bool Crash;
        /// <summary>
        /// Зона регулирования
        /// </summary>
        public ControlLoopZone zone;
        /// <summary>
        /// Выходное зачение
        /// </summary>
        public float NormalizedOutput;
        /// <summary>
        /// Флаг использования регулятора
        /// </summary>
        public bool Used;
        /// <summary>
        /// Флаг использования линейной коррекции
        /// </summary>
        public bool AllowLinearCorrections;
        /// <summary>
        /// Флаг критического режима
        /// </summary>
        public bool IsCritical;
    }
    /// <summary>
    /// Демпфирубщий коэффициент
    /// </summary>
    public class DempCfg
    {
        /// <summary>
        /// Флаг использования
        /// </summary>
        public bool Enable;
        /// <summary>
        /// Минимальное значение
        /// </summary>
        public float MinValue;
        /// <summary>
        /// Максимальное значение
        /// </summary>
        public float MaxValue;
        /// <summary>
        /// Минимальный коэффициент
        /// </summary>
        public float CoeffForMin;
        /// <summary>
        /// Максимальный коэффициент
        /// </summary>
        public float CoeffForMax;

        public float CalculateCoeff(float value)
        {
            float coeff;
            if (Enable)
            {
                if (value > MaxValue)
                {
                    coeff = CoeffForMax;
                }

                else if (value < MinValue)
                {
                    coeff = CoeffForMin;
                }
                else
                {
                    coeff = (value - MinValue) / (MaxValue - MinValue) * (CoeffForMax - CoeffForMin) + CoeffForMin;
                }
                
            }
            else
            {
                coeff = 1.0f;
            }

            if (coeff < 0.1f)
            {
                coeff = 0.1f;
            }

            return coeff;
        }
    }
    /// <summary>
    /// 
    /// </summary>
    public class SardStorage
    {
        /// <summary>
        /// Активный регулятор
        /// </summary>
        public ControlLoopOutput ActiveControlLoop;
        /// <summary>
        /// Тип регулирования
        /// </summary>
        public SardRegulationMode mode;
    }

    public class ControlLoopCfg
    {
        
        public bool IsReverse;

        public float KIClose;
        public float KIOpen;
        public float NeedImpulseError;
        public float ImpulseValue;

        public float LpfZone;

        public float CloseZone;
        public float CloseOffZone;
        public float IntegrOffCloseZone;


        public float IntegrOffOpenZone;
        public float OpenOffZone;
        public float OpenZone;

        public float KdRise;
        public float KdFall;

        public bool Enable;
        public bool IsCritical = true;
    }

    public class SardCfg
    {
        public float RampCorrectionUst;
        public float RampAbortUst;

        public float PinCancelRampUst;
        public float DpCancelRampUst;
    }

    //public class Sensor
    //{
    //    public float Val; //Значение измеряемого параметра
    //    public float LPF_Val; //Фильтрованное значение измеряемого параметра
    //    public bool Ndv; //Флаг недостоверность значения измеряемого параметра
    //    public float Speed;
    //}
    /// <summary>
    /// Измерение
    /// </summary>
    public class Measurement
    {
        /// <summary>
        /// Массив аналоговых датчиков
        /// </summary>
        public StArray<AnalogSignal> sensors;
        /// <summary>
        /// Количество датчиков
        /// </summary>
        public int SensorsCount => sensors.Count;
        /// <summary>
        /// Максимальная скорость изменения
        /// </summary>
        public float MaxThrottleSpeedApplyUst;
    }

    //public class SyncStorage
    //{
    //    public StArray<ThrottleStorage> Throttles;
    //    public int ThrottlesCount => Throttles.Count;

    //    public float SyncUst;

    //    public StArray<float> CorrectedSpeeds;
    //}

    public class Sard
    {
        //in
        public bool RampFuncTrigger;
        public Measurement Pin;
        public Measurement Pout;

        //out

        //cfg
        
        //inner
        public SardStorage storage;


    }
}
