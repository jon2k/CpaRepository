﻿using Friday.Helpers;
using Friday.Runtime.CpaLocal;

namespace TarReferenceSource.Mpt.TriggersCard
{
    public class TriggersCard : TriggersCardIo
    {

        public TriggersCard(int countTrigger):base(countTrigger)
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }
        public override void Execute()
        {
            Output.AnyOfTriggersIsTriggered = false;

            for (int I = 1; I <= Input.TriggersCount; I++)
            {

                if (!Output.Triggers[I].Ndv && Input.Triggers[I].Ndv)
                {
                    //АПУ №{} неисправен
                    Messenger.Send(1);
                }
                if (Output.Triggers[I].Ndv && !Input.Triggers[I].Ndv)
                {
                    //АПУ №{} исправен
                    Messenger.Send(2);
                }
                Output.Triggers[I].Ndv = Input.Triggers[I].Ndv;

                if (!Output.Triggers[I].Ndv)
                {
                    if (!Input.InRem)
                    {
                        if (!Output.Triggers[I].Triggered && Input.Triggers[I].Triggered)
                        {
                            //АПУ №{} сработал
                            Messenger.Send(3);
                        }
                        if (Output.Triggers[I].Triggered && !Input.Triggers[I].Triggered)
                        {
                            //АПУ №{} в норме
                            Messenger.Send(4);
                        }
                    }
                    Output.Triggers[I].Triggered = Input.Triggers[I].Triggered;
                }
                if (Output.Triggers[I].Triggered)
                {
                    Output.AnyOfTriggersIsTriggered = true;
                }
            }
            if (Input.InRem)
            {
                Output.AnyOfTriggersIsTriggered = false;
            }
        }
    }
}
