﻿using System.Collections.Generic;
using System.Linq;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Runtime;
using TarFoundation.St;
using TarReferenceSource.Common;
using TarReferenceSource.Common.Timer;
using TarReferenceSource.CommonNa;
using TarReferenceSource.Ktpr;
using TarReferenceSource.Ktpra;
using TarReferenceSource.Shoulder;
using TarReferenceSource.Uzd;

namespace TarReferenceSource.LocalStorages
{
    /// <summary>
    /// 
    /// </summary>
    internal class AvrInGroupState
    {
        /// <summary>
        /// 
        /// </summary>
        public int Rez_Index;
        /// <summary>
        /// Количество НА в состоянии основной 
        /// </summary>
        public int OSN_COUNT;
    }
    /// <summary>
    /// 
    /// </summary>
    internal class AvrForAgrState
    {
        /// <summary>
        /// Флаг задержки на остановку
        /// </summary>
        public bool DelayedStop;
        /// <summary>
        /// 
        /// </summary>
        public ushort AVR_STEP;
        
    }
    /// <summary>
    /// 
    /// </summary>
    public class AvrTimers
    {
        public ITimer T01;
        public ITimer T02;
    }
    /// <summary>
    /// Состояние перехода
    /// </summary>
    internal class TransitionState
    {
        /// <summary>
        /// 
        /// </summary>
        public ushort ProcessStep;
    }
    /// <summary>
    /// Структура остановки НА в плече
    /// </summary>
    internal class ShoulderStopState
    {
        /// <summary>
        /// Текущая команда
        /// </summary>
        public ShoulderStopCmd CurrentCmd
        {
            get => _currentCmd;
            set => value.CopyTo(_currentCmd);
        }

        //public NaStopType NsAutoStopMethod;
        //public NsStopType NsAutoStop;
        /// <summary>
        /// Тип остановки станции
        /// </summary>
        public NsStopType StopShoulderTask;
        /// <summary>
        /// 
        /// </summary>
        public ushort StopStationSubTask;
        /// <summary>
        /// 
        /// </summary>
        public bool[] OffShoulderMap = new bool[10];
        /// <summary>
        /// 
        /// </summary>
        public int NextForOffe;
        /// <summary>
        /// 
        /// </summary>
        public int StopCount;
        /// <summary>
        /// 
        /// </summary>
        public bool ChangedShoulderStopMetod;
        /// <summary>
        /// 
        /// </summary>
        public bool ChangedSubShoulderStopMetod;
        /// <summary>
        /// 
        /// </summary>
        private readonly ShoulderStopCmd _currentCmd = new ShoulderStopCmd();
    }
    /// <summary>
    /// 
    /// </summary>
    public class ShoulderTimers
    {
        public ITimer T01;
        public ITimer T02;
        public ITimer T03;
    }
    /// <summary>
    /// Структура остановки НА в подплече
    /// </summary>
    internal class SubshoulderStopState
    {
        /// <summary>
        /// Текущая команда
        /// </summary>
        public ShoulderStopCmd CurrentCmd
        {
            get => _currentCmd;
            set => value.CopyTo(_currentCmd);
        }
        /// <summary>
        /// Тип остановки станции
        /// </summary>
        public NsStopType StopSubShoulderTask;
        /// <summary>
        /// 
        /// </summary>
        public bool[] OffSubShoulderMap = new bool[10];
        /// <summary>
        /// 
        /// </summary>
        private readonly ShoulderStopCmd _currentCmd = new ShoulderStopCmd();
    }

    public class Krmpn : KrmpnIo
    {
        /// <summary>
        /// 
        /// </summary>
        private StArray<ShoulderTimers> ShoulderTimers;
        /// <summary>
        /// 
        /// </summary>
        private StArray<AvrTimers> AvrTimers;
        /// <summary>
        /// 
        /// </summary>
        private StArray<AvrInGroupState> AvrInGroup;
        /// <summary>
        /// 
        /// </summary>
        private StArray<AvrForAgrState> AvrForAgr;
        /// <summary>
        /// 
        /// </summary>
        private TransitionState Transition = new TransitionState();
        /// <summary>
        /// 
        /// </summary>
        private StArray<bool> RestrictAvrPrev;
        /// <summary>
        /// 
        /// </summary>
        private StArray<ShoulderStopState> StopNS;
        /// <summary>
        /// 
        /// </summary>
        private StArray<SubshoulderStopState> StopSubshoulders;

        
        /// <summary>
        /// Максимальное число плеч станции
        /// </summary>
        private int MAX_SHOULDER_COUNT => shoulders.Count;
        /// <summary>
        /// Максимальное количество НА в плече
        /// </summary>
        private int MAX_UMPNA_IN_SHOULDER => NA.Count;
        /// <summary>
        /// Максимальное количество подплеч станции
        /// </summary>
        private int MAX_SUBSHOULDER_COUNT => subshoulders.Count;

        public Krmpn(NaIo[] na, KtpraResult[] ktpraResults, ShoulderIo[] shoulders, SubshoulderIo[] subshoulders) : base(na, ktpraResults, shoulders, subshoulders)
        {
            RestrictAvrPrev = new StArray<bool>(1, new bool[NA.Count]);
            AvrForAgr = new StArray<AvrForAgrState>(1, Enumerable.Range(1, NA.Count).Select(i => new AvrForAgrState()).ToArray());
            StopNS = new StArray<ShoulderStopState>(1, Enumerable.Range(1, this.shoulders.Count).Select(i => new ShoulderStopState()).ToArray());
            AvrInGroup = new StArray<AvrInGroupState>(1, Enumerable.Range(1, this.shoulders.Count).Select(i => new AvrInGroupState()).ToArray());
            StopSubshoulders = new StArray<SubshoulderStopState>(1, Enumerable.Range(1, this.subshoulders.Count).Select(i => new SubshoulderStopState()).ToArray());
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));


            ShoulderTimers = new StArray<ShoulderTimers>(1, Enumerable.Range(1, this.shoulders.Count).Select(i => new ShoulderTimers
            {
                T01 = new CpaLocalTimer(),
                T02 = new CpaLocalTimer(),
                T03 = new CpaLocalTimer(),
            }).ToArray());

            ShouldersTimers = new StArray<ShoulderPublicTimers>(1, ShoulderTimers.ToList().Select(x => new ShoulderPublicTimers(new List<ITimeTraveler> { x.T01, x.T02, x.T03 })).ToArray());

            AvrTimers = new StArray<AvrTimers>(1, Enumerable.Range(1, this.NA.Count).Select(i => new AvrTimers
            {
                T01 = new CpaLocalTimer(),
                T02 = new CpaLocalTimer(),
            }).ToArray());

            AvrsTimers = new StArray<AvrPublicTimers>(1, AvrTimers.ToList().Select(x => new AvrPublicTimers(new List<ITimeTraveler> { x.T01, x.T02 })).ToArray());
        }
        public override void Execute()
        {
            //Добавить в ТПР
            var TellMsgBefore = false;
            var TellMsgFirstOff = false;
            var CheckTransitionConditions = false;


            for (int i = 1; i <= MAX_UMPNA_IN_SHOULDER; i++)
            {
                Commands[i].StopType = NaStopType.None;
                Commands[i].StartAuto = false;
                Commands[i].SetOsnAuto = false;
                Commands[i].StartRez = false;
            }

            /******************   Алгоритм автоматизированного перехода с МНА на МНА *******************/

            var flTmp = false;
            if (MNA_FROM > 0)
            {
                Messenger.Send(28/*, MNA_FROM*/); ///28   . Команда - назначить на отключение при переходе МНА № PRM_U
                flTmp = true;
                if (Transition.ProcessStep != 0)
                {
                    Messenger.Send(27); ///ВЫПОЛНЕНИЕ НЕВОЗМОЖНО- ИДЕТ ПРОЦЕСС ПЕРЕХОДА (27)
                    flTmp = false;
                }
            }


            /*1*/
            if (MNA_TO > 0)
            {
                Messenger.Send(29/*, MNA_TO*/); ///29 . Команда - назначить на запуск при переходе МНА № PRM_U
                flTmp = true;
                if (Transition.ProcessStep != 0)
                {
                    Messenger.Send(27); ///ВЫПОЛНЕНИЕ НЕВОЗМОЖНО- ИДЕТ ПРОЦЕСС ПЕРЕХОДА (27)
                    flTmp = false;
                }
            }



            if (flTmp)
            {
                if (MNA_FROM > 0)
                {
                    MNA_TO_MNA.MNA_FROM = MNA_FROM;
                    Messenger.Send(30/*, MNA_FROM*/); ///30   . На отключение при переходе назначен МНА №
                }

                if (MNA_TO > 0)
                {
                    MNA_TO_MNA.MNA_TO = MNA_TO;
                    Messenger.Send(31/*, MNA_TO*/); ///31 .  На запуск при переходе назначен МНА №{X}
                }

                /*3*/
                if (MNA_TO_MNA.MNA_TO > 0 && MNA_TO_MNA.MNA_FROM > 0 && MNA_TO_MNA.MNA_TO != MNA_TO_MNA.MNA_FROM)
                {
                    if (NA[MNA_TO_MNA.MNA_FROM].WheelSize < NA[MNA_TO_MNA.MNA_TO].WheelSize)
                    {
                        Messenger.Send(33);
                        MNA_TO_MNA.FromSmallToBig = true;
                    }
                    else if (NA[MNA_TO_MNA.MNA_FROM].WheelSize > NA[MNA_TO_MNA.MNA_TO].WheelSize)
                    {
                        Messenger.Send(32);
                        MNA_TO_MNA.FromSmallToBig = false;
                    }
                    else
                    {
                        Messenger.Send(34);
                        MNA_TO_MNA.FromSmallToBig = false;
                    }
                }
            }

            var transitionCmd = false;
            if (CMD == 1)
            {
                Messenger.Send(0); ///Команда выполнить переход с МНА на МНА;
                transitionCmd = true;
            }

            if (CMD == 2 && Transition.ProcessStep == 0)
            {
                /*ОТМЕНА ПЕРЕХОДА*/
                Messenger.Send(41); /// Окно управления переходм с МНА на МНА закрыто. Сброс настроек перехода
                MNA_TO_MNA.MNA_FROM = 0;
                MNA_TO_MNA.MNA_TO = 0;
            }

            /*4*/
            if (MNA_TO_MNA.MNA_FROM > 0 && MNA_TO_MNA.MNA_TO > 0)
            {

                MNA_TO_MNA.MNA_FROM_IsON = NA[MNA_TO_MNA.MNA_FROM].MainStateOut == NaState.Vkl;
                MNA_TO_MNA.MNA_FROM_IsOSN = NA[MNA_TO_MNA.MNA_FROM].ModeOut == NaMode.Osn;
                MNA_TO_MNA.MNA_FROM_IsNotIMIT = !NA[MNA_TO_MNA.MNA_FROM].IsImitOut;

                MNA_TO_MNA.MNA_TO_IsOFF = NA[MNA_TO_MNA.MNA_TO].MainStateOut == NaState.Otkl;
                MNA_TO_MNA.MNA_TO_IsOSN = NA[MNA_TO_MNA.MNA_TO].ModeOut == NaMode.Osn;
                MNA_TO_MNA.MNA_TO_IsNotIMIT = !NA[MNA_TO_MNA.MNA_TO].IsImitOut;
                MNA_TO_MNA.MNA_TO_IsP1 = NA[MNA_TO_MNA.MNA_TO].ProgOut == NaProg.P1;

                MNA_TO_MNA.MNA_TO_IsZDOpened = NA[MNA_TO_MNA.MNA_TO].ZvState == ZdState.Opened && NA[MNA_TO_MNA.MNA_TO].ZpState == ZdState.Opened;
                MNA_TO_MNA.MNA_TO_IsZDNotIMIT = !(NA[MNA_TO_MNA.MNA_TO].ZpStateIsImit || NA[MNA_TO_MNA.MNA_TO].ZvStateIsImit);

                //в тпр не так
                MNA_TO_MNA.MNA_TO_GP = NA[MNA_TO_MNA.MNA_TO].ReadyToStart;
                //MNA_TO_MNA.MNA_TO_GP          = KGMPNA_Result[MNA_TO_MNA.MNA_TO].P;

                if (IsNPSModePsl && MNA_TO_MNA.FromSmallToBig)
                {
                    MNA_TO_MNA.Pressure_Ready = IsPressureReady;
                }
                else
                {
                    MNA_TO_MNA.Pressure_Ready = true;
                }

                if (NA[MNA_TO_MNA.MNA_TO].IsImitOut && NA[MNA_TO_MNA.MNA_FROM].IsImitOut)
                {
                    //в тпр есть еще
                    MNA_TO_MNA.MNA_FROM_IsNotIMIT = true;
                    MNA_TO_MNA.MNA_TO_IsNotIMIT = true;
                }

                /*6*/
                MNA_TO_MNA.MNA_TO_InOneShoulder = (NA[MNA_TO_MNA.MNA_FROM].Shoulder == NA[MNA_TO_MNA.MNA_TO].Shoulder);

                var READY_TO_STOP = (MNA_TO_MNA.MNA_FROM_IsON && MNA_TO_MNA.MNA_FROM_IsOSN && MNA_TO_MNA.MNA_FROM_IsNotIMIT);

                var READY_TO_START = (MNA_TO_MNA.MNA_TO_IsOFF && MNA_TO_MNA.MNA_TO_IsOSN && MNA_TO_MNA.MNA_TO_IsNotIMIT && MNA_TO_MNA.MNA_TO_IsP1 && MNA_TO_MNA.MNA_TO_IsZDOpened && MNA_TO_MNA.MNA_TO_IsZDNotIMIT && MNA_TO_MNA.MNA_TO_GP && MNA_TO_MNA.MNA_TO_InOneShoulder && MNA_TO_MNA.Pressure_Ready);

                MNA_TO_MNA.MNA_TO_LIST3 = KtpraResults[MNA_TO_MNA.MNA_TO].P; //Агрегатная защита KtpraResults[i].P
                MNA_TO_MNA.MNA_FROM_LIST3 = KtpraResults[MNA_TO_MNA.MNA_FROM].P;
                MNA_TO_MNA.MNA_TO_LIST2 = shoulders[NA[MNA_TO_MNA.MNA_FROM].Shoulder].AutoCmd.P; //Станционная защита KTPR_RESULT.P для плеча/группы МНА

                var TransitionErrFirst = MNA_TO_MNA.MNA_TO_LIST3;

                var TransitionErr = (NA[MNA_TO_MNA.MNA_FROM].StopErrOut || NA[MNA_TO_MNA.MNA_TO].StartErrOut || /*NA[MNA_TO_MNA.MNA_TO].StartErr2Out || NA[MNA_TO_MNA.MNA_TO].StartErr3Out ||*/ MNA_TO_MNA.MNA_TO_LIST3 || MNA_TO_MNA.MNA_TO_LIST2);

                if (transitionCmd)
                {
                    if (Transition.ProcessStep != 0)
                    {
                        Messenger.Send(27); ///ВЫПОЛНЕНИЕ НЕВОЗМОЖНО- ИДЕТ ПРОЦЕСС ПЕРЕХОДА (27)
                    }
                    else
                    {
                        Transition.ProcessStep = 1; /*Устранено . Изменения от 14.10.2016*/
                        Messenger.Send(1/*, MNA_TO_MNA.MNA_FROM*/); ///11 .  Отключаемый МНА №
                        Messenger.Send(2/*, MNA_TO_MNA.MNA_TO*/); ///12   .Запускаемый МНА №
                    }
                }

                /*8*/
                switch (Transition.ProcessStep)
                {
                    case 0:
                        if (!MNA_TO_MNA.Ready && (READY_TO_START && READY_TO_STOP && MNA_TO_MNA.Pressure_Ready))
                        {
                            Messenger.Send(16); ///Готовность к переходу с МНА на МНА установлена)
                        }
                        else if (MNA_TO_MNA.Ready && !(READY_TO_START && READY_TO_STOP && MNA_TO_MNA.Pressure_Ready))
                        {
                            Messenger.Send(25); ///Готовность к переходу с МНА на МНА снята
                            TellMsgBefore = true;
                            TellMsgFirstOff = true;
                        }

                        break;
                    case 1:
                        if (!(READY_TO_START && READY_TO_STOP && MNA_TO_MNA.Pressure_Ready) || TransitionErrFirst)
                        {
                            TellMsgBefore = true;
                            TellMsgFirstOff = true;
                            CheckTransitionConditions = true;
                            Transition.ProcessStep = 32;
                        }
                        else
                        {
                            Transition.ProcessStep = 10;
                        }

                        break;
                    case 10:
                        //добавить ограничивающий таймер

                        if (TransitionErr)
                        {
                            CheckTransitionConditions = true;
                            Transition.ProcessStep = 31;
                        }
                        else
                        {
                            Commands[MNA_TO_MNA.MNA_FROM].StopType = NaStopType.StopAuto;
                            if (!(READY_TO_START))
                            {
                                Messenger.Send(14); //Во время выполнения процедуры перехода потеряна готовность к переходу
                                TellMsgFirstOff = true;
                                Transition.ProcessStep = 31;
                            }
                            else
                            {
                                var flCanStartOnTran = NA[MNA_TO_MNA.MNA_FROM].MainStateOut == NaState.Otkl || !NA[MNA_TO_MNA.MNA_FROM].WaitForStop;
                                if (flCanStartOnTran)
                                {
                                    Transition.ProcessStep = 20;
                                }
                            }
                        } /*10*/

                        break;
                    case 20:
                        if (TransitionErr)
                        {
                            CheckTransitionConditions = true;
                            Transition.ProcessStep = 31;
                        }
                        else if (NA[MNA_TO_MNA.MNA_TO].MainStateOut == NaState.Vkl)
                        {
                            Transition.ProcessStep = 30;
                        }
                        else if (NA[MNA_TO_MNA.MNA_TO].MainStateOut == NaState.Ostanov)
                        {
                            Transition.ProcessStep = 31; //16.01.2018  //09.02.2018 И в крмпн на 20 шаге перехода в ТПР MainState_TO == 4 (строка 193)
                        }
                        else if (READY_TO_START || NA[MNA_TO_MNA.MNA_TO].MainStateOut == NaState.Pusk || NA[MNA_TO_MNA.MNA_FROM].MainStateOut != NaState.Otkl)
                        {
                            Commands[MNA_TO_MNA.MNA_TO].StartAuto = true;
                        }
                        else
                        {
                            Transition.ProcessStep = 31;
                        }

                        break;
                    case 30:
                        Messenger.Send(22); //Переход с МНА на МНА завершен
                        Transition.ProcessStep = 0;
                        MNA_TO_MNA.MNA_FROM = 0;
                        MNA_TO_MNA.MNA_TO = 0;

                        break;
                    case 31:
                        Messenger.Send(26); //Процесс перехода с МНА на МНА отменен
                        Transition.ProcessStep = 0;
                        MNA_TO_MNA.MNA_FROM = 0;
                        MNA_TO_MNA.MNA_TO = 0;
                        break;
                    case 32:
                        Messenger.Send(15); //Отсутствует готовность к переходу с МНА на МНА
                        Transition.ProcessStep = 0;
                        MNA_TO_MNA.MNA_FROM = 0;
                        MNA_TO_MNA.MNA_TO = 0;
                        break;
                }






                /*11*/
                if (TellMsgBefore)
                {
                    if (!MNA_TO_MNA.MNA_FROM_IsON)
                    {
                        Messenger.Send(3); //Отключаемый МНА не включен            
                    }

                    if (!MNA_TO_MNA.MNA_FROM_IsOSN)
                    {
                        Messenger.Send(4); // У отключаемого МНА не установлен режим осн
                    }

                    if (!MNA_TO_MNA.MNA_FROM_IsNotIMIT)
                    {
                        Messenger.Send(5); //Отключаемый МНА в имитации
                    }

                    TellMsgBefore = false;
                }

                if (TellMsgFirstOff)
                {
                    if (!MNA_TO_MNA.MNA_TO_IsOFF)
                    {
                        Messenger.Send(6); //. Запускаемый МНА не отключен
                    }

                    if (!MNA_TO_MNA.MNA_TO_GP)
                    {
                        Messenger.Send(12); //  Запускаемый МНА не готов к пуску
                    }

                    if (!MNA_TO_MNA.MNA_TO_IsOSN)
                    {
                        Messenger.Send(7); //  У запускаемого МНА не установлен режим осн
                    }

                    if (!MNA_TO_MNA.MNA_TO_IsNotIMIT)
                    {
                        Messenger.Send(8); // Запускаемый МНА в имитации
                    }

                    /*13*/
                    if (!MNA_TO_MNA.MNA_TO_IsP1)
                    {
                        Messenger.Send(9); //  У запускаемого МНА не установлена п1
                    }

                    if (!MNA_TO_MNA.MNA_TO_IsZDOpened)
                    {
                        Messenger.Send(10); //  У запускаемого МНА не открыты агрегатные задвижки
                    }

                    if (!MNA_TO_MNA.MNA_TO_IsZDNotIMIT)
                    {
                        Messenger.Send(11); // У запускаемого МНА установлена имитация агрегатных задвижек
                    }

                    if (!MNA_TO_MNA.MNA_TO_InOneShoulder)
                    {
                        Messenger.Send(13); // Запускаемый и отключаемый МНА не в одном плече
                    }

                    if (!MNA_TO_MNA.Pressure_Ready)
                    {
                        /*Устранено . Изменения от 14.10.2016*/
                        Messenger.Send(35); // Отсутствует зазор давления на выходе мнс
                    }

                    TellMsgFirstOff = false;
                }

                MNA_TO_MNA.Ready = READY_TO_START && READY_TO_STOP && MNA_TO_MNA.Pressure_Ready;

                /*14*/
                if (CheckTransitionConditions)
                {
                    if (NA[MNA_TO_MNA.MNA_FROM].StopErrOut)
                    {
                        Messenger.Send(17); // Отключаемый МНА не отключился
                    }

                    if (NA[MNA_TO_MNA.MNA_TO].StartErrOut /*|| NA[MNA_TO_MNA.MNA_TO].StartErr2Out || NA[MNA_TO_MNA.MNA_TO].StartErr3Out*/)
                    {
                        Messenger.Send(18); // Запускаемый МНА не включился
                    }

                    if (MNA_TO_MNA.MNA_FROM_LIST3)
                    {
                        Messenger.Send(19); // На МНА назначенном на отключение Наличие агрегатной защиты
                    }

                    if (MNA_TO_MNA.MNA_TO_LIST3)
                    {
                        Messenger.Send(20); // На МНА назначенном на запуск Наличие агрегатной защиты
                    }

                    if (MNA_TO_MNA.MNA_TO_LIST2)
                    {
                        Messenger.Send(21); // Во время процедуры перехода с МНА на МНА сработала общестанционная защита
                    }

                    CheckTransitionConditions = false;
                }
            }
            else
            {
                if (MNA_TO_MNA.MNA_TO == 0 && transitionCmd)
                {
                    Messenger.Send(55);//ВЫПОЛНЕНИЕ НЕВОЗМОЖНО. НЕ ВЫБРАН ЗАПУСКАЕМЫЙ МНА
                }

                if (MNA_TO_MNA.MNA_FROM == 0 && transitionCmd)
                {
                    Messenger.Send(54);//ВЫПОЛНЕНИЕ НЕВОЗМОЖНО. НЕ ВЫБРАН ОТКЛЮЧАЕМЫЙ МНА
                }
                MNA_TO_MNA.FromSmallToBig = false;
                MNA_TO_MNA.MNA_FROM_IsON = false;
                MNA_TO_MNA.MNA_FROM_IsOSN = false;
                MNA_TO_MNA.MNA_FROM_IsNotIMIT = false;
                MNA_TO_MNA.MNA_TO_IsOFF = false;
                MNA_TO_MNA.MNA_TO_IsOSN = false;
                MNA_TO_MNA.MNA_TO_IsNotIMIT = false;
                MNA_TO_MNA.MNA_TO_IsP1 = false;
                MNA_TO_MNA.MNA_TO_IsZDOpened = false;
                MNA_TO_MNA.MNA_TO_IsZDNotIMIT = false;
                MNA_TO_MNA.MNA_TO_GP = false;
                MNA_TO_MNA.MNA_FROM_LIST3 = false;
                MNA_TO_MNA.MNA_TO_LIST3 = false;
                MNA_TO_MNA.MNA_TO_LIST2 = false;
                MNA_TO_MNA.Ready = false;
                MNA_TO_MNA.Pressure_Ready = false;
                MNA_TO_MNA.MNA_TO_InOneShoulder = false;
            }
            /**END Алгоритм автоматизированного перехода с МНА на МНА **/


            /********************************************************/
            /****Алгоритм назначения резерва***/
            /*15*/
            for (int SHOULDER = 1; SHOULDER <= MAX_SHOULDER_COUNT; SHOULDER++)
            {
                AvrInGroup[SHOULDER].Rez_Index = 0;
                AvrInGroup[SHOULDER].OSN_COUNT = 0;
                for (int INDEX = 1; INDEX <= MAX_UMPNA_IN_SHOULDER; INDEX++)
                {
                    if (NA[INDEX].Shoulder == SHOULDER)
                    {
                        if (NA[INDEX].ModeOut == NaMode.Osn || NA[INDEX].ModeOut == NaMode.Tm)
                        {
                            AvrInGroup[SHOULDER].OSN_COUNT = AvrInGroup[SHOULDER].OSN_COUNT + 1;
                        }

                        if (NA[INDEX].ModeOut == NaMode.Rez)
                        {
                            if (AvrInGroup[SHOULDER].Rez_Index != 0)
                            {
                                Commands[INDEX].SetOsnAuto = true;
                                Commands[AvrInGroup[SHOULDER].Rez_Index].SetOsnAuto = true;
                            }
                            else
                            {
                                AvrInGroup[SHOULDER].Rez_Index = INDEX;
                            }
                        }
                    }
                }
            }



            /*16*/
            var NAOnCount = 0; //>>в ТПР NAOnCount и NAOffCount 16.01.2018
            var NAOffCount = 0;

            for (int INDEX = 1; INDEX <= MAX_UMPNA_IN_SHOULDER; INDEX++)
            {

                //сделать также в ТПР
                if (NA[INDEX].MainStateOut == NaState.Vkl)
                {
                    NAOnCount = NAOnCount + 1;
                }

                if (NA[INDEX].MainStateOut == NaState.Otkl)
                {
                    NAOffCount = NAOffCount + 1;
                }

                Commands[INDEX].NoOsnForRes = false;
                Commands[INDEX].RezExist = false;
                Commands[INDEX].DoRez = false;
                var SHOULDER = NA[INDEX].Shoulder;
                if (SHOULDER == 0)
                {
                    continue;
                }

                var OsnExist = (AvrInGroup[SHOULDER].OSN_COUNT == 1 && !(NA[INDEX].ModeOut == NaMode.Osn || NA[INDEX].ModeOut == NaMode.Tm)) || AvrInGroup[SHOULDER].OSN_COUNT > 1;
                if (AvrInGroup[SHOULDER].Rez_Index == 0)
                {
                    if (OsnExist)
                    {
                        Commands[INDEX].DoRez = true;
                    }
                }
                else
                {
                    Commands[INDEX].RezExist = true;
                }

                Commands[INDEX].NoOsnForRes = !OsnExist;

                if (KtpraResults[INDEX].P)
                {
                    if (Commands[INDEX].StopType < KtpraResults[INDEX].StopType)
                    {
                        Commands[INDEX].StopType = KtpraResults[INDEX].StopType;
                    }
                }
                else
                {
                    if (Transition.ProcessStep == 0)
                    {
                        Commands[INDEX].StopType = NaStopType.None;
                    }
                }

                AvrForAgr[INDEX].DelayedStop = Commands[INDEX].StopType == NaStopType.ElectricStop || Commands[INDEX].StopType == NaStopType.ChRPAlarmStop;
                var flExternalStopped = AvrForAgr[INDEX].DelayedStop && (NA[INDEX].StopNoCmdOut == StopNoCmdState.Phase1) && (NA[INDEX].MainStateOut == NaState.Otkl || NA[INDEX].MainStateOut == NaState.Ostanov);
                var flAllowAVR = AvrForAgr[INDEX].AVR_STEP == 0 && KtpraResults[INDEX].Avr && !shoulders[SHOULDER].AutoCmd.P && !subshoulders[SHOULDER].AutoCmd.P;

                /*18*/
                if (NA[INDEX].ModeOut != NaMode.Rem)
                {
                    if (NA[INDEX].MainStateOut == NaState.Vkl || NA[INDEX].MainStateOut == NaState.Pusk || flExternalStopped)
                    {
                        if ((KtpraResults[INDEX].P))
                        {
                            if (flAllowAVR)
                            {
                                if (NA[INDEX].RestrictAvr && !RestrictAvrPrev[INDEX])
                                {
                                    Messenger.Send(46); // Запрет АВР
                                    RestrictAvrPrev[INDEX] = true;
                                }
                                else if (!NA[INDEX].RestrictAvr)
                                {
                                    AvrForAgr[INDEX].AVR_STEP = 1;
                                }
                            }
                        }
                    }
                }

                if (!KtpraResults[INDEX].P)
                {
                    RestrictAvrPrev[INDEX] = false;
                }
            } /* Алгоритм назначения резерва. Окончание.*/

            /****Алгоритм АВР. Начало***/
            /*19*/
            /***************************************************/
            var ProcessingAvr = false;
            for (int I = 1; I <= MAX_UMPNA_IN_SHOULDER; I++)
            {
                var SHOULDER = NA[I].Shoulder;
                if ((!KtpraResults[I].Avr || shoulders[SHOULDER].AutoCmd.P) && AvrForAgr[I].AVR_STEP != 0)
                {
                    /*06.03.2017 Замечание от ИЦ 4*/
                    AvrForAgr[I].AVR_STEP = 35; /*Отмена АВР*/
                }

                if (AvrForAgr[I].AVR_STEP == 1)
                {
                    /*Необходимость АВР с ожиданием остановки*/
                    Messenger.Send(36); // Необходимость АВР
                    AvrForAgr[I].AVR_STEP = 10;
                    //NA[i].WaitForStop:= true ;
                    AvrTimers[I].T01.Start(); /*T.I.01 Запусить -время на ожидании остановки агрегата при выполнении АВР для группы агрегатов*/
                }

                if (AvrForAgr[I].AVR_STEP == 10)
                {
                    /*Проверка отключенности*/
                    if (NA[I].MainStateOut == NaState.Otkl || (!NA[I].WaitForStop && !AvrForAgr[I].DelayedStop))
                    {
                        /*АГрегат остановлен или нет флага необходимости остановки АГРЕГАТА для ПНА*/
                        AvrTimers[I].T01.Stop(); /*T.I.01 Остановить*/
                        AvrForAgr[I].AVR_STEP = 13;
                    }
                    else if (NA[I].MainStateOut == NaState.Ostanov && (AvrForAgr[I].DelayedStop && !NA[I].WaitForStop))
                    {
                        AvrTimers[I].T01.Stop(); /*T.I.01 Остановить*/
                        AvrForAgr[I].AVR_STEP = 13;
                    }
                    else if (AvrTimers[I].T01.IsQ)
                    {
                        /*T.I.01 Сработал*/
                        Messenger.Send(40); // АГрегат не отключился за заданное время
                        AvrForAgr[I].AVR_STEP = 35;
                    }
                }

                /*20*/
                if (AvrForAgr[I].AVR_STEP == 13)
                {
                    /*Проверка наличия резерва*/
                    if (AvrInGroup[SHOULDER].Rez_Index != 0 && I != AvrInGroup[SHOULDER].Rez_Index)
                    {
                        AvrForAgr[I].AVR_STEP = 16;
                    }
                    else
                    {
                        Messenger.Send(24); // Нет МНА в РЕЗЕРВе
                        AvrForAgr[I].AVR_STEP = 35;
                    }
                }

                if (AvrForAgr[I].AVR_STEP == 16)
                {
                    /*Проверка горячего резерва*/
                    if (AvrInGroup[SHOULDER].Rez_Index == 0)
                    {
                        Messenger.Send(24); // Нет МНА в РЕЗЕРВе
                        AvrForAgr[I].AVR_STEP = 35;
                    }
                    else if (NA[AvrInGroup[SHOULDER].Rez_Index].SubstateOut == NaSubstate.HotRez)
                    {
                        /*Проверяем горячий резерв*/
                        AvrTimers[I].T02.Stop(); /*T.I.02 Остановить*/
                        AvrForAgr[I].AVR_STEP = 20;
                    }
                    else
                    {
                        if (AvrTimers[I].T02.IsQ)
                        {
                            /*T.I.02 Сработал Не появился за вермя */
                            Messenger.Send(23); // Нет МНА в горячем РЕЗЕРВе
                            AvrForAgr[I].AVR_STEP = 35;
                        }
                        else
                        {
                            if (!AvrTimers[I].T02.IsStarted)
                            {
                                /*T.I.02 НЕ Запущен */
                                Messenger.Send(37); // Начало процедуры отложенного АВР
                                AvrTimers[I].T02.Start(); /*T.I.02 Запусить*/
                            }
                        }
                    }
                }

                /*21*/
                if (AvrForAgr[I].AVR_STEP == 20)
                {
                    /*Команда на запуск*/
                    if (NA[AvrInGroup[SHOULDER].Rez_Index].IsImitOut == NA[I].IsImitOut /**IsImitOut*/)
                    {
                        Commands[AvrInGroup[SHOULDER].Rez_Index].StartRez = true;
                        AvrForAgr[I].AVR_STEP = 0;
                    }
                    else
                    {
                        //ошибка ветвления в БС
                        if (NA[AvrInGroup[SHOULDER].Rez_Index].IsImitOut)
                        {
                            Messenger.Send(39); // МНА в РЕЗЕРВе в режиме ИМИТАЦИИ
                            AvrForAgr[I].AVR_STEP = 35;
                        }

                        if (NA[I].IsImitOut /**IsImitOut*/)
                        {
                            AvrForAgr[I].AVR_STEP = 35;
                        }
                    }
                }

                if (AvrForAgr[I].AVR_STEP == 35)
                {
                    AvrForAgr[I].AVR_STEP = 0;
                    Messenger.Send(38); // АВР отменен
                }

                ProcessingAvr = ProcessingAvr || AvrForAgr[I].AVR_STEP != 0;
            } /*Алгоритм АВР. Окончание*/

            IsMNSOn = (NAOnCount > 0) || (Transition.ProcessStep >= 10 && Transition.ProcessStep <= 30) || ProcessingAvr;
            IsMNSOff = (NAOffCount == MAX_UMPNA_IN_SHOULDER) && !(Transition.ProcessStep >= 10 && Transition.ProcessStep <= 30) && !ProcessingAvr; //>>а тут уже выставляются IsMNSOn и IsMNSOff по NAOnCount и NAOffCount 16.01.2018
            //TODO: тут можно сразу учесть процессы по АВР и переходам

            /*22.3*/
            flTmp = false;
            for (int I = 1; I <= MAX_SHOULDER_COUNT; I++)
            {

                StopNS[I].NextForOffe = 0;
                for (int J = 1; J <= MAX_UMPNA_IN_SHOULDER; J++)
                {
                    if (NA[J].Shoulder == I)
                    {
                        if (!StopNS[I].OffShoulderMap[J] && (NA[J].MainStateOut == NaState.Vkl || NA[J].MainStateOut == NaState.Pusk))
                        {
                            // >> в тпр не так- исправлено 22.01. 2018
                            StopNS[I].NextForOffe = J;
                            break;
                        }
                    }
                    else
                    {
                        StopNS[I].OffShoulderMap[J] = false;
                    }
                }

                /*-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
                if (!StopNS[I].ChangedShoulderStopMetod)
                {
                    StopNS[I].ChangedShoulderStopMetod =
                        (shoulders[I].AutoCmd.StopNsCmd < StopNS[I].CurrentCmd.StopNsCmd && shoulders[I].AutoCmd.P)
                        || (shoulders[I].Cmd.StopNsCmd < StopNS[I].CurrentCmd.StopNsCmd && shoulders[I].Cmd.P);
                    if (StopNS[I].ChangedShoulderStopMetod)//если пришла более приоритетная защита
                    {
                        //прекращаем остановку станции
                        ShoulderTimers[I].T01.Stop();
                        ShoulderTimers[I].T02.Stop();
                        ShoulderTimers[I].T03.Stop();
                        StopNS[I].StopShoulderTask = NsStopType.None;
                        StopNS[I].StopStationSubTask = 0;
                        StopNS[I].StopCount = 0;
                        StopNS[I].CurrentCmd.StopNaMethod = NaStopType.None;
                        StopNS[I].CurrentCmd.StopNsCmd = NsStopType.None;
                        StopNS[I].CurrentCmd.P = false;
                        for (int Index = 1; Index <= MAX_UMPNA_IN_SHOULDER; Index++)
                        {
                            StopNS[I].OffShoulderMap[Index] = false;
                        }
                    }
                }

                if (StopNS[I].StopShoulderTask == NsStopType.None)
                {
                    if (shoulders[I].AutoCmd.StopNsCmd == NsStopType.StopAllInShoulder && shoulders[I].AutoCmd.P &&
                        shoulders[I].IsSafety)
                    {
                        if (StopNS[I].CurrentCmd.StopNsCmd != NsStopType.StopAllInShoulder)
                        {
                            Messenger.Send(89 + I); // ОДНОВРЕМЕННАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ В НАПРАВЛЕНИИ I
                        }

                        StopNS[I].StopShoulderTask = NsStopType.StopAllInShoulder;
                        StopNS[I].CurrentCmd = shoulders[I].AutoCmd;
                    }
                    else if (shoulders[I].Cmd.StopNsCmd == NsStopType.StopAllInShoulder && shoulders[I].Cmd.P)
                    {
                        if (StopNS[I].CurrentCmd.StopNsCmd != NsStopType.StopAllInShoulder)
                        {
                            Messenger.Send(114 + I); //команда отключить НА, работающие в направлении I
                        }

                        StopNS[I].StopShoulderTask = NsStopType.StopAllInShoulder;
                        StopNS[I].CurrentCmd = shoulders[I].Cmd;
                    }
                    else if (shoulders[I].AutoCmd.StopNsCmd == NsStopType.StopOneByOneInShoulder &&
                             shoulders[I].AutoCmd.P && shoulders[I].IsSafety)
                    {
                        if (StopNS[I].CurrentCmd.StopNsCmd != NsStopType.StopOneByOneInShoulder)
                        {
                            ///По другом в последовательный останов никогда не зайдем
                            Messenger.Send(99 + I); // ПОСЛЕДОВАТЕЛЬНАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ В НАПРАВЛЕНИИ I
                        }

                        StopNS[I].StopShoulderTask = NsStopType.StopOneByOneInShoulder;
                        StopNS[I].StopStationSubTask = 1;
                        StopNS[I].CurrentCmd = shoulders[I].AutoCmd;
                    }
                    else if (shoulders[I].Cmd.StopNsCmd == NsStopType.StopOneByOneInShoulder && shoulders[I].Cmd.P)
                    {
                        if (StopNS[I].CurrentCmd.StopNsCmd != NsStopType.StopOneByOneInShoulder)
                        {
                            Messenger.Send(114 + I); //команда отключить НА, работающие в направлении I
                        }

                        StopNS[I].StopShoulderTask = NsStopType.StopOneByOneInShoulder;
                        StopNS[I].StopStationSubTask = 1;
                        StopNS[I].CurrentCmd = shoulders[I].Cmd;
                    }
                    else if (shoulders[I].AutoCmd.StopNsCmd == NsStopType.StopOnlyFirstInShoulder &&
                             StopNS[I].StopCount < shoulders[I].OffNaShoulderCount && shoulders[I].AutoCmd.P &&
                             shoulders[I].IsSafety)
                    {
                        if (StopNS[I].CurrentCmd.StopNsCmd != NsStopType.StopOnlyFirstInShoulder)
                        {
                            Messenger.Send(109 + I); // ОСТАНОВКА ПЕРВОГО ПО ПОТОКУА НА, РАБОТАЮЩЕГО В НАПРАВЛЕНИИ I
                        }

                        StopNS[I].StopShoulderTask = NsStopType.StopOnlyFirstInShoulder;
                        StopNS[I].StopStationSubTask = 1;
                        StopNS[I].CurrentCmd = shoulders[I].AutoCmd;
                    }
                    else if (shoulders[I].AutoCmd.StopNsCmd == NsStopType.StopFirstNextInShoulder &&
                             shoulders[I].AutoCmd.P && shoulders[I].IsSafety)
                    {
                        if (StopNS[I].CurrentCmd.StopNsCmd != NsStopType.StopFirstNextInShoulder)
                        {
                            ///По другом в останов следующего никогда не зайдем
                            Messenger.Send(104 + I); // ПОСЛЕДОВАТЕЛЬНАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ В НАПРАВЛЕНИИ I
                        }

                        StopNS[I].StopShoulderTask = NsStopType.StopFirstNextInShoulder;
                        StopNS[I].StopStationSubTask = 1;
                        StopNS[I].CurrentCmd = shoulders[I].AutoCmd;
                    }

                    StopNS[I].ChangedShoulderStopMetod = false;
                }

                switch (StopNS[I].StopShoulderTask)
                {
                    case NsStopType.StopAllInShoulder:
                    {
                        if (shoulders[I].AutoCmd.StopNsCmd == NsStopType.StopAllInShoulder)
                        {
                            StopNS[I].CurrentCmd = shoulders[I].AutoCmd;
                        }
                        for (int Index = 1; Index <= MAX_UMPNA_IN_SHOULDER; Index++)
                        {
                            if (NA[Index].Shoulder == I)
                            {
                                StopNS[I].OffShoulderMap[Index] = true;
                            }
                            else
                            {
                                StopNS[I].OffShoulderMap[Index] = false;
                            }
                        }

                        if (shoulders[I].AutoCmd.P)
                        {
                            ; //StopNS[I].NS_Shoulder = shoulders[I].Cfg;
                        }
                        else if (shoulders[I].Cmd.P)
                        {
                            ; //StopNS[I].NS_Shoulder = ShoulderCmd[I].Cfg;
                        }
                        else
                        {
                            StopNS[I].StopShoulderTask = (NsStopType) 999;
                        }

                        break;
                    }

                    case NsStopType.StopOneByOneInShoulder:
                    {
                        if (shoulders[I].AutoCmd.StopNsCmd == NsStopType.StopOneByOneInShoulder &&
                            shoulders[I].AutoCmd.StopNaMethod > StopNS[I].CurrentCmd.StopNaMethod)
                        {
                            StopNS[I].CurrentCmd = shoulders[I].AutoCmd;
                        }

                        if (shoulders[I].Cmd.StopNsCmd == NsStopType.StopOneByOneInShoulder &&
                            shoulders[I].Cmd.StopNaMethod > StopNS[I].CurrentCmd.StopNaMethod)
                        {
                            StopNS[I].CurrentCmd = shoulders[I].Cmd;
                        }

                        switch (StopNS[I].StopStationSubTask)
                        {

                            case 1:
                                for (int Index = 1; Index <= MAX_UMPNA_IN_SHOULDER; Index++)
                                {
                                    if (NA[Index].Shoulder == I && (NA[Index].MainStateOut == NaState.Otkl || NA[Index].MainStateOut == NaState.Ostanov))
                                    {
                                        StopNS[I].OffShoulderMap[Index] = true;
                                    }
                                }

                                if (StopNS[I].NextForOffe > 0)
                                {
                                    StopNS[I].OffShoulderMap[StopNS[I].NextForOffe] = true;
                                    StopNS[I].StopStationSubTask = 2;
                                    ShoulderTimers[I].T02.Start();
                                }
                                else if (shoulders[I].AutoCmd.P)
                                {
                                    StopNS[I].StopStationSubTask = 1;
                                }
                                else if (shoulders[I].Cmd.P)
                                {
                                    StopNS[I].StopStationSubTask = 1;
                                }
                                else
                                {
                                    StopNS[I].StopShoulderTask = (NsStopType) 999;
                                }

                                break;
                            case 2:
                                if (!ShoulderTimers[I].T02.IsStarted)
                                {
                                    StopNS[I].StopStationSubTask = 1;
                                }

                                if (StopNS[I].NextForOffe == 0 && !shoulders[I].AutoCmd.P && !shoulders[I].Cmd.P)
                                {
                                    StopNS[I].StopShoulderTask = (NsStopType) 999;
                                }

                                break;
                            default:
                            {
                                StopNS[I].StopShoulderTask = (NsStopType) 999;
                                break;
                            }
                        }

                        break;
                    }

                    case NsStopType.StopFirstNextInShoulder: /*StopNext*/
                    {

                        if (shoulders[I].AutoCmd.StopNsCmd == NsStopType.StopFirstNextInShoulder &&
                            shoulders[I].AutoCmd.StopNaMethod > StopNS[I].CurrentCmd.StopNaMethod)
                        {
                            StopNS[I].CurrentCmd = shoulders[I].AutoCmd;
                        }

                        switch (StopNS[I].StopStationSubTask)
                        {
                            case 1:

                                if (StopNS[I].NextForOffe > 0 && shoulders[I].AutoCmd.P)
                                {
                                    StopNS[I].OffShoulderMap[StopNS[I].NextForOffe] = true;
                                    StopNS[I].StopStationSubTask = 2;
                                    ShoulderTimers[I].T01.Start();
                                }
                                else if (shoulders[I].AutoCmd.StopNsCmd == NsStopType.StopFirstNextInShoulder)
                                {
                                    StopNS[I].StopStationSubTask = 1;
                                }
                                else
                                {
                                    StopNS[I].StopShoulderTask = (NsStopType) 999;
                                }

                                break;
                            case 2:
                                if (!ShoulderTimers[I].T01.IsStarted)
                                {
                                    StopNS[I].StopStationSubTask = 1;
                                    if (shoulders[I].AutoCmd.StopNsCmd != NsStopType.StopFirstNextInShoulder)
                                    {
                                        StopNS[I].StopShoulderTask = (NsStopType) 999;
                                    }
                                }

                                if (!shoulders[I].AutoCmd.P)
                                {
                                    StopNS[I].StopShoulderTask = (NsStopType) 999;
                                }

                                break;
                            default:
                            {
                                StopNS[I].StopShoulderTask = (NsStopType) 999;
                                break;
                            }
                        }

                        break;
                    }

                    case NsStopType.StopOnlyFirstInShoulder:

                        switch (StopNS[I].StopStationSubTask)
                        {
                            case 1:
                                StopNS[I].CurrentCmd = shoulders[I].AutoCmd;

                                for (int Index = 1; Index <= MAX_UMPNA_IN_SHOULDER; Index++)
                                {
                                    StopNS[I].OffShoulderMap[Index] = false;
                                }

                                if (StopNS[I].StopCount < shoulders[I].OffNaShoulderCount && StopNS[I].NextForOffe > 0)
                                {
                                    StopNS[I].StopCount = StopNS[I].StopCount + 1;
                                    StopNS[I].OffShoulderMap[StopNS[I].NextForOffe] = true;
                                    StopNS[I].StopStationSubTask = 2;
                                    ShoulderTimers[I].T03.Start();
                                }
                                else if (StopNS[I].StopCount < shoulders[I].OffNaShoulderCount ||
                                         shoulders[I].AutoCmd.P)
                                {
                                    StopNS[I].StopStationSubTask = 1;
                                }
                                else
                                {
                                    StopNS[I].StopShoulderTask = (NsStopType) 999;
                                }

                                break;
                            case 2:
                                if (!ShoulderTimers[I].T03.IsStarted)
                                {
                                    StopNS[I].StopStationSubTask = 1;
                                }

                                break;
                            default:
                            {
                                StopNS[I].StopShoulderTask = (NsStopType) 999;
                                break;
                            }
                        }

                        break;
                    default:
                    {
                        StopNS[I].StopShoulderTask = (NsStopType) 999;
                        break;
                    }
                }

                if (StopNS[I].StopShoulderTask == (NsStopType) 999)
                {
                    ShoulderTimers[I].T01.Stop();
                    ShoulderTimers[I].T02.Stop();
                    ShoulderTimers[I].T03.Stop();
                    StopNS[I].StopShoulderTask = NsStopType.None;
                    StopNS[I].StopStationSubTask = 0;
                    StopNS[I].StopCount = 0;
                    StopNS[I].CurrentCmd.StopNaMethod = NaStopType.None;
                    StopNS[I].CurrentCmd.StopNsCmd = NsStopType.None;
                    StopNS[I].CurrentCmd.P = false;
                    for (int Index = 1; Index <= MAX_UMPNA_IN_SHOULDER; Index++)
                    {
                        StopNS[I].OffShoulderMap[Index] = false;
                    }
                }

                //вешаем команды по защитам в плечах

                if (StopNS[I].StopShoulderTask != NsStopType.None)
                {
                    for (int INDEX = 1; INDEX <= MAX_UMPNA_IN_SHOULDER; INDEX++)
                    {
                        if (StopNS[I].OffShoulderMap[INDEX])
                        {
                            if (Commands[INDEX].StopType < StopNS[I].CurrentCmd.StopNaMethod)
                            {
                                Commands[INDEX].StopType = StopNS[I].CurrentCmd.StopNaMethod;
                            }
                        }
                    }
                }
            }

            /*-----------------------------------------------------------------------------------------------------------------------------------------------------------*/
            for (int I = 1; I <= MAX_SUBSHOULDER_COUNT; I++)
            {
                if (!StopNS[I].ChangedSubShoulderStopMetod)
                {
                    StopNS[I].ChangedSubShoulderStopMetod =
                        subshoulders[I].AutoCmd.StopNsCmd < StopSubshoulders[I].CurrentCmd.StopNsCmd;
                    if (StopNS[I].ChangedSubShoulderStopMetod)
                    {
                        StopSubshoulders[I].StopSubShoulderTask = NsStopType.None;
                    }
                }

                if (StopSubshoulders[I].StopSubShoulderTask == NsStopType.None)
                {

                    if (subshoulders[I].AutoCmd.StopNsCmd == NsStopType.StopAllInSubShoulder &&
                        subshoulders[I].AutoCmd.P && subshoulders[I].IsSafety)
                    {
                        if (StopSubshoulders[I].CurrentCmd.StopNsCmd != NsStopType.StopAllInSubShoulder)
                        {
                            Messenger.Send(94 + I); // ОДНОВРЕМЕННАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ С КОЛЛЕКТОРА Х
                            StopSubshoulders[I].StopSubShoulderTask = NsStopType.StopAllInSubShoulder;
                        }
                    }

                }

                switch (StopSubshoulders[I].StopSubShoulderTask)
                {
                    case NsStopType.StopAllInSubShoulder:
                        StopSubshoulders[I].CurrentCmd = subshoulders[I].AutoCmd;
                        for (int Index = 1; Index <= MAX_UMPNA_IN_SHOULDER; Index++)
                        {
                            if (NA[Index].Subshoulder == I)
                            {
                                StopSubshoulders[I].OffSubShoulderMap[Index] = true;
                            }
                            else
                            {
                                StopSubshoulders[I].OffSubShoulderMap[Index] = false;
                            }
                        }

                        if (subshoulders[I].AutoCmd.P)
                        {
                            ;
                        }
                        else
                        {
                            StopSubshoulders[I].StopSubShoulderTask = (NsStopType) 999;
                        }

                        break;
                    default:
                    {
                        StopSubshoulders[I].StopSubShoulderTask = (NsStopType) 999;
                        break;
                    }

                }

                if (StopSubshoulders[I].StopSubShoulderTask == (NsStopType) 999)
                {
                    StopSubshoulders[I].StopSubShoulderTask = NsStopType.None;
                    StopSubshoulders[I].CurrentCmd.StopNsCmd = NsStopType.None;
                    StopSubshoulders[I].CurrentCmd.StopNaMethod = NaStopType.None;
                    StopSubshoulders[I].CurrentCmd.P = false;
                    for (int Index = 1; Index <= MAX_UMPNA_IN_SHOULDER; Index++)
                    {
                        StopSubshoulders[I].OffSubShoulderMap[Index] = false;
                    }
                }


                if (StopSubshoulders[I].CurrentCmd.StopNsCmd == subshoulders[I].AutoCmd.StopNsCmd)
                {
                    StopNS[I].ChangedSubShoulderStopMetod = false;
                }

                //вешаем команды по защитам в подплечах
                if (StopSubshoulders[I].StopSubShoulderTask != NsStopType.None)
                {
                    for (int INDEX = 1; INDEX <= MAX_UMPNA_IN_SHOULDER; INDEX++)
                    {
                        if (StopSubshoulders[I].OffSubShoulderMap[INDEX])
                        {

                            if (Commands[INDEX].StopType < StopSubshoulders[I].CurrentCmd.StopNaMethod)
                            {
                                Commands[INDEX].StopType = StopSubshoulders[I].CurrentCmd.StopNaMethod;
                            }
                        }
                    }
                }
            }


            for (int INDEX = 1; INDEX <= MAX_UMPNA_IN_SHOULDER; INDEX++)
            {
                if (NA[INDEX].Achr)
                {
                    if (NA[INDEX].SwitchOffOut)
                    {
                        if ((Commands[INDEX].StopType < NaStopType.StopAuto))
                        {
                            Commands[INDEX].StopType = NaStopType.StopAuto;
                        }
                    }
                }
            }

            /*>>в ТПР добавлена обработка команд по смене ном/неном инт подач 2018.06.06 изм МО*/
            /*32 Схема 22.25 Алгоритм назначения режима НС*/

            if (CMD == 4 && !NeNomFeedInterval) {
                Messenger.Send(42); // КОМАНДА – НАЗНАЧИТЬ НЕНОМИНАЛЬНЫЙ ИНТЕРВАЛ ПОДАЧ
                Messenger.Send(43); // НАЗНАЧЕН НЕНОМИНАЛЬНЫЙ РЕЖИМ ПОДАЧ
                NeNomFeedInterval = true;
            }

            if (CMD == 8 && NeNomFeedInterval) {
                Messenger.Send(44); // КОМАНДА – НАЗНАЧИТЬ НОМИНАЛЬНЫЙ ИНТЕРВАЛ ПОДАЧ
                Messenger.Send(45); // НАЗНАЧЕН НОМИНАЛЬНЫЙ РЕЖИМ ПОДАЧ
                NeNomFeedInterval = false;
            }
        }

        
    }
}
