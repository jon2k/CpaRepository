﻿using System.Collections.Generic;
using System.Linq;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;

namespace TarReferenceSource.Ktpras
{
    public abstract class Ktpras_1Io : IFunctionBlock
    {
        public Ktpras_1Io()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }

        // in
        /// <summary>
        /// input Массив сигналов «Аварийное отключение кнопкой «Стоп». Только агрегатные кнопки останова. 
        /// </summary>
        public StArray<bool> KKC = new StArray<bool>(1, Enumerable.Range(1, 10).Select(i => false).ToArray()); // Аварийное отключение кнопками стоп. 
        /// <summary>
        /// input Сигнал «Контроль наличия напряжения в цепях оперативного тока»
        /// </summary>
        public bool EC1; // Контроль наличия напряжения в цепях оперативного тока.
        /// <summary>
        /// input Сигнал "Исправность цепей отключения ВВ МНА (ПНА) (сигнал 1)" 
        /// </summary>
        public bool ECO1; // Исправность цепей отключения.
        /// <summary>
        /// input Сигнал "Исправность цепей отключения ВВ МНА (ПНА) (сигнал 2)"
        /// </summary>
        public bool ECO3; // Исправность цепей отключения.   
        /// <summary>
        /// input факт выдачи команды «Отключить ВВ» модулем CMNA
        /// </summary>
        public bool StopCmd;  // Факт выдачи команды «Стоп» МНА (ПНА) модулем UMPNA (факт выдачи команды «Отключить ВВ» модулем CMNA)   
        /// <summary>
        /// input Количество сигналов «Аварийное отключение кнопкой «Стоп»
        /// </summary>
        public ushort KKCCount; // Количество сигналов «Аварийное отключение кнопкой «Стоп»
        /// <summary>
        /// input Счетчик циклов определения недостоверности сигналов, участвующих в определении наличия напряжения на автоматическом выключателе QF1 (3 A)
        /// </summary>
        public ushort CounterNdv;
        /// <summary>
        /// input 
        /// </summary>
        public ushort Threshold;

        // out
        /// <summary>
        /// output Флаг наличия оперативного напряжения на автоматическом выключателе QF1 (3 А)
        /// </summary>
        public bool QF3A; // Флаг наличия оперативного напряжения на автоматическом выключателе QF1 (3 А)
        /// <summary>
        /// output Флаг наличия оперативного напряжения на автоматическом выключателе QF2 (1 А)
        /// </summary>
        public bool QF1A; // Флаг наличия оперативного напряжения на автоматическом выключателе QF2 (1 А)
        /// <summary>
        /// output Флаг недостоверности сигнала «Контроль наличия напряжения в цепях оперативного тока»
        /// </summary>
        public bool EC1_Ndv; // Флаг недостоверности сигнала «Контроль наличия напряжения в цепях оперативного тока» 
        /// <summary>
        /// output Флаг недостоверности сигнала «Исправность цепей отключения (сигнал 1)» 
        /// </summary>
        public bool ECO1_Ndv; // Флаг недостоверности сигнала «Исправность цепей отключения (сигнал 1)» 
        /// <summary>
        /// output Флаг недостоверности сигнала «Исправность цепей отключения (сигнал 2)»
        /// </summary>
        public bool ECO3_Ndv; // Флаг недостоверности сигнала «Исправность цепей отключения (сигнал 2)»   
        /// <summary>
        /// output Флаг неисправности цепей отключения МНА (ПНА), определяемой по сигналу «Исправность цепей отключения (сигнал 1)» 
        /// </summary>
        public bool ECO1_Err; // Флаг неисправности цепей отключения МНА (ПНА), определяемой по сигналу «Исправность цепей отключения (сигнал 1)»
        /// <summary>
        /// output Флаг неисправности цепей отключения МНА (ПНА), определяемой по сигналу «Исправность цепей отключения (сигнал 2)» 
        /// </summary>
        public bool ECO3_Err; // Флаг неисправности цепей отключения МНА (ПНА), определяемой по сигналу «Исправность цепей отключения (сигнал 2)»    
        /// <summary>
        /// output Массив флагов недостоверности сигнала «Аварийное отключение кнопкой «Стоп» 
        /// </summary>
        public StArray<bool> KKCNdv = new StArray<bool>(1, Enumerable.Range(1, 10).Select(i => false).ToArray()); // Массив флагов недостоверности сигнала «Аварийное отключение кнопкой «Стоп» 
        /// <summary>
        /// output Массив флагов аварийных сигналов защиты «Аварийное отключение кнопкой «Стоп» 
        /// </summary>
        public StArray<bool> KKCAlarm = new StArray<bool>(1, Enumerable.Range(1, 10).Select(i => false).ToArray()); // Массив флагов аварийных сигналов защиты «Аварийное отключение кнопкой «Стоп» 

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
            {
                {1, new MessageDescription{Text = "МНА Х. ИСЧЕЗНОВЕНИЕ ОПЕРАТИВНОГО НАПРЯЖЕНИЯ НА QF1 (3 A) ВВ", Type = MessageType.Attention} },
                {2, new MessageDescription{Text = "МНА Х. ВОССТАНОВЛЕНИЕ ОПЕРАТИВНОГО НАПРЯЖЕНИЯ НА QF1 (3 A) ВВ", Type = MessageType.Neutral} },
                {3, new MessageDescription{Text = "МНА Х. ИСЧЕЗНОВЕНИЕ ОПЕРАТИВНОГО НАПРЯЖЕНИЯ НА QF2 (1 A) ВВ", Type = MessageType.Attention} },
                {4, new MessageDescription{Text = "МНА Х. ВОССТАНОВЛЕНИЕ ОПЕРАТИВНОГО НАПРЯЖЕНИЯ НА QF2 (1 A) ВВ", Type = MessageType.Neutral} },
                {5, new MessageDescription{Text = "МНА Х. СИГНАЛ \"АВАРИЙНОЕ ОТКЛЮЧЕНИЕ КНОПКОЙ СТОП В НАСОСНОМ ЗАЛЕ\" НЕДОСТОВЕРЕН", Type = MessageType.Attention} },
                {6, new MessageDescription{Text = "МНА Х. СИГНАЛ \"АВАРИЙНОЕ ОТКЛЮЧЕНИЕ КНОПКОЙ СТОП В НАСОСНОМ ЗАЛЕ\" ДОСТОВЕРЕН", Type = MessageType.Attention} },
                {7, new MessageDescription{Text = "МНА Х. СИГНАЛ \"АВАРИЙНОЕ ОТКЛЮЧЕНИЕ КНОПКОЙ СТОП В ЭЛЕКТРОЗАЛЕ\" НЕДОСТОВЕРЕН", Type = MessageType.Attention} },
                {8, new MessageDescription{Text = "МНА Х. СИГНАЛ \"АВАРИЙНОЕ ОТКЛЮЧЕНИЕ КНОПКОЙ СТОП ЭЛЕКТРОЗАЛЕ\" ДОСТОВЕРЕН", Type = MessageType.Neutral} },
                {9, new MessageDescription{Text = "МНА Х. СИГНАЛ \"АВАРИЙНОЕ ОТКЛЮЧЕНИЕ КНОПКОЙ СТОП С БРУ\" НЕДОСТОВЕРЕН", Type = MessageType.Attention} },
                {10, new MessageDescription{Text = "МНА Х. СИГНАЛ \"АВАРИЙНОЕ ОТКЛЮЧЕНИЕ КНОПКОЙ СТОП С БРУ\" ДОСТОВЕРЕН", Type = MessageType.Neutral} },
                {11, new MessageDescription{Text = "МНА Х. СИГНАЛ \"АВАРИЙНОЕ ОТКЛЮЧЕНИЕ КНОПКОЙ СТОП С ЧРП\" НЕДОСТОВЕРЕН", Type = MessageType.Attention} },
                {12, new MessageDescription{Text = "МНА Х. СИГНАЛ \"АВАРИЙНОЕ ОТКЛЮЧЕНИЕ КНОПКОЙ СТОП С ЧРП\" ДОСТОВЕРЕН", Type = MessageType.Neutral} },
                {13, new MessageDescription{Text = "МНА Х. СИГНАЛ \"НАЛИЧИЕ НАПРЯЖЕНИЯ В ЦЕПЯХ ОПЕРАТИВНОГО ТОКА\" ВВ НЕДОСТОВЕРЕН", Type = MessageType.Attention} },
                {14, new MessageDescription{Text = "МНА Х. СИГНАЛ \"НАЛИЧИЕ НАПРЯЖЕНИЯ В ЦЕПЯХ ОПЕРАТИВНОГО ТОКА\" ВВ ДОСТОВЕРЕН", Type = MessageType.Neutral} },
                {15, new MessageDescription{Text = "МНА Х. СИГНАЛ \"ИСПРАВНОСТЬ ЦЕПЕЙ ОТКЛЮЧЕНИЯ ВВ (УСО1)\" НЕДОСТОВЕРЕН", Type = MessageType.Attention} },
                {16, new MessageDescription{Text = "МНА Х. СИГНАЛ \"ИСПРАВНОСТЬ ЦЕПЕЙ ОТКЛЮЧЕНИЯ ВВ (УСО1)\" ДОСТОВЕРЕН", Type = MessageType.Neutral} },
                {17, new MessageDescription{Text = "МНА Х. СИГНАЛ \"ИСПРАВНОСТЬ ЦЕПЕЙ ОТКЛЮЧЕНИЯ ВВ (УСО3)\" НЕДОСТОВЕРЕН", Type = MessageType.Attention} },
                {18, new MessageDescription{Text = "МНА Х. СИГНАЛ \"ИСПРАВНОСТЬ ЦЕПЕЙ ОТКЛЮЧЕНИЯ ВВ (УСО3)\" ДОСТОВЕРЕН", Type = MessageType.Neutral} },
                {19, new MessageDescription{Text = "МНА Х. СИГНАЛ \"ИСПРАВНОСТЬ ЦЕПЕЙ ВКЛЮЧЕНИЯ ВВ\" НЕДОСТОВЕРЕН", Type = MessageType.Attention} },
                {20, new MessageDescription{Text = "МНА Х. СИГНАЛ \"ИСПРАВНОСТЬ ЦЕПЕЙ ВКЛЮЧЕНИЯ ВВ\" ДОСТОВЕРЕН", Type = MessageType.Neutral} },
                {21, new MessageDescription{Text = "МНА Х. ЦЕПИ ВКЛЮЧЕНИЯ ВВ НЕИСПРАВНЫ", Type = MessageType.Attention} },
                {22, new MessageDescription{Text = "МНА Х. ЦЕПИ ВКЛЮЧЕНИЯ ВВ ИСПРАВНЫ", Type = MessageType.Neutral} },
                {23, new MessageDescription{Text = "МНА Х. ЦЕПИ ОТКЛЮЧЕНИЯ ВВ (УСО1) НЕИСПРАВНЫ", Type = MessageType.Alarm} },
                {24, new MessageDescription{Text = "МНА Х. ЦЕПИ ОТКЛЮЧЕНИЯ ВВ (УСО1) ИСПРАВНЫ", Type = MessageType.Neutral} },
                {25, new MessageDescription{Text = "МНА Х. ЦЕПИ ОТКЛЮЧЕНИЯ ВВ (УСО3) НЕИСПРАВНЫ", Type = MessageType.Alarm} },
                {26, new MessageDescription{Text = "МНА Х. ЦЕПИ ОТКЛЮЧЕНИЯ ВВ (УСО3) ИСПРАВНЫ", Type = MessageType.Neutral} },
            };
    }
}
