﻿using System.Collections.Generic;
using System.Linq;

namespace TarFoundation.St
{

    public sealed class StArray<T>
    {
        private readonly T[] _array;
        private readonly int _shift;
        
        public StArray(int startIndex, T[] array)
        {
            _shift = startIndex;
            _array = array;
        }

        public T this[int index]
        {
            get => _array[index - _shift];
            set => _array[index - _shift] = value;
        }

        public T this[uint index]
        {
            get => _array[index - _shift];
            set => _array[index - _shift] = value;
        }

        public int Count => _array.Length;

        public List<T> ToList()
        {
            return _array.ToList();
        }

        public T[] ToArray()
        {
            return _array;
        }
    }
}
