﻿using TarFoundation.Messenger;
using TarFoundation.St;

namespace TarReferenceSource.Oip
{
    public interface ISignalDataSource
    {
        AnalogSignal Signal { get; }
    }

    /// <summary>
    /// Структура, хранящая состояние уровня
    /// </summary>
    public class LevelState
    {
        /// <summary>
        /// Флаг достижения измеряемым параметром уровня
        /// </summary>
        public bool Level;
        /// <summary>
        /// Программная блокировка обработки уровня (используется OIP_Vibration)
        /// </summary>
        public bool Block = false;
        /// <summary>
        /// Флаг необходимости оперативного сообщения при достижении уровня
        /// </summary>
        public bool Msg;
    }

    /// <summary>
    /// Структура, хранящая настройки уровня измеряемого параметра
    /// </summary>
    public class LevelConfig
    {
        /// <summary>
        /// Разрешение на обработку уровня («неблокировка») от пользователя
        /// </summary>
        public bool Enable { get; set; }
        /// <summary>
        /// Флаг необходимости оперативного сообщения при достижении уровня
        /// </summary>
        public bool Msg { get; set; } = true;
        /// <summary>
        /// Уставка уровня
        /// </summary>
        public float Ust { get; set; }
    }

    public abstract class AbstractProcLevels : IFunctionBlock
    {
        private ISignalDataSource _signalSource;
        public AnalogSignal Signal { get; set; } = new AnalogSignal();

        public AbstractProcLevels(ISignalDataSource signalSource)
        {
            _signalSource = signalSource;
        }
        /// <summary>
        /// input Флаг настройки выдачи сообщения о нормальном состоянии измеряемого параметра. 1 — выдавать сообщение. 0 — не выдавать сообщение
        /// </summary>
        public bool NeedNormMsg { get; set; }
        /// <summary>
        /// input Значение для гистерезиса при определении уровней
        /// </summary>
        public float Hist { get; set; }
        /// <summary>
        /// output Флаг нормального состояния измеряемого параметра. 1 — измеряемый параметр в норме. 0 — измеряемый параметр не в норме
        /// </summary>
        public bool Norm { get; set; }

        public override void BeforeCall()
        {
            if (_signalSource != null)
            {
                Signal.Ndv = _signalSource.Signal.Ndv;
                Signal.ExtNdv = _signalSource.Signal.ExtNdv;
                Signal.LTMin = _signalSource.Signal.LTMin;
                Signal.MTMax = _signalSource.Signal.MTMax;
                Signal.Value = _signalSource.Signal.Value;
                Signal.VisualValue = _signalSource.Signal.VisualValue;
                Signal.AlgNdv = _signalSource.Signal.AlgNdv;
            }
        }

        public abstract LevelConfig GetLevelsConfig(int lvlNum);
        public abstract bool IsLevel(int lvlNum);
    }

    public static class OipHelpers
    {
        /*
         * добавлены флаги для указания разрешенных операций (для правильности вывода сообщений в группе уровней)
         * сообщения перенесены сюда
         */
        public static void ProcMax(float value, LevelConfig cfg, float hist, LevelState level, bool setOperation, bool unsetOperation, bool blockOperation, int levelOffset, IMessenger Messenger)
        {
            /* Обработка уровней выше нормального состояния измеряемого параметра */

            if (cfg.Enable && !level.Block)
            {
                if (level.Level)
                {
                    if (!(value >= (cfg.Ust - hist)) && unsetOperation)
                    {
                        level.Level = false;
                        if (cfg.Msg)
                        {
                            Messenger.Send(21 + levelOffset * 3 + 1);
                        }
                    }
                }
                else if (setOperation)
                {
                    if (value >= cfg.Ust)
                    {
                        level.Level = true;
                        if (cfg.Msg)
                        {
                            Messenger.Send(21 + levelOffset * 3 + 2);
                        }
                    }
                }
            }
            else
            {
                if (level.Level && blockOperation)
                {
                    level.Level = false;
                    if (cfg.Msg)
                    {
                        Messenger.Send(21 + levelOffset * 3 + 0);
                    }
                }
            }
        }
        public static void ProcMin(float value, LevelConfig cfg, float hist, LevelState level, bool setOperation, bool unsetOperation, bool blockOperation, int levelOffset, IMessenger Messenger)
        {
            /* Обработка уровней ниже нормального состояния измеряемого параметра */

            if (cfg.Enable && !level.Block)
            {
                if (level.Level)
                {
                    if (!(value <= (cfg.Ust + hist))  && unsetOperation)
                    {
                        level.Level = false;
                        if (cfg.Msg)
                        {
                            Messenger.Send(21 + levelOffset * 3 + 1);
                        }
                    }
                }
                else if (setOperation)
                {
                    if (value <= cfg.Ust)
                    {
                        level.Level = true;
                        if (cfg.Msg)
                        {
                            Messenger.Send(21 + levelOffset * 3 + 2);
                        }
                    }
                }
            }
            else
            {
                if (level.Level && blockOperation)
                {
                    level.Level = false;
                    if (cfg.Msg)
                    {
                        Messenger.Send(21 + levelOffset * 3 + 0);
                    }
                }
            }
        }
    }
}
