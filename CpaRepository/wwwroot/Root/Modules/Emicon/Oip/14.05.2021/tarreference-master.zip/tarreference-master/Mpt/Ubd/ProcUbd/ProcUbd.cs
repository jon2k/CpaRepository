﻿using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.St;
using TarReferenceSource.Common.Timer;
using TarReferenceSource.Uzd;

namespace TarReferenceSource.Mpt.Ubd.ProcUbd
{
    /// <summary>
    /// Структура состояния бака-дозатора
    /// </summary>
    internal class UbdStorage
    {
        /// <summary>
        /// Состояние бака
        /// </summary>
        public UbdState state; //0-неопред, 1 - бак-дозатор закрыт, 2 - открыт, 3 промежуточное
        /// <summary>
        /// Флаг аварии
        /// </summary>
        public bool isCrashed;//авария
        /// <summary>
        /// Режим работы бака
        /// </summary>
        public UbdMode mode;  //0- режим "Аварийный", 1 - режим "Автоматический", 2-"Резервный"
        /// <summary>
        /// 
        /// </summary>
        public byte SettedMode;
        /// <summary>
        /// Неисправность бака
        /// </summary>
        public bool err;   //Неисправность
        /// <summary>
        /// Бак пуст
        /// </summary>
        public bool empty; //Пуст
        /// <summary>
        /// Бак полон
        /// </summary>
        public bool full; //Полон
        /// <summary>
        /// Аварийный запас
        /// </summary>
        public bool low; //Аварийный запас
        /// <summary>
        /// Команда на открытие задвижек БД
        /// </summary>
        public bool openCmd; //Команда на открытие задвижек БД
        /// <summary>
        /// Команда на закрытие задвижек БД
        /// </summary>
        public bool closeCmd; //Команда на закрытие задвижек БД
        /// <summary>
        /// Команда на открытие задвижек БД в прошлом цикле
        /// </summary>
        public bool openCmdPrev; //Команда на открытие задвижек БД
        /// <summary>
        /// Команда на закрытие задвижек БД в прошлом цикле
        /// </summary>
        public bool closeCmdPrev; //Команда на закрытие задвижек БД      
        /// <summary>
        /// Флаг необходимости резерва
        /// </summary>
        public bool needRezOn;
        /// <summary>
        /// Состояние аварий входной задвижки БД
        /// </summary>
        public ZdOut ZdStateIn; //Состояние аварий входной задвижки БД
        /// <summary>
        /// Состояние аварий выходной задвижки БД
        /// </summary>
        public ZdOut ZdStateOut; //Состояние аварий выходной задвижки БД
        /// <summary>
        /// 
        /// </summary>
        public bool zdNu;
    }
    public class ProcUbd : ProcUbdIo
    {
        /// <summary>
        /// Внутреннее состояние бака
        /// </summary>
        private UbdStorage storage = new UbdStorage();
        private CpaLocalTimer _timer;
        public ProcUbd(ProcUzdIo inZd, ProcUzdIo outZd) : base(inZd, outZd)
        {
            _timer = new CpaLocalTimer();
            InternalTimers = new StArray<ITimer>(1, new []{_timer});
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }

        public override void Execute()
        {
            storage.openCmd = openCmd;
            storage.closeCmd = closeCmd;
            storage.needRezOn = needRezOn;


            switch (input.cmd)
            {
                case UbdCmd.SetOsnCmd:
                    //осн
                    Messenger.Send(5);
                    if (storage.mode == UbdMode.osn)
                    {
                        Messenger.Send(23);//НАЗНАЧЕНИЕ РЕЖИМА НЕ ТРЕБУЕТСЯ. РЕЖИМ УЖЕ НАЗНАЧЕН
                    }
                    else if (storage.isCrashed)
                    {
                        Messenger.Send(19);//НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. БД НЕИСПРАВЕН
                    }
                    else
                    {
                        storage.mode = UbdMode.osn;
                        Messenger.Send(20);//НАЗНАЧЕН РЕЖИМ ОСНОВНОЙ
                    }
                    break;
                case UbdCmd.SetRezCmd:
                    //рез
                    Messenger.Send(6);
                    if (storage.mode == UbdMode.rez)
                    {
                        Messenger.Send(23);//НАЗНАЧЕНИЕ РЕЖИМА НЕ ТРЕБУЕТСЯ. РЕЖИМ УЖЕ НАЗНАЧЕН
                    }
                    else if (storage.isCrashed)
                    {
                        Messenger.Send(19);//НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. БД НЕИСПРАВЕН
                    }
                    else if (!canBeRez)
                    {
                        Messenger.Send(28);
                    }
                    else if (storage.state != UbdState.closed)
                    {
                        Messenger.Send(18);//НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. БД НЕ ЗАКРЫТ
                    }
                    else
                    {
                        Messenger.Send(21);
                        storage.mode = UbdMode.rez;
                    }
                    break;
                case UbdCmd.SetRemCmd:
                    //рем
                    Messenger.Send(7);
                    if (storage.mode == UbdMode.rem)
                    {
                        Messenger.Send(23);//НАЗНАЧЕНИЕ РЕЖИМА НЕ ТРЕБУЕТСЯ. РЕЖИМ УЖЕ НАЗНАЧЕН
                    }
                    else
                    {
                        storage.openCmd = false;
                        storage.closeCmd = input.empty;//если пуст, то закрываемся
                        storage.mode = UbdMode.rem;
                        Messenger.Send(22);
                    }
                    break;
            }

            //авария задвижек
            if (input.ZdStateIn.Crash || input.ZdStateOut.Crash || //ЕСЛИ АВАРИЯ задвижки или
                (!input.ZdStateIn.CorrCo && input.ZdStateIn.State == ZdState.Closed) || (!input.ZdStateOut.CorrCo && input.ZdStateOut.State == ZdState.Closed))
            {
                if (!storage.err)
                {
                    storage.err = true;
                    storage.needRezOn = storage.openCmd && storage.mode == UbdMode.osn;
                    Messenger.Send(12);       /* оп. НЕИСПРАВНОСТЬ ЗАДВИЖЕК*/
                }
            }
            else
            {
                storage.err = false;
            }

            //задвижки обесточены   
            if (_timer.IsQ)
            {
                _timer.Stop();
                storage.zdNu = true;
                storage.needRezOn = storage.openCmd && storage.mode == UbdMode.osn;
            }

            if ((input.ZdStateIn.NoEc || input.ZdStateOut.NoEc) && !storage.zdNu && !_timer.IsStarted)
            {
                _timer.Start();
            }

            if (!input.ZdStateIn.NoEc && !input.ZdStateOut.NoEc)
            {
                storage.zdNu = false;
                _timer.Stop();
            }

            //бд пуст
            storage.full = input.full;
            storage.low = input.low;

            if (input.empty && !storage.empty)
            { //ЕСЛИ ПУСТ
                storage.needRezOn = (storage.state == UbdState.opened || storage.openCmd) && storage.mode == UbdMode.osn;//открываем резерв если открыт или открываелся
                Messenger.Send(11);       /* оп. БАК ПУСТ */
            }
            storage.empty = input.empty;

            if (input.ZdStateIn.State == 0 || input.ZdStateOut.State == 0 /*не готов*/)
            {
                if (storage.state != 0)
                {
                    storage.state = 0;
                    Messenger.Send(4);        /* оп. НЕОПРЕДЕЛЕННОЕ СОСТОЯНИЕ */
                }
            }
            else if (input.ZdStateIn.State == ZdState.Closed || input.ZdStateOut.State == ZdState.Closed /*ЗАКРЫТЫ*/ )
            {
                if (storage.state != UbdState.closed)
                {
                    storage.state = UbdState.closed;
                    Messenger.Send(2);        /* оп. ЗАКРЫТ */
                }
            }
            else if (input.ZdStateIn.State == ZdState.Opened && input.ZdStateOut.State == ZdState.Opened /*ОТКРЫТЫ*/ )
            {
                if (storage.state != UbdState.opened)
                {
                    storage.state = UbdState.opened;
                    Messenger.Send(1);        /* оп. ОТКРЫТ*/
                }
            }
            else
            {
                if (storage.state != UbdState.middle)
                {
                    storage.state = UbdState.middle;
                    Messenger.Send(3);        /* оп. НЕ ОТКРЫТ*/
                }
            }

            if (storage.state == 0 /*не готов*/ || storage.zdNu/*обесточены*/ || input.empty || storage.err)
            {

                storage.openCmd = false;
                storage.closeCmd = storage.closeCmd || storage.empty;//если пуст, то закрываемся

                if (!storage.isCrashed)
                {
                    storage.isCrashed = true;
                    Messenger.Send(27);       /* оп. АВАРИЯ БАКА ДОЗАТОРА */
                }
                if (storage.mode != UbdMode.rem)
                {
                    storage.mode = UbdMode.rem;
                    Messenger.Send(26);       /* оп. НАЗНАЧЕН РЕЖИМ РЕМ АВТОМАТИЧЕСКИ */
                }
            }
            else
            {
                if (storage.isCrashed)
                {
                    Messenger.Send(13);       /* оп. БАК ДОЗАТОР ИСПРАВЕН */
                    storage.isCrashed = false;
                    storage.openCmd = false;
                    storage.closeCmd = false;
                }
            }
            if (storage.mode == UbdMode.rez && (storage.state != UbdState.closed || storage.openCmd || !canBeRez))
            {
                storage.mode = UbdMode.osn;
                Messenger.Send(25);       /* оп. НАЗНАЧЕН РЕЖИМ ОСН АВТОМАТИЧЕСКИ*/
            }
            output.ZDCtrlIn.nlOpen = false;
            output.ZDCtrlOut.nlOpen = false;
            output.ZDCtrlIn.nlClose = false;
            output.ZDCtrlOut.nlClose = false;

            //Проверяем наличие команды на открытие БД
            if (storage.openCmd)
            {
                if (!storage.openCmdPrev && storage.state != UbdState.opened)
                {
                    Messenger.Send(8);        /* оп. АВТОМАТИЧЕСКОЕ ОТКРЫТИЕ */
                }
                output.ZDCtrlIn.nlOpen = true;
                output.ZDCtrlOut.nlOpen = true;
                storage.closeCmd = false;
            }
            else if (storage.closeCmd)
            { //Проверяем наличие команды на закрытие БД
                if (!storage.closeCmdPrev && storage.state != UbdState.closed)
                {
                    Messenger.Send(9);        /* оп. АВТОМАТИЧЕСКОЕ ЗАКРЫТИЕ */
                }
                output.ZDCtrlIn.nlClose = true;
                output.ZDCtrlOut.nlClose = true;
                storage.openCmd = false;
            }
            storage.openCmdPrev = storage.openCmd;
            storage.closeCmdPrev = storage.closeCmd;

            storage.ZdStateIn = input.ZdStateIn;
            storage.ZdStateOut = input.ZdStateOut;

            empty = storage.empty;
            low = storage.low;
            full = storage.full;
            state = storage.state;
            isCrashed = storage.isCrashed;
            mode = storage.mode;
            err = storage.err;
            needRezOn = storage.needRezOn;
            openCmd = storage.openCmd;
            closeCmd = storage.closeCmd;
            ready = (storage.full || storage.low) && !storage.empty && !storage.err && !(input.ZdStateIn.Imit || input.ZdStateOut.Imit) && storage.mode != UbdMode.rem;
        }
    }
}
