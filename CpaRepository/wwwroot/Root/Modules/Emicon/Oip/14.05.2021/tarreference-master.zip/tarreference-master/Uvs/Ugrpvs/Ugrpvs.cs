﻿using System;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.St;
using TarReference.InteractionStorages;
using TarReferenceSource.Common.Timer;

namespace TarReferenceSource.Uvs
{
    public class Ugrpvs : GrpvsIo
    {
        public ITimer timer;
        /// <summary>
        /// Внутреннее состояния агрегата
        /// </summary>
        private GrpvsStorage storage = new GrpvsStorage();
        public Ugrpvs(ProcAvsIo[] avs) : base(avs)
        {
            timer = new CpaLocalTimer();
            InternalTimers = new StArray<ITimer>(1, new[] { timer });
        }

        public override void Execute()
        {
            var OsnCount = 0;
            var OsnVklCount = 0;
            var StopBlockedCount = 0;
            var WorkBlockedCount = 0;
            var OsnZapuskCount = 0;
            var OtklNoApvCount = 0;
            var OsnOstanovExist = false;
            var rezNum = 0;
            var DoApv = false;

            /*ЕСЛИ НЕТ СМЕНЫ РЕЗЕРВНОГО, ТО СБРАСЫВАЕМ АВР*/
            if (!storage.BlockResetAvr)
            {
                storage.DoAvr = false;
            }

            storage.BlockResetAvr = false;



            for (int j = 1; j <= AvsCount; j++)
            {
                /*1. ОПРЕДЕЛЕНИЕ КОЛИЧЕСТВО ОСНОВНЫХ*/
                if (AvsStates[j].Mode == VsMode.osn)
                {
                    OsnCount = OsnCount + 1;
                }
                /*2. ОПРЕДЕЛЕНИЕ ВКЛЮЧЕННОГО В ОСНОВНОМ*/
                if (AvsStates[j].State == VsState.on && AvsStates[j].Mode == VsMode.osn)
                {
                    OsnVklCount = OsnVklCount + 1;
                }
                /*3. ОПРЕДЕЛЕНИЕ КОЛИЧЕСТВА БЛОКИРОВОК ОТКЛЮЧЕНИЯ*/
                if (AvsStates[j].StopBlocked)
                {
                    StopBlockedCount = StopBlockedCount + 1;
                }
                /*4. ОПРЕДЕЛЕНИЕ КОЛИЧЕСТВА БЛОКИРОВОК ВКЛЮЧЕНИЯ*/
                if (AvsStates[j].WorkBlocked)
                {
                    WorkBlockedCount = WorkBlockedCount + 1;
                }
                /*5. ОПРЕДЕЛЕНИЕ НАЛИЧИЯ ЗАПУСКАЮЩЕГОСЯ В ОСНОВНОМ*/
                if (AvsStates[j].State == VsState.starting && AvsStates[j].Mode == VsMode.osn)
                {
                    OsnZapuskCount = OsnZapuskCount + 1;
                }
                /*6. ОПРЕДЕЛЕНИЕ ОСТАНАВЛИВАЮЩЕГОСЯ В ОСНОВНОМ*/
                if (AvsStates[j].State == VsState.stopping && AvsStates[j].Mode == VsMode.osn)
                {
                    OsnOstanovExist = true;
                }

                if ((AvsStates[j].State == VsState.off || AvsStates[j].State == VsState.stopping) && !AvsStates[j].WaitFutureStart && !AvsStates[j].WaitApv)
                {
                    OtklNoApvCount = OtklNoApvCount + 1;
                }

                /*8. ОПРЕДЕЛЕНИЕ РЕЗЕРВНОГО В ГРУППЕ*/
                if (AvsStates[j].Mode == VsMode.rez)
                {
                    if (rezNum == 0)
                    {
                        rezNum = j;
                    }
                    else
                    {
                        AutoCmds[j].SetMode = VsMode.osn;
                    }
                }
                /*9. ОПРЕДЕЛЕНИЕ НЕОБХОДИМОСТИ ВЫПОЛНЕНИЯ АВР*/
                storage.DoAvr = storage.DoAvr || AvsStates[j].NeedAvr;
                /*10. ОПРЕДЕЛЕНИЕ НЕОБХОДИМОСТИ ВЫПОЛНЕНИЯ АПВ*/
                DoApv = DoApv || AvsStates[j].WaitApv;


                //ПРОВОДИМ СБРОС ВСЕХ КОМАНД ДЛЯ КАЖДОЙ ВС
                AutoCmds[j].SilentStop = false;
                AutoCmds[j].AutoStop = false;
                AutoCmds[j].AutoStart = false;
                AutoCmds[j].ResStart = false;
                AutoCmds[j].BlockStop = false;
                AutoCmds[j].BlockWork = false;
                AutoCmds[j].ResetBlocksCmd = false;
                AutoCmds[j].BlockApv = false;
                AutoCmds[j].ResetBlocksApvCmd = false;
                AutoCmds[j].SetMode = VsMode.none;
            }


            if (storage.RezNum == 0)
            {
                storage.RezNum = rezNum;
            }

            if (storage.RezNum == 0)
            {

            }
            else if (AvsStates[storage.RezNum].NeedAvr || AvsStates[storage.RezNum].Crash)
            {
                storage.ReorderRez = true;
                storage.NeedReorderRezNum = storage.RezNum;
                storage.RezNum = 0;
            }
            else if (AvsStates[storage.RezNum].Mode == VsMode.osn && AvsStates[storage.RezNum].State != VsState.off)
            {
                storage.ReorderRez = true;
                storage.NeedReorderRezNum = storage.RezNum;
                storage.RezNum = 0;
            }
            else if (AvsStates[storage.RezNum].Mode != VsMode.rez)
            {
                storage.RezNum = 0;
            }

            if (storage.RezNum != 0 && OsnCount == 0)
            {
                AutoCmds[storage.RezNum].SetMode = VsMode.osn;
            }

            var GroupStateMachineStep = 1;
            uint SetBlockWorkCnt = 0;
            uint SetBlockStopCnt = 0;

            while (BlockWorkCount != WorkBlockedCount || BlockStopCount != StopBlockedCount)
            {
                if (GroupStateMachineStep == 1)
                {
                    SetBlockWorkCnt = BlockWorkCount;
                    SetBlockStopCnt = BlockStopCount;

                    GroupStateMachineStep = 2;
                }
                else if (GroupStateMachineStep == 2)
                {
                    for (int j = 1; j <= AvsCount; j++)
                    {
                        AutoCmds[j].ResetBlocksCmd = true;
                    }

                    GroupStateMachineStep = 3;
                }
                else if (GroupStateMachineStep == 3)
                {
                    for (int j = 1; j <= AvsCount; j++)
                    {
                        if (SetBlockStopCnt == 0)
                        {
                            break;
                        }

                        if ((AvsStates[j].Mode == VsMode.osn))
                        {
                            if (AvsStates[j].State == VsState.starting || AvsStates[j].State == VsState.@on)
                            {
                                AutoCmds[j].BlockStop = true;
                                SetBlockStopCnt = SetBlockStopCnt - 1;
                            }
                        }
                    }

                    GroupStateMachineStep = 4;
                }
                else if (GroupStateMachineStep == 4)
                {
                    for (int j = 1; j <= AvsCount; j++)
                    {
                        if (SetBlockWorkCnt > 0)
                        {
                            if (AvsStates[j].State == VsState.stopping || AvsStates[j].State == VsState.off)
                            {
                                AutoCmds[j].BlockWork = true;
                                SetBlockWorkCnt = SetBlockWorkCnt - 1;
                            }
                        }
                        else
                        {
                            break;
                        }
                    }
                    GroupStateMachineStep = 0;
                }
                else if (GroupStateMachineStep == 0)
                {
                    storage.PrevWorkCtrl = 0;
                    break;
                }
            }

            if (storage.StartedAsDopNum != 0)
            {
                if (storage.RezNum != 0)
                {
                    AutoCmds[storage.StartedAsDopNum].MarkAsDop = false;
                    storage.StartedAsDopNum = 0;
                }
                else if (AvsStates[storage.StartedAsDopNum].Crash)
                {
                    AutoCmds[storage.StartedAsDopNum].MarkAsDop = false;
                    storage.ReorderRez = true;
                    storage.SetRezNum = storage.StartedAsDopNum;
                    storage.StartedAsDopNum = 0;
                }
                else if (AvsStates[storage.StartedAsDopNum].Mode != VsMode.osn)
                {
                    AutoCmds[storage.StartedAsDopNum].MarkAsDop = false;
                    storage.StartedAsDopNum = 0;
                }
                else if (AvsStates[storage.StartedAsDopNum].State == VsState.off)
                {
                    AutoCmds[storage.StartedAsDopNum].MarkAsDop = false;
                    if (OsnCount > 1)
                    {
                        AutoCmds[storage.StartedAsDopNum].SetMode = VsMode.rez;
                        storage.RezNum = storage.StartedAsDopNum;
                    }
                    storage.StartedAsDopNum = 0;
                }
            }

            GroupStateMachineStep = 1;
            int WorkDelta = 0;
            bool exitWhile = false;
            while (WorkCount != storage.PrevWorkCtrl && !exitWhile)
            {
                switch (GroupStateMachineStep)
                {
                    case 1: //ИНИЦИАЛИЗАЦИЯ
                        if (WorkCount > 0 && !storage.DoAvr)
                        {
                            GroupStateMachineStep = 2;
                        }
                        else if (WorkCount < 0)
                        {
                            GroupStateMachineStep = 3;
                        }
                        else
                        {
                            GroupStateMachineStep = 0;
                        }

                        break;
                    /*
                     * Обработка команды на включение:
                     * Определяем достаточно ли уже включенных
                     * если нет включаем те что в основном режиме
                     * если не хватило, то включаем резерв как дополнительный
                     */
                    case 2:

                        //определяем сколько нужно еще включить в ОСН
                        WorkDelta = WorkCount - OsnVklCount - OsnZapuskCount;

                        //нужно еще включать
                        if (WorkDelta > 0)
                        {
                            GroupStateMachineStep = 4;
                        }
                        else
                        {
                            GroupStateMachineStep = 0;
                        }

                        break;
                    //ВКЛЮЧЕНИЕ В ОСН
                    case 4:
                        for (int j = 1; j <= AvsCount; j++)
                        {
                            if (AvsSignals[j].Ec && AvsSignals[j].SecEc)
                            {
                                if (AvsStates[j].Mode == VsMode.osn && AvsStates[j].State == VsState.off && !AvsStates[j].WorkBlocked)
                                {
                                    if (!AutoCmds[j].AutoStart)
                                    {
                                        AutoCmds[j].AutoStart = true;
                                        AutoCmds[j].AutoStop = false;
                                        WorkDelta = WorkDelta - 1;
                                    }
                                }
                            }

                            if (WorkDelta <= 0)//ВСЕ ВКЛЮЧИЛИ
                            {
                                GroupStateMachineStep = 0;
                                break;
                            }
                        }
                        //ОТПРАВЛЕНЫ КОМАНДЫ НА ВКЛЮЧЕНИЕ ВСЕХ ОСНОВНЫХ, НО НУЖНО ВКЛЮЧИТЬ ЕЩЕ РЕЗЕРВНЫЕ
                        if (WorkDelta > 0)
                        {
                            GroupStateMachineStep = 5;
                        }

                        break;
                    //ВКЛЮЧЕНИЕ В РЕЗ
                    case 5:
                        for (int j = 1; j <= AvsCount; j++)
                        {
                            if (AvsSignals[j].Ec && AvsSignals[j].SecEc)
                            {
                                if (AvsStates[j].Mode == VsMode.rez && !AvsStates[j].WorkBlocked)
                                {
                                    if (!AutoCmds[j].AutoStart)
                                    {
                                        AutoCmds[j].AutoStart = true;
                                        AutoCmds[j].AutoStop = false;
                                        AutoCmds[j].MarkAsDop = true;
                                        storage.StartedAsDopNum = j;
                                        WorkDelta = WorkDelta - 1;
                                    }
                                }
                            }
                            //ВСЕ ВКЛЮЧИЛИ
                            if (WorkDelta <= 0)
                            {
                                GroupStateMachineStep = 0;
                                break;
                            }
                        }
                        //ОТПРАВЛЕНЫ КОМАНДЫ НА ВКЛЮЧЕНИЕ ВСЕХ РЕЗЕРВНЫХ, НО НУЖНО ВКЛЮЧИТЬ ЕЩЕ - ПОПРОБУЕМ НА СЛЕД СКАНАХ
                        if (WorkDelta > 0)
                        {
                            GroupStateMachineStep = 999;
                        }

                        break;
                    /*
                     * Обработка команды на отключение:
                     * Проверяем достаточно ли отключенных агрегатов, не ожидающих включения
                     * если нет, то вначале сбрасываем отложенный пуск резервным
                     * если недостаточно, сбрасываем отложенный пуск основным
                     * если недостаточно, то отключаем дополнительные
                     * если недостаточно, то отключаем основные
                     * если недостаточно, то отключаем в ручном режиме
                     */
                    case 3:
                        //определяем сколько нужно еще отключить в ОСН
                        WorkDelta = Math.Abs(WorkCount) - OtklNoApvCount;

                        //нужно еще отключить
                        if (WorkDelta > 0)
                        {
                            GroupStateMachineStep = 9;
                        }
                        else
                        {
                            GroupStateMachineStep = 0;
                        }

                        break;
                    case 9:
                        for (int j = 1; j <= AvsCount; j++)
                        {
                            if (AvsStates[j].Mode == VsMode.rez && !AvsStates[j].StopBlocked)
                            {
                                if (AvsStates[j].WaitFutureStart || AvsStates[j].WaitApv)
                                {
                                    AutoCmds[j].SilentStop = true;
                                    WorkDelta = WorkDelta - 1;
                                }
                            }
                            //КОМАНДА ВЫПОЛНЕНА
                            if (WorkDelta <= 0)
                            {
                                GroupStateMachineStep = 0;
                                break;
                            }
                        }
                        //ОТПРАВЛЕНЫ КОМАНДЫ НА ОТМЕНУ ОТЛОЖЕННОГО ПУСКА ВСЕХ РЕЗЕРВНЫХ
                        if (WorkDelta > 0)
                        {
                            GroupStateMachineStep = 10;
                        }

                        break;
                    case 10:
                        for (int j = 1; j <= AvsCount; j++)
                        {
                            if (AvsStates[j].Mode == VsMode.osn && !AvsStates[j].StopBlocked)
                            {
                                if (AvsStates[j].WaitFutureStart || AvsStates[j].WaitApv)
                                {
                                    AutoCmds[j].SilentStop = true;
                                    WorkDelta = WorkDelta - 1;
                                }
                            }
                            //КОМАНДА ВЫПОЛНЕНА
                            if (WorkDelta <= 0)
                            {
                                GroupStateMachineStep = 0;
                                break;
                            }
                        }
                        //ОТПРАВЛЕНЫ КОМАНДЫ НА ОТМЕНУ ОТЛОЖЕННОГО ПУСКА ВСЕХ ОСНОВНЫХ
                        if (WorkDelta > 0)
                        {
                            GroupStateMachineStep = 6;
                        }

                        break;
                    case 6: //ВЫПОЛНЕНИЕ ПРОЦЕДУРЫ ОСТАНОВА ДОПОЛНИТЕЛЬНЫХ
                        for (int j = 1; j <= AvsCount; j++)
                        {
                            if (AvsStates[j].Mode == VsMode.osn && storage.StartedAsDopNum == j && !AvsStates[j].StopBlocked)
                            {
                                if (AvsStates[j].State == VsState.@on || AvsStates[j].State == VsState.starting)
                                {
                                    AutoCmds[j].AutoStart = false;
                                    AutoCmds[j].AutoStop = true;
                                    WorkDelta = WorkDelta - 1;
                                }
                            }
                            //КОМАНДА ВЫПОЛНЕНА
                            if (WorkDelta <= 0)
                            {
                                GroupStateMachineStep = 0;
                                break;
                            }
                        }
                        //ОТПРАВЛЕНЫ КОМАНДЫ НА ОТКЛЮЧЕНИЕ ВСЕХ ДОПОЛНИТЕЛЬНЫХ, НО КОМАНДА НЕ ВЫПОЛНЕНА
                        if (WorkDelta > 0)
                        {
                            GroupStateMachineStep = 7;
                        }

                        break;
                    case 7: //ВЫПОЛНЕНИЕ ПРОЦЕДУРЫ ОСТАНОВА ОСН
                        for (int j = 1; j <= AvsCount; j++)
                        {
                            if (AvsStates[j].Mode == VsMode.osn && storage.StartedAsDopNum != j && !AvsStates[j].StopBlocked)
                            {
                                if (AvsStates[j].State == VsState.@on || AvsStates[j].State == VsState.starting)
                                {
                                    AutoCmds[j].AutoStart = false;
                                    AutoCmds[j].AutoStop = true;
                                    WorkDelta = WorkDelta - 1;
                                }
                            }
                            //КОМАНДА ВЫПОЛНЕНА
                            if (WorkDelta <= 0)
                            {
                                GroupStateMachineStep = 0;
                                break;
                            }
                        } //ОТПРАВЛЕНЫ КОМАНДЫ НА ОТКЛЮЧЕНИЕ ВСЕХ ОСНОВНЫХ, НО КОМАНДА НЕ ВЫПОЛНЕНА

                        if (WorkDelta > 0)
                        {
                            GroupStateMachineStep = 8;
                        }

                        break;
                    case 8: //ВЫПОЛНЕНИЕ ПРОЦЕДУРЫ ОСТАНОВА РУЧ, ЕСЛИ ЕСТЬ БЛОКИРОВКИ ВКЛЮЧЕНИЯ
                        for (int j = 1; j <= AvsCount; j++)
                        {
                            if (AvsStates[j].Mode == VsMode.manual && !AvsStates[j].WorkBlocked)
                            {
                                if (AvsStates[j].State == VsState.@on || AvsStates[j].State == VsState.starting)
                                {
                                    AutoCmds[j].AutoStart = false;
                                    AutoCmds[j].AutoStop = true;
                                    WorkDelta = WorkDelta - 1;
                                }
                            }
                            //КОМАНДА ВЫПОЛНЕНА
                            if (WorkDelta <= 0)
                            {
                                GroupStateMachineStep = 0;
                                break;
                            }
                        }
                        //ОТПРАВЛЕНЫ КОМАНДЫ НА ОТКЛЮЧЕНИЕ ВСЕХ ОСНОВНЫХ, НО КОМАНДА НЕ ВЫПОЛНЕНА
                        if (WorkDelta > 0)
                        {
                            GroupStateMachineStep = 999;
                        }
                        break;
                    case 0:
                        storage.PrevWorkCtrl = WorkCount;
                        break;
                    case 999:
                        exitWhile = true;
                        break;

                }
            }

            //снимаем блокировки при смене режима на не осн
            for (int j = 1; j <= AvsCount; j++)
            {
                if (AvsStates[j].Mode != VsMode.osn && AvsStates[j].StopBlocked)
                {
                    AutoCmds[j].ResetBlocksCmd = true;
                }

                if (AvsStates[j].State == VsState.off && AvsStates[j].StopBlocked)
                {
                    AutoCmds[j].ResetBlocksCmd = true;
                }
            }
            /*
             * ПОСЛЕДОВАТЕЛЬНЫЙ АПВ
             * Если уставка на последовательный АПВ равна 0, то снимаем блокировку АПВ со всех агрегатов
             * Если идет задержка АПВ, то оставляем блокировки как есть и контролируем выполнение АПВ
             * Если агрегат во время пуска снова начал требовать АПВ, то перезапускаем алгоритм
             * Если таймер отсчитал, то ищем агрегат требующий АПВ и снимаем с него блокировку, запускаем таймер
             */
            var flag = false;
            GroupStateMachineStep = 1;
            while (GroupStateMachineStep != -1)
            {
                switch (GroupStateMachineStep)
                {
                    case 1:
                        if (timer.Ust == TimeSpan.Zero)
                        {
                            GroupStateMachineStep = 0;
                            storage.ApvProcessingNum = 0;
                        }
                        else if (!timer.IsStarted)
                        {
                            GroupStateMachineStep = 2;
                        }
                        else if (storage.ApvProcessingNum != 0)
                        {
                            GroupStateMachineStep = 3;
                        }
                        else
                        {
                            GroupStateMachineStep = 0;
                        }

                        break;
                    case 2:
                        var apvNeedExist = false;
                        for (ushort j = 1; j <= AvsCount; j++)
                        {
                            if (AvsStates[j].WaitApv)
                            {
                                apvNeedExist = true;
                                if (AvsSignals[j].Ec && AvsSignals[j].SecEc)
                                {
                                    timer.Start();
                                    storage.ApvProcessingNum = j;
                                    break;
                                }
                            }
                        }

                        if (!apvNeedExist)
                        {
                            storage.ApvProcessingNum = 0;
                        }

                        GroupStateMachineStep = 0;

                        break;
                    case 3:
                        var apvFail = false;
                        for (int j = 1; j <= AvsCount; j++)
                        {
                            //Пропало напряжение на том кого запускали
                            if (AvsStates[j].WaitApv && storage.ApvProcessingNum == j)
                            {
                                timer.Stop();
                                storage.ApvProcessingNum = 0;
                                GroupStateMachineStep = 1;
                                apvFail = true;
                                break;
                            }
                        }

                        if (!apvFail)
                        {
                            GroupStateMachineStep = 0;
                        }

                        break;
                    case 0:
                        for (int j = 1; j <= AvsCount; j++)
                        {
                            if (storage.ApvProcessingNum == 0)
                            {
                                AutoCmds[j].ResetBlocksApvCmd = true;
                            }
                            else if (j == storage.ApvProcessingNum)
                            {
                                AutoCmds[j].ResetBlocksApvCmd = true;
                            }
                            else
                            {
                                AutoCmds[j].BlockApv = true;
                            }

                        }

                        GroupStateMachineStep = -1;
                        break;
                }
            }
            /*
             * Алгоритм переназначения резервного агрегата:
             * Вначале ищем остановленный основной готовый быть горячим резервом
             * если не нашли ждем пока закончится остановка последнего в ОСН для назначения резерва ему
             * если все основные уже остановлены, то пытаемся назначить один из работающих дополнительным
             * если ничего не нашли - потеряли резерв
             */
            if (storage.ReorderRez)
            {
                storage.BlockResetAvr = true;
                var osnNotReadyExist = false;
                for (int j = 1; j <= AvsCount; j++)
                {
                    if (AvsStates[j].Mode == VsMode.osn && AvsStates[j].State == VsState.off)
                    {
                        if (!AvsStates[j].WaitFutureStart && j != storage.SetRezNum)
                        {
                            if (AvsSignals[j].Ec && AvsSignals[j].SecEc)
                            {
                                /*1-37*/
                                var lastNeedAvr = false;
                                if (storage.NeedReorderRezNum != 0)
                                {
                                    if (AvsStates[storage.NeedReorderRezNum].NeedAvr && OsnCount == 1)
                                    {
                                        lastNeedAvr = true;
                                    }
                                }
                                else
                                {
                                    lastNeedAvr = OsnCount == 1;
                                }
                                if (OsnCount > 1 || lastNeedAvr)
                                {
                                    AutoCmds[j].SetMode = VsMode.rez;
                                    storage.RezNum = j;
                                }
                                storage.ReorderRez = false;
                                storage.SetRezNum = 0;
                                break;
                            }
                            else
                            {
                                osnNotReadyExist = true;
                            }
                        }
                    }
                }

                if (!OsnOstanovExist && storage.ReorderRez && !osnNotReadyExist)
                {
                    if (storage.NeedReorderRezNum != 0)
                    {
                        if (AvsStates[storage.NeedReorderRezNum].Mode == VsMode.osn && (AvsStates[storage.NeedReorderRezNum].State == VsState.@on || AvsStates[storage.NeedReorderRezNum].State == VsState.starting))
                        {
                            AutoCmds[storage.NeedReorderRezNum].MarkAsDop = true;
                            storage.StartedAsDopNum = storage.NeedReorderRezNum;
                        }
                    }
                    if (OsnCount >= 1 && storage.StartedAsDopNum == 0)
                    {
                        for (int j = 1; j <= AvsCount; j++)
                        {
                            if (AvsStates[j].Mode == VsMode.osn && AvsStates[j].State == VsState.@on &&
                                j != storage.SetRezNum)
                            {
                                AutoCmds[j].MarkAsDop = true;
                                storage.StartedAsDopNum = j;
                                break;
                            }
                        }
                    }

                    storage.ReorderRez = false;
                    storage.SetRezNum = 0;
                }
            }
            /*
             * Алгоритм включения резервного агрегата:
             * Не выполняем алгоритм если идет переназначение резерва
             * Ищем агрегат требующий АВР, если такого нет, то АПВ. Если не нашли завершаем алгоритм
             * Если нашли, ищем резервный агрегат
             * Если нашли, то запускаем его.
             */
            else if (storage.DoAvr || DoApv)
            {
                //ищем агрегат, требующий включения резерва
                var avrFrom = 0;
                for (int j = 1; j <= AvsCount; j++)
                {
                    if (AvsStates[j].NeedAvr)
                    {
                        avrFrom = j;
                        break;
                    }
                }

                //не нашли агрегат требующий АВР, выбираем агрегат требующий АПВ
                for (int j = 1; j <= AvsCount; j++)
                {
                    if (AvsStates[j].WaitApv && avrFrom == 0 && !timer.IsStarted)
                    {
                        avrFrom = j;
                        break;
                    }
                }

                //
                if (avrFrom == 0 && storage.NeedReorderRezNum != 0)
                {
                    avrFrom = storage.NeedReorderRezNum;
                    storage.NeedReorderRezNum = 0;
                }


                if (avrFrom != 0)
                {
                    var rezWasFound = false;
                    ushort avrTo;
                    //ищем горячий резерв резерв 
                    for (avrTo = 1; avrTo <= AvsCount; avrTo++)
                    {
                        if (AvsStates[avrTo].Mode == VsMode.rez && AvsStates[avrTo].State == VsState.off &&
                            AvsSignals[avrTo].Ec && AvsSignals[avrTo].SecEc)
                        {
                            AutoCmds[avrTo].ResStart = true;
                            storage.ReorderRez = true;
                            storage.SetRezNum = avrTo;
                            rezWasFound = true;
                            timer.Start();
                            storage.ApvProcessingNum = avrTo;
                            break;
                        }
                    }

                    //не нашли, делаем отложенный пуск резервного
                    if (!rezWasFound && storage.DoAvr)
                    {

                        for (avrTo = 1; avrTo <= AvsCount; avrTo++)
                        {
                            if (AvsStates[avrTo].Mode == VsMode.rez && AvsStates[avrTo].State == VsState.off)
                            {
                                AutoCmds[avrTo].ResStart = true;
                                rezWasFound = true;
                                break;
                            }
                        }
                    }

                    //АВР выполнен - перебрасываем блокировки
                    if (rezWasFound)
                    {
                        AutoCmds[avrFrom].ResetBlocksCmd = true;
                        AutoCmds[avrTo].BlockStop = AvsStates[avrFrom].StopBlocked;

                        AutoCmds[avrTo].ResetBlocksCmd = true;
                        AutoCmds[avrFrom].BlockWork = AvsStates[avrTo].WorkBlocked;

                        AutoCmds[avrFrom].SilentStop = true;
                        if (FireProtectProcessing)
                        {
                            AutoCmds[avrFrom].SetMode = VsMode.manual;
                            AutoCmds[avrFrom].AutoStop = true;
                        }
                    }

                    //выполняем повторное включение пожнасосов
                    //TODO сделать через АПВ
                    for (int i = 1; i <= AvsCount; i++)
                    {
                        if (AvsStates[i].Mode == VsMode.osn && AvsStates[i].State == VsState.off && AvsStates[i].NeedAvr &&
                            !AvsStates[i].Crash && AvsSignals[i].Ec && AvsSignals[i].SecEc && AutoCmds[i].SetMode != VsMode.manual)
                        {
                            AutoCmds[i].AutoStart = true;
                        }
                    }
                }
            }

            for (int i = 1; i <= AvsCount; i++)
            {
                AutoCmds[i].FireProtectProcessing = FireProtectProcessing;
                if (rezNum != 0)
                {
                    AutoCmds[i].ReserveStatus = ReserveGroupStatus.ResExist;
                }
                else if (OsnCount > 1)
                {
                    AutoCmds[i].ReserveStatus = ReserveGroupStatus.AllowSetRez;
                }
                else if (OsnCount == 1)
                {
                    AutoCmds[i].ReserveStatus = ReserveGroupStatus.AllowSetForNotOsn;
                }
                else
                {
                    AutoCmds[i].ReserveStatus = ReserveGroupStatus.NotEnoughOsn;
                }
            }
        }
      
    }
    /// <summary>
    /// Структура состояния Grpvs
    /// </summary>
    public class GrpvsStorage
    {
        /// <summary>
        /// НОМЕР ВС КОТОРАЯ УЧАСТВУЕТ В ПРОЦЕДУРЕ ОТЛОЖЕННОГО АПВ
        /// </summary>
        public uint ApvProcessingNum;   /*НОМЕР ВС КОТОРАЯ УЧАСТВУЕТ В ПРОЦЕДУРЕ ОТЛОЖЕННОГО АПВ*/
        /// <summary>
        /// НОМЕР ВС КОТОРЫЙ НЕ НУЖНО СТАВИТЬ В РЕЗЕРВ, она сама пытается установить другую ВС в резерв
        /// </summary>
        public int SetRezNum;  /*НОМЕР ВС КОТОРЫЙ НЕ НУЖНО СТАВИТЬ В РЕЗЕРВ, она сама пытается установить другую ВС в резерв*/
        public bool DoAvr;
        public bool ReorderRez; /*НЕЛЬЗЯ СБРАСЫВАТЬ В КАЖДОМ ЦИКЛЕ*/
        public int NeedReorderRezNum;
        public bool BlockResetAvr;
        public int PrevWorkCtrl;
        public int StartedAsDopNum;
        public int RezNum;
    }
}
