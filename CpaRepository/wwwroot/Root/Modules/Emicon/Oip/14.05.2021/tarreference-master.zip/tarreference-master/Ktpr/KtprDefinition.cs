﻿using TarReferenceSource.Ktpra;

namespace TarReferenceSource.Ktpr
{
    public enum NsStopType : ushort
    {
        StopAllInShoulder = 1,
        StopOneByOneInShoulder = 2,
        StopFirstNextInShoulder = 3,
        StopOnlyFirstInShoulder = 4,
        StopAllInSubShoulder = 5,
        None = 6
    }
    public enum ProcKtprCmd : ushort
    {
        None = 0,
        Mask = 1,
        UnMask = 2,
        Deblock = 3
    }
    /// <summary>
    /// Выходные даные из модуля ProcKtpr
    /// </summary>
    public class ProcKtprResult
    {
        /// <summary>
        /// Флаг аварийного параметра агрегатной защиты
        /// </summary>
        public bool F;
        /// <summary>
        /// Флаг маскирования агрегатной защиты
        /// </summary>
        public bool M;
        /// <summary>
        /// Флаг срабатывание агрегатной защиты
        /// </summary>
        public bool P;
        /// <summary>
        /// Настроечный флаг запрета маскирования защиты.
        /// </summary>
        public bool NotMasked;
    }
    /// <summary>
    /// Данные для конфигурации модуля ProcKtpr
    /// </summary>
    public class ProcKtprConfig
    {
        /// <summary>
        /// Тип остановки, производимой по результатам срабатывания защиты.
        /// </summary>
        public NsStopType AutoStopCmd;
        /// <summary>
        /// Способ остановки агрегатов 
        /// </summary>
        public NaStopType AutoStopCmdMethod;
        /// <summary>
        /// Битовая маска принадлежности защита группе. 1 в N-м бите – разрешение сработки данной защиты на N-й группе 
        /// </summary>
        public int GroupMap;
        /// <summary>
        /// Настроечный флаг автоматической деблокировки защиты
        /// </summary>
        public bool AutoDeblock;
        /// <summary>
        /// Настроечный флаг запрета маскирования защиты.
        /// </summary>
        public bool NotMasked;
    }
}
