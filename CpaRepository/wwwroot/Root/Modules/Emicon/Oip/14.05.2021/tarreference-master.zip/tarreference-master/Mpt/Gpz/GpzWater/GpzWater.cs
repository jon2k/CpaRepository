﻿using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarReferenceSource.Mpt.Gpz.GpzFoam;

namespace TarReferenceSource.Mpt.Gpz.GpzWater
{
    public class GpzWater : GpzWaterIo
    {
		/// <summary>
		/// Обобщенный флаг готовности защищаемого резервуара к водоорошению.
		/// </summary>
		private bool _flReady; // Обобщенный флаг готовности защищаемого резервуара к водоорошению.
		/// <summary>
		/// Входной параметр блока ProcGpz.
		/// </summary>
		private bool _procInput; // Входной параметр блока ProcGpz.

		public GpzWater()
		{
			Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
		}

        public override void Execute()
        {
			if (Source.IsRem || Source.SuccessfulStart)
			{
				Out = GpzState.NoControl;
				for (int i = 1; i <= Source.ReadinesCount; i++)
				{
					Output[i] = true;
				}
			}
			else
			{
				_flReady = true;
				for (int i = 1; i <= Source.ReadinesCount; i++)
				{ // Цикл по параметрам готовности
					if (!Source.CfgDisabled[i])
					{  // Флаг необходимости проверки готовности
						switch (i)
						{
							case 1:
								_procInput = Source.OsnIsprCount >= Source.CfgPumpsNeeded;                       // ОТСУТСТВИЕ ИСПРАВНЫХ НАСОСОВ В РЕЖИМЕ ОСНОВНОЙ
								break;
							case 2:
								_procInput = !Source.GeneralWaterLineAnyErr;                                        // ЗАДВИЖКА  БЩЕЙ ЛИНИИ НЕИСПРАВНА
								break;
							case 3:
								_procInput = !Source.GeneralWaterLineAnyImit;                                       // ЗАДВИЖКА ОБЩЕЙ ЛИНИИ В РЕЖИМЕ «ИМИТ»
								break;
							case 4:
								_procInput = !Source.SelfWaterLineAnyErr;                                       // ЗАДВИЖКА ЛИНИИ СООРУЖЕНИЯ НЕИСПРАВНА
								break;
							case 5:
								_procInput = !Source.SelfWaterLineAnyImit;                                       // ЗАДВИЖКА ЛИНИИ СООРУЖЕНИЯ В РЕЖИМЕ «ИМИТ»
								break;
							case 6:
								_procInput = Source.SupIsAuto;                                                 // РЕЖИМ АВТОМАТИЧЕСКОГО ТУШЕНИЯ ОТКЛЮЧЕН
								break;
							case 7:
								_procInput = true;
								for (int j = 1; j <= Source.CountProt; j++)
								{
									_procInput = _procInput && !Source.ProtM;                               // МАСКИРОВАНИЕ ЗАЩИТЫ ПО ПОЖАРУ
								}
								break;
						}

						if (_procInput && !Output[i])
						{
							Output[i] = true;
							Messenger.Send(2 + i * 2);
						}
						else if (!_procInput && Output[i])
						{
							Output[i] = false;
							Messenger.Send(3 + i * 2);
						}

						_flReady = _flReady && Output[i]; // Обобщенный флаг готовности защищаемого сооружения к пенотушению
					}
				}


				if (_flReady && Out != GpzState.Ready)
				{
					Messenger.Send(1);       // ГОТОВ К АВТОМАТИЧЕСКОМУ ТУШЕНИЮ
				}
				if (!_flReady && Out != GpzState.NotReady)
				{
					Messenger.Send(2);       // НЕ ГОТОВ К АВТОМАТИЧЕСКОМУ ТУШЕНИЮ
				}
				Out = _flReady ? GpzState.Ready : GpzState.NotReady;                // Флаг готовности
			}
		}
    }
}
