﻿using System;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.St;
using TarReferenceSource.Common.Timer;
using TarReferenceSource.Ktpr;
using TarReferenceSource.Ktpra;

namespace TarReferenceSource
{
    public class ProcKtpra : ProcKtpraIo
    {
        public ITimer T01;
        /// <summary>
        /// 
        /// </summary>
        private bool InnerP;
        /// <summary>
        /// Состояние алгоритма обработки защиты
        /// </summary>
        private int State;

        public ProcKtpra()
        {
            T01 = new CpaLocalTimer();
            InternalTimers = new StArray<ITimer>(1, new []{T01});
        }

        public override void Execute()
        {
            Result.F = Input;

            if (Cfg.NotMasked)
            {
                Result.M = false;
            }
            if (Cmd == ProcKtpraCmd.Mask)
            {
                Messenger.Send(001);/*принята команда установить режим "Маскирование для защиты i (1)*/
                if (Cfg.NotMasked)
                {
                    Messenger.Send(002);/* защиты i не маскируется. выполение не возможно(2)*/
                }
                else
                {
                    if (!Result.M)
                    {  /*ВОПРОС к блок схеме ТПР почему так? по запрету же сброшено? получим "не возможно" и следом "установлено" а в влед цикле сброшено */
                        Messenger.Send(003);/* защита i - маскирование установлено(3)*/
                        Result.M = true;
                    }
                    else
                    {
                        Messenger.Send(004);/* защита i - маскирование установлено. Выполнение не требуется (4)*/
                    }
                }
            }
            if (Cmd == ProcKtpraCmd.UnMask)
            {
                Messenger.Send(005);/*принята команда снять "Маскирование для защиты i (5)*/
                if (Result.M)
                {
                    Messenger.Send(006);/* защита i - маскирование снято(6)*/
                    Result.M = false;
                }
                else
                {
                    Messenger.Send(007);/* защита i - маскирование снято. Выполнение не требуется(7)*/
                }
            }
            if (Cmd == ProcKtpraCmd.Deblock)
            {
                Messenger.Send(008);/*защита i -принята команда  "Деблокировать"  (8)*/
                if (Result.P)
                {
                    if (Input && !Result.M)
                    {
                        Messenger.Send(009);/* защита i - деблокирование невозможно. Сигнал не снят(9)*/
                    }
                    else if (!NaIsOff)
                    {
                        Messenger.Send(016);/* защита i - деблокирование невозможно. Агрегат не остановлен(16)*/
                    }
                    else
                    {
                        Messenger.Send(010);/* защита i - деблокирована (10)*/
                        State = 5;
                        Result.P = false;
                    }
                }
                else
                {
                    Messenger.Send(011);/* защита i - Деблокирована. Выполнение не требуется(11)*/
                }
            }           
            if (!Input)
            {
                T01.Start();
            }
            
            if ((Input && !T01.IsStarted) || Result.P || (T01.Ust == TimeSpan.Zero && Input))
            {
                InnerP = true;
            }
            else
            {
                InnerP = false;
            }
            if (State == 0)
            {
                if (Result.F)
                {
                    if (T01.Ust > TimeSpan.Zero)
                    {
                        Messenger.Send(012);/*защита i - взведена (12)*/
                    }
                    State = 10;
                }
            }
            if (State == 5)
            {  /*деблокирована*/
                if (Result.F)
                {
                    State = 10;
                }
                else
                {
                    State = 0;
                }
            }
            if (State == 10)
            { /*взведение защиты*/
                if (!Result.F)
                {
                    Messenger.Send(013);/*защита i - авар. параметр снят (13)*/
                    State = 0;
                }
                if (InnerP)
                {
                    State = 20;
                }
            }
            if (State == 20)
            { /*срабатывание защиты*/
                if (!Result.M)
                {
                    Messenger.Send(014);/*защита i  (14)*/
                    Result.P = true;
                    State = 25;
                }
                else
                {
                    Messenger.Send(015);/*защита i - игнор (15)*/
                    State = 22;
                }
            }
            if (State == 22)
            { /*маска, наличие авар параметра*/
                if (!Result.F)
                {
                    Messenger.Send(013);/*защита i - авар. параметр снят (13)*/
                    State = 0;
                }
                else if (!Result.M)
                { /*сняли маску*/
                    Messenger.Send(014);/*защита i  (14)*/
                    Result.P = true;
                    State = 25;
                }
            }
            if (State == 25)
            { /*снятие праметра, сработанной защиты*/
                if (!Result.F)
                {
                    Messenger.Send(013);/*защита i - авар. параметр снят (13)*/
                    State = 27;
                }
            }
            if (State == 27)
            { /*маска, нет авар параметра*/
                if (Result.F)
                {
                    Messenger.Send(012);/*аварийный параметр установлен*/
                    State = 25;
                }
            }
            Result.NotMasked = Cfg.NotMasked;
        }
    }
}
