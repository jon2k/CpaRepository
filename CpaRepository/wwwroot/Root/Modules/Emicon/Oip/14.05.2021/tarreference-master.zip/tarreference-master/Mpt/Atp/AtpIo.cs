﻿using System;
using System.Collections.Generic;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;

namespace TarReferenceSource.Mpt.Atp
{
    public enum enumATPCmd : ushort
    {
        None = 0,
        StartCmd,      //Команда - старт пожаротушения
        StopCmd,       //Команда - стоп пожаротушения
        ContinueCmd,   //Команда - продолжить пожаротушения
        NonContinueCmd //Команда - не продолжать тушение пожара
    }

    public enum enumATPMainState : ushort
    {
        None = 0,
        Idle = 10,    //остановлено
        Paused = 15,    //остановлено с возможностью повторного запуска
        DoStop = 20,    //останавливается. начало
        ProcStop = 25,    //останавливается
        DoStart = 30,    //запускается. начало
        ProcStart = 35,    //запускается
        Work = 40,     //в работе
        WaitWork = 45
    }
    /// <summary>
    /// Конфигурация модуля тушения пожара
    /// </summary>
    public class AtpCfg
    {/// <summary>
    /// 
    /// </summary>
        public ushort Offset;
        /// <summary>
        /// Количество пенных атак
        /// </summary>
        public ushort MaxFires;
        /// <summary>
        /// Флаг определяющий поведение алгоритма после окончания последней пенной атаки и отсутствия ответа от оператора. 0 – продолжение пожаротушения без остановок
        /// </summary>
        public bool stopAfterMaxFires;
    }
    /// <summary>
    /// Выходная информация модуля алгоритма пожаротушения
    /// </summary>
    public struct AtpOutput
    {
        /// <summary>
        /// Флаг включения исполнительных механизмов
        /// </summary>
        public bool flStart;
        /// <summary>
        /// Флаг отключения исполнительных механизмов
        /// </summary>
        public bool flStop;
        /// <summary>
        /// Флаг отображения окна повторной атаки
        /// </summary>
        public bool flContinueCheck;
        /// <summary>
        /// Флаг отображения окна остановки пожаротушения
        /// </summary>
        public bool flStopCheck;
        /// <summary>
        /// Флаг включения защиты по пожару
        /// </summary>
        public bool flFire;
    }
    /// <summary>
    /// Структура, хранящая основные состояния алгоритма
    /// </summary>
    public struct AtpStorage
    {
        /// <summary>
        /// Основное состояние алгоритма
        /// </summary>
        public enumATPMainState MainState;
        /// <summary>
        /// Предыдущее состояние требования к тушению
        /// </summary>
        public bool prevFire;
        /// <summary>
        /// Флаг подтверждения продолжения пожаротушения
        /// </summary>
        public bool ContinuationConfirmed;
        /// <summary>
        /// Флаг подтверждения остановки пожаротушения
        /// </summary>
        public bool StopConfirmed;
        /// <summary>
        /// Количество тушений
        /// </summary>
        public int Counter;
    }

    public abstract class AtpIo : IFunctionBlock
    {
        public AtpIo()
        {
            Description.TimerDescriptions = TimerDescriptions;
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }
        /// <summary>
        /// input Команда с АРМ оператора
        /// </summary>
        public enumATPCmd cmd;
        /// <summary>
        /// input Требование к запуску алгоритма пожаротушения
        /// </summary>
        public bool doFirefight;
        /// <summary>
        /// input Возможность запуска алгоритма тушения пожара
        /// </summary>
        public bool canFirefight;
        /// <summary>
        /// input Условие запущенности оборудования пожаротушения
        /// </summary>
        public bool flWorkState;
        /// <summary>
        /// input Условие остановки оборудования пожаротушения 
        /// </summary>
        public bool flStopState;
        /// <summary>
        /// input Конфигурация модуля
        /// </summary>
        public AtpCfg cfg = new AtpCfg();
        /// <summary>
        /// input Наличие сработки новой защиты
        /// </summary>
        public bool NewFireProtection;
        /// <summary>
        /// output Выходные параметры модуля 
        /// </summary>
        public AtpOutput output;
        /// <summary>
        /// output  Счетчик тушений пожара
        /// </summary>
        public int Counter;

        public override void AfterCall()
        {
            cmd = enumATPCmd.None;
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {
            {1, new MessageDescription{Text = "КОМАНДА ПУСК АВТОМАТИЧЕСКИ", Type = MessageType.Neutral} },
            {2, new MessageDescription{Text = "ПУСК НЕВОЗМОЖЕН. РЕЖИМ АВТОМАТИЧЕСКИЙ СБРОШЕН", Type = MessageType.Neutral} },
            {3, new MessageDescription{Text = "ВЫПОЛНЯЕТСЯ ЗАДЕРЖКА ПУСКА ПЕНОТУШЕНИЯ", Type = MessageType.Neutral} },
            {4, new MessageDescription{Text = "ЗАДЕРЖКА ПУСКА ЗАВЕРШЕНА", Type = MessageType.Neutral} },
            {5, new MessageDescription{Text = "КОМАНДА ПУСК С АРМ", Type = MessageType.Information} },
            {6, new MessageDescription{Text = "ПУСК НЕВОЗМОЖЕН. ПОЖАРОТУШЕНИЕ НЕ БЫЛО ОСТАНОВЛЕНО ПО КОМАНДЕ ОПЕРАТОРА", Type = MessageType.Neutral} },
            {7, new MessageDescription{Text = "ПУСК НЕ ТРЕБУЕТСЯ. ИДЕТ ПУСК ПОЖАРОТУШЕНИЯ", Type = MessageType.Neutral} },
            {8, new MessageDescription{Text = "ПУСК НЕ ТРЕБУЕТСЯ. ПОЖАРОТУШЕНИЕ В РАБОТЕ", Type = MessageType.Neutral} },
            {9, new MessageDescription{Text = "КОМАНДА СТОП С АРМ", Type = MessageType.Information} },
            {10, new MessageDescription{Text = "СТОП НЕ ТРЕБУЕТСЯ. ПОЖАРОТУШЕНИЕ ОСТАНОВЛЕНО", Type = MessageType.Neutral} },
            {11, new MessageDescription{Text = "СТОП НЕ ТРЕБУЕТСЯ. ИДЕТ ОСТАНОВКА ПОЖАРОТУШЕНИЯ", Type = MessageType.Neutral} },
            {12, new MessageDescription{Text = "КОМАНДА ПРОДОЛЖИТЬ ПОЖАРОТУШЕНИЕ", Type = MessageType.Information} },
            {13, new MessageDescription{Text = "КОМАНДА ОТКЛОНЕНА", Type = MessageType.Neutral} },
            {14, new MessageDescription{Text = "ПРИНЯТО РЕШЕНИЕ ПРОДОЛЖИТЬ ТУШЕНИЕ", Type = MessageType.Information} },
            {15, new MessageDescription{Text = "КОМАНДА ЗАКОНЧИТЬ ПОЖАРОТУШЕНИЕ", Type = MessageType.Information} },
            {16, new MessageDescription{Text = "ПРИНЯТО РЕШЕНИЕ ЗАКОНЧИТЬ ТУШЕНИЕ", Type = MessageType.Information} },
            {17, new MessageDescription{Text = "ПОЖАРОТУШЕНИЕ ОСТАНОВЛЕНО", Type = MessageType.Attention} },
            {18, new MessageDescription{Text = "ЗАПУСК ПОЖАРОТУШЕНИЯ", Type = MessageType.Attention} },
            {19, new MessageDescription{Text = "ПОЖАРОТУШЕНИЕ В РАБОТЕ", Type = MessageType.Attention} },
            {20, new MessageDescription{Text = "ЗАПУСК ПОЖАРОТУШЕНИЯ НЕ ОКОНЧЕН В ЗАДАННОЕ ВРЕМЯ", Type = MessageType.Alarm} },
            {21, new MessageDescription{Text = "ОСТАНОВКА ПОЖАРОТУШЕНИЯ", Type = MessageType.Attention} },
            {22, new MessageDescription{Text = "ОСТАНОВКА ПОЖАРОТУШЕНИЯ НЕ ОКОНЧЕНА В ЗАДАННОЕ ВРЕМЯ", Type = MessageType.Alarm} },
            {23, new MessageDescription{Text = "ОКОНЧАНИЕ РЕГЛАМЕНТНОГО ВРЕМЕНИ ТУШЕНИЯ. ОПЕРАТОРУ НЕОБХОДИМО ПРИНЯТЬ РЕШЕНИЕ", Type = MessageType.Attention} },
            {24, new MessageDescription{Text = "ПРОДОЛЖЕНИЕ ПОЖАРОТУШЕНИЯ", Type = MessageType.Attention} },
            {25, new MessageDescription{Text = "ПОДТВЕРЖДЕНИЕ ПРОДОЛЖЕНИЯ ПОЖАРОТУШЕНИЯ НЕ ПОЛУЧЕНО. ПРОДОЛЖЕНИЕ ПОЖАРОТУШЕНИЯ", Type = MessageType.Information} },
            {26, new MessageDescription{Text = "ВРЕМЯ ТУШЕНИЯ ОБЪЕКТА ЗАКОНЧИЛОСЬ. ОСТАНОВКА ПОЖАРОТУШЕНИЯ", Type = MessageType.Information} },
            {27, new MessageDescription{Text = "ПОДТВЕРЖДЕНИЕ ОСТАНОВКИ ПОЖАРОТУШЕНИЯ НЕ ПОЛУЧЕНО. ПРОДОЛЖЕНИЕ ПОЖАРОТУШЕНИЯ", Type = MessageType.Information} },
            {28, new MessageDescription{Text = "ПУСК ПЕНОТУШЕНИЯ ОТМЕНЕН", Type = MessageType.Neutral} },
        };
        protected static Dictionary<int, TimerDescription> TimerDescriptions = new Dictionary<int, TimerDescription>
        {
            {1, new TimerDescription("Таймер задержки атаки", TimeSpan.FromMilliseconds(1000)) },
            {2, new TimerDescription("Таймер подтверждения атаки ", TimeSpan.FromMilliseconds(7000)) },
            {3, new TimerDescription("Таймер следующей атаки", TimeSpan.FromMilliseconds(15000)) },
            {4, new TimerDescription("Таймер контрольный процесса запуска тушения", TimeSpan.FromMilliseconds(1000)) },
            {5, new TimerDescription("Таймер контрольный процесса останова тушения", TimeSpan.FromMilliseconds(1000)) }
        };
    }
}
