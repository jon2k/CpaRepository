﻿using TarFoundation.St;
using TarReferenceSource.Mpt.Ubd.ProcUbd;

namespace TarReferenceSource.Mpt.Ubd.UbdGrp
{
    /// <summary>
    /// Выходные данные модуля UbdGrp
    /// </summary>
    public class structUbdGrpOutput
    {
        /// <summary>
        /// Все баки полны
        /// </summary>
        public bool allLowFull;
        /// <summary>
        /// Все баки исправны
        /// </summary>
        public bool allNotCrashed;
        /// <summary>
        /// Все баки не в имитации
        /// </summary>
        public bool allNotImit;
        /// <summary>
        /// Хотя бы один бак не пустой
        /// </summary>
        public bool haveNotEmpty;
        /// <summary>
        /// КОличество готовых баков
        /// </summary>
        public uint readyCount;
        /// <summary>
        /// Все баки закрыты
        /// </summary>
        public bool allClose;
        /// <summary>
        /// КОличество открытых баков
        /// </summary>
        public ushort openCount;
        /// <summary>
        /// КОличество баков в основном и резервном режимах
        /// </summary>
        public ushort osnRezCount;
        //public ushort osnCount;
    }
    /// <summary>
    /// Входные данные для UbdGrp
    /// </summary>
    public class structUbdGrpInput
    {
        /// <summary>
        /// Кол-во баков дозаторов, которое необходимо открыть
        /// </summary>
        public ushort NeedOpenCount; //Кол-во баков дозаторов, которое необходимо открыть
        /// <summary>
        /// Тушение
        /// </summary>
        public bool FirefightStart;
        /// <summary>
        /// Остановка тушения
        /// </summary>
        public bool FirefightStop;
    }
    public abstract class UbdGrpIo : IFunctionBlock
    {
        /// <summary>
        /// input Входные данные
        /// </summary>
        public structUbdGrpInput input;
         /// <summary>
         /// output Выходные данные
         /// </summary>
        public structUbdGrpOutput output;
        /// <summary>
        /// input Массив баков-дозаторов
        /// </summary>
        public StArray<ProcUbdIo> bd { get; }
        /// <summary>
        /// output Количество баков-дозаторов
        /// </summary>
        public int UbdCount => bd.Count;

        public UbdGrpIo(ProcUbdIo[] bds)
        {
            bd = new StArray<ProcUbdIo>(1, bds);
            input = new structUbdGrpInput();
            output = new structUbdGrpOutput();
        }
    }
}
