﻿using TarReferenceSource.Uzd;
using TarFoundation.St;

namespace TarReferenceSource.Mpt.Gpz.ZdLine
{
    public abstract class ZdLineIo : IFunctionBlock
    {
        // in
        /// <summary>
        /// input Массив состояний задвижек, входящих в пенолинию.
        /// </summary>
        public StArray<ZdOut> Zds; // Массив состояний задвижек, входящих в пенолинию.
        /// <summary>
        /// input Количество задвижек в линии.
        /// </summary>
        public int MaxZdLineCount; // Количество задвижек в линии.

        // out
        /// <summary>
        /// output Наличие хоть одной аварии в всех задвижках.
        /// </summary>
        public bool AnyErr; // Наличие хоть одной аварии в всех задвижках.
        /// <summary>
        /// output Наличие хоть одной задвижки в режиме имитации.
        /// </summary>
        public bool AnyImit; // Наличие хоть одной задвижки в режиме имитации.

        public ZdLineIo(ZdOut[] zdOuts)
        {
            Zds = new StArray<ZdOut>(1, zdOuts);
        }

    }
}
