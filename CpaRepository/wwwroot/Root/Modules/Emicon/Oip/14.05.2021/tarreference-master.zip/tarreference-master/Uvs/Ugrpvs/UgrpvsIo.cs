﻿using System;
using System.Collections.Generic;
using System.Linq;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.St;
using TarReferenceSource.Uvs;

namespace TarReference.InteractionStorages
{
    public abstract class GrpvsIo : IFunctionBlock
    {
        public GrpvsIo(ProcAvsIo[] avs)
        {
            AutoCmds = new StArray<AvsAutoCmds>(1, avs.Select(x => x.AutoCmd).ToArray());
            AvsStates = new StArray<AvsOuterState>(1, avs.Select(x => x.OuterState).ToArray());
            AvsSignals = new StArray<AvsNu>(1, avs.Select(x => x.Nu).ToArray());
            Description.TimerDescriptions = TimerDescriptions;
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }

        //in
        /// <summary>
        /// input Количество агрегатов в группе
        /// </summary>
        public ushort AvsCount;
        /// <summary>
        /// input Флаг тушения пожара
        /// </summary>
        public bool FireProtectProcessing;
        /// <summary>
        /// input Количество агрегатов для запуска 
        /// </summary>
        public short WorkCount;
        /// <summary>
        /// input
        /// </summary>
        public ushort BlockWorkCount;
        /// <summary>
        /// input
        /// </summary>
        public ushort BlockStopCount;
        /// <summary>
        /// input Массив состояний агрегатов вспомсистем
        /// </summary>
        public StArray<AvsOuterState> AvsStates;
        /// <summary>
        /// input Массив данных нижнего уровня от агрегатов вспомсистем
        /// </summary>
        public StArray<AvsNu> AvsSignals;
        //out
        /// <summary>
        /// output Массив данных для каждого агрегата вспомсистемы
        /// </summary>
        public StArray<AvsAutoCmds> AutoCmds;

        //inout

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>();
        protected static Dictionary<int, TimerDescription> TimerDescriptions = new Dictionary<int, TimerDescription>
        {
            {1, new TimerDescription("Задержка между АПВ на нескольких агрегатах", TimeSpan.FromMilliseconds(1000)) }        
        };
    }
}
