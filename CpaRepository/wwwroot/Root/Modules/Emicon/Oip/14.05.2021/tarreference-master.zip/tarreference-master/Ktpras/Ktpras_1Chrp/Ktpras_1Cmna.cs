﻿using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using System.Linq;
using TarFoundation.St;

namespace TarReferenceSource.Ktpras.Ktpras_1Chrp
{
    /// <summary>
    /// Внутренее состояние алгоритма Ktpras_1Chrp
    /// </summary>
    internal class KtprasChrpStorage
    {
        /// <summary>
        /// Счетчик циклов ожидания восстановления сигналов «исправность цепей отключения» после выдачи команды «стоп МНА (ПНА)» 
        /// </summary>
        public int StopCounter;
        /// <summary>
        /// Флаг значения "Исправность цепей отключения ВВ МНА (ПНА) (сигнал 1)" на предыдущем цикле работы программы
        /// </summary>
        public bool ECO1_Prev;
        /// <summary>
        /// Флаг значения "Исправность цепей отключения ВВ МНА (ПНА) (сигнал 2)" на предыдущем цикле работы программы
        /// </summary>
        public bool ECO3_Prev;
        /// <summary>
        /// Флаг наличия оперативного напряжения на автоматическом выключателе QF1 (3 А) на предыдущем цикле работы программы
        /// </summary>
        public bool QF3A_Prev;
        /// <summary>
        /// Флаг наличия оперативного напряжения на автоматическом выключателе QF2 (1 А) на предыдущем цикле работы программы
        /// </summary>
        public bool QF1A_Prev;
        /// <summary>
        /// Массив счетчиков циклов определения нажатия на кнопку «стоп» 
        /// </summary>
        public StArray<int> KKCCounter = new StArray<int>(1, Enumerable.Range(1, 10).Select(i => 0).ToArray());
        /// <summary>
        /// Счетчик циклов определения недостоверности сигнала «наличие напряжения в цепях оперативного тока» в случае его исчезновения. Принимаемые значения: 0, 1, 2
        /// </summary>
        public int EC1NdvCounter;
        /// <summary>
        /// Счетчик циклов определения недостоверности сигналов, участвующих в определении наличия напряжения на автоматическом выключателе QF1 (3 A). Принимаемые значения: 0, 1, 2
        /// </summary>
        public int NdvCounter;
    }
    public class Ktpras_1Cmna:Ktpras_1Io
    {
        /// <summary>
        /// Внутреннее состояние алгоритма
        /// </summary>
        private KtprasChrpStorage NA = new KtprasChrpStorage();

        public Ktpras_1Cmna()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }

        public override void Execute()
        {

            /* Команды на агрегат */       
            if (StopCmd)
            {
                NA.StopCounter = Threshold;
            }
            else
            {
                if (NA.StopCounter > 0)
                {
                    NA.StopCounter = NA.StopCounter - 1;
                }
                else if (NA.StopCounter == 0)
                {
                    NA.ECO1_Prev = ECO1; NA.ECO3_Prev = ECO3; /*фиксация предыдущих значений на время команды*/
                }
            }

            var QF3A_Counter = 0;
            var QF1A_Counter = 0;
            /*учет сигналов от кнопок*/
            for (int i = 1; i <= KKCCount; i++)
            {
                if (KKC[i])
                {
                    QF3A_Counter = QF3A_Counter + 1;
                    QF1A_Counter = QF1A_Counter + 1;
                }
            }
            /*21.9*/

            /*учет состояния ЦО1(2) и ЦВ: текущий сигнал без команды или "фиксированный" сигнал при наличии команды*/
            if (NA.StopCounter == 0 && ECO1)
            {
                QF3A_Counter = QF3A_Counter + 1;
            }
            else if (NA.StopCounter > 0 && NA.ECO1_Prev)
            {
                QF3A_Counter = QF3A_Counter + 1;
            }
            if (NA.StopCounter == 0 && ECO3)
            {
                QF3A_Counter = QF3A_Counter + 1;
            }
            else if (NA.StopCounter > 0 && NA.ECO3_Prev)
            {
                QF3A_Counter = QF3A_Counter + 1;
            }

            /*учет оперативного напряжения*/
            if (EC1)
            {
                QF3A_Counter = QF3A_Counter + 1;
                QF1A_Counter = QF1A_Counter + 1;
            }

            /*оценка наличия напряжения за автоматами QF3A и QF1A*/
            QF3A = QF3A_Counter >= 2;
            QF1A = (QF1A_Counter > 1) && QF3A;
            /*21.10*/

            /*отработка сообщений*/
            if (QF3A ^ NA.QF3A_Prev)
            {
                if (QF3A)
                {
                    Messenger.Send(2);              /*ВОССТАНОВЛЕНИЕ ОПЕРАТИВНОГО НАПРЯЖЕНИЯ НА QF1 (3 A) ВВ*/
                }
                else
                {
                    Messenger.Send(1);            /*ИСЧЕЗНОВЕНИЕ ОПЕРАТИВНОГО НАПРЯЖЕНИЯ НА QF1 (3 A) ВВ*/
                }
                NA.QF3A_Prev = QF3A;
            }
            if (QF1A ^ NA.QF1A_Prev)
            {
                if (QF1A)
                {
                    Messenger.Send(4);              /*ВОССТАНОВЛЕНИЕ ОПЕРАТИВНОГО НАПРЯЖЕНИЯ НА QF2 (1 A) ВВ*/
                }
                else
                {
                    Messenger.Send(3);              /*ИСЧЕЗНОВЕНИЕ ОПЕРАТИВНОГО НАПРЯЖЕНИЯ НА QF2 (1 A) ВВ*/
                }
                NA.QF1A_Prev = QF1A;
            }
            /*21.11*/

            /*Срабатывание кнопок*/
            for (int i = 1; i <= KKCCount; i++)
            {
                if (!KKC[i] && QF1A)
                {
                    if (NA.KKCCounter[i] < CounterNdv)
                    {
                        NA.KKCCounter[i] = NA.KKCCounter[i] + 1;
                    }
                    else if (NA.KKCCounter[i] >= CounterNdv)
                    {
                        KKCAlarm[i] = true;
                    }
                }
                else
                {
                    KKCAlarm[i] = false; NA.KKCCounter[i] = 0;
                }
            }

            /*Счетчик недостоверности оперативного напряжения*/
            if (QF1A && !EC1)
            {
                if (NA.EC1NdvCounter < CounterNdv) { NA.EC1NdvCounter = NA.EC1NdvCounter + 1; }
            }
            else
            {
                NA.EC1NdvCounter = 0;
            }
            /*21.12*/

            var flTmp = false;
            for (int i = 1; i <= KKCCount; i++) { flTmp = flTmp || KKC[i]; }/*хотя бы одна кнопка в норме ?*/
            /*Счетчик недостоверности сигалов*/
            if (((flTmp || EC1) && !QF1A) || (( ECO1 || ECO3) && !QF3A))
            {
                if (NA.NdvCounter < CounterNdv)
                {
                    NA.NdvCounter = NA.NdvCounter + 1;
                }
            }
            else
            {
                NA.NdvCounter = 0;
            }

            /*Недостоверность кнопок СТОП*/
            for (int i = 1; i <= KKCCount; i++)
            {
                /*ТПР содержит сообщения только для 4-х кнопок, остальные пришлось располагать в конце*/
                if (NA.NdvCounter >= CounterNdv && KKC[i])
                {
                    if (!KKCNdv[i]) { KKCNdv[i] = true; Messenger.Send(5 + (i - 1) * 2); }  /*СИГНАЛ "АВАРИЙНОЕ ОТКЛЮЧЕНИЕ КНОПКОЙ СТОП Y" НЕДОСТОВЕРЕН*/
                }
                else
                {
                    if (KKCNdv[i]) { KKCNdv[i] = false; Messenger.Send(5 + (i - 1) * 2 + 1); }                    /*СИГНАЛ "АВАРИЙНОЕ ОТКЛЮЧЕНИЕ КНОПКОЙ СТОП Y" ДОСТОВЕРЕН*/
                }
            }
            /*21.13*/

            /*Недостоверность оперативного напряжения*/
            if ((NA.NdvCounter >= CounterNdv && EC1) || NA.EC1NdvCounter >= CounterNdv)
            {
                if (!EC1_Ndv) { EC1_Ndv = true; Messenger.Send(13); }     /*СИГНАЛ "НАЛИЧИЕ НАПРЯЖЕНИЯ В ЦЕПЯХ ОПЕРАТИВНОГО ТОКА" ВВ НЕДОСТОВЕРЕН*/
            }
            else
            {
                if (EC1_Ndv) { EC1_Ndv = false; Messenger.Send(14); }                    /*СИГНАЛ "НАЛИЧИЕ НАПРЯЖЕНИЯ В ЦЕПЯХ ОПЕРАТИВНОГО ТОКА" ВВ ДОСТОВЕРЕН*/
            }

            /* Недостоверность цепей включения / отключения */
            if ((NA.NdvCounter >= CounterNdv) && !QF3A && ECO1)
            {
                if (!ECO1_Ndv) { ECO1_Ndv = true; Messenger.Send(15); }      /*СИГНАЛ "ИСПРАВНОСТЬ ЦЕПЕЙ ОТКЛЮЧЕНИЯ ВВ (УСО1)" НЕДОСТОВЕРЕН*/
            }
            else
            {
                if (ECO1_Ndv) { ECO1_Ndv = false; Messenger.Send(16); }                        /*СИГНАЛ "ИСПРАВНОСТЬ ЦЕПЕЙ ОТКЛЮЧЕНИЯ ВВ (УСО1)" ДОСТОВЕРЕН*/
            }
            if ((NA.NdvCounter >= CounterNdv) && !QF3A && ECO3)
            {
                if (!ECO3_Ndv) { ECO3_Ndv = true; Messenger.Send(17); } /*СИГНАЛ "ИСПРАВНОСТЬ ЦЕПЕЙ ОТКЛЮЧЕНИЯ ВВ (УСО3)" НЕДОСТОВЕРЕН*/
            }
            else
            {
                if (ECO3_Ndv) { ECO3_Ndv = false; Messenger.Send(18); }                        /*СИГНАЛ "ИСПРАВНОСТЬ ЦЕПЕЙ ОТКЛЮЧЕНИЯ ВВ (УСО3)" ДОСТОВЕРЕН*/
            }
            /*21.14*/

            /*21.15*/
            if ((!ECO1 && NA.StopCounter == 0) || !QF3A)
            {
                if (!ECO1_Err) { ECO1_Err = true; Messenger.Send(23); } /*ЦЕПИ ОТКЛЮЧЕНИЯ ВВ (УСО1) НЕИСПРАВНЫ*/
            }
            else if (ECO1)
            {
                if (ECO1_Err) { ECO1_Err = false; Messenger.Send(24); }                        /*ЦЕПИ ОТКЛЮЧЕНИЯ ВВ (УСО1) ИСПРАВНЫ*/
            }
            if ((!ECO3 && NA.StopCounter == 0) || !QF3A)
            {
                if (!ECO3_Err) { ECO3_Err = true; Messenger.Send(25); } /*ЦЕПИ ОТКЛЮЧЕНИЯ ВВ (УСО3) НЕИСПРАВНЫ*/
            }
            else if (ECO3)
            {
                if (ECO3_Err) { ECO3_Err = false; Messenger.Send(26); }                        /*ЦЕПИ ОТКЛЮЧЕНИЯ ВВ (УСО3) ИСПРАВНЫ*/
            }

            /*учет команд (запуск/останов) на "фиксированние" сигналов*/
            if (NA.StopCounter == 0) { NA.ECO1_Prev = ECO1; NA.ECO3_Prev = ECO3; }
            /*21.16*/
         
        }
    }
}
