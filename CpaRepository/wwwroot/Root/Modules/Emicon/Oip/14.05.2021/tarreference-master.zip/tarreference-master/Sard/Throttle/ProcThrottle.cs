﻿using System;
using System.Collections.Generic;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;
using TarReferenceSource.Oip;

namespace TarReferenceSource.Sard.Throttle
{
    public enum ThrottleMode : ushort
    {
        manual = 1,
        auto = 0,
    }
    /// <summary>
    /// Конфигурация заслонки
    /// </summary>
    public class ThrottleCfg
    {
        /// <summary>
        /// Флаг использования заслонки
        /// </summary>
        public bool IsEnable;
        /// <summary>
        /// Флаг виртуальных концевиков
        /// </summary>
        public bool VirtKvInPosMode;
        /// <summary>
        /// Максимальная скорость заслонки
        /// </summary>
        public float MaxThrottleSpeed;
        /// <summary>
        /// Виртуальный гистерезис
        /// </summary>
        public float VirtHist;
        /// <summary>
        /// Виртуальный концевик Кво
        /// </summary>
        public float VirtKvo;
        /// <summary>
        /// Виртуальный концевик Квз
        /// </summary>
        public float VirtKvz;
    }
    /// <summary>
    /// Данные с нижнего уровня для заслонки
    /// </summary>
    public class ThrottleNu
    {
        /// <summary>
        /// Позиция
        /// </summary>
        public AnalogSignal Position;
        /// <summary>
        /// Кво
        /// </summary>
        public bool Kvo;
        /// <summary>
        /// Квз
        /// </summary>
        public bool Kvz;
        /// <summary>
        /// Режим управления
        /// </summary>
        public ThrottleMode Mode;
        /// <summary>
        /// Авария
        /// </summary>
        public bool Crash;
        /// <summary>
        /// Моментный выключатель открытия
        /// </summary>
        public bool Mvo;
        /// <summary>
        /// Моментный выключатель закрытия
        /// </summary>
        public bool Mvz;
    }

    
    /// <summary>
    /// Структура данных заслонки
    /// </summary>
    public class ThrottleStorage
    {
        /// <summary>
        /// Скорость
        /// </summary>
        public float Speed;
        /// <summary>
        /// Кво
        /// </summary>
        public bool Kvo;
        /// <summary>
        /// Квз
        /// </summary>
        public bool Kvz;
        /// <summary>
        /// Режим работы
        /// </summary>
        public ThrottleMode Mode;
        /// <summary>
        /// Авария
        /// </summary>
        public bool Crash;
        /// <summary>
        /// 
        /// </summary>
        /// <summary>
        /// Моментный выключатель открытия
        /// </summary>
        public bool Mvo;
        /// <summary>
        /// Моментный выключатель закрытия
        /// </summary>
        public bool Mvz;
    }
    /// <summary>
    /// Структура выходных данных заслонки
    /// </summary>
    public class ThrottleOutput
    {
        /// <summary>
        /// Выходная скорость
        /// </summary>
        public float OutSpeed;
        /// <summary>
        /// Открыта
        /// </summary>
        public bool Open;
        /// <summary>
        /// Закрыта
        /// </summary>
        public bool Close;
        /// <summary>
        /// Авария
        /// </summary>
        public bool Crash;
        /// <summary>
        /// Кво
        /// </summary>
        public bool Kvo;
        /// <summary>
        /// Квз
        /// </summary>
        public bool Kvz;
        /// <summary>
        /// Режим работы
        /// </summary>
        public ThrottleMode Mode;
        /// <summary>
        /// Положение
        /// </summary>
        public AnalogSignal Position;
    }

    public abstract class ProcThrottleIo : IFunctionBlock
    {
        public ProcThrottleIo(AnalogSignal pos, ControlLoopIo posControlLoop, SardStorage sar)
        {
            nu.Position = pos;
            output.Position = pos;
            _positionControlLoop = posControlLoop;
            sard = sar;
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }
        //in
        /// <summary>
        /// input Данные с нижнего уровня
        /// </summary>
        public ThrottleNu nu = new ThrottleNu();
        /// <summary>
        /// cfg Конфигурация заслонки
        /// </summary>
        public ThrottleCfg cfg = new ThrottleCfg();
        /// <summary>
        /// input 
        /// </summary>
        public SardStorage sard;
        /// <summary>
        /// input Данные от модуля ControlLoop
        /// </summary>
        public ControlLoopOutput PositionControlLoop => _positionControlLoop.Output;
        /// <summary>
        /// input Коррекция
        /// </summary>
        public ThrottleCorrections corrections = new ThrottleCorrections();
        //out
        /// <summary>
        /// output Выходные данные заслонки
        /// </summary>
        public ThrottleOutput output = new ThrottleOutput();

        //private
        /// <summary>
        /// Данные от модуля ControlLoop
        /// </summary>
        private ControlLoopIo _positionControlLoop;

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {
            {1, new MessageDescription{Text = "УСТАНОВЛЕН АВТОМАТИЧЕСКИЙ РЕЖИМ", Type = MessageType.Neutral} },
            {2, new MessageDescription{Text = "УСТАНОВЛЕН РУЧНОЙ РЕЖИМ", Type = MessageType.Neutral} },
            {3, new MessageDescription{Text = "СРАБОТАЛ МВО", Type = MessageType.Neutral} },
            {4, new MessageDescription{Text = "МВО СНЯТ", Type = MessageType.Neutral} },
            {5, new MessageDescription{Text = "СРАБОТАЛ МВЗ", Type = MessageType.Neutral} },
            {6, new MessageDescription{Text = "МВЗ СНЯТ", Type = MessageType.Neutral} },
            {7, new MessageDescription{Text = "РД НЕИСПРАВЕН", Type = MessageType.Neutral} },
            {8, new MessageDescription{Text = "РД ИСПРАВЕН", Type = MessageType.Neutral} },
        };
    }

    public class ProcThrottle : ProcThrottleIo
    {
        /// <summary>
        /// Внутреннее состояние модуля
        /// </summary>
        private ThrottleStorage storage;

        public ProcThrottle(AnalogSignal pos, ControlLoopIo posControlLoop, SardStorage sar) : base(pos, posControlLoop, sar)
        {
            storage = new ThrottleStorage();
        }

        public override void Execute()
        {
            //определяем концевики
            //RD limit ending (6.3.25)
            if (!cfg.VirtKvInPosMode && sard.mode == SardRegulationMode.ByPosition)
            {
                storage.Kvz = false;
                storage.Kvo = false;
            }
            else if (nu.Position.Ndv)
            {
                storage.Kvz = false;
                storage.Kvo = false;
            }
            else if (nu.Position.VisualValue <= cfg.VirtKvz)
            {
                storage.Kvo = false;
                storage.Kvz = true;
            }
            else if (nu.Position.VisualValue >= cfg.VirtKvo)
            {
                storage.Kvo = true;
                storage.Kvz = false;
            }
            else if (nu.Position.VisualValue > (cfg.VirtKvz + cfg.VirtHist) && nu.Position.VisualValue < (cfg.VirtKvo - cfg.VirtHist))
            {
                storage.Kvz = false;
                storage.Kvo = false;
            }

            output.Kvo = storage.Kvo || nu.Kvo;
            output.Kvz = storage.Kvz || nu.Kvz;

            //переключение режима заслонки
            if (nu.Mode != storage.Mode)
            {
                if (nu.Mode == ThrottleMode.auto)
                {
                    Messenger.Send(1);//установлен автоматический режим
                }
                else if (nu.Mode == ThrottleMode.manual)
                {
                    Messenger.Send(2);//установлен ручной режим
                }
                storage.Mode = nu.Mode;
            }

            
            if (nu.Mvo ^ storage.Mvo)
            {
                if (nu.Mvo)
                {
                    Messenger.Send(3);//сработал МВО
                }
                else
                {
                    Messenger.Send(4);//МВО снят
                }

                storage.Mvo = nu.Mvo;
            }

            if (nu.Mvz ^ storage.Mvz)
            {
                if (nu.Mvz)
                {
                    Messenger.Send(5);//сработал МВЗ
                }
                else
                {
                    Messenger.Send(6);//МВЗ снят
                }

                storage.Mvz = nu.Mvz;
            }

            if (nu.Crash ^ storage.Crash)
            {
                if (nu.Crash)
                {
                    Messenger.Send(7);//РД неисправен
                }
                else
                {
                    Messenger.Send(8);//РД исправен
                }

                storage.Crash = nu.Crash;
            }

            output.Crash = storage.Crash || nu.Position.Ndv;

            //выбираем регулятор в зависимости от режима заслонки
            //модуль вычисления задания скорости на ПЧ (6.3.21)
            //часть логики перенесена в Regulator Select (обработка режима регулирования)
            if (storage.Mode == ThrottleMode.manual)
            {
                storage.Speed = 0;
            }
            else if (output.Crash)
            {
                storage.Speed = 0;
            }
            else
            {
                if (sard.mode == SardRegulationMode.ByPosition)
                {
                    if (!PositionControlLoop.Crash)
                    {
                        storage.Speed = PositionControlLoop.NormalizedOutput * 100.0f;
                    }
                }
                else
                {
                    storage.Speed = sard.ActiveControlLoop.NormalizedOutput * 100.0f;
                    if (sard.ActiveControlLoop.AllowLinearCorrections)
                    {
                        storage.Speed = storage.Speed * corrections.LinearCorrections;
                    }
                }
            }

            if (corrections.NeedSpeedLimit && storage.Speed > cfg.MaxThrottleSpeed)
            {
                storage.Speed = cfg.MaxThrottleSpeed;
            }

            output.Crash = output.Crash || storage.Mvo || storage.Mvz;

            //вычисляем выходное воздействие
            //RD control impulse (6.3.26)
            output.Open = false;
            output.Close = false;
            if (storage.Speed > 0 && !output.Kvz && !storage.Mvz)
            {
                output.Close = true;
                if (storage.Speed > 100)
                {
                    storage.Speed = 100;
                }
            }
            else if (storage.Speed < 0 && !output.Kvo && !storage.Mvo)
            {
                if (storage.Speed < -100)
                {
                    storage.Speed = -100;
                }
                output.Open = true;
            }
            else
            {
                storage.Speed = 0;
            }

            output.OutSpeed = Math.Abs(storage.Speed);
            output.Mode = storage.Mode;

        }

    }

}
