﻿using System;
using System.Collections.Generic;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;

namespace TarReferenceSource.Oip
{
    public enum OipCmds : ushort
    {
        None = 0,
        SET_IMIT = 1,
        DROP_IMIT = 2
    }
    /// <summary>
    /// Структура, хранящая информацию о диапазоне
    /// </summary>
    public class Range
    {
        /// <summary>
        /// Нижняя граница диапазона
        /// </summary>
        public float Bottom { get; set; }
        /// <summary>
        /// Верхняя граница диапазона
        /// </summary>
        public float Top { get; set; }

        public override string ToString()
        {
            return $"bot: {Bottom} top: {Top}";
        }
    }

    /// <summary>
    /// Структура, хранящая данные о измеренном значении
    /// </summary>
    public class AnalogSignal
    {
        /// <summary>
        /// Измеренное значение (без учета диапазона измерения и фильтрации)
        /// </summary>
        public float Value { get; set; }
        /// <summary>
        /// Отображаемое измеренное значение (с учетом диапазона измерения и фильтрации). Значение в пределах диапазона измерения (в инженерных единицах)
        /// </summary>
        public float VisualValue { get; set; }
        /// <summary>
        /// Флаг недостоверности измеренного значения. 1 — есть недостоверность. 0 — нет недостоверности
        /// </summary>
        public bool Ndv { get; set; }
        /// <summary>
        /// Флаг недостоверности при вычислениях. 1 — есть недостоверность. 0 — нет недостоверности
        /// </summary>
        public bool AlgNdv { get; set; }
        /// <summary>
        /// Внешняя недостоверность.
        /// </summary>
        public bool ExtNdv { get; set; }
        /// <summary>
        /// Флаг недостоверности измеренного значения (ВПД). 1 — есть недостоверность. 0 — нет недостоверности
        /// </summary>
        public bool MTMax { get; set; }
        /// <summary>
        /// Флаг недостоверности измеренного значения (НПД). 1 — есть недостоверность. 0 — нет недостоверности
        /// </summary>
        public bool LTMin { get; set; }
    }
    public abstract class OipElectricIo : IFunctionBlock, ISignalDataSource
    {
        public OipElectricIo()
        {
            Description.TimerDescriptions = TimerDescriptions;
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }
        private AnalogSignal _outSignal = new AnalogSignal();
        /// <summary>
        /// input команда установки имитации
        /// </summary>
        public OipCmds Cmd { get; set; }
        /// <summary>
        /// input Значение, получаемое из модуля аналогового ввода
        /// </summary>
        public float ElInput { get; set; }
        /// <summary>
        /// input Значение для имитации
        /// </summary>
        public float ImitInput { get; set; }
        /// <summary>
        /// input Внешняя недостоверность
        /// </summary>
        public bool ExtNdv { get; set; }
        /// <summary>
        /// input Переменная, хранящая информацию о зоне достоверности (токовой)
        /// </summary>
        public Range ElAllowedRange { get; set; } = new Range();
        /// <summary>
        /// input Переменная, хранящая информацию о диапазоне (токовом)
        /// </summary>
        public Range ElRange { get; set; } = new Range();
        /// <summary>
        /// input Переменная, хранящая информацию о диапазоне (измеряемом)
        /// </summary>
        public Range ValRange { get; set; } = new Range();
        /// <summary>
        /// input Флаг разрешения сглаживания 
        /// </summary>
        public bool EnableFiltering { get; set; }
        /// <summary>
        /// input Коэффициент
        /// </summary>
        public float dT { get; set; }
        /// <summary>
        /// input Коэффициент
        /// </summary>
        public float T { get; set; }
        /// <summary>
        /// output Переменная, хранящая данные о измеренном значении
        /// </summary>

        public AnalogSignal OutSignal
        {
            get => _outSignal;
            set
            {
                _outSignal.Value = value.Value;
                _outSignal.VisualValue = value.VisualValue;
                _outSignal.Ndv= value.Ndv;
                _outSignal.ExtNdv = value.ExtNdv;
                _outSignal.LTMin = value.LTMin;
                _outSignal.MTMax = value.MTMax;
                _outSignal.AlgNdv = value.AlgNdv;
            }
        }

        /// <summary>
        /// output Наличие имитации
        /// </summary>
        public bool Imit { get; set; }

        //реализация интерфейсов
        /// <summary>
        /// output Переменная, хранящая данные о измеренном значении
        /// </summary>
        public AnalogSignal Signal { get => OutSignal; }

        public override void BeforeCall()
        {
            
        }

        public override void AfterCall()
        {
            Cmd = OipCmds.None;
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
            {
                {1, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ ИМИТАЦИИ", Type = MessageType.Information} },
                {2, new MessageDescription{Text = "РЕЖИМ ИМИТАЦИИ СНЯТ", Type = MessageType.Information} },
                {3, new MessageDescription{Text = "НЕДОСТОВЕРЕН. ИЗМЕРИТЕЛЬНЫЙ КАНАЛ НЕИСПРАВЕН", Type = MessageType.Attention} },
                {4, new MessageDescription{Text = "НЕДОСТОВЕРНОСТЬ. НПД", Type = MessageType.Attention} },
                {5, new MessageDescription{Text = "НЕДОСТОВЕРНОСТЬ. ВПД", Type = MessageType.Attention} },
                {6, new MessageDescription{Text = "ДОСТОВЕРЕН (РЕЖИМ ИМИТАЦИИ)", Type = MessageType.Neutral} },
                {7, new MessageDescription{Text = "ДОСТОВЕРЕН", Type = MessageType.Neutral} },
                {8, new MessageDescription{Text = "НЕДОСТОВЕРЕН. НЕКОРРЕКТНЫЕ НАСТРОЙКИ", Type = MessageType.Attention} },
                {9, new MessageDescription{Text = "КОМАНДА СНЯТЬ ИМИТАЦИЮ НЕ ТРЕБУЕТСЯ, ИМИТАЦИЯ ОТСУСТВУЕТ", Type = MessageType.Neutral} },
                {10, new MessageDescription{Text = "КОМАНДА НАЗНАЧИТЬ ИМИТАЦИЮ НЕ ТРЕБУЕТСЯ, НАЛИЧИЕ ИМИТАЦИИ", Type = MessageType.Neutral} },
                {19, new MessageDescription{Text = "таймер", Type = MessageType.Neutral} },
            };

        protected static Dictionary<int, TimerDescription> TimerDescriptions = new Dictionary<int, TimerDescription>
        {
            {1, new TimerDescription("Восстановление нормального значения измеряемого параметра при выхоже из недостоверности", TimeSpan.FromMilliseconds(100)) }
        };
    }

}
