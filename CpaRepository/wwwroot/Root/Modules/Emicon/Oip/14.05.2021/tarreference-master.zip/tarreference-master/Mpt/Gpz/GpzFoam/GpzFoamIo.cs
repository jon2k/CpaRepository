﻿using System.Collections.Generic;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;

namespace TarReferenceSource.Mpt.Gpz.GpzFoam
{
    /// <summary>
    /// Входные данные для модуля GpzFoam
    /// </summary>
    public class GpzFoamIoInput
    {
        /// <summary>
        /// Количество исправных насосов водоорошения в основном режиме (по результатам работы модуля UVS).
        /// </summary>
        public int OsnIsprCount; // Количество исправных насосов водоорошения в основном режиме (по результатам работы модуля UVS).
        /// <summary>
        /// Флаг наличия неисправных задвижек на общей линии пенотушения (по результатам работы модуля ZDLine).
        /// </summary>
        public bool GeneralFoamLineAnyErr; // Флаг наличия неисправных задвижек на общей линии пенотушения (по результатам работы модуля ZDLine).
        /// <summary>
        /// Флаг наличия задвижек с назначенным режимом «ИМИТ» задвижек на общей линии пенотушения (по результатам работы модуля ZDLine).
        /// </summary>
        public bool GeneralFoamLineAnyImit; // Флаг наличия задвижек с назначенным режимом «ИМИТ» задвижек на общей линии пенотушения (по результатам работы модуля ZDLine).
        /// <summary>
        /// Флаг отсутствия баков дозаторов с неисправными задвижками (по результатам работы модуля UGrpDB).
        /// </summary>
        public bool BdsNonCrash; // Флаг отсутствия баков дозаторов с неисправными задвижками (по результатам работы модуля UGrpDB).
        /// <summary>
        /// Флаг отсутствия баков дозаторов с задвижками в режиме «ИМИТ» (по результатам работы модуля UGrpDB).
        /// </summary>
        public bool BdsNonImit; // Флаг отсутствия баков дозаторов с задвижками в режиме «ИМИТ» (по результатам работы модуля UGrpDB).
        /// <summary>
        /// Флаг наличия заполненных баков дозаторов (по результатам работы модуля UGrpDB).
        /// </summary>
        public bool BdsLowFull; // Флаг наличия заполненных баков дозаторов (по результатам работы модуля UGrpDB).
        /// <summary>
        /// Количество баков дозаторов с наличием всех готовностей (по результатам работы модуля UGrpDB).
        /// </summary>
        public uint BdsReadyCount; // Количество баков дозаторов с наличием всех готовностей (по результатам работы модуля UGrpDB).
        /// <summary>
        /// Количество баков дозаторов в основном или резервном режиме (по результатам работы модуля UGrpDB).
        /// </summary>
        public uint BdsOsnRezCount; // Количество баков дозаторов в основном или резервном режиме (по результатам работы модуля UGrpDB).
        /// <summary>
        /// Флаг наличия минимального уровня в резервуаре противопожарного запаса воды.
        /// </summary>
        public bool TanksAnyMin; // Флаг наличия минимального уровня в резервуаре противопожарного запаса воды.
        /// <summary>
        ///  Флаг наличия неисправных задвижек на пенолинии защищаемого сооружения (по результатам работы модуля ZDLine).
        /// </summary>
        public bool SelfFoamLineAnyErr; // Флаг наличия неисправных задвижек на пенолинии защищаемого сооружения (по результатам работы модуля ZDLine).
        /// <summary>
        /// Флаг наличия задвижек с назначенным режимом «ИМИТ» на пенолинии защищаемого сооружения (по результатам работы модуля ZDLine).
        /// </summary>
        public bool SelfFoamLineAnyImit; // Флаг наличия задвижек с назначенным режимом «ИМИТ» на пенолинии защищаемого сооружения (по результатам работы модуля ZDLine).
        /// <summary>
        /// Флаг отсутствия необходимого количества исправных ПИ на защищаемом сооружении (по результатам работы модуля SensorCard).
        /// </summary>
        public bool SensorsNotEnoughSensors; // Флаг отсутствия необходимого количества исправных ПИ на защищаемом сооружении (по результатам работы модуля SensorCard).
        /// <summary>
        /// Флаг назначения режима автоматического пенотушения защищаемого сооружения (по результатам работы модуля SUP).
        /// </summary>
        public bool SupIsAuto; // Флаг назначения режима автоматического пенотушения защищаемого сооружения (по результатам работы модуля SUP).
        /// <summary>
        /// Флаг наличия маскирования агрегатной защиты по пожару защищаемого сооружения (по результатам работы модуля KTPRP).
        /// </summary>
        public bool ProtM; // Флаг наличия маскирования агрегатной защиты по пожару защищаемого сооружения (по результатам работы модуля KTPRP).
        /// <summary>
        /// Флаг наличия ремонтного режима сооружения.
        /// </summary>
        public bool IsRem; // Флаг наличия ремонтного режима сооружения.
        /// <summary>
        /// Флаг наличия требования запуска и успешного включения оборудования.
        /// </summary>
        public bool SuccessfulStart; // Флаг наличия требования запуска и успешного включения оборудования.
        /// <summary>
        /// Количество параметров готовности к автоматическому водоорошению резервуара.
        /// </summary>
        public int ReadinesCount; // Количество параметров готовности к автоматическому водоорошению резервуара.
        /// <summary>
        /// Массив флагов отключенности обработки готовностей.
        /// </summary>
        public StArray<bool> CfgDisabled; // Массив флагов отключенности обработки готовностей.
        /// <summary>
        /// Необходимое количество исправных насосов водоорошения.
        /// </summary>
        public uint CfgPumpsNeeded; // Необходимое количество исправных насосов водоорошения.
        /// <summary>
        /// Необходимое количество исправных баков-дозаторов.
        /// </summary>
        public uint CfgBDCount; // Необходимое количество исправных баков-дозаторов.
        /// <summary>
        /// Количество защит по пожару сооружения. 
        /// </summary>
        public uint CountProt; // Количество защит по пожару сооружения. 
    }

    public enum GpzState : byte
    {
        NotReady = 0,
        Ready = 1,
        NoControl = 2,
    }
    public abstract class GpzFoamIo:IFunctionBlock
    {
        // in
        /// <summary>
        /// input Входные данные для модуля
        /// </summary>
        public GpzFoamIoInput Source;

        // out
        /// <summary>
        /// output Массив флагов готовности к пенотушению резервуара по каждому фактору готовности.
        /// </summary>
        public StArray<bool> Output; // Массив флагов готовности к пенотушению резервуара по каждому фактору готовности.
        /// <summary>
        /// output Статус готовности защищаемого сооружения к пенотушению
        /// </summary>
        public GpzState Out; // Статус готовности защищаемого сооружения к пенотушению: 0 – нет готовности, 1 – готово, 2 – не контролируется . 

        public GpzFoamIo()
        {
            Source = new GpzFoamIoInput();
            Source.CfgDisabled = new StArray<bool>(1, new bool[13]);
            Source.ReadinesCount = 13;
            Output = new StArray<bool>(1, new bool[13]);          
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {
            {1, new MessageDescription{Text = "ГОТОВ К АВТОМАТИЧЕСКОМУ ПЕНОТУШЕНИЮ", Type = MessageType.Information} },
            {2, new MessageDescription{Text = "НЕ ГОТОВ К АВТОМАТИЧЕСКОМУ ПЕНОТУШЕНИЮ", Type = MessageType.Alarm} },
            {3, new MessageDescription{Text = "ОТСУТСТВИЕ ИСПРАВНЫХ НАСОСОВ ВОДООРОШЕНИЯ В РЕЖИМЕ ОСНОВНОЙ. ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {4, new MessageDescription{Text = "ОТСУТСТВИЕ ИСПРАВНЫХ НАСОСОВ ВОДООРОШЕНИЯ В РЕЖИМЕ ОСНОВНОЙ. ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
            {5, new MessageDescription{Text = "ЗАДВИЖКА ПЕНОТУШЕНИЯ ОБЩЕЙ ПЕНОЛИНИИ НЕИСПРАВНА. ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {6, new MessageDescription{Text = "ЗАДВИЖКА ПЕНОТУШЕНИЯ ОБЩЕЙ ПЕНОЛИНИИ НЕИСПРАВНА. ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
            {7, new MessageDescription{Text = "ЗАДВИЖКА ПЕНОТУШЕНИЯ ОБЩЕЙ ПЕНОЛИНИИ В РЕЖИМЕ «ИМИТ». ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {8, new MessageDescription{Text = "ЗАДВИЖКА ПЕНОТУШЕНИЯ ОБЩЕЙ ПЕНОЛИНИИ В РЕЖИМЕ «ИМИТ». ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
            {9, new MessageDescription{Text = "НЕИСПРАВНОСТЬ ЗАДВИЖЕК БАКОВ-ДОЗАТОРОВ. ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {10, new MessageDescription{Text = "НЕИСПРАВНОСТЬ ЗАДВИЖЕК БАКОВ-ДОЗАТОРОВ. ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
            {11, new MessageDescription{Text = "ЗАДВИЖКИ БАКОВ-ДОЗАТОРОВ В РЕЖИМЕ «ИМИТ». ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {12, new MessageDescription{Text = "ЗАДВИЖКИ БАКОВ-ДОЗАТОРОВ В РЕЖИМЕ «ИМИТ». ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
            {13, new MessageDescription{Text = "БАКИ-ДОЗАТОРЫ НЕ ЗАПОЛНЕНЫ. ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {14, new MessageDescription{Text = "БАКИ-ДОЗАТОРЫ НЕ ЗАПОЛНЕНЫ. ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
            {15, new MessageDescription{Text = "МИНИМАЛЬНЫЙ УРОВЕНЬ РЕЗЕРВУАРА ПРОТИВОПОЖАРНОГО ЗАПАСА ВОДЫ. ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {16, new MessageDescription{Text = "МИНИМАЛЬНЫЙ УРОВЕНЬ РЕЗЕРВУАРА ПРОТИВОПОЖАРНОГО ЗАПАСА ВОДЫ. ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
            {17, new MessageDescription{Text = "ЗАДВИЖКА ПЕНОЛИНИИ СООРУЖЕНИЯ НЕИСПРАВНА. ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {18, new MessageDescription{Text = "ЗАДВИЖКА ПЕНОЛИНИИ СООРУЖЕНИЯ НЕИСПРАВНА. ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
            {19, new MessageDescription{Text = "ЗАДВИЖКА ПЕНОЛИНИИ СООРУЖЕНИЯ В РЕЖИМЕ «ИМИТ». ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {20, new MessageDescription{Text = "ЗАДВИЖКА ПЕНОЛИНИИ СООРУЖЕНИЯ В РЕЖИМЕ «ИМИТ». ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
            {21, new MessageDescription{Text = "НЕДОСТАТОЧНО ИСПРАВНЫХ ПОЖАРНЫХ ИЗВЕЩАТЕЛЕЙ. ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {22, new MessageDescription{Text = "НЕДОСТАТОЧНО ИСПРАВНЫХ ПОЖАРНЫХ ИЗВЕЩАТЕЛЕЙ. ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
            {23, new MessageDescription{Text = "РЕЖИМ АВТОМАТИЧЕСКОГО ПЕНОТУШЕНИЯ ОТКЛЮЧЕН. ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {24, new MessageDescription{Text = "РЕЖИМ АВТОМАТИЧЕСКИЙ АВТОМАТИЧЕСКОГО ПЕНОТУШЕНИЯ ОТКЛЮЧЕН. ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
            {25, new MessageDescription{Text = "МАСКИРОВАНИЕ ЗАЩИТЫ ПО ПОЖАРУ. ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {26, new MessageDescription{Text = "МАСКИРОВАНИЕ ЗАЩИТЫ ПО ПОЖАРУ. ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
            {27, new MessageDescription{Text = "НЕОБХОДИМОЕ КОЛИЧЕСТВО БАКОВ-ДОЗАТОРОВ. ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {28, new MessageDescription{Text = "НЕОБХОДИМОЕ КОЛИЧЕСТВО БАКОВ-ДОЗАТОРОВ. ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} }
        };
    }
}
