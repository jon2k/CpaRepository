﻿using System;

namespace TarReferenceSource.Uvs
{
    public enum VsState : ushort
    {
        on = 1,
        off = 2,
        starting = 3,
        stopping = 4
    }

    public enum VsMode : ushort
    {
        none = 0,
        osn = 1,
        rez = 2,
        manual = 3,
        repair = 4
    }

    public enum VsCrash : ushort
    {
        NoError = 0,
        NoAVR = 1,
        DoAVR = 2,
        NoErrorAVR = 3
    }

    public enum VsCmds : ushort
    {
        CmdPusk = 1,   /*Пуск*/
        CmdStop = 2,   /*Стоп*/
        CmdOsn = 3,    /*Установить режим Основной*/
        CmdRez = 4,    /*Установить режим Резервный*/
        CmdRem = 5,    /*Установить режим Ремонтный*/
        CmdRuch = 6,   /*Установить режим Ручной*/
        CmdDebl = 7,   /*Деблокировать*/
    }
    /// <summary>
    /// Структура аварий агрегата вспомсистемы
    /// </summary>
    public class AvsCrashes
    {
        /// <summary>
        /// Флаг неисправности датчика давления
        /// </summary>
        public bool PcFall;
        public bool PcNotUp;
        public bool MpcControl;
        public bool PcControl;
        public bool MpCepiVkl;
        public bool MpCepiOtkl;
        public bool EcControl;
        public bool EcFall;
        public bool MpNotFall;
        public bool MpcFall;
        public bool MpControlRuch;
        public bool PcControlRuch;
        public bool EcControlRuch;
        public bool MpNotUp;
        public bool External;
    }
    /// <summary>
    /// Структура данных с нижнего уровня агрегата вспомсистемы
    /// </summary>
    public class AvsNu
    {
        /// <summary>
        /// Флаг включения магнитного пускателя
        /// </summary>
        public bool Mp;
        /// <summary>
        /// Флаг наличия давления в трубопроводе
        /// </summary>
        public bool Pc;
        /// <summary>
        /// Флаг наличия напряжения в схеме управления
        /// </summary>
        public bool Ec;
        /// <summary>
        /// Флаг наличия напряжения на секции шин
        /// </summary>
        public bool SecEc;
        /// <summary>
        /// Флаг контроля целостности цепей включения (только для пожарных агрегатов)
        /// </summary>
        public bool Opc;
        /// <summary>
        /// Флаг внешней аварии
        /// </summary>
        public bool ExternalCrash;
        /// <summary>
        /// Флаг несиправности датчика давления
        /// </summary>
        public bool PcNeisprav;
    }

    public enum ReserveGroupStatus : ushort
    {
        NotEnoughOsn = 0,
        ResExist = 1,
        AllowSetForNotOsn = 2,
        AllowSetRez = 3,
    }
    /// <summary>
    /// Структура данных от модуля Ugrpvs
    /// </summary>
    public class AvsAutoCmds
    {
        //управление
        /// <summary>
        /// 
        /// </summary>
        public bool SilentStop;
        /// <summary>
        /// Флаг автоматического стопа
        /// </summary>
        public bool AutoStop;
        /// <summary>
        /// Флаг автоматического старта
        /// </summary>
        public bool AutoStart;
        /// <summary>
        /// Флаг старта резерва
        /// </summary>
        public bool ResStart;
        /// <summary>
        /// Флаг тушения пожара (для пожарных насосов)
        /// </summary>
        public bool FireProtectProcessing;
        //смена режимов
        /// <summary>
        /// Смена режимов
        /// </summary>
        public VsMode SetMode;
        /// <summary>
        /// Статус резерва
        /// </summary>
        public ReserveGroupStatus ReserveStatus;
        //блокировки
        /// <summary>
        /// Флаг блокировки останова
        /// </summary>
        public bool BlockStop;
        /// <summary>
        /// Флаг блокировки работы
        /// </summary>
        public bool BlockWork;
        /// <summary>
        /// 
        /// </summary>
        public bool ResetBlocksCmd;
        /// <summary>
        /// Флаг блокировки АПВ
        /// </summary>
        public bool BlockApv;
        /// <summary>
        /// Флаг сброса блокировки АПВ
        /// </summary>
        public bool ResetBlocksApvCmd;
        /// <summary>
        /// Флаг метки как дополнительного агрегата
        /// </summary>
        public bool MarkAsDop;
    }
}
