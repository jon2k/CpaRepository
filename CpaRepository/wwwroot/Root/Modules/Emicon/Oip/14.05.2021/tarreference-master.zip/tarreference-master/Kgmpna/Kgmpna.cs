﻿namespace TarReferenceSource.Kgmpna
{
    public class Kgmpna : KgmpnaIo
    {
        public Kgmpna(uint count):base(count)
        {
        }

        public override void Execute()
        {
			Result.P = true;
			Result.F = true;
			Result.M = false;

            for (int i = 1; i <= Input.Count; i++)
			{
				Result.F = Input[i].F && Result.F;
				Result.P = Input[i].P && Result.P;
				Result.M = Input[i].M || Result.M;
            }
        }
    }
}
