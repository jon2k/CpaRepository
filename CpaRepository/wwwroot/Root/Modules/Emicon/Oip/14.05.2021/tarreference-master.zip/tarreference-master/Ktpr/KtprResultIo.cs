﻿using TarFoundation.St;
using TarReferenceSource.Ktpra;
using TarReferenceSource.Shoulder;

namespace TarReferenceSource.Ktpr
{
    public abstract class KtprResultIo : IFunctionBlock
    {
        //in
        /// <summary>
        /// input Массив данных от модулей ProcKtpr
        /// </summary>
        public StArray<ProcKtprResult> Input;
        /// <summary>
        /// cfg Конфигурация от каждой из защит ProcKtpr 
        /// </summary>
        public StArray<ProcKtprConfig> Cfg;
        //out
        /// <summary>
        /// output Массив выходных данных в модуль Ktpras для насосных агрегатов в плечах 
        /// </summary>
        public StArray<ShoulderIo> Shoulders;
        /// <summary>
        /// output Массив выходных данных в модуль Ktpras для насосных агрегатов в подплечах 
        /// </summary>
        public StArray<SubshoulderIo> Subshoulders;

        public override void AfterCall()
        {
            for (int i = 1; i <= Shoulders.Count; i++)
            {
                Shoulders[i].Cmd.StopNsCmd = NsStopType.None;
                Shoulders[i].Cmd.StopNaMethod = NaStopType.None;
            }        
        }
    }
}
