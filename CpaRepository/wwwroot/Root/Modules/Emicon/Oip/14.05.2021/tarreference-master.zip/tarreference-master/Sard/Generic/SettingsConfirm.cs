﻿using TarFoundation.St;
using TarReferenceSource.Oip;

namespace TarReferenceSource.Sard.Generic
{
    /// <summary>
    /// Параметр уставки
    /// </summary>
    public class Parametr
    {
        /// <summary>
        /// Введенное значение уставки
        /// </summary>
        public float EnteredValue;
        /// <summary>
        /// Команда подтверждения уставки
        /// </summary>
        public bool ConfirmCmd;
        /// <summary>
        /// Необходимость подтверждения уставки
        /// </summary>
        public bool NeedConfirm;
    }

    public abstract class SettingsConfirmIo : IFunctionBlock
    {
        //in
        /// <summary>
        /// input Максимальное и минимальное значение уствки
        /// </summary>
        public Range AllowedRange;
        /// <summary>
        /// input Источник задания уставки
        /// </summary>
        public SardControlSource Mode;
        /// <summary>
        /// input Параметр панели оператора
        /// </summary>
        public Parametr PanelSetting = new Parametr();
        /// <summary>
        /// input Параметр внешнего источника задания
        /// </summary>
        public Parametr ExternalSetting = new Parametr();
        //out
        /// <summary>
        /// output Текущая уставка
        /// </summary>
        public float CurrentSetting;

        public virtual void AfterCall()
        {
            PanelSetting.ConfirmCmd = false;
            ExternalSetting.ConfirmCmd = false;
        }
    }
    //TODO: не ясно что делать при первом запуске
    public class SettingsConfirm : SettingsConfirmIo
    {
        /// <summary>
        /// Текущая уставка
        /// </summary>
        private float currentSetting;

        public override void Execute()
        {
            if (PanelSetting.ConfirmCmd)
            {
                Messenger.Send(1); //команда задать уставку с панели
                if (Mode == SardControlSource.external)
                {
                    Messenger.Send(2);//задание уставки невозможно. режим управление "внешний"
                }
                else if (PanelSetting.EnteredValue == currentSetting)
                {
                    Messenger.Send(7);//не требуется
                }
                else if (AllowedRange.Top < PanelSetting.EnteredValue ||
                         AllowedRange.Bottom > PanelSetting.EnteredValue)
                {
                    Messenger.Send(8);//значение вне разрешенного диапазона
                }
                else
                {
                    Messenger.Send(3);//значение изменено с дисплейной панели
                    currentSetting = PanelSetting.EnteredValue;
                }
            }

            PanelSetting.NeedConfirm = PanelSetting.EnteredValue != currentSetting && Mode == SardControlSource.panel;

            if (ExternalSetting.ConfirmCmd)
            {
                Messenger.Send(4); //команда задать уставку от МПСА
                if (Mode == SardControlSource.panel)
                {
                    Messenger.Send(5);//задание уставки невозможно. режим управление "с дисплейной панели"
                }
                else if (ExternalSetting.EnteredValue == currentSetting)
                {
                    Messenger.Send(7);//не требуется
                }
                else if (AllowedRange.Top < ExternalSetting.EnteredValue ||
                         AllowedRange.Bottom > ExternalSetting.EnteredValue)
                {
                    Messenger.Send(8);//значение вне разрешенного диапазона
                }
                else
                {
                    Messenger.Send(6);//значение изменено с МПСА
                    currentSetting = ExternalSetting.EnteredValue;
                }
            }

            ExternalSetting.NeedConfirm = ExternalSetting.EnteredValue != currentSetting && Mode == SardControlSource.external;
            CurrentSetting = currentSetting;
        }
    }
}
