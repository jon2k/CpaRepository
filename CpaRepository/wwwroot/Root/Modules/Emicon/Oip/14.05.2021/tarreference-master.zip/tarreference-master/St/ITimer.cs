﻿using TarFoundation.Runtime;

namespace TarFoundation.St
{
    public interface ITimer : ITimeTraveler
    {
        void Start();
        void Stop();
        void Pause();
        void Continue();
    }
}
