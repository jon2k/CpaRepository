﻿using TarFoundation.St;
using TarReferenceSource.Ktpra;
using TarReferenceSource.Uzd;


namespace TarReferenceSource.CommonNa
{
    public interface NaDataSource
    {

    }
    public enum NaState : ushort
    {
        Vkl = 1,
        Otkl = 2,
        Pusk = 3,
        Ostanov = 4
    }

    public enum NaMode : ushort
    {
        Osn = 1,
        Tm = 2,
        Rez = 3,
        Rem = 4
    }

    public enum NaSubstate : ushort
    {
        None = 0,
        Ready = 1,
        HotRez = 2, // Горячий резерв.
        Pp = 3, // Программа пуска.
        Po = 4 // Программа останова.
    }


    public enum NaProg : ushort
    {
        P1 = 1,
        P2 = 2
    }

    public enum NaZdCmd : ushort
    {
        None = 0,
        Open = 1,
        Close = 2
    }

    public enum NaZdBlocks : ushort
    {
        None = 0,
        NoOpen = 1,
        NoClose = 2
    }

    public enum StopNoCmdState : ushort
    {
        None = 0,
        Phase1 = 1,
        Phase2 = 2
    }

    public enum NaCmd : ushort
    {
        none                = 0,
        SET_P1  			= 1,
        SET_P2		 		= 2,
        STOP  				= 5,
        PUSK  				= 6,
        SET_OSN  			= 8,
        SET_TM 				= 9,
        SET_REZ  			= 10,
        SET_REM  			= 11,
        SET_SIM  			= 12,
        UNSET_SIM  		= 13,
        ALLOW_LOCAL = 16,
        DISALLOW_LOCAL = 17,

        SET_PREPARE_CHRP  	= 18
    }
    /// <summary>
    /// Структура данных воздушного выключателя
    /// </summary>
    public class VvStorage
    {
        /// <summary>
        /// Флаг включенного состояния выключателя
        /// </summary>
        public bool SwitchOn1; // ВВ включен.
        /// <summary>
        /// Флаг отключенного состояния выключателя
        /// </summary>
        public bool SwitchOff1; // ВВ выключен.
        /// <summary>
        /// Флаг включенного состояния выключателя
        /// </summary>
        public bool SwitchOn2;
        /// <summary>
        /// Флаг отключенного состояния выключателя
        /// </summary>
        public bool SwitchOff2;
        /// <summary>
        /// Флаг наличия тока
        /// </summary>
        public bool Tok; // Есть ток.
        /// <summary>
        /// Дискретный  сигнал наличия питания в цепях отключения ВВ (дублирующий сигнал)
        /// </summary>
        public bool ECx03_1; // Есть напряжение.
        /// <summary>
        /// Дискретный  сигнал наличия питания в цепях отключения ВВ
        /// </summary>
        public bool ECx03; // Есть напряжение.
        /// <summary>
        /// Дискретный  сигнал наличия питания в цепях включения ВВ
        /// </summary>
        public bool ECx02; // Есть напряжение.
    }

    public abstract class NaIo : IFunctionBlock
    {

        //in
        /// <summary>
        /// input Код команды, сформированный с АРМ оператора из операторной или МДП или по ТМ
        /// </summary>
        public NaCmd Cmd;
        /// <summary>
        /// input Данные от воздушного выключателя
        /// </summary>
        public VvStorage vv = new VvStorage();
        /// <summary>
        /// input Команда, полученная по каналам телемеханики, на пуск НА
        /// </summary>
        public bool PuskTmCmd;
        /// <summary>
        /// input Команда, полученная по каналам телемеханики на остановку НА
        /// </summary>
        public bool StopTmCmd;
        /// <summary>
        /// input Команда, на остановку НА от ЦСПА
        /// </summary>
        public bool StopCspaCmd;
        /// <summary>
        /// input Задвижка выкидныя в имитации
        /// </summary>
        public bool ZvStateIsImit; // с задвижки
        /// <summary>
        /// input Состояние выкидной задвижки
        /// </summary>
        public ZdState ZvState; // Состояние задвижки.
        /// <summary>
        /// input Задвижка приемная в имитации
        /// </summary>
        public bool ZpStateIsImit;
        /// <summary>
        /// input Состояние приемной задвижки
        /// </summary>
        public ZdState ZpState; // Состояние задвижки.
        /// <summary>
        /// input Флаг наличия напряжения на QF1 (3 A)
        /// </summary>
        public bool QF3A; // из модуля ktpras
        /// <summary>
        /// input Контроль тока МНА
        /// </summary>
        public bool TokControl;
        /// <summary>
        /// input Принятие решения об установке режима «Резервный», по результатам работы KRMPN
        /// </summary>
        public bool DoRez; // из krmpn
        /// <summary>
        /// input Наличие НА с назначенным режимом «РЕЗ» в текущем плече, по результатам работы KRMPN
        /// </summary>
        public bool RezExist; //  из krmpn
        /// <summary>
        /// input Отсутствие НА с назначенным режимом «ТМ» или «ОСН» в текущем плече, по результатам работы KRMPN
        /// </summary>
        public bool NoOsnForRez; // из krmpn
        /// <summary>
        /// input Флаг наличия электрозащиты
        /// </summary>
        public bool StopElectric; // из krmpn
        /// <summary>
        /// input Готовность к старту от модуля Kgmpna
        /// </summary>
        public bool ReadyToStart; //  из Kgmpna
        /// <summary>
        /// input Флаг дистанционного режима НПС
        /// </summary>
        public bool NpsDist; // Дистанционный режим. Настройка.
        /// <summary>
        /// input Команда на выполнение автоматического включения НА
        /// </summary>
        public bool StartAuto; // из krmpn
        /// <summary>
        /// input Команда на выполнение автоматического включения резервного НА
        /// </summary>
        public bool StartRez; //  из krmpn
        /// <summary>
        /// input Команда на автоматическое отключение НА
        /// </summary>
        public bool StopAuto; //  из krmpn
        /// <summary>
        /// input Повтор останова НА
        /// </summary>
        public bool RepeatedStop; //  из krmpn
        /// <summary>
        /// input 
        /// </summary>
        public bool AutoOsn; //   из krmpn
        /// <summary>
        /// input Тип остановки НА
        /// </summary>
        public NaStopType AutoStopCmd; // из krmpn 
        //out
        /// <summary>
        /// output Команда на включение воздушного выключателя ЧРП
        /// </summary>
        public bool OffVvCmdOut;
        /// <summary>
        /// output Команда на включение ЧРП
        /// </summary>
        public bool SwitchOnOut; // Включить.
        /// <summary>
        /// output Команда на отключение ЧРП
        /// </summary>
        public bool SwitchOffOut; // Выключить.
        /// <summary>
        /// output Флаг высокой вибрации насоса
        /// </summary>
        public bool HighVibrPumpOut; // Высокая вибрация насоса.
        /// <summary>
        /// output Флаг высокой вибрации двигателя
        /// </summary>
        public bool HighVibrEngOut; // Высокая вибрация двигателя.
        /// <summary>
        /// output Несанкционированное включение ВВ НА. Примечание –  после установки, сигнал сбрасывается при условии получения отключенного состояния ВВ и основного состояния «ВВ отключен» или при успешном выполнении программы остановки НА
        /// </summary>
        public bool StartNoCmdOut;
        /// <summary>
        /// output Несанкционированное отключение ВВ НА. Примечание –  после установки, сигнал сбрасывается при условии получения отключенного состояния ВВ и основного состояния «ВВ отключен» или при успешном выполнении программы остановки НА
        /// </summary>
        public StopNoCmdState StopNoCmdOut;
        /// <summary>
        /// output Флаг аварии воздушного выключателя
        /// </summary>
        public bool StateAlarmVVOut; // Авария вакумника. 
        /// <summary>
        /// output Невыполнения программы пуска. Примечание– после установки, сигнал сбрасывается при успешном выполнении программы остановки НА
        /// </summary>
        public bool StartErrOut; // Ошибка старта.
        /// <summary>
        /// output Невыполнение команды отключения ВВ. Примечание– после установки, сигнал сбрасывается при успешном выполнении программы остановки НА
        /// </summary>
        public bool StartErr2Out;
        /// <summary>
        /// output Невыполнение программы остановки. Примечание –  после установки, сигнал сбрасывается при успешном выполнении программы остановки НА
        /// </summary>
        public bool StopErrOut; // Ошибка останова.
        /// <summary>
        /// output Невыполнение команды отключения ВВ. Примечание– после установки, сигнал сбрасывается при успешном выполнении программы остановки НА
        /// </summary>
        public bool StopErr2Out;
        /// <summary>
        /// output Команда на выкидную задвижку НА Примечание –  после установки, команда автоматически сбрасывается в начале следующего цикла работы программы
        /// </summary>
        public NaZdCmd ZvCmdOut; // Команда на задвижку.
        /// <summary>
        /// output Команда на приемную задвижку НА Примечание –  после установки, команда автоматически сбрасывается в начале следующего цикла работы программы
        /// </summary>
        public NaZdCmd ZpCmdOut; // Команда на задвижку.
        /// <summary>
        /// output Команда на установку блокировки закрытия выкидной задвижки НА.Примечание –  после установки, команда автоматически сбрасывается в начале следующего цикла работы программы
        /// </summary>
        public NaZdBlocks ZvBlockOut; // Блокировка задвижки.
        /// <summary>
        /// output Команда на установку блокировки закрытия приемной задвижки НА. Примечание –  после установки, команда автоматически сбрасывается в начале следующего цикла работы программы
        /// </summary>
        public NaZdBlocks ZpBlockOut; // Блокировка задвижки.
        /// <summary>
        /// output Основное состояние НА
        /// </summary>
        public NaState MainStateOut; // Главное состояние агрегата.
        /// <summary>
        /// output Дополнительное состояние НА
        /// </summary>
        public NaSubstate SubstateOut; // Вспомогательное состояние агрегата.
        /// <summary>
        /// output Режим НА
        /// </summary>
        public NaMode ModeOut; // Режим.
        /// <summary>
        /// output Флаг режима имитации НА
        /// </summary>
        public bool IsImitOut; // Имитация.
        /// <summary>
        /// output для KRMPN пришлось положить сюда
        /// </summary>
        public NaProg ProgOut;//для KRMPN пришлось положить сюда

        // other fb
        // in
        /// <summary>
        /// input Флан не номинального интервала подач
        /// </summary>
        public bool NeNomIntervalPodach; // из krmpn 
        /// <summary>
        /// input Ширина колеса
        /// </summary>
        public ushort WheelSize; // Ширина колеса.
        /// <summary>
        /// input Принадлежность к плечу
        /// </summary>
        public ushort Shoulder; // Плечо.
        /// <summary>
        /// input ПРинадлежность к подплечу
        /// </summary>
        public ushort Subshoulder; // Подплечо
        /// <summary>
        /// input
        /// </summary>
        public bool RestrictAvr;
        /// <summary>
        /// input Флаг ожидания стопа
        /// </summary>
        public bool WaitForStop; // Ожидание стопа.
        /// <summary>
        /// input Флаг автоматической частотной нагрузки
        /// </summary>
        public bool Achr; // авт частотная нагрузка
        /// <summary>
        /// input
        /// </summary>
        public bool Safety; // Безопасность.
    }

}
