﻿using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using System;
using TarFoundation.St;
using TarReferenceSource.Common.Timer;
using TarReferenceSource.Ktpr;

namespace TarReferenceSource
{
    public class ProcKtpr : ProcKtprIo
    {
        public ITimer T01;
        /// <summary>
        /// Команда установить маскирование по ТМ на предыдущем цикле работы программы
        /// </summary>
        private bool nlTUSetMask_prev;
        /// <summary>
        /// Команда снять маскирование по ТМ на предыдущем цикле работы программы
        /// </summary>
        private bool nlTUDropMask_prev;
        /// <summary>
        /// Команда деблокировать по ТМ на предыдущем цикле работы программы на предыдущем цикле работы программы
        /// </summary>
        private bool nlTUDeblock_prev;
        /// <summary>
        /// Состояние алгоритма обработки защиты
        /// </summary>
        private uint state;

        public ProcKtpr()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
            T01 = new CpaLocalTimer();
            InternalTimers = new StArray<ITimer>(1, new []{T01});
        }

        public override void Execute()
        {
            Result.F = Input;

            if (Cfg.NotMasked)
            {
                Result.M = false;
            }

            var flSetMask = false;
            var flDropMask = false;

            if (!(nlTUSetMask && nlTUDropMask))
            {
                if (nlTUSetMask && !nlTUSetMask_prev)
                {
                    Messenger.Send(018); /* защита i - КОМАНДА – УСТАНОВИТЬ МАСКИРОВАНИЕ ПО ТМ */
                    flSetMask = true;
                }
                else if (nlTUDropMask && !nlTUDropMask_prev)
                {
                    Messenger.Send(019);/* защита i - КОМАНДА – СНЯТЬ МАСКИРОВАНИЕ ПО ТМ */
                    flDropMask = true;
                }
            }

            nlTUSetMask_prev = nlTUSetMask;
            nlTUDropMask_prev = nlTUDropMask;

            if (!NpsDist && (flDropMask || flSetMask))
            {
                Messenger.Send(020);/* защита i - КОМАНДА ОТКЛОНЕНА – НПС В МЕСТНОМ РЕЖИМЕ УПРАВЛЕНИЯ  */
                flDropMask = false;
                flSetMask = false;
            }

            if (Cmd == ProcKtprCmd.Mask)
            { /*Команда установить режим Маскирование*/
                Messenger.Send(001);/*принята команда установить режим "Маскирование для защиты i (1)*/
                flSetMask = true;
            }
            else if (Cmd == ProcKtprCmd.UnMask)
            { /*Команда сбросить режим Маскирование*/
                Messenger.Send(005);/*принята команда снять "Маскирование для защиты i (5)*/
                flDropMask = true;
            }

            if (flSetMask)
            {
                if (Cfg.NotMasked)
                {
                    Messenger.Send(002);/* защиты i не маскируется. выполение не возможно(2)*/
                }
                else if (!Result.M)
                {  /*ВОПРОС к блок схеме ТПР почему так? по запрету же сброшено? получим "не возможно" и следом "установлено" а в влед цикле сброшено */
                    Messenger.Send(003);/* защита i - маскирование установлено(3)*/
                    Result.M = true;
                }
                else
                {
                    Messenger.Send(004);/* защита i - маскирование установлено. Выполнение не требуется (4)*/
                }
            }

            if (flDropMask)
            {
                if (Result.M)
                {
                    Messenger.Send(006);/* защита i - маскирование снято(6)*/
                    Result.M = false;
                }
                else
                {
                    Messenger.Send(007);/* защита i - маскирование снято. Выполнение не требуется(7)*/
                }
            }

            var flDeblock = false;

            if (nlTUDeblock && !nlTUDeblock_prev)
            {
                flDeblock = true;
                Messenger.Send(017);/*защита i -КОМАНДА – ДЕБЛОКИРОВАТЬ ПО ТМ */
            }

            nlTUDeblock_prev = nlTUDeblock;

            if (!NpsDist && flDeblock)
            {
                Messenger.Send(020);/* защита i - КОМАНДА ОТКЛОНЕНА – НПС В МЕСТНОМ РЕЖИМЕ УПРАВЛЕНИЯ  */
                flDeblock = false;
            }

            if (Cmd == ProcKtprCmd.Deblock)
            {
                flDeblock = true;
                Messenger.Send(008);/*защита i -принята команда  "Деблокировать"  (8)*/
            }
            if (flDeblock)
            {
                if (Result.P)
                {
                    if (Input && !Result.M)
                    {
                        Messenger.Send(009);/* защита i - деблокирование невозможно. Сигнал не снят(9)*/
                    }
                    else
                    {
                        Messenger.Send(010);/* защита i - деблокирована (10)*/
                        state = 5;
                        Result.P = false;
                    }
                }
                else
                {
                    Messenger.Send(011);/* защита i - Деблокирована. Выполнение не требуется(11)*/
                }
            }

            if (!Input)
            {
                T01.Start();
            }

            var InnerP = (!T01.IsStarted) || Result.P;

            if (state == 0)
            { /*НОРМА*/
                if (Result.F)
                {
                    if (T01.Ust > TimeSpan.Zero)
                    {
                        Messenger.Send(012);/*защита i - взведена (12)*/
                    }
                    state = 10;
                }
            }


            if (state == 5)
            {  /*деблокирована*/
                if (Result.F)
                {
                    state = 10;
                }
                else
                {
                    state = 0;
                }
            }

            if (state == 10)
            { /*взведение защиты*/
                if (!Result.F)
                {
                    Messenger.Send(013);/*защита i - авар. параметр снят (13)*/
                    state = 0;
                }
                else if (InnerP)
                {
                    state = 20;
                }
            }
            if (state == 20)
            { /*срабатывание защиты*/
                if (!Result.M)
                {
                    Messenger.Send(014);/*защита i  (14)*/
                    Result.P = true;
                    state = 25;
                }
                else
                {
                    Messenger.Send(015);/*защита i - игнор (15)*/
                    state = 22;
                }
            }

            if (state == 22)
            { /*маска, наличие авар параметра*/
                if (!Result.F)
                {
                    Messenger.Send(013);/*защита i - авар. параметр снят (13)*/
                    state = 0;
                }
                else if (!Result.M)
                { /*сняли маску*/
                    Messenger.Send(014);/*защита i  (14)*/
                    Result.P = true;
                    state = 25;
                }
            }
            if (state == 25)
            { /*снятие праметра, сработанной защиты*/
                if (!Result.F)
                {
                    Messenger.Send(013);/*защита i - авар. параметр снят (13)*/
                    if (Cfg.AutoDeblock && DblkCond)
                    { //Автоматически деблокируем защиты по давлениям согласно РД
                        state = 0;
                        Result.P = false;
                        Messenger.Send(016);/*защита i - ДЕБЛОКИРОВАНА АВТОМАТИЧЕСКИ (16)*/ //09.02.2018 ИЦ: добавили сообщение
                    }
                    else
                    {                           ///Остальные защиты-ждем деблокировки
                        state = 27;
                    }
                }
            }
            if (state == 27)
            { /*маска, нет авар параметра*/
                if (Cfg.AutoDeblock && DblkCond)
                { //Автоматически деблокируем защиты по давлениям согласно РД
                    state = 0;
                    Result.P = false;
                    Messenger.Send(016);/*защита i - ДЕБЛОКИРОВАНА АВТОМАТИЧЕСКИ (16)*/ //09.02.2018 ИЦ: добавили сообщение
                }
                else if (Result.F)
                {
                    Messenger.Send(012);/*АВАРИЙНЫЙ ПАРАМЕТР УСТАНОВЛЕН*/
                    state = 25;
                }
            }

            Result.NotMasked = Cfg.NotMasked;
        }
        
    }
}
