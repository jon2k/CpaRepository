﻿using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarReferenceSource.Mpt.Spz;

namespace TarReferenceSource.Mpt.Sup
{
    public class Sup : SupIo
    {
        /// <summary>
        /// Команда автоматического сброса режима принята
        /// </summary>
        private bool DropModeAccepted; 

        public Sup()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }

        public override void Execute()
        {

            /* Обработка команд на смену режимов */
            if ((inp.cmd == enumSUPCmd.DropAutoMode))
            {
                Messenger.Send(1); //КОМАНДА - СБРОСИТЬ РЕЖИМ
                if (output.Mode == enumSUPMode.NONE)
                {
                    Messenger.Send(2); //СБРОС НЕ ТРЕБУЕТСЯ. РЕЖИМ АВТ НЕ НАЗНАЧЕН
                }
                else if (inp.atpInProgress)
                {
                    Messenger.Send(4); //СБРОС НЕВОЗМОЖЕН. ИДЕТ ТУШЕНИЕ ПОЖАРА
                }
                else if (inp.szs.State == enumSPZState.Fire)
                {
                    Messenger.Send(3); //СБРОС НЕВОЗМОЖЕН. ПОЖАР!
                }
                else
                {
                    Messenger.Send(5); //РЕЖИМ СБРОШЕН
                    output.Mode = enumSUPMode.NONE;
                }
            }

            if (inp.cmd == enumSUPCmd.SetAutoMode)
            {
                Messenger.Send(6); //КОМАНДА - НАЗНАЧИТЬ РЕЖИМ АВТОМАТИЧЕСКИЙ
                if (inp.szs.IsRem)
                {
                    Messenger.Send(7); //НАЗНАЧЕНИЕ НЕВОЗМОЖНО. СООРУЖЕНИЕ В РЕМОНТЕ
                }
                else if (inp.szs.ZoneInMask)
                {
                    Messenger.Send(8); //НАЗНАЧЕНИЕ НЕВОЗМОЖНО. МАСКИРОВАНИЕ ЗАШИТЫ ПО ПОЖАРУ
                }
                else
                {
                    Messenger.Send(9); //НАЗНАЧЕН РЕЖИМ АВТ.
                    output.Mode = enumSUPMode.AUTO;
                }
            }

            if (!inp.szs.ZoneInMask && !inp.NeedDropMode && !inp.szs.IsRem)
            {
                DropModeAccepted = false;
            }

            if ((inp.szs.ZoneInMask || inp.NeedDropMode) && !DropModeAccepted && output.Mode != enumSUPMode.NONE)
            {
                Messenger.Send(10); //КОМАНДА - СБРОСИТЬ РЕЖИМ АВТОМАТИЧЕСКИ
                DropModeAccepted = true;
                if (output.Mode != enumSUPMode.NONE)
                {
                   
                    if (inp.atpInProgress) {

                        Messenger.Send(4); //СБРОС НЕВОЗМОЖЕН. ИДЕТ ТУШЕНИЕ ПОЖАРА
                    }
                    else if (inp.szs.State == enumSPZState.Fire)
                    {
                        Messenger.Send(3);//СБРОС НЕВОЗМОЖЕН. ПОЖАР!
                    }
                    else
                    {
                        Messenger.Send(11);//РЕЖИМ СБРОШЕН АВТОМАТИЧЕСКИ
                        output.Mode = enumSUPMode.NONE;
                    }
                }
                
            }

            if (inp.szs.ZoneInMask && output.Mode != enumSUPMode.NONE && inp.szs.State != enumSPZState.Fire && !inp.atpInProgress)
            {
                Messenger.Send(10); //КОМАНДА - СБРОСИТЬ РЕЖИМ АВТОМАТИЧЕСКИ
                Messenger.Send(11); //РЕЖИМ СБРОШЕН АВТОМАТИЧЕСКИ
                output.Mode = enumSUPMode.NONE;
            } /* //Обработка команд на смену режимов */


            /*Формирование выходов*/

            output.CanFirefight = (output.Mode == enumSUPMode.AUTO) && (!inp.szs.IsRem);
            output.NeedFirefight = (inp.szs.State == enumSPZState.Fire);



        }
    }
}
