﻿using TarFoundation.St;
using TarReferenceSource.Oip;

namespace TarReferenceSource.Sard.Throttle
{
    public abstract class ProcCorrectionIo : IFunctionBlock
    {
        //in
        /// <summary>
        /// input Аналоговый синал с датчика давления
        /// </summary>
        public AnalogSignal dp;
        /// <summary>
        /// input Фналоговый сигнал с датчика положения
        /// </summary>
        public AnalogSignal pos;
        /// <summary>
        /// cfg Настройка для регулирования по положению
        /// </summary>
        public DempCfg PosDempCfg = new DempCfg();
        /// <summary>
        /// cfg Настройка для регулирования по давлению
        /// </summary>
        public DempCfg dpDempCfg = new DempCfg();
        //out
        /// <summary>
        /// output Корректирующее воздействие
        /// </summary>
        public ThrottleCorrections corrections = new ThrottleCorrections();
    }
    public class ProcCorrection : ProcCorrectionIo
    {

        public override void Execute()
        {
            corrections.LinearCorrections = 1.0f;
            if (!dp.Ndv)
            {
                corrections.LinearCorrections = corrections.LinearCorrections * dpDempCfg.CalculateCoeff(dp.VisualValue);
            }
            
            if (!pos.Ndv)
            {
                corrections.LinearCorrections = corrections.LinearCorrections * PosDempCfg.CalculateCoeff(pos.VisualValue);
            }
        }
    }
}
