﻿using System.Collections.Generic;
using TarFoundation.Description;
using TarFoundation.Messenger;

namespace Friday.Helpers
{
    public class MessageDecoder
    {
        private readonly Dictionary<uint, MessageDescription> _d;

        public MessageDecoder(Dictionary<uint, MessageDescription> d)
        {
            _d = d;
        }
        public void Decode(Message m)
        {
            m.text = _d.ContainsKey(m.msgId) ? _d[m.msgId].Text : "unknown message";
            m.type = _d.ContainsKey(m.msgId) ? _d[m.msgId].Type : MessageType.Neutral;
        }
    }
}