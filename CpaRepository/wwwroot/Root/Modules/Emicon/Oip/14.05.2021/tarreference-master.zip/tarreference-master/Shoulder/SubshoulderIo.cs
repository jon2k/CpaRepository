﻿namespace TarReferenceSource.Shoulder
{
    public class SubshoulderIo
    {
        public readonly ShoulderStopCmd AutoCmd = new ShoulderStopCmd();
        //public NsStopType AutoStopCmd;
        //public NaStopType AutoStopCmdMethod;
        public bool IsSafety;
    }
}
