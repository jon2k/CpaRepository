﻿using System.Collections.Generic;
using System.Linq;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.Runtime;
using TarFoundation.St;
using TarReferenceSource.CommonNa;
using TarReferenceSource.Ktpra;
using TarReferenceSource.Shoulder;

namespace TarReferenceSource.LocalStorages
{
    /// <summary>
    /// Струкрура перехода между МНА
    /// </summary>
    public struct TransitionStruct
    {
        /// <summary>
        /// Номер агрегата, назначенного на запуск при автоматизированном переходе
        /// </summary>
        public ushort MNA_TO;
        /// <summary>
        /// Номер агрегата, назначенного на остановку при автоматизированном переходе
        /// </summary>
        public ushort MNA_FROM;
        /// <summary>
        /// Конфигурация перехода. 1 – с меньшего на большее колесо. 0 – с большего на меньшее, либо равное колесо
        /// </summary>
        public bool FromSmallToBig;
        /// <summary>
        /// Назначенный на остановку при автоматизированном переходе МНА в работе. 1 – в работе. 0 – не в работе
        /// </summary>
        public bool MNA_FROM_IsON;
        /// <summary>
        /// Назначенный на остановку при автоматизированном переходе МНА в режиме «ОСН». 1 – в режиме «ОСН». 0 – не в режиме «ОСН»
        /// </summary>
        public bool MNA_FROM_IsOSN;
        /// <summary>
        /// Назначенный на остановку при автоматизированном переходе МНА не в имитации. 1 – не в имитации. 0 – в имитации
        /// </summary>
        public bool MNA_FROM_IsNotIMIT;
        /// <summary>
        /// Назначенный на запуск при автоматизированном переходе МНА остановлен. 1 – остановлен. 0 – не остановлен
        /// </summary>
        public bool MNA_TO_IsOFF;
        /// <summary>
        /// Назначенный на запуск при автоматизированном переходе МНА в режиме «ОСН». 1 – в режиме «ОСН». 0 – не в режиме «ОСН»
        /// </summary>
        public bool MNA_TO_IsOSN;
        /// <summary>
        /// Назначенный на запуск при автоматизированном переходе МНА не в имитации. 1 – не в имитации. 0 – в имитации
        /// </summary>
        public bool MNA_TO_IsNotIMIT;
        /// <summary>
        /// Назначенному на запуск при автоматизированном переходе МНА назначена П1. 1 – назначена П1. 0 – назначена П2
        /// </summary>
        public bool MNA_TO_IsP1;
        /// <summary>
        /// Агрегатные задвижки назначенного на запуск при автоматизированном переходе МНА открыты. 1 – агрегатные задвижки открыты. 0 – агрегатные задвижки не открыты
        /// </summary>
        public bool MNA_TO_IsZDOpened;
        /// <summary>
        /// Агрегатные задвижки назначенного на запуск при автоматизированном переходе МНА не в имитации. 1 – агрегатные задвижки не в имитации. 0 – одна из агрегатных задвижек в имитации
        /// </summary>
        public bool MNA_TO_IsZDNotIMIT;
        /// <summary>
        /// Назначенный на запуск при автоматизированном переходе МНА готов к пуску. 1 – готов к пуску. 0 – не готов к пуску
        /// </summary>
        public bool MNA_TO_GP;
        /// <summary>
        /// Наличие агрегатной защиты назначенного на запуск при автоматизированном переходе МНА . 1 – наличие защиты. 0 – отсутствие защиты
        /// </summary>
        public bool MNA_FROM_LIST3;
        /// <summary>
        /// Наличие агрегатной защиты назначенного на остановку при автоматизированном переходе МНА. 1 – наличие защиты. 0 – отсутствие защиты
        /// </summary>
        public bool MNA_TO_LIST3;
        /// <summary>
        /// Наличие общестанционной защиты. 1 – наличие защиты. 0 – отсутствие защиты
        /// </summary>
        public bool MNA_TO_LIST2;
        /// <summary>
        /// Готовность к автоматизированному переходу с МНА на МНА. 1 – наличие готовности. 0 – отсутствие готовности
        /// </summary>
        public bool Ready;
        /// <summary>
        /// Готовность к автоматизированному переходу с МНА на МНА по давлению. 1 – наличие готовности. 0 – отсутствие готовности
        /// </summary>
        public bool Pressure_Ready;
        /// <summary>
        /// Запускаемый и отключаемый НА в одном плече. 1 – в одном плече. 0 – в разных плечах
        /// </summary>
        public bool MNA_TO_InOneShoulder;
    }
    /// <summary>
    /// 
    /// </summary>
    public class ShoulderPublicTimers : ICallable
    {
        public ShoulderPublicTimers(List<ITimeTraveler> timers)
        {
            Timers = timers;
        }
        public List<ITimeTraveler> Timers { get; }
        public void Call()
        {
            ;
        }
    }
    /// <summary>
    /// 
    /// </summary>
    public class AvrPublicTimers : ICallable
    {
        public AvrPublicTimers(List<ITimeTraveler> timers)
        {
            Timers = timers;
        }
        public List<ITimeTraveler> Timers { get; }
        public void Call()
        {
            ;
        }
    }
    /// <summary>
    /// Структура данных для управления насосным агрегатом
    /// </summary>
    public class NaAutoCmds
    {
        /// <summary>
        /// Команда на остановку НА 
        /// </summary>
        public NaStopType StopType { get; set; }
        /// <summary>
        /// Команда на запуск НА 
        /// </summary>
        public bool StartAuto { get; set; }  // Команда на запуск НА № I+
        /// <summary>
        /// Команда на запуск НА по АВР
        /// </summary>
        public bool StartRez { get; set; } // Команда на запуск резервного НА № I+
        /// <summary>
        /// Команда на автоматическую установку режима «ОСН» НА
        /// </summary>
        public bool SetOsnAuto { get; set; }  // Команда на автоматическую установку режима «ОСН» НА № I+
        /// <summary>
        /// Флаг отсутствия НА с назначенным режимом «ОСН» или «ТМ» в текущем плече
        /// </summary>
        public bool NoOsnForRes { get; set; } //Отсутствие НА с назначенным режимом «ТМ» или «ОСН» в текущем плече
        /// <summary>
        /// Флаг наличия НА в режиме «РЕЗ» в текущем плече
        /// </summary>
        public bool RezExist { get; set; }  //Наличие НА с назначенным режимом «РЕЗв текущем плече
        /// <summary>
        /// Флаг, разрешающий НА установку режима «РЕЗ»
        /// </summary>
        public bool DoRez { get; set; } //Принятие решения об установке режима «Резервный»
    }

    public abstract class KrmpnIo : IFunctionBlock
    {
        // in
        /// <summary>
        /// input
        /// </summary>
        public bool IsPressureReady;
        /// <summary>
        /// input Массив насосных агрегатов
        /// </summary>
        public StArray<NaIo> NA;
        /// <summary>
        /// input Массив результата работы модуля Ktpra
        /// </summary>
        public StArray<KtpraResult> KtpraResults;
        /// <summary>
        /// input Массив результата работы моделя Ktpr
        /// </summary>
        public StArray<ShoulderIo> shoulders;
        /// <summary>
        /// input Массив результата работы моделя Ktpr
        /// </summary>
        public StArray<SubshoulderIo> subshoulders;
        /// <summary>
        /// 
        /// </summary>
        public StArray<ShoulderPublicTimers> ShouldersTimers;
        /// <summary>
        /// 
        /// </summary>
        public StArray<AvrPublicTimers> AvrsTimers;
        
        // out
        /// <summary>
        /// output Флаг включенного состояния насосной станции. 0 – НС не в работе. 1 – Хотя бы один НА в состоянии «в работе»
        /// </summary>
        public bool IsMNSOn;
        /// <summary>
        /// output Флаг отключенного состояния насосной станции. 1 – Все НА в состоянии «остановлен»
        /// </summary>
        public bool IsMNSOff;
        /// <summary>
        /// output Неноминальный интервал подач
        /// </summary>
        public bool NeNomFeedInterval;
        
        // in
        /// <summary>
        /// input Команды модуля KRMPN. 1 – Выполнить переход с МНА на МНА. 2 – Сброс настроек автоматизированного перехода
        /// </summary>
        public ushort CMD;
        /// <summary>
        /// input Номер агрегата, назначенного на отключение при автоматизированном переходе, полученный с ВУ. Является командой с ВУ, т.е. устанавливается в значение 0 после принятия команды модулем KRMPN.
        /// </summary>
        public ushort MNA_FROM;
        /// <summary>
        /// input Номер агрегата, назначенного на запуск при автоматизированном переходе, полученный с ВУ Является командой с ВУ, т.е. устанавливается в значение 0 после принятия команды модулем KRMPN.
        /// </summary>
        public ushort MNA_TO;
        
        // out
        /// <summary>
        /// output Режим перекачки МНС. 1 – последовательный. 0 – параллельный
        /// </summary>
        public bool IsNPSModePsl;
        /// <summary>
        /// output Структура данных для агрегатных переходов
        /// </summary>
        public TransitionStruct MNA_TO_MNA;
        /// <summary>
        /// output Массив команд для управления агрегатами
        /// </summary>
        public StArray<NaAutoCmds> Commands;
        public KrmpnIo(NaIo[] na, KtpraResult[] ktpraResults, ShoulderIo[] shoulders, SubshoulderIo[] subshoulders)
        {
            NA = new StArray<NaIo>(1, na);
            KtpraResults = new StArray<KtpraResult>(1, ktpraResults);
            this.shoulders = new StArray<ShoulderIo>(1, shoulders);
            this.subshoulders = new StArray<SubshoulderIo>(1, subshoulders);

            Commands = new StArray<NaAutoCmds>(1, Enumerable.Range(1, NA.Count).Select(i => new NaAutoCmds()).ToArray());
        }

        public override void AfterCall()
        {
            MNA_FROM = 0;
            MNA_TO = 0;
            CMD = 0;
            for (int i = 1; i <= NA.Count; i++)
            {
                NA[i].AutoStopCmd = Commands[i].StopType;
                NA[i].StartAuto = Commands[i].StartAuto;
                NA[i].StartRez = Commands[i].StartRez;
                NA[i].AutoOsn = Commands[i].SetOsnAuto;
                NA[i].DoRez = Commands[i].DoRez;
                NA[i].NoOsnForRez = Commands[i].NoOsnForRes;
                NA[i].RezExist = Commands[i].RezExist;
            }
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
            {
                {0, new MessageDescription{Text = "КОМАНДА ВЫПОЛНИТЬ ПЕРЕХОД С МНА НА МНА", Type = MessageType.Information} },
                {1, new MessageDescription{Text = "ОТКЛЮЧАЕМЫЙ МНА № X", Type = MessageType.Neutral} },
                {2, new MessageDescription{Text = "ЗАПУСКАЕМЫЙ МНА № X", Type = MessageType.Neutral} },
                {3, new MessageDescription{Text = "ОТКЛЮЧАЕМЫЙ МНА НЕ ВКЛЮЧЕН", Type = MessageType.Neutral} },
                {4, new MessageDescription{Text = "У ОТКЛЮЧАЕМОГО МНА НЕ УСТАНОВЛЕН РЕЖИМ ОСН", Type = MessageType.Neutral} },
                {5, new MessageDescription{Text = "ОТКЛЮЧАЕМЫЙ МНА В ИМИТАЦИИ", Type = MessageType.Neutral} },
                {6, new MessageDescription{Text = "ЗАПУСКАЕМЫЙ МНА НЕ ОТКЛЮЧЕН", Type = MessageType.Neutral} },
                {7, new MessageDescription{Text = "У ЗАПУСКАЕМОГО МНА НЕ УСТАНОВЛЕН РЕЖИМ ОСН", Type = MessageType.Neutral} },
                {8, new MessageDescription{Text = "ЗАПУСКАЕМЫЙ МНА В ИМИТАЦИИ", Type = MessageType.Neutral} },
                {9, new MessageDescription{Text = "У ЗАПУСКАЕМОГО МНА НЕ УСТАНОВЛЕНА П1", Type = MessageType.Neutral} },
                {10, new MessageDescription{Text = "У ЗАПУСКАЕМОГО МНА НЕ ОТКРЫТЫ АГРЕГАТНЫЕ ЗАДВИЖКИ", Type = MessageType.Neutral} },
                {11, new MessageDescription{Text = "У ЗАПУСКАЕМОГО МНА УСТАНОВЛЕНА ИМИТАЦИЯ АГРЕГАТНЫХ ЗАДВИЖЕК", Type = MessageType.Neutral} },
                {12, new MessageDescription{Text = "ЗАПУСКАЕМЫЙ МНА НЕ ГОТОВ К ПУСКУ", Type = MessageType.Neutral} },
                {13, new MessageDescription{Text = "ЗАПУСКАЕМЫЙ И ОТКЛЮЧАЕМЫЙ МНА НЕ В ОДНОМ ПЛЕЧЕ", Type = MessageType.Neutral} },
                {14, new MessageDescription{Text = "ВО ВРЕМЯ ВЫПОЛНЕНИЯ ПРОЦЕДУРЫ ПЕРЕХОДА ПОТЕРЯНА ГОТОВНОСТЬ К ПЕРЕХОДУ", Type = MessageType.Neutral} },
                {15, new MessageDescription{Text = "ОТСУТСТВУЕТ ГОТОВНОСТЬ К ПЕРЕХОДУ С МНА НА МНА", Type = MessageType.Neutral} },
                {16, new MessageDescription{Text = "ГОТОВНОСТЬ К ПЕРЕХОДУ С МНА НА МНА УСТАНОВЛЕНА", Type = MessageType.Neutral} },
                {17, new MessageDescription{Text = "ОТКЛЮЧАЕМЫЙ МНА НЕ ОТКЛЮЧИЛСЯ", Type = MessageType.Attention} },
                {18, new MessageDescription{Text = "ЗАПУСКАЕМЫЙ МНА НЕ ВКЛЮЧИЛСЯ", Type = MessageType.Attention} },
                {19, new MessageDescription{Text = "НАЛИЧИЕ ЗАЩИТЫ НАЗНАЧЕННОГО НА ОТКЛЮЧЕНИЕ МНА", Type = MessageType.Attention} },
                {20, new MessageDescription{Text = "НАЛИЧИЕ ЗАЩИТЫ НАЗНАЧЕННОГО НА ОТКЛЮЧЕНИЕ МНА", Type = MessageType.Attention} },
                {21, new MessageDescription{Text = "ВО ВРЕМЯ ПРОЦЕДУРЫ ПЕРЕХОДА С МНА НА МНА СРАБОТАЛА ОБЩЕСТАНЦИОННАЯ ЗАЩИТА", Type = MessageType.Attention} },
                {22, new MessageDescription{Text = "ПЕРЕХОД С МНА НА МНА ЗАВЕРШЕН", Type = MessageType.Information} },
                {23, new MessageDescription{Text = "НЕТ МНА В ГОРЯЧЕМ РЕЗЕРВЕ", Type = MessageType.Neutral} },
                {24, new MessageDescription{Text = "НЕТ МНА В РЕЗЕРВЕ", Type = MessageType.Neutral} },
                {25, new MessageDescription{Text = "ГОТОВНОСТЬ К ПЕРЕХОДУ С МНА НА МНА СНЯТА", Type = MessageType.Neutral} },
                {26, new MessageDescription{Text = "ПРОЦЕСС ПЕРЕХОДА С МНА НА МНА ОТМЕНЕН", Type = MessageType.Neutral} },
                {27, new MessageDescription{Text = "ВЫПОЛНЕНИЕ НЕВОЗМОЖНО. ИДЕТ ПРОЦЕСС ПЕРЕХОДА", Type = MessageType.Neutral} },
                {28, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ НА ОТКЛЮЧЕНИЕ ПРИ ПЕРЕХОДЕ МНА № X", Type = MessageType.Information} },
                {29, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ НА ЗАПУСК ПРИ ПЕРЕХОДЕ МНА № X", Type = MessageType.Information} },
                {30, new MessageDescription{Text = "НА ОТКЛЮЧЕНИЕ ПРИ ПЕРЕХОДЕ НАЗНАЧЕН МНА № X", Type = MessageType.Neutral} },
                {31, new MessageDescription{Text = "НА ЗАПУСК ПРИ ПЕРЕХОДЕ НАЗНАЧЕН МНА № X", Type = MessageType.Neutral} },
                {32, new MessageDescription{Text = "КОНФИГУРАЦИЯ ПЕРЕХОДА - С БОЛЬШЕГО НА МЕНЬШЕЕ КОЛЕСО", Type = MessageType.Neutral} },
                {33, new MessageDescription{Text = "КОНФИГУРАЦИЯ ПЕРЕХОДА - С МЕНЬШЕГО НА БОЛЬШЕЕ КОЛЕСО", Type = MessageType.Neutral} },
                {34, new MessageDescription{Text = "КОНФИГУРАЦИЯ ПЕРЕХОДА - НА РАВНОЕ КОЛЕСО", Type = MessageType.Neutral} },
                {35, new MessageDescription{Text = "ОТСУТСТВУЕТ ЗАЗОР ДАВЛЕНИЯ НА ВЫХОДЕ МНС", Type = MessageType.Neutral} },
                {36, new MessageDescription{Text = "НЕОБХОДИМОСТЬ АВР", Type = MessageType.Attention} },
                {37, new MessageDescription{Text = "НАЧАЛО ПРОЦЕДУРЫ ОТЛОЖЕННОГО АВР", Type = MessageType.Attention} },
                {38, new MessageDescription{Text = "АВР ОТМЕНЕН", Type = MessageType.Attention} },
                {39, new MessageDescription{Text = "МНА В РЕЗЕРВЕ, В РЕЖИМЕ ИМИТАЦИИ", Type = MessageType.Information} },
                {40, new MessageDescription{Text = "АГРЕГАТ НЕ ОТКЛЮЧИЛСЯ ЗА ЗАДАННОЕ ВРЕМЯ", Type = MessageType.Attention} },
                {41, new MessageDescription{Text = "ОКНО УПРАВЛЕНИЯ ПЕРЕХОДОМ С МНА НА МНА ЗАКРЫТО. СБРОС НАСТРОЕК ПЕРЕХОДА", Type = MessageType.Information} },
                {42, new MessageDescription{Text = "КОМАНДА – НАЗНАЧИТЬ НЕНОМИНАЛЬНЫЙ ИНТЕРВАЛ ПОДАЧ", Type = MessageType.Information} },//TODO: В РАБОЧЕМ
                {43, new MessageDescription{Text = "НАЗНАЧЕН НЕНОМИНАЛЬНЫЙ РЕЖИМ ПОДАЧ", Type = MessageType.Neutral} },//TODO: В РАБОЧЕМ
                {44, new MessageDescription{Text = "КОМАНДА – НАЗНАЧИТЬ НЕНОМИНАЛЬНЫЙ ИНТЕРВАЛ ПОДАЧ", Type = MessageType.Information} },//TODO: ВНЕ РАБОЧЕГО
                {45, new MessageDescription{Text = "НАЗНАЧЕН НЕНОМИНАЛЬНЫЙ РЕЖИМ ПОДАЧ", Type = MessageType.Neutral} },//TODO: ВНЕ РАБОЧЕГО
                {46, new MessageDescription{Text = "ЗАПРЕТ АВР", Type = MessageType.Neutral} },
                {54, new MessageDescription{Text = "ВЫПОЛНЕНИЕ НЕВОЗМОЖНО. НЕ ВЫБРАН ОТКЛЮЧАЕМЫЙ МНА", Type = MessageType.Neutral} },
                {55, new MessageDescription{Text = "ВЫПОЛНЕНИЕ НЕВОЗМОЖНО. НЕ ВЫБРАН ЗАПУСКАЕМЫЙ МНА", Type = MessageType.Neutral} },
                {90, new MessageDescription{Text = "ОДНОВРЕМЕННАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {91, new MessageDescription{Text = "ОДНОВРЕМЕННАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {92, new MessageDescription{Text = "ОДНОВРЕМЕННАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {93, new MessageDescription{Text = "ОДНОВРЕМЕННАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {94, new MessageDescription{Text = "ОДНОВРЕМЕННАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {95, new MessageDescription{Text = "ОДНОВРЕМЕННАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ С КОЛЛЕКТОРА X", Type = MessageType.Alarm} },
                {96, new MessageDescription{Text = "ОДНОВРЕМЕННАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ С КОЛЛЕКТОРА X", Type = MessageType.Alarm} },
                {97, new MessageDescription{Text = "ОДНОВРЕМЕННАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ С КОЛЛЕКТОРА X", Type = MessageType.Alarm} },
                {98, new MessageDescription{Text = "ОДНОВРЕМЕННАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ С КОЛЛЕКТОРА X", Type = MessageType.Alarm} },
                {99, new MessageDescription{Text = "ОДНОВРЕМЕННАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ С КОЛЛЕКТОРА X", Type = MessageType.Alarm} },
                {100, new MessageDescription{Text = "ПОСЛЕДОВАТЕЛЬНАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {101, new MessageDescription{Text = "ПОСЛЕДОВАТЕЛЬНАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {102, new MessageDescription{Text = "ПОСЛЕДОВАТЕЛЬНАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {103, new MessageDescription{Text = "ПОСЛЕДОВАТЕЛЬНАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {104, new MessageDescription{Text = "ПОСЛЕДОВАТЕЛЬНАЯ ОСТАНОВКА НА, РАБОТАЮЩИХ В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {105, new MessageDescription{Text = "ОСТАНОВКА ПЕРВОГО ПО ПОТОКУ НА (С ОСТАНОВКОЙ ПОСЛЕДУЮЩЕГО ПРИ СОХРАНЕНИИ АВАРИЙНОГО ПАРАМЕТРА), РАБОТАЮЩЕГО В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {106, new MessageDescription{Text = "ОСТАНОВКА ПЕРВОГО ПО ПОТОКУ НА (С ОСТАНОВКОЙ ПОСЛЕДУЮЩЕГО ПРИ СОХРАНЕНИИ АВАРИЙНОГО ПАРАМЕТРА), РАБОТАЮЩЕГО В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {107, new MessageDescription{Text = "ОСТАНОВКА ПЕРВОГО ПО ПОТОКУ НА (С ОСТАНОВКОЙ ПОСЛЕДУЮЩЕГО ПРИ СОХРАНЕНИИ АВАРИЙНОГО ПАРАМЕТРА), РАБОТАЮЩЕГО В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {108, new MessageDescription{Text = "ОСТАНОВКА ПЕРВОГО ПО ПОТОКУ НА (С ОСТАНОВКОЙ ПОСЛЕДУЮЩЕГО ПРИ СОХРАНЕНИИ АВАРИЙНОГО ПАРАМЕТРА), РАБОТАЮЩЕГО В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {109, new MessageDescription{Text = "ОСТАНОВКА ПЕРВОГО ПО ПОТОКУ НА (С ОСТАНОВКОЙ ПОСЛЕДУЮЩЕГО ПРИ СОХРАНЕНИИ АВАРИЙНОГО ПАРАМЕТРА), РАБОТАЮЩЕГО В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {110, new MessageDescription{Text = "ОСТАНОВКА ПЕРВОГО ПО ПОТОКУ НА, РАБОТАЮЩЕГО В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {111, new MessageDescription{Text = "ОСТАНОВКА ПЕРВОГО ПО ПОТОКУ НА, РАБОТАЮЩЕГО В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {112, new MessageDescription{Text = "ОСТАНОВКА ПЕРВОГО ПО ПОТОКУ НА, РАБОТАЮЩЕГО В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {113, new MessageDescription{Text = "ОСТАНОВКА ПЕРВОГО ПО ПОТОКУ НА, РАБОТАЮЩЕГО В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {114, new MessageDescription{Text = "ОСТАНОВКА ПЕРВОГО ПО ПОТОКУ НА, РАБОТАЮЩЕГО В НАПРАВЛЕНИИ X", Type = MessageType.Alarm} },
                {120, new MessageDescription{Text = "ИЗМЕНЕНА ВРЕМЕННАЯ УСТАВКА I. НОВОЕ ЗНАЧЕНИЕ Usts", Type = MessageType.Neutral} },

            };
}
}
