﻿using Friday.Helpers;
using Friday.Runtime.CpaLocal;

namespace TarReferenceSource.Mpt.Spz
{
    public class Spz : SpzIo
    {
        /// <summary>
        /// Флаг наличия хотя бы одной пожарной установки в автоматическом режиме
        /// </summary>
        private bool flAnyInAuto;
        /// <summary>
        /// Флаг наличия хотя бы одной пожарной установки зоны в работе
        /// </summary>
        private bool flAnyInAction;
        /// <summary>
        /// Флаг наличия хотя бы одного аварийного сигнала защиты по пожару зоны
        /// </summary>
        private bool F;
        /// <summary>
        /// Флаг наличия хотя бы одной сработавшей защиты по пожару зоны
        /// </summary>
        private bool P;
        /// <summary>
        /// Флаг маскирования всех защит по пожару зоны
        /// </summary>
        private bool M;


        public Spz()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }

        public override void Execute()
        {
            
            flAnyInAuto = false;
            flAnyInAction = false;

            F = inp.KTPRP.F;
            P = inp.KTPRP.P;
            M = inp.KTPRP.M;

            //Формирование состояния
            if (output.ToSUP.IsRem)
            {
                //сброс состояния сооружения в ремонте
                output.ToSUP.State = enumSPZState.NOTHING;
            }
            else if (P)
            {
                if (output.ToSUP.State != enumSPZState.Fire)
                {
                    Messenger.Send(1); //Пожар
                }
                output.ToSUP.State = enumSPZState.Fire;
            }
            else if (inp.OneSensorTriggered)
            {
                if (output.ToSUP.State != enumSPZState.Attention)
                {
                    Messenger.Send(2); //Внимание
                }
                output.ToSUP.State = enumSPZState.Attention;
            }
            else if (!(P || inp.OneSensorTriggered))
            {
                if (output.ToSUP.State != enumSPZState.Norm)
                {
                    Messenger.Send(3); //Норма
                }
                output.ToSUP.State = enumSPZState.Norm;
            }
            flAnyInAuto = inp.facilities.IsAuto;
            flAnyInAction = inp.facilities.IsFireProc;

            //Команды сооружению
            //Команда - назначить РЕМ
            if (inp.structCmd == enumSPZCmd.SetRepairMode)
            {
                Messenger.Send(4); //Команда - назначить режим РЕМ
                if (output.ToSUP.State == enumSPZState.Fire || output.ToSUP.State == enumSPZState.Attention)
                {
                    Messenger.Send(5); //Назначение невозможно. Состояние не норма
                }
                else if (flAnyInAuto)
                {
                    Messenger.Send(6); //Назначение невозможно. Режим АВТ не сброшен
                }
                else if (flAnyInAction)
                {
                    Messenger.Send(7); //Назначение невозможно. Идет тушение пожара
                }
                else if (output.ToSUP.IsRem)
                {
                    Messenger.Send(8); //Назначение не требуется. Режим РЕМ назначен
                }
                else
                {
                    Messenger.Send(9); //Назначен режим РЕМ
                    output.ToSUP.IsRem = true;
                }
            }//Команда - снять РЕМ
            if (inp.structCmd == enumSPZCmd.ResetRepairMode)
            {
                Messenger.Send(10); //Команда - снять режим РЕМ
                if (!output.ToSUP.IsRem)
                {
                    Messenger.Send(11); //Команда не требуется. Режим РЕМ не снят
                }
                else
                {
                    Messenger.Send(12); //Режим РЕМ снят
                    output.ToSUP.IsRem = false;
                }
            }
            output.ToSUP.ZoneInMask = M;

            output.Alarm = P;

        }
    }
}
