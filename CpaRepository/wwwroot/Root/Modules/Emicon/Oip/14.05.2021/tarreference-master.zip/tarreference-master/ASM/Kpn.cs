﻿using TarReferenceSource.ASM;
using TarFoundation.St;

namespace KPN
{
    public class Kpn : KpnIo
    {
        /// <summary>
        /// Индексатор массива.
        /// </summary>
        private int k;
        /// <summary>
        /// Модуль анализ потоков нефти.
        /// </summary>
        private AsmIo asmIo;

        public Kpn(int elementSize, StArray<StArray<uint>> msm, StArray<uint> startPointCount):base(msm, startPointCount)
        {
            asmIo = new Asm(elementSize);
            asmIo.MSM = MSM;
            asmIo.States = States;
        }
        public override void Execute()
        {

            for (k = 1; k <= StartPointCount.Count; k++)
            {
                asmIo.StartPoint = StartPointCount[k];
                asmIo.Execute();
                Results[k] = asmIo.Result;
            }
        }


    }
}
