﻿using System.Collections.Generic;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.Messenger;

namespace TarReferenceSource.Oip
{
    public abstract class ProcLevelsIo : AbstractProcLevels
    {
        public ProcLevelsIo(ISignalDataSource signalSource) : base(signalSource)
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }

        public override LevelConfig GetLevelsConfig(int lvlNum)
        {
            return lvlNum > 0 ? MaxCfgs[lvlNum - 1] : MinCfgs[-lvlNum - 1];
        }

        public override bool IsLevel(int lvlNum)
        {
            return lvlNum > 0 ? Maxs[lvlNum - 1] : Mins[-lvlNum - 1];
        }
        //интерфейс модуля
        /// <summary>
        /// input Массив структур Level, соответствующим уровням выше нормального значения измеряемого параметра
        /// </summary>
        public LevelConfig[] MinCfgs { get; set; } = { new LevelConfig(), new LevelConfig(), new LevelConfig(), new LevelConfig(), new LevelConfig(), new LevelConfig(), };
        /// <summary>
        /// input  Массив структур Level, соответствующим уровням ниже нормального значения измеряемого параметра
        /// </summary>
        public LevelConfig[] MaxCfgs { get; set; } = { new LevelConfig(), new LevelConfig(), new LevelConfig(), new LevelConfig(), new LevelConfig(), new LevelConfig(), };
        /// <summary>
        /// output Массив, соответствующий уровням выше нормального значения измеряемого параметра
        /// </summary>
        public bool[] Maxs { get; set; } = new bool[6];
        /// <summary>
        /// output Массив, соответствующий уровням ниже нормального значения измеряемого параметра
        /// </summary>
        public bool[] Mins { get; set; } = new bool[6];


        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
            {
                {20, new MessageDescription{Text = "НОРМА", Type = MessageType.Neutral} },
                {21, new MessageDescription{Text = "«Минимум 1» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
                {22, new MessageDescription{Text = "«Минимум 1» СНЯТ", Type = MessageType.Neutral} },
                {23, new MessageDescription{Text = "«Минимум 1»", Type = MessageType.Neutral} },
                {24, new MessageDescription{Text = "«Минимум 2» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
                {25, new MessageDescription{Text = "«Минимум 2» СНЯТ", Type = MessageType.Neutral} },
                {26, new MessageDescription{Text = "«Минимум 2»", Type = MessageType.Attention} },
                {27, new MessageDescription{Text = "«Минимум 3» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
                {28, new MessageDescription{Text = "«Минимум 3» СНЯТ", Type = MessageType.Neutral} },
                {29, new MessageDescription{Text = "«Минимум 3»", Type = MessageType.Alarm} },
                {30, new MessageDescription{Text = "«Минимум 4» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
                {31, new MessageDescription{Text = "«Минимум 4» СНЯТ", Type = MessageType.Neutral} },
                {32, new MessageDescription{Text = "«Минимум 4»", Type = MessageType.Alarm} },
                {33, new MessageDescription{Text = "«Минимум 5» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
                {34, new MessageDescription{Text = "«Минимум 5» СНЯТ", Type = MessageType.Neutral} },
                {35, new MessageDescription{Text = "«Минимум 5»", Type = MessageType.Alarm} },
                {36, new MessageDescription{Text = "«Минимум 6» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
                {37, new MessageDescription{Text = "«Минимум 6» СНЯТ", Type = MessageType.Neutral} },
                {38, new MessageDescription{Text = "«Минимум 6»", Type = MessageType.Alarm} },
                {39, new MessageDescription{Text = "«Максимум 1» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
                {40, new MessageDescription{Text = "«Максимум 1» СНЯТ", Type = MessageType.Neutral} },
                {41, new MessageDescription{Text = "«Максимум 1»", Type = MessageType.Neutral} },
                {42, new MessageDescription{Text = "«Максимум 2» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
                {43, new MessageDescription{Text = "«Максимум 2» СНЯТ", Type = MessageType.Neutral} },
                {44, new MessageDescription{Text = "«Максимум 2»", Type = MessageType.Attention} },
                {45, new MessageDescription{Text = "«Максимум 3» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
                {46, new MessageDescription{Text = "«Максимум 3» СНЯТ", Type = MessageType.Neutral} },
                {47, new MessageDescription{Text = "«Максимум 3»", Type = MessageType.Alarm} },
                {48, new MessageDescription{Text = "«Максимум 4» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
                {49, new MessageDescription{Text = "«Максимум 4» СНЯТ", Type = MessageType.Neutral} },
                {50, new MessageDescription{Text = "«Максимум 4»", Type = MessageType.Alarm} },
                {51, new MessageDescription{Text = "«Максимум 5» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
                {52, new MessageDescription{Text = "«Максимум 5» СНЯТ", Type = MessageType.Neutral} },
                {53, new MessageDescription{Text = "«Максимум 5»", Type = MessageType.Alarm} },
                {54, new MessageDescription{Text = "«Максимум 6» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
                {55, new MessageDescription{Text = "«Максимум 6» СНЯТ", Type = MessageType.Neutral} },
                {56, new MessageDescription{Text = "«Максимум 6»", Type = MessageType.Alarm} },

            };
    }
}
