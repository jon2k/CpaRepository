﻿using TarFoundation.St;
using TarReferenceSource.Uzd;

namespace TarReferenceSource.ASM
{
    public enum PathState:ushort
    {
        Close,
        Other,
        Open
    }

    public abstract class AsmIo : IFunctionBlock
    {
        // Input.      
        /// <summary>
        /// input Матрица смежности задвижек.
        /// </summary>
        public StArray<StArray<uint>> MSM;
        /// <summary>
        /// input Количество задвижек в рассчитываемом маршруте.
        /// </summary>
        public uint ElementSize => (uint)States.Count;
        /// <summary>
        /// input Начальная точка рассчитываемого маршрута.
        /// </summary>
        public uint StartPoint;
        /// <summary>
        /// input Максимальная связность задвижек маршрута.
        /// </summary>
        public uint Connectivy;
        /// <summary>
        /// input Массив состояний задвижек маршрута.
        /// </summary>
        public StArray<ZdState> States;

        // Output.
        /// <summary>
        /// output Массив состояний маршрутов.
        /// </summary>
        public StArray<PathState> Result;

    }
}
