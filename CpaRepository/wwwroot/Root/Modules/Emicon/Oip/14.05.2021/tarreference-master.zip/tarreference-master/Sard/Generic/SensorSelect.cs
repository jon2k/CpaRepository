﻿using TarFoundation.St;
using TarReferenceSource.Oip;

namespace TarReferenceSource.Sard.Generic
{
    public class SensorSelect : IFunctionBlock
    {
        //in
        /// <summary>
        /// input Массив значений от аналоговых датчиков
        /// </summary>
        public StArray<AnalogSignal> sensors;
        /// <summary>
        /// input Количество датчиков
        /// </summary>
        public int SensorsCount => sensors.Count;
        //out
        /// <summary>
        /// output Выбранный датчик
        /// </summary>
        public AnalogSignal SelectedSensor;
        /// <summary>
        /// output Индекс выбранного датчика из массива
        /// </summary>
        public int SelectedIndex;

        public override void Execute()
        {
            SelectedSensor.Ndv = true;
            SelectedIndex = 0;
            for (int i = 1; i <= SensorsCount; i++)
            {
                if (!sensors[i].Ndv)
                {
                    SelectedSensor = sensors[i];
                    SelectedIndex = i;
                    break;
                }
            }
        }
    }
}
