﻿using System;
using TarFoundation.St;

namespace TarReferenceSource.Oip.TankSpeed
{
    public class TankSpeed : TankSpeedIo
    {
        /// <summary>
        /// Номер первого значения скорости в буфере
        /// </summary>
        private int begin;
        /// <summary>
        /// Размер буфера
        /// </summary>
        private int size;
        /// <summary>
        /// Результат, полученный на предыдущем цикле работы
        /// </summary>
        private float prevResult;
        /// <summary>
        /// Массив, содержащий значения уровня
        /// </summary>
        private StArray<float> xs = new StArray<float>(0, new float[1000]);
        /// <summary>
        /// Массив, содержащий массив времени регистрации уровня
        /// </summary>
        private StArray<float> ts = new StArray<float>(0, new float[1000]);


        public override void ResetBuffer()
        {
            begin = 0;
            size = 0;
            prevResult = 0.0f;
        }

        public override void Execute()
        {
            /* Запись в буфер новых значений уровня */
            if (size == CAPACITY)
            {
                size = size - 1;
                begin = (begin + 1) % CAPACITY;
            }
            else if (size > CAPACITY)
            {
                //Буфер заполнен сдвигаем
                size = 0;
                begin = 0;
                prevResult = 0.0f;
            }

            if (Ndv)
            {
                //При недостоверности уровня - возвращаем последнее достоверное значение скорости
                Result = prevResult * ScaleFactor;
            }
            else
            {
                var index = (begin + size) % CAPACITY; //ИНДЕКС текущего элемента в массиве
                xs[index] = Value; //Сохраняем в массив значение
                ts[index] = Timestamp; //и метку времени значения
                size = size + 1;

                if (size > 1)
                {
                    /*СЧИТАЕМ СРЕДНЕЕ НАКОПЛЕНОЕ ИЗ МАССИВА*/
                    var avgH = 0.0f;
                    for (int i = 0; i < size; i++)
                    {
                        int uTmp = (begin + i) % CAPACITY;
                        avgH = avgH + xs[uTmp] / (float) (size);
                    }

                    var p1 = 0.0f;
                    var p2 = 0.0f;
                    var d1 = 0.0f;
                    var d2 = 0.0f; //ОБНУЛЕНИЕ СУММ ПЕРЕД РАСЧЕТОМ

                    var d_t = ts[begin];
                    var HiPrev = (xs[begin] - avgH);

                    var Ok = true;
                    /*СЧИТАЕМ СУММАРНЫЕ КОЭФФИЦИЕНТЫ*/
                    for (int i = 0; i < size; i++)
                    {
                        index = (begin + i) % CAPACITY;
                        var Hi = xs[index] - avgH;
                        var ti = ts[index] - d_t;
                        if (Math.Abs(Hi - HiPrev) >= THRESHOLD)
                        {
                            /* Проверка на неожиданный всплеск уровня */
                            Ok = false;
                            break;
                        }
                        else
                        {
                            HiPrev = Hi;
                            /* Ограничиваем временной диапазон во избежание переполнения при возведении в квадрат и суммировании, даже если время передавать в мс, хватит на 65 секунд*/

                            p1 = p1 + ti * ti;
                            p2 = p2 + ti;
                            d1 = d1 + ti * Hi;
                            d2 = d2 + Hi;
                        }
                    } /* Расчет скорости */


                    var bottom = 0.0f;
                    if (Ok)
                    {
                        bottom = (p1 - (p2 * p2) / (float) (size)); //Достоверно 
                    }

                    if (bottom != 0 && Ok)
                    {
                        var top = (d1 - p2 * d2 / size);
                        Result = top / bottom;
                    }
                    else
                    {
                        Result = prevResult;
                    }

                    prevResult = Result;
                    Result = Result * ScaleFactor;
                }
            }
        }

        public void Run2()
        {
            /*---------------------------------------------------------------------------------------------*/
/*—--------- TankSpeed — модуль расчета скорости наполнения/опорожнения резервуара ------------*/
/*---------------------------------- 03.2018 V1.1.0.1------------------------------------------*/
            var NDVSpeed = Ndv;

            if (NDVSpeed)
            {
                Result = prevResult * ScaleFactor;
            }
            else
            {
                /* Защита от некорректных значений входных параметров */
                CAPACITY = (ushort)(CAPACITY + ((CAPACITY == 0) ? 2 : 0));

                /* Запись в буфер новых значений уровня */
                if (size >= CAPACITY)
                {
                    size = CAPACITY - 1;
                    begin = (begin + 1) % CAPACITY;
                }

                var index = (begin + size) % CAPACITY;
                xs[index] = Value;
                ts[index] = Timestamp;
                size = size + 1;

                var AvgH = 0.0f;
                for (int i = 0; i <= size - 1; i++)
                {
                    AvgH = AvgH + xs[(begin + i) % CAPACITY]/ (float)(size);
                }

                var p1 = 0.0f;
                var p2 = 0.0f;
                var d1 = 0.0f;
                var d2 = 0.0f;

                var d_t = ts[begin];
                var Hiprev = xs[begin] - AvgH;
                float ti = 0;
                var Ok = true;
                var LimSpeed = false;
                float bottom = 0.0f;
                float sum = 0.0f;

                for (int i = 0; i <= size - 1; i++)
                {
                    index = (begin + i) % CAPACITY;
                    var Hi = xs[index] - AvgH;
                    //sum = sum + ts[index];
                    //ti = sum - d_t;
                    ti = ti + ts[index];

                    /* Проверка на неожиданный всплеск уровня */
                    if (Math.Abs((Hi - Hiprev)) >= THRESHOLD)
                    {
                        Ok = false;
                        LimSpeed = true;
                        break;
                    }

                    Hiprev = Hi;

                    /* Ограничиваем временной диапазон во избежание переполнения при возведении в квадрат и суммировании */
                    //if (ti > 65535)
                    //{
                    //    Ok = false;
                    //    break;
                    //}

                    p1 = p1 + (float) (ti * ti);
                    p2 = p2 + (float) (ti);
                    d1 = d1 + (float) (ti) * Hi;
                    d2 = d2 + Hi;
                }

                /* Расчет скорости */
                if (Ok)
                {
                    bottom = p1 - (p2 * p2) / (float) (size);
                }

                if (Ok && bottom != 0.0)
                {
                    var top = d1 - (p2 * d2) / (float) (size);
                    Result = top / bottom;
                    NDVSpeed = false;
                }
                else
                {
                    Result = prevResult;
                    NDVSpeed = !Ok;
                }

                prevResult = Result; /* Скорость мм/10*мс */
                Result = Result * ScaleFactor; /* Скорость м/ч */
            }
        }
    }
}