﻿using TarFoundation.St;
using TarReferenceSource.Common;

namespace TarReferenceSource.Sard.Throttle
{

    public abstract class RegulatorSelectIo : IFunctionBlock
    {
        //in
        /// <summary>
        /// input Массив результатов работы модулей ControlLoop
        /// </summary>
        public StArray<ControlLoopOutput> ControlLoops;
        /// <summary>
        /// input количество регуляторов
        /// </summary>
        public int RegulatorsCount => ControlLoops.Count;
        //out
        /// <summary>
        /// output Номер активного регулятора
        /// </summary>
        public int ActiveRegulatorNum;
        /// <summary>
        /// output Выходные данные активного регулятора
        /// </summary>
        public ControlLoopOutput ActiveRegulator { get; protected set; } = new ControlLoopOutput();

    }
    public class RegulatorSelect : RegulatorSelectIo
    {

        public override void Execute()
        {
            //выбор регулятора (6.3.22)
            ActiveRegulatorNum = 0;
            for (int i = 1; i <= RegulatorsCount; i++)
            {
                if (!ControlLoops[i].Used)
                {
                    continue;
                }

                if (ControlLoops[i].Crash)
                {
                    if (ControlLoops[i].IsCritical)
                    {
                        ActiveRegulatorNum = 0;
                        break;
                    }
                }
                else if (ActiveRegulatorNum == 0)
                {
                    ActiveRegulatorNum = i;
                }
                else if (ControlLoops[i].NormalizedOutput > ControlLoops[ActiveRegulatorNum].NormalizedOutput)
                {
                    ActiveRegulatorNum = i;
                }
            }


            if (ActiveRegulatorNum > 0)
            {
                //ActiveRegulator = ControlLoops[ActiveRegulatorNum];
                ControlLoops[ActiveRegulatorNum].CopyTo(ActiveRegulator);
            }
            else
            {
                ActiveRegulator.Crash = true;
                ActiveRegulator.zone = ControlLoopZone.OffZone;
                ActiveRegulator.NormalizedOutput = 0.0f;
                ActiveRegulator.Used = false;

            }
        }
    }
}
