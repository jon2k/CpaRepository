﻿using System;
using TarFoundation.St;

namespace TarReferenceSource.Sard.Throttle
{
    public abstract class ThrottleSyncIo : IFunctionBlock
    {
        /// <summary>
        /// input Уставка синхронизации
        /// </summary>
        public float SyncUst;
        /// <summary>
        /// input Флаг использования
        /// </summary>
        public bool IsEnable;
        /// <summary>
        /// input Массив выходных данных заслонок 
        /// </summary>
        public StArray<ThrottleOutput> ThrottlesOutput;
        /// <summary>
        /// 
        /// </summary>
        public SardStorage sard;
        /// <summary>
        /// output Количество заслонок
        /// </summary>
        public int ThrottlesCount => ThrottlesOutput.Count;
    }
    public class ThrottleSync : ThrottleSyncIo
    {

        public override void Execute()
        {
            //6.3.27
            bool IsOpening = false;
            bool IsClosing = false;
            if (sard.mode != SardRegulationMode.ByPosition)
            {
                for (int i = 1; i <= ThrottlesCount; i++)
                {
                    IsOpening = IsOpening || ThrottlesOutput[i].Open;
                    IsClosing = IsClosing || ThrottlesOutput[i].Close;
                }
            }

            if (IsOpening && IsEnable)
            {
                float MinPos = 100;
                for (int i = 1; i <= ThrottlesCount; i++)
                {
                    if (!ThrottlesOutput[i].Crash && ThrottlesOutput[i].Mode == ThrottleMode.auto && ThrottlesOutput[i].Position.VisualValue < MinPos)
                    {
                        MinPos = ThrottlesOutput[i].Position.VisualValue;
                    }
                }

                for (int i = 1; i <= ThrottlesCount; i++)
                {
                    if (!ThrottlesOutput[i].Crash && ThrottlesOutput[i].Mode == ThrottleMode.auto && sard.ActiveControlLoop.AllowLinearCorrections)
                    {
                        if (Math.Abs(ThrottlesOutput[i].Position.VisualValue - MinPos) < SyncUst)
                        {
                            ThrottlesOutput[i].OutSpeed =
                                ThrottlesOutput[i].OutSpeed * (1 - Math.Abs(ThrottlesOutput[i].Position.VisualValue - MinPos) / SyncUst);
                        }
                        else
                        {
                            ThrottlesOutput[i].OutSpeed = 0.0f;
                        }
                    }
                }
            }
            else if (IsClosing && IsEnable)
            {
                float MaxPos = 0;
                for (int i = 1; i <= ThrottlesCount; i++)
                {
                    if (!ThrottlesOutput[i].Crash && ThrottlesOutput[i].Mode == ThrottleMode.auto && ThrottlesOutput[i].Position.VisualValue > MaxPos)
                    {
                        MaxPos = ThrottlesOutput[i].Position.VisualValue;
                    }
                }

                for (int i = 1; i <= ThrottlesCount; i++)
                {
                    if (!ThrottlesOutput[i].Crash && ThrottlesOutput[i].Mode == ThrottleMode.auto && sard.ActiveControlLoop.AllowLinearCorrections)
                    {
                        if (Math.Abs(ThrottlesOutput[i].Position.VisualValue - MaxPos) < SyncUst)
                        {
                            ThrottlesOutput[i].OutSpeed =
                                ThrottlesOutput[i].OutSpeed * (1 - Math.Abs(ThrottlesOutput[i].Position.VisualValue - MaxPos) / SyncUst);
                        }
                        else
                        {
                            ThrottlesOutput[i].OutSpeed = 0.0f;
                        }
                    }
                }
            }

        }
    }
}
