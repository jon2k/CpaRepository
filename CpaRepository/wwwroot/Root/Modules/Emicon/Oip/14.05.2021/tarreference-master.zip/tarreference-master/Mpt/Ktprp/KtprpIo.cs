﻿using TarFoundation.St;

namespace TarReferenceSource.Mpt.Ktprp
{
    /// <summary>
    /// Структура, отвечающая за выходные данные модуля 
    /// </summary>
    public class structSPZFireProtOut
    {
        /// <summary>
        ///  Аварийный сигнал сработавшей защиты по пожару
        /// </summary>
        public bool P; //Fire!
        /// <summary>
        /// Аварийный сигнал защиты по пожару
        /// </summary>
        public bool F; //Input
        /// <summary>
        /// Маскирование защиты по пожару
        /// </summary>
        public bool M; //Mask
        /// <summary>
        /// 
        /// </summary>
        public bool NP; //New prot
    }

    public abstract class KtprpIo : IFunctionBlock
    {
        // in
        /// <summary>
        /// input Входные данные для модуля
        /// </summary>
        public StArray<structSPZFireProtOut> Input;
        // out
        /// <summary>
        /// output Выходные данные для модуля
        /// </summary>
        public structSPZFireProtOut Result; // Обобщенный результат.

        public KtprpIo(int count)
        {         
            Input = new StArray<structSPZFireProtOut>(1, new structSPZFireProtOut[count]);
            Result = new structSPZFireProtOut();
        }      
    }
}
