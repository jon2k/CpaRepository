﻿using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.St;
using TarReferenceSource.Common.Timer;
using TarReferenceSource.CommonNa;

namespace TarReferenceSource.Kgmpna.Gmpna
{
    public class Gmpna : GmpnaIo
    {
        private ITimer T01;

        public Gmpna()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
            T01 = new CpaLocalTimer();
            InternalTimers = new StArray<ITimer>(1, new []{T01});
        }

        public override void Execute()
        {
            Result.F = Input;
            if (Result.F)
            {
                T01.Start();
            }

            if (Cfg.NotMasked)
            {
                Result.M = false;
            }

            if (Cmd == GmpnaCmd.Mask)
            {
                Messenger.Send(1);
                if (Cfg.NotMasked)
                {
                    Messenger.Send(2);
                }
                else if (Result.M)
                {
                    Messenger.Send(4);
                }
                else
                {
                    Messenger.Send(3);
                    Result.M = true;
                }
            }
            else if (Cmd == GmpnaCmd.UnMask)
            {
                Messenger.Send(5);
                if (Result.M)
                {
                    Messenger.Send(6);
                    Result.M = false;
                }
                else
                {
                    Messenger.Send(7);
                }
            }

            var tmpP = Result.F || (T01.IsStarted) || Result.M;

            if (!Result.M && (MainState == NaState.Otkl))
            {
                if (tmpP && !Result.P)
                {
                    Messenger.Send(8);
                }

                if (!tmpP && Result.P)
                {
                    Messenger.Send(9);
                }
            }
            Result.P = tmpP;
            Result.NotMasked = Cfg.NotMasked;
        }
    }
}
