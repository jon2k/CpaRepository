﻿using System.Linq;
using TarFoundation.St;
using TarReferenceSource.Common.Timer;
using TarReferenceSource.CommonNa;
using TarReferenceSource.Uzd;

namespace TarReferenceSource.Umpna
{
    /// <summary>
    /// Структура состояния насосного агрегата
    /// </summary>
    public class NaStorage
    {
        /// <summary>
        /// Основное состояние
        /// </summary>
        public NaState MainState;
        /// <summary>
        /// Дополнительное состояние
        /// </summary>
        public NaSubstate SubState;
        /// <summary>
        /// Режим
        /// </summary>
        public NaMode Mode;
        /// <summary>
        /// Программа пуска
        /// </summary>
        public NaProg Prog; /* программа пуска */
        /// <summary>
        /// Флаг имитационного режима работы привода НА
        /// </summary>
        public bool SimAgr; /* Имитационный режим работы привода НА */
        /// <summary>
        /// Флаг невыполнения программы остановки
        /// </summary>
        public bool StopErr; /* невыполнение программы остановки */
        /// <summary>
        /// Флаг невыполнения команды отключения ВВ
        /// </summary>
        public bool StopErr2; /* Невыполнение команды отключения ВВ */
        /// <summary>
        /// Флаг невыполнения команды пуска
        /// </summary>
        public bool StartErr; /* невыполнение программы пуска */
        /// <summary>
        /// Невыполнения программы пуска. Примечание - сигнал формируется при определении невыполнении программы пуска до выдачи команды «Включить ВВ». После установки, сигнал сбрасывается при успешном выполнении программы остановки НА
        /// </summary>
        public bool StartErr2;
        /// <summary>
        /// Невыполнения программы пуска. Примечание - сигнал формируется при неполучении включенного состояния ВВ НА и значении силы тока ЭД ниже уставки холостого хода после выдачи команды «Включить ВВ». После установки, сигнал сбрасывается при успешном выполнении программы остановки НА
        /// </summary>
        public bool StartErr3; /*StartErr_ext : BOOL;*/ /*StopErr_ext : BOOL;*/
        /// <summary>
        /// Номер активной задачи, выполняемой НА. 0 – задача отсутствует. 1 – задача выполнение программы остановки НА. 2 – задача выполнения программы пуска НА
        /// </summary>
        public ushort ActvTaskMPNA;
        /// <summary>
        /// Номер шага активной задачи, выполняемой НА. Принимаемые значения лежат в диапазоне от 1 до 9, в зависимости от номера активной задачи
        /// </summary>
        public ushort TaskStepMPNA; /* Номер шага активной задачи, выполняемой МНА*/
        /// <summary>
        /// Флаг повтора отключения
        /// </summary>
        public bool flag_PovtorOtkl;
        /// <summary>
        /// 
        /// </summary>
        public bool AlreadyStopped = true;
        /// <summary>
        /// Дискретный сигнал наличия питания в цепях включения ВВ
        /// </summary>
        public bool ECx02; /* дискретный сигнал наличия питания в цепях включения ВВ */
        /// <summary>
        /// Дискретный сигнал наличия питания в цепях отключения ВВ
        /// </summary>
        public bool ECx03; /* дискретный сигнал наличия питания в цепях отключения ВВ */
        /// <summary>
        /// Дублирующий сигнал наличия питания в цепях отключения ВВ
        /// </summary>
        public bool ECx03_1; /* дублирующий сигнал наличия питания в цепях отключения ВВ */
        /// <summary>
        /// Подтверждение выполнения команды «Включить ВВ» НА
        /// </summary>
        public bool OnCmdConfimed;
        /// <summary>
        /// Подтверждение выполнения команды «Отключить ВВ» НА
        /// </summary>
        public bool OffCmdConfimed;
        /// <summary>
        /// Флаг недостоверности сигнала включения ВВ
        /// </summary>
        public bool BBB1_Ndv;
        /// <summary>
        /// Флаг недостоверности сигнала включения ВВ
        /// </summary>
        public bool BBB2_Ndv;
        /// <summary>
        /// Флаг недостоверности сигнала отключения ВВ
        /// </summary>
        public bool BBO1_Ndv;
        /// <summary>
        /// Флаг недостоверности сигнала отключения ВВ
        /// </summary>
        public bool BBO2_Ndv;
        /// <summary>
        /// Флаг недостоверности тока
        /// </summary>
        public bool Tok_Ndv;
        /// <summary>
        /// Флаг аварии
        /// </summary>
        public bool StateAlarm;
    }
    /// <summary>
    /// Структура состояния ВВ
    /// </summary>
    struct VvStruct
    {
        /// <summary>
        /// Флаг включения
        /// </summary>
        public bool SwitchOn1;
        /// <summary>
        /// Флаг отключения
        /// </summary>
        public bool SwitchOff1;
        /// <summary>
        /// Флаг включения
        /// </summary>
        public bool SwitchOn2;
        /// <summary>
        /// Флаг отключения
        /// </summary>
        public bool SwitchOff2;
        /// <summary>
        /// Флаг наличия тока
        /// </summary>
        public bool Tok;

    }

    public class Umpna : UmpnaIo
    {
        /// <summary>
        /// Внутреннее состояние НА
        /// </summary>
        private NaStorage na = new NaStorage();
        /// <summary>
        /// Флаг высокой вибрации насоса
        /// </summary>
        bool HIGHVIBNas;
        /// <summary>
        /// Флаг высокой вибрации
        /// </summary>
        bool HIGHVIB;
        /// <summary>
        /// Несанкционированное отключение ВВ НА. Примечание - после установки, сигнал сбрасывается при условии получения отключенного состояния ВВ и основного состояния «ВВ отключен» или при успешном выполнении программы остановки НА
        /// </summary>
        bool StartNoCmd;
        /// <summary>
        /// Несанкционированное отключение ВВ НА. Примечание - после установки, сигнал сбрасывается при условии получения отключенного состояния ВВ и основного состояния «ВВ отключен» или при успешном выполнении программы остановки НА
        /// </summary>
        StopNoCmdState StopNoCmd;
        /// <summary>
        /// Команда на приемную задвижку НА.Примечание-  после установки, команда автоматически сбрасывается в начале следующего цикла работы программы
        /// </summary>
        NaZdCmd ZVCmd;
        /// <summary>
        /// Команда на приемную задвижку НА. Примечание-  после установки, команда автоматически сбрасывается в начале следующего цикла работы программы
        /// </summary>
        NaZdCmd ZPCmd;
        /// <summary>
        /// Команда на включение ВВ НА. Примечание- после установки, команда автоматически сбрасывается при срабатывании таймера Т17, который взводится при получении включенного состояния ВВ НА
        /// </summary>
        bool StartWork;
        /// <summary>
        /// Команда на отключение ВВ НА. Примечание- после установки, команда автоматически сбрасывается при получении отключенного состояния ВВ НА
        /// </summary>
        bool StopWork;
        /// <summary>
        /// Команда САРД на выполнение рамповой функции. Примечание -  после установки, команда автоматически сбрасывается при срабатывании таймера Т14
        /// </summary>
        bool SAR_Ramp;
        /// <summary>
        /// Команда на установку блокировки закрытия выкидной задвижки НА. Примечание - после установки, команда автоматически сбрасывается в начале следующего цикла работы программы
        /// </summary>
        NaZdBlocks ZVBlocks;
        /// <summary>
        /// Команда на установку блокировки закрытия приемной задвижки НА. Примечание -  после установки, команда автоматически сбрасывается в начале следующего цикла работы программы
        /// </summary>
        NaZdBlocks ZPBlocks;
        /// <summary>
        /// Команда StopCSPA на предыдущем шаге алгоритма
        /// </summary>
        private bool StopCSPA_Prev;
        /// <summary>
        /// Запрет выдачи сообщений состояния ВВ НА
        /// </summary>
        private bool BlockMsgBB;
        /// <summary>
        /// Команда PuskTM на предыдущем шаге алгоритма
        /// </summary>
        private bool PuskTM_Prev;
        /// <summary>
        /// Команда UseCT на предыдущем шаге алгоритма
        /// </summary>
        private bool UseCT_Prev;
        /// <summary>
        /// Команда на принудительное удержание команды ”Отключить ВВ”
        /// </summary>
        private bool KeepStopWork;
        /// <summary>
        /// Запрет выдачи сообщений состояния силы тока ЭД НА
        /// </summary>
        private bool BlockMsgCurr;
        /// <summary>
        /// Команда StopTM на предыдущем шаге алгоритма
        /// </summary>
        private bool StopTM_Prev;
        /// <summary>
        /// Запрет выдачи сообщений состояния НА
        /// </summary>
        private bool BlockMsgState;

        public Umpna()
        {
            InternalTimers = new StArray<ITimer>(1, Enumerable.Range(1, 17).Select(i => new CpaLocalTimer()).ToArray());
            UseBBB1 = true;
            UseBBB2 = true;
            UseBBO1 = true;
            UseBBO2 = true;
        }

        public override void Execute()
        {
            var vvRef = new VvStruct();

            if (na.MainState == 0)
            {
                na.MainState = NaState.Otkl;
                na.AlreadyStopped = true;
            }

            if (na.Mode == 0)
            {
                na.Mode = NaMode.Osn;
            }

            if (na.Prog == 0)
            {
                na.Prog = NaProg.P1;
            }

            var waitOnVv = na.ActvTaskMPNA == 2 && (na.TaskStepMPNA == 6 || na.TaskStepMPNA == 7);
            var waitOffVv = na.ActvTaskMPNA == 1 && (na.TaskStepMPNA == 2 || na.TaskStepMPNA == 3);
            var waitTokUp = na.ActvTaskMPNA == 2 && na.TaskStepMPNA == 7;
            var waitTokDown = na.ActvTaskMPNA == 1 && na.TaskStepMPNA == 3;

            /*==================================================================================================*/
            /*   РАЗДЕЛ  - ФОНОВАЯ ЗАДАЧА КОНТРОЛЯ ФИЗИЧЕСКИХ СИГНАЛОВ      */
            var BBon = false;
            var BBoff = false;
            var diagnoNeedVv = true;

            //Голосуем за включенность
            vvRef.SwitchOn1 = UseBBB1 || vv.SwitchOn1;
            vvRef.SwitchOff1 = !UseBBO1 && vv.SwitchOff1;
            vvRef.SwitchOn2 = UseBBB2 || vv.SwitchOn2;
            vvRef.SwitchOff2 = !UseBBO2 && vv.SwitchOff2;
            if (vv.SwitchOn1 == vvRef.SwitchOn1 && vv.SwitchOff1 == vvRef.SwitchOff1 && vv.SwitchOn2 == vvRef.SwitchOn2 && vv.SwitchOff2 == vvRef.SwitchOff2)
            {
                BBon = true;
                diagnoNeedVv = false;
            }

            //Голосуем за отключенность
            vvRef.SwitchOn1 = !UseBBB1 && vv.SwitchOn1;
            vvRef.SwitchOff1 = UseBBO1 || vv.SwitchOff1;
            vvRef.SwitchOn2 = !UseBBB2 && vv.SwitchOn2;
            vvRef.SwitchOff2 = UseBBO2 || vv.SwitchOff2;
            if (vv.SwitchOn1 == vvRef.SwitchOn1 && vv.SwitchOff1 == vvRef.SwitchOff1 && vv.SwitchOn2 == vvRef.SwitchOn2 && vv.SwitchOff2 == vvRef.SwitchOff2)
            {
                BBoff = true;
                diagnoNeedVv = false;
            }


            var flTmp1 = BBoff && (!TokControl || !vv.Tok || (waitTokUp || waitTokDown) && !na.Tok_Ndv);
            var flTmp2 = BBon && (!TokControl || vv.Tok || (waitTokUp || waitTokDown) && !na.Tok_Ndv);

            var BB_Curr = false;
            var diagnoNeed = false;
            if (flTmp1)
            {
                /* если состояние откл */
                BB_Curr = false;
            }
            else if (flTmp2)
            {
                /* если состояние вкл*/
                BB_Curr = true;
            }
            else
            {
                diagnoNeed = true;
            }

            if (!diagnoNeed)
            {
                na.BBB1_Ndv = false;
                na.BBB2_Ndv = false;
                na.BBO1_Ndv = false;
                na.BBO2_Ndv = false;
                na.Tok_Ndv = false;
                InternalTimers[1].Stop();
                na.StateAlarm = false;
            }
            else
            {
                var BB_Vkl = 0;
                var BB_Otkl = 0;
                var Cost_Table_Vkl_1 = new StArray<int>(1, new[] {0, 1, 1, 0});
                var Cost_Table_Otkl_1 = new StArray<int>(1, new[] {1, 0, 0, 1});
                var Cost_Table_Vkl_3 = new StArray<int>(1, new[] {0, 1, 1, 0, 0, 1});
                var Cost_Table_Otkl_3 = new StArray<int>(1, new[] {1, 0, 0, 1, 1, 0});
                var Cost_Table_Vkl_Common = new StArray<int>(1, new[] {4, 0, 0});
                var Cost_Table_Otkl_Common = new StArray<int>(1, new[] {0, 4, 1});
                var Index = 0;
                /*УСО 3*/
                /*ВВ включен УСО3*/

                if (!na.BBB1_Ndv && UseBBB1)
                {
                    Index = 1 + (vv.SwitchOn1 ? 1 : 0);
                    BB_Vkl = BB_Vkl + Cost_Table_Vkl_3[Index];
                    BB_Otkl = BB_Otkl + Cost_Table_Otkl_3[Index];
                } /*ВВ отключен УСО3*/

                if (!na.BBO1_Ndv && UseBBO1)
                {
                    Index = 3 + (vv.SwitchOff1 ? 1 : 0);
                    BB_Vkl = BB_Vkl + Cost_Table_Vkl_3[Index];
                    BB_Otkl = BB_Otkl + Cost_Table_Otkl_3[Index];
                } /*ток*/

                if (!na.Tok_Ndv && TokControl)
                {
                    Index = 5 + (vv.Tok ? 1 : 0);
                    BB_Vkl = BB_Vkl + Cost_Table_Vkl_3[Index];
                    BB_Otkl = BB_Otkl + Cost_Table_Otkl_3[Index];
                }

                /*УСО1*/
                /*ВВ включен УСО1*/
                if (!na.BBB2_Ndv && UseBBB2)
                {
                    Index = 1 + (vv.SwitchOn2 ? 1 : 0);
                    BB_Vkl = BB_Vkl + Cost_Table_Vkl_1[Index];
                    BB_Otkl = BB_Otkl + Cost_Table_Otkl_1[Index];
                } /*ВВ отключен УСО1*/

                if (!na.BBO2_Ndv && UseBBO2)
                {
                    Index = 3 + (vv.SwitchOff2 ? 1 : 0);
                    BB_Vkl = BB_Vkl + Cost_Table_Vkl_1[Index];
                    BB_Otkl = BB_Otkl + Cost_Table_Otkl_1[Index];
                }
                /*ПРОЧЕЕ*/
                /*последняя команда*/

                if (na.OnCmdConfimed)
                {
                    Index = 1;
                    BB_Vkl = BB_Vkl + Cost_Table_Vkl_Common[Index];
                    BB_Otkl = BB_Otkl + Cost_Table_Otkl_Common[Index];
                }

                if (na.OffCmdConfimed)
                {
                    Index = 2;
                    BB_Vkl = BB_Vkl + Cost_Table_Vkl_Common[Index];
                    BB_Otkl = BB_Otkl + Cost_Table_Otkl_Common[Index];
                }

                /*отключен, нет напряжения*/
                if (na.MainState == NaState.Otkl &&
                    !(vv.SwitchOn1 || vv.SwitchOff1 || vv.SwitchOn2 || vv.SwitchOff2 || vv.Tok && TokControl) && !QF3A)
                {
                    Index = 3;
                    BB_Vkl = BB_Vkl + Cost_Table_Vkl_Common[Index];
                    BB_Otkl = BB_Otkl + Cost_Table_Otkl_Common[Index];
                }

                if (BB_Vkl >= BB_Otkl)
                {
                    vvRef.SwitchOn1 = UseBBB1 || vv.SwitchOn1;
                    vvRef.SwitchOff1 = !UseBBO1 && vv.SwitchOff1;
                    vvRef.SwitchOn2 = UseBBB2 || vv.SwitchOn2;
                    vvRef.SwitchOff2 = !UseBBO2 && vv.SwitchOff2;
                    vvRef.Tok = TokControl || vv.Tok;
                }
                else
                {
                    vvRef.SwitchOn1 = !UseBBB1 && vv.SwitchOn1;
                    vvRef.SwitchOff1 = UseBBO1 || vv.SwitchOff1;
                    vvRef.SwitchOn2 = !UseBBB2 && vv.SwitchOn2;
                    vvRef.SwitchOff2 = UseBBO2 || vv.SwitchOff2;
                    vvRef.Tok = !TokControl && vv.Tok;
                }

                if (!TokControl || waitOnVv || waitOffVv)
                {
                    vvRef.Tok = vv.Tok;
                }

                if (!InternalTimers[1].IsStarted && !InternalTimers[1].IsQ && !na.StateAlarm)
                {
                    InternalTimers[1].Start();
                }

                //Нет необходимости проверять на Use

                if (InternalTimers[1].IsQ)
                {
                    na.BBB1_Ndv = false;
                    na.BBO1_Ndv = false;
                    na.BBB2_Ndv = false;
                    na.BBO2_Ndv = false;
                    na.Tok_Ndv = false;
                    if (vv.SwitchOn1 ^ vvRef.SwitchOn1)
                    {
                        Messenger.Send(1); /* СИГНАЛ ВВ ВКЛЮЧЕН В УСО 1.1 НЕДОСТОВЕРЕН */
                        na.BBB1_Ndv = true;
                    }

                    if (vv.SwitchOff1 ^ vvRef.SwitchOff1)
                    {
                        Messenger.Send(2); /* СИГНАЛ ВВ ОТКЛЮЧЕН В УСО 1.1 НЕДОСТОВЕРЕН */
                        na.BBO1_Ndv = true;
                    }

                    if (vv.SwitchOn2 ^ vvRef.SwitchOn2)
                    {
                        Messenger.Send(3); /* СИГНАЛ ВВ ВКЛЮЧЕН В УСО 3 НЕДОСТОВЕРЕН */
                        na.BBB2_Ndv = true;
                    }

                    if (vv.SwitchOff2 ^ vvRef.SwitchOff2)
                    {
                        Messenger.Send(4); /* СИГНАЛ ВВ ОТКЛЮЧЕН В УСО 3 НЕДОСТОВЕРЕН */
                        na.BBO2_Ndv = true;
                    }

                    if (vv.Tok ^ vvRef.Tok)
                    {
                        Messenger.Send(5); /* ЗНАЧЕНИЕ СИЛЫ ТОКА НЕДОСТОВЕРНО */
                        na.Tok_Ndv = true;
                    }
                }

                BB_Curr = BB_Vkl >= BB_Otkl;
            }
            /* включая 20 */

            na.StateAlarm = na.BBB1_Ndv || na.BBO1_Ndv || na.BBB2_Ndv || na.BBO2_Ndv || na.Tok_Ndv && TokControl;

            /*окончательное определение тещего состояния ВВ НА с учетом недостоверностей*/
            if (na.StateAlarm)
            {
                BBon = false;
                BBoff = false;

                //Голосуем за включенность
                vvRef.SwitchOn1 = UseBBB1 && !na.BBB1_Ndv || vv.SwitchOn1;
                vvRef.SwitchOff1 = (!UseBBO1 || na.BBO1_Ndv) && vv.SwitchOff1;
                vvRef.SwitchOn2 = UseBBB2 && !na.BBB2_Ndv || vv.SwitchOn2;
                vvRef.SwitchOff2 = (!UseBBO2 || na.BBO2_Ndv) && vv.SwitchOff2;

                if (vv.SwitchOn1 == vvRef.SwitchOn1 && vv.SwitchOff1 == vvRef.SwitchOff1 && vv.SwitchOn2 == vvRef.SwitchOn2 && vv.SwitchOff2 == vvRef.SwitchOff2)
                {
                    BBon = true;
                }

                //Голосуем за отключенность
                vvRef.SwitchOn1 = (!UseBBB1 || na.BBB1_Ndv) && vv.SwitchOn1;
                vvRef.SwitchOff1 = UseBBO1 && !na.BBO1_Ndv || vv.SwitchOff1;
                vvRef.SwitchOn2 = (!UseBBB2 || na.BBB2_Ndv) && vv.SwitchOn2;
                vvRef.SwitchOff2 = UseBBO2 && !na.BBO2_Ndv || vv.SwitchOff2;

                if (vv.SwitchOn1 == vvRef.SwitchOn1 && vv.SwitchOff1 == vvRef.SwitchOff1 && vv.SwitchOn2 == vvRef.SwitchOn2 && vv.SwitchOff2 == vvRef.SwitchOff2)
                {
                    BBoff = true;
                }

                if (BBon == BBoff)
                {
                    BBon = BB_Curr;
                    BBoff = !BB_Curr;
                }
            }

            //////////////////////////////////////////////////////////////////////////////////////
            //
            //                           ПРОВЕРКА ДОСТАВКИ КОМАНДЫ УПРАВЛЕНИЯ В ЯЧЕЙКУ ЗРУ
            //
            //////////////////////////////////////////////////////////////////////////////////////

            /*контроль цепей включения и отключения при выдаче команд*/
            if (!vv.ECx03 && na.ECx03 || !vv.ECx03_1 && na.ECx03_1)
            {
                if (waitOffVv)
                {
                    Messenger.Send(19); /* ОП. КОМАНДА НА ОТКЛЮЧЕНИЕ ВВ В ЯЧЕЙКУ ЗРУ ДОСТАВЛЕНА*/
                    na.OffCmdConfimed = true;
                }
            }

            if (!vv.ECx02 && na.ECx02)
            {
                if (waitOnVv)
                {
                    Messenger.Send(69); /* ОП. КОМАНДА НА ВКЛЮЧЕНИЕ ВВ В ЯЧЕЙКУ ЗРУ ДОСТАВЛЕНА*/
                    na.OnCmdConfimed = true;
                }
            }

            na.ECx03_1 = vv.ECx03_1;
            na.ECx03 = vv.ECx03;
            na.ECx02 = vv.ECx02;

            if (!waitOnVv && !waitTokUp)
            {
                na.OnCmdConfimed = false;
            }

            if (!waitOffVv && !waitTokDown)
            {
                na.OffCmdConfimed = false;
            }
            /*установка дополнительного состояния НА при готовности*/
            if (na.ActvTaskMPNA == 0)
            {
                if (ReadyToStart && na.MainState == NaState.Otkl && StopNoCmd != StopNoCmdState.Phase1)
                {
                    if (na.Mode == NaMode.Rez)
                    {
                        na.SubState = NaSubstate.HotRez;
                    }
                    else
                    {
                        na.SubState = NaSubstate.Ready;
                    }
                }
                else
                {
                    na.SubState = NaSubstate.None;
                }
            }

            if (na.MainState == NaState.Vkl && na.SubState == NaSubstate.Ready)
            {
                na.SubState = 0;
            }

            // для определения состояния агрегата, на который еще не подавались команды включения и отключения
            if (na.ActvTaskMPNA == 0)
            {
                /* Контроль работающего агрегата */
                if (na.MainState == NaState.Vkl)
                {
                    if (BBoff && !na.SimAgr)
                    {
                        /* Если зафиксировано состоЯние  МВ отключен */
                        if (!StartNoCmd && !(StopNoCmd > 0))
                        {
                            Messenger.Send(20); /* ОП. МВ ОТКЛЮЧИЛСЯ. ВНЕШНАЯ ПРИЧИНА */
                            StopNoCmd = StopNoCmdState.Phase1; /* Установить флаг Откл. без команды */
                            if (!InternalTimers[16].IsStarted)
                            {
                                InternalTimers[16].Start();
                            }
                        }
                        else if (StartNoCmd)
                        {
                            StartNoCmd = false;
                            Messenger.Send(20); /* ОП. МВ ОТКЛЮЧИЛСЯ. ВНЕШНАЯ ПРИЧИНА */
                        }

                        na.MainState = NaState.Otkl;
                    }
                }
            }

            if (StopNoCmd == StopNoCmdState.Phase1 && !InternalTimers[16].IsStarted)
            {
                StopNoCmd = StopNoCmdState.Phase2;
            }
            if (StopNoCmd == StopNoCmdState.None)
            {
                InternalTimers[16].Stop();
            }

            /* Контроль стоящего агрегата */
            if (na.MainState == NaState.Otkl && na.ActvTaskMPNA == 0 || na.ActvTaskMPNA == 2 && (na.TaskStepMPNA == 4 || na.TaskStepMPNA == 5))
            {
                if (BBon && !na.SimAgr)
                {
                    /* Если зафиксировано состоЯние  МВ включен */
                    if (!StartNoCmd && !(StopNoCmd > 0))
                    {
                        StartNoCmd = true; /* Устанвить флаг Вкл. без команды */
                        na.AlreadyStopped = false;
                        Messenger.Send(15); /* ОП. ВНИМАНИЕ! МВ ВКЛЮЧЕН. НЕУСТ ПРИЧИНА */
                    }
                    else if (StopNoCmd > 0)
                    {
                        StopNoCmd = StopNoCmdState.None;
                        InternalTimers[16].Stop();
                        Messenger.Send(15); /* ОП. ВНИМАНИЕ! МВ ВКЛЮЧЕН. НЕУСТ ПРИЧИНА */
                    }

                    na.MainState = NaState.Vkl;
                }
            }


            if (na.MainState == NaState.Otkl && BBoff)
            {
                StartNoCmd = false;
            }

            /*ОБРАБОТКА КОМАНД НА ОТКЛЮЧЕНИЯ ПО ЗАЩИТАМ*/


            //Все время взводим таймер, если нет электрозащиты
            if (!StopElectric)
            {
                InternalTimers[17].Start();
            }

            if (StopAuto && !na.StopErr || RepeatedStop && !na.flag_PovtorOtkl || StopAuto2 && !na.StopErr2)
            {
                if (na.ActvTaskMPNA != 1 && (!na.AlreadyStopped || BBon && !na.SimAgr))
                {
                    //Если состояние==включен или ВВ включен или
                    //несанкционированный останов и нужна диагностика и нет ошибок пуска по включению ВВ и открытию задвижки по П2
                    if ((na.MainState == NaState.Vkl || na.MainState == NaState.Pusk || BBon || StopNoCmd > 0 && diagnoNeedVv) && !na.StartErr2 && !na.StartErr3)
                    {
                        Messenger.Send(59); //КОМАНДА ОТКЛЮЧИТЬ АВТОМАТИЧЕСКИ
                    }

                    if (RepeatedStop)
                    {
                        //Если есть команда на повторное отключение ВВ
                        na.flag_PovtorOtkl = true; //выставляем флаг работы повторного отключения
                    }

                    na.ActvTaskMPNA = 1; //Задача 1 - останов
                    na.TaskStepMPNA = 1; //Шаг задачи - 1
                }
            }
            else if (StopElectric)
            {
                if (StopNoCmd != StopNoCmdState.None || !InternalTimers[17].IsStarted)
                {
                    if (na.ActvTaskMPNA != 1 && !BBoff)
                    {
                        Messenger.Send(59); //КОМАНДА ОТКЛЮЧИТЬ АВТОМАТИЧЕСКИ
                        na.ActvTaskMPNA = 1; //Задача 1 - останов
                        na.TaskStepMPNA = 1; //Шаг задачи - 1
                    }
                    else if (StopNoCmd != StopNoCmdState.None && BBoff)
                    {
                        InternalTimers[16].Stop();
                        StopNoCmd = StopNoCmdState.None;
                        HIGHVIB = false;
                        HIGHVIBNas = false;
                    }
                }
            }
            else if (!(StopAuto || StopAuto2 || RepeatedStop))
            {
                //если все авт. команды сброшены (защиты деблокированы)
                na.AlreadyStopped = false; //снимаем признак выполнения успешного отключения		
            }

            /*----------------------------------------------------------------------*/
            /* Отработка команды Останов агрегата по каналу ТУ или от оператором */
            flTmp1 = false;

            if (StopTmCmd && !StopTM_Prev)
            {
                Messenger.Send(73); /* ОП.КОМАНДА - ОСТАНОВ ПО ТМ */
                flTmp1 = true;
            }

            StopTM_Prev = StopTmCmd;

            if (Cmd == NaCmd.STOP)
            {
                /* Сообщение о команде оператора выдаем безусловно */
                Messenger.Send(72); /* ОП.КОМАНДА - ОСТАНОВ С АРМ */
                flTmp1 = true;
            }

            if (StopCspaCmd && !StopCSPA_Prev)
            {
                Messenger.Send(106); /* KOMMANDA - STOP OT CSPA */
                flTmp1 = true;
            }

            StopCSPA_Prev = StopCspaCmd;

            /*  27  */
            if (flTmp1)
            {
                //если есть флаг наличия команды
                //сброс ошибок пуска
                na.StartErr = false;
                na.StartErr2 = false;
                na.StartErr3 = false;
                if (na.MainState == NaState.Otkl)
                {
                    //если состояние - остановлен
                    Messenger.Send(100); //ОСТАНОВЛЕН. КОМАНДА НЕ ТРЕБУЕТСЯ
                    //сброс ошибок останова
                    na.StopErr = false;
                    na.StopErr2 = false;
                }
                else if (na.MainState == NaState.Ostanov && na.ActvTaskMPNA == 1)
                {
                    //если состояние - останавливается и вып. задача 1 - остановка
                    Messenger.Send(102); //ОСТАНАВЛИВАЕТСЯ. КОМАНДА НЕ ТРЕБУЕТСЯ
                }
                else
                {
                    //сброс ошибок останова
                    na.StopErr = false;
                    na.StopErr2 = false;
                    na.ActvTaskMPNA = 1; //задача 1 - останов НА
                    na.TaskStepMPNA = 1; //шаг 1
                }
            }


            /*----------------------------------------------------------------------*/
            /* Отработка команды Пуска агрегата по каналу ТУ или от оператором */
            flTmp1 = false; /* флаг разрешениЯ дальнейшего анализа TASK */

            if (PuskTmCmd && !PuskTM_Prev)
            {
                /* Сообщение о команде с РДП выдаем безусловно */
                Messenger.Send(71); /* ОП.КОМАНДА - ЗАПУСК ИЗ РДП */
                if (na.Mode != NaMode.Tm)
                {
                    Messenger.Send(31); /* ОП.ЗАПУСК ИЗ РДП НЕВОЗМОЖЕН. РЕЖИМ ТУ НЕ ВЫБРАН */
                }
                else
                {
                    flTmp1 = true; /* флаг разрешениЯ дальнейшего анализа TASK */
                }
            }
            PuskTM_Prev = PuskTmCmd;

            if (Cmd == NaCmd.PUSK)
            {
                /* Если есть команда на запуск агрегата от оператора */
                Messenger.Send(70); /* ОП.КОМАНДА - ЗАПУСК ИЗ МДП */
                if (na.Mode != NaMode.Osn)
                {
                    Messenger.Send(30); /* ОП.ПУСК НЕВОЗМОЖЕН. РЕЖИМ НЕ ВЫБРАН */
                }
                else
                {
                    flTmp1 = true; /* флаг разрешениЯ дальнейшего анализа TASK */
                }
            }


            //поднять проверку что установлен REZ
            // TODO: Проверить режимы!!!
            if (StartRez && na.ActvTaskMPNA == 0)
            {
                if (na.Mode == NaMode.Rez)
                {
                    Messenger.Send(56); /*ОП.ВКЛЮЧЕНИЕ РЕЗЕРВА*/
                    na.ActvTaskMPNA = 2;
                    na.TaskStepMPNA = 1;
                }
                else
                {//TODO: приводит к зацикливанию сообщений если startRez > 1 цикла
                    Messenger.Send(107); /*ОП.ВКЛЮЧЕНИЕ РЕЗЕРВА НЕВОЗМОЖНО - РЕЖИМ НЕ РЕЗ*/
                }
            }

            if (na.MainState == NaState.Otkl)
            {
                if (StartAuto && na.ActvTaskMPNA == 0)
                {
                    if (na.Mode == NaMode.Osn || na.Mode == NaMode.Tm)
                    {
                        Messenger.Send(104); /*ОП.АВТОМАТИЧЕСКОЕ ВКЛЮЧЕНИЕ*/
                        na.ActvTaskMPNA = 2;
                        na.TaskStepMPNA = 1;
                    }
                    else
                    {
                        Messenger.Send(108); /*ОП.АВТОМАТИЧЕСКОЕ ВКЛЮЧЕНИЕ НЕВОЗМОЖНО - РЕЖИМ НЕ ОСН И НЕ ТУ*/
                    }
                }
            }

            if (flTmp1)
            {
                if (na.MainState == NaState.Vkl)
                {
                    Messenger.Send(101); /*ОП.В РАБОТЕ. КОМАНДА НЕ ТРЕБУЕТСЯ*/
                }
                else if (na.MainState == NaState.Pusk)
                {
                    Messenger.Send(103); /*ОП.ЗАПУСКАЕТСЯ. КОМАНДА НЕ ТРЕБУЕТСЯ*/
                }
                else if (na.MainState == NaState.Ostanov || StopNoCmd == StopNoCmdState.Phase1)
                {
                    Messenger.Send(102); /*ОП.ОСТАНАВЛИВАЕТСЯ. КОМАНДА НЕ ТРЕБУЕТСЯ*/
                }
                else if (IsMnaTo)
                {
                    Messenger.Send(105); /*ОП.«ПУСК НЕВОЗМОЖЕН. АГРЕГАТ НАЗНАЧЕН НА ЗАПУСК ПРИ ПЕРЕХОДЕ*/
                }
                else if (!ReadyToStart)
                {
                    Messenger.Send(29); /*ОП.ПУСК НЕВОЗМОЖЕН. АГРЕГАТ НЕ ГОТОВ К ПУСКУ*/
                }
                else
                {
                    na.ActvTaskMPNA = 2;
                    na.TaskStepMPNA = 1;
                }
            }

            /*----------------------------------------------------------------------*/
            /* Выполнение команд оператора по смене программ пуска */
            /*----------------------------------------------------------------------*/

            /* Сообщения о поступивших командах оператора по смене программы */
            flTmp1 = false;
            if (Cmd == NaCmd.SET_P1)
            {
                /* Если есть команда на установку прогр П1 */
                Messenger.Send(74); /* ОП. КОМАНДА УСТАНОВИТЬ ПРОГРАММУ ПУСКА 1 */
                flTmp1 = true;
            }

            if (Cmd == NaCmd.SET_P2)
            {
                /* Если есть команда на установку прогр П2 */
                Messenger.Send(75); /* ОП. 79 КОМАНДА УСТАНОВИТЬ ПРОГРАММУ ПУСКА П2 */
                flTmp1 = true;
            }

            /* Общие сообщения о невозможности смены программы */
            if (flTmp1)
            {
                /* Если имеется команда смены программы */
                if (na.Prog == NaProg.P1 && Cmd == NaCmd.SET_P1)
                {
                    Messenger.Send(41);
                    flTmp1 = false;
                }
                else if (na.Prog == NaProg.P2 && Cmd == NaCmd.SET_P2)
                {
                    Messenger.Send(41);
                    flTmp1 = false;
                }
                else if (na.SubState == NaSubstate.Po)
                {
                    Messenger.Send(40); /* ОП. ИЗМЕНЕНИЕ ПРОГРАММЫ ПУСКА НЕВОЗМОЖНО. ИДЕТ ПРОГАММА ОСТАНОВА */
                    flTmp1 = false;
                }
                else if (na.SubState == NaSubstate.Pp)
                {
                    Messenger.Send(38); /* ОП. ИЗМЕНЕНИЕ ПРОГРАММЫ ПУСКА НЕВОЗМОЖНО. ИДЕТ ПРОГРАММА ПУСКА */
                    flTmp1 = false;
                }
                else if (na.Mode == NaMode.Rez)
                {
                    /* Если режим резервный */
                    Messenger.Send(39); /* ОП. ИЗМ-НИЕ ПРОГР ПУСКА НЕВОЗМ. РЕЖИМ РЕЗЕРВНЫЙ */
                    flTmp1 = false;
                }
                else
                {
                    flTmp1 = true;
                }
            }

            /*  33  */
            /* Выполнение команд оператора по смене программы */
            if (flTmp1)
            {
                /* Если команда смены программы принЯта к исполнению */
                if (Cmd == NaCmd.SET_P1)
                {
                    na.Prog = NaProg.P1; /* Установить программу пуска П1 */
                    Messenger.Send(36); /* ОП. УСТАНОВЛЕНА ПРОГРАММа ПУСКА 1 */
                }

                if (Cmd == NaCmd.SET_P2)
                {
                    /* Если есть команда на установку прогр П2 */
                    na.Prog = NaProg.P2; /* Установить программу пуска П2 */
                    Messenger.Send(37); /* ОП. УСТАНОВЛЕНА ПРОГРАММа ПУСКА 2 */
                }
            }


            /*----------------------------------------------------------------------*/
            /* Выполнение команд оператора по смене режима агрегата */
            /*----------------------------------------------------------------------*/

            /* Сообщения о поступивших командах оператора по смене режимов */
            flTmp1 = false;
            var SetOsnAuto = AutoOsn;
            /*Если агрегат в ТМ, но станция в МЕСТНОМ*/
            if (na.Mode == NaMode.Tm && !NpsDist)
            {
                SetOsnAuto = true;
            }

            /*Если агрегат в резерве, но для него нет ОСН*/
            if (na.Mode == NaMode.Rez && NoOsnForRez)
            {
                SetOsnAuto = true;
            }

            if (SetOsnAuto)
            {
                flTmp1 = true;
                Messenger.Send(77); /* ОП.КОМАНДА УСТАНОВИТЬ  РЕЖИМ ОСН АВТОМАТИЧЕСКИ */
            }

            if (Cmd == NaCmd.SET_OSN)
            {
                /* Если есть к-да на установку осн реж от оператора */
                Messenger.Send(76); /* ОП.КОМАНДА УСТАНОВИТЬ  РЕЖИМ ОСН */
                flTmp1 = true;
            }

            if (Cmd == NaCmd.SET_TM)
            {
                /* Если есть к-да на установку режима ТУ */
                Messenger.Send(78); /* ОП.КОМАНДА УСТАНОВИТЬ РЕЖИМ ТУ */
                flTmp1 = true;
            }

            if (Cmd == NaCmd.SET_REZ)
            {
                /* Если есть к-да на установку режима РЕЗ */
                Messenger.Send(79); /* ОП.КОМАНДА УСТАНОВИТЬ РЕЖИМ РЕЗ */
                flTmp1 = true;
            }

            if (Cmd == NaCmd.SET_REM)
            {
                /* Если есть команда на установку режима РЕМ от операто */
                Messenger.Send(80); /* ОП.КОМАНДА УСТАНОВИТЬ РЕЖИМ РЕМ */
                flTmp1 = true;
            }

            if (Cmd == NaCmd.SET_SIM)
            {
                /* Если есть команда на установку режима ИМИТ  */
                Messenger.Send(81); /* ОП. НАЗНАЧЕН РЕЖИМ ИМИТ */
                flTmp1 = true;
            }

            if (Cmd == NaCmd.UNSET_SIM)
            {
                /* Если есть команда на снятие режима ИМИТ  */
                Messenger.Send(82); /* ОП. СНЯТ РЕЖИМ ИМИТ */
                flTmp1 = true;
            }

            /*  35  */
            /* Выполнение команд оператора по смене режима */
            /* Для упрощения - ситуациЯ повторного установления режима не проверяется */
            if (flTmp1)
            {
                /* Если команда смены режима принята к исполнению */
                /* Установка режима Испытательный */
                if (Cmd == NaCmd.SET_SIM)
                {
                    /* команда на установку режима ИСПЫТ */
                    if (na.MainState != NaState.Otkl)
                    {
                        Messenger.Send(50); /* ОП. ИЗМЕНЕНИЕ РЕЖИМА НЕВОЗМОЖНО. АГРЕГАТ НЕ ОТКЛЮЧЕН */
                    }
                    else
                    {
                        /* Если агрегат не отключен */
                        na.SimAgr = true;
                        Messenger.Send(46);
                    }
                }

                /* Снятие режима испытательный */
                if (Cmd == NaCmd.UNSET_SIM)
                {
                    /* команда на снЯтие режима ИСПЫТ */
                    if (na.MainState != NaState.Otkl)
                    {
                        Messenger.Send(50); /* ОП. ИЗМЕНЕНИЕ РЕЖИМА НЕВОЗМОЖНО. АГРЕГАТ НЕ ОТКЛЮЧЕН */
                    }
                    else
                    {
                        /* Если агрегат не отключен */
                        na.SimAgr = false;
                        Messenger.Send(47);
                    }
                }

                /*  37  */
                if (Cmd == NaCmd.SET_OSN || SetOsnAuto)
                {
                    /* Если есть к-да на установку осн реж от оператора */
                    if (na.Mode == NaMode.Osn)
                    {
                        Messenger.Send(48);
                    }
                    else
                    {
                        na.Mode = NaMode.Osn /*OSN*/; /* установить режим агрегата ОСН */
                        Messenger.Send(42); /* ОП.УСТАНОВЛЕН  РЕЖИМ  ОСН */
                    }
                }

                /*  39  */
                if (Cmd == NaCmd.SET_TM)
                {
                    /* Если есть к-да на установку режима ТМ */
                    if (na.Mode == NaMode.Tm)
                    {
                        Messenger.Send(48);
                    }
                    else if (!NpsDist)
                    {
                        /* Если режим станции не дистанционный */
                        Messenger.Send(49); /* ОП. НАЗНАЧЕНИЕ РЕЖ ТУ НЕВОЗМ-НО. СТАНЦИЯ В МЕСТНОМ */
                    }
                    else
                    {
                        na.Mode = NaMode.Tm; /* Установить режим агрегата ТУ */
                        Messenger.Send(43); /* ОП. УСТАНОВЛЕН РЕЖИМ ТУ */
                    }
                }

                /*  41  */
                /* УСТАНОВКА РЕЗЕРВНОГО РЕЖИМА - ТОЛЬКО ПО КОМАНДЕ ОПЕРАТОРА*/
                if (Cmd == NaCmd.SET_REZ)
                {
                    /* Если есть к-да на установку режима РЕЗ */
                    if (na.Mode == NaMode.Rez)
                    {
                        Messenger.Send(48);
                    }
                    else
                    {
                        var flTmp = ZpState == ZdState.Opened;
                        flTmp1 = ZvState == ZdState.Opened;
                        flTmp2 = na.Prog == NaProg.P1;
                        var flTmp3 = na.MainState == NaState.Otkl && StopNoCmd != StopNoCmdState.Phase1;

                        if (!flTmp || !flTmp1 || !flTmp2 || !flTmp3)
                        {
                            if (!flTmp)
                            {
                                Messenger.Send(51); /* ОП. НАЗН РЕЖ РЕЗ НЕВОЗМ. ПРИЕМ ЗАДВ НЕ ОТКРЫТА */
                            } /*  44  */

                            if (!flTmp1)
                            {
                                Messenger.Send(52); /* ОП.НАЗН РЕЖ РЕЗ НЕВОЗМОЖНО. ВЫХ ЗАДВ НЕ ОТКРЫТА */
                            }

                            if (!flTmp2)
                            {
                                Messenger.Send(53); /* ОП.НАЗН РЕЖ РЕЗ НЕВОЗМОЖНО. НЕТ ПРОГРАММЫ П1 */
                            }

                            if (!flTmp3)
                            {
                                Messenger.Send(50); /* ОП. ИЗМЕНЕНИЕ РЕЖИМА НЕВОЗМОЖНО. АГРЕГАТ НЕ ОТКЛЮЧЕН */
                            }
                        }
                        else if (DoRez)
                        {
                            na.Mode = NaMode.Rez; /* Установить режим агрегата РЕЗ */
                            Messenger.Send(44); /* ОП.44 УСТАНОВЛЕН  РЕЖИМ  РЕЗ */
                        }
                        else if (RezExist)
                        {
                            Messenger.Send(54);
                        }
                        else if (NoOsnForRez)
                        {
                            Messenger.Send(55);
                        }
                        else
                        {
                            //добавить обработку 
                        }

                    }
                }

                /*  62   */
                /* УСТАНОВКА РЕМОНТНОГО РЕЖИМА - ТОЛЬКО ПО КОМАНДЕ ОПЕРАТОРА   */
                if (Cmd == NaCmd.SET_REM)
                {
                    /* Если есть команда на установку режима РЕМ от операто */
                    if (na.Mode == NaMode.Rem)
                    {
                        Messenger.Send(48);
                    }
                    else if(na.MainState != NaState.Otkl)
                    {
                        Messenger.Send(50); /* ОП. ИЗМЕНЕНИЕ РЕЖИМА НЕВОЗМОЖНО. АГРЕГАТ НЕ ОТКЛЮЧЕН */
                    }
                    else
                    {
                        na.Mode = NaMode.Rem; /* Установить режим РЕМ */
                        Messenger.Send(45); /* ОП. НАЗНАЧЕН РЕЖИМ РЕМ */
                    }
                }
            }

            /*
             * Установка контроля по току
             */
            if (TokControl != UseCT_Prev)
            {
                if (TokControl)
                {
                    Messenger.Send(94); /* КОМАНДА - УСТАНОВИТЬ КОНТРОЛЬ ТОКА*/
                    Messenger.Send(66); /* ОП. КОНТРОЛЬ ТОКА УСТАНОВЛЕН */
                }

                if (!TokControl)
                {
                    Messenger.Send(95); /* КОМАНДА - СНЯТЬ КОНТРОЛЬ ТОКА*/
                    Messenger.Send(67); /* ОП. КТ СНЯТ */
                }
            }
            UseCT_Prev = TokControl;

            /*
             * Программа остановки
             */
            if (na.ActvTaskMPNA == 1)
            {
                switch (na.TaskStepMPNA)
                {
                    case 1:
                        InternalTimers[11].Stop();
                        InternalTimers[5].Stop();
                        InternalTimers[8].Stop();
                        InternalTimers[7].Stop();
                        KeepStopWork = false;
                        if (na.SimAgr)
                        {
                            /* Если агрегат в имитации */
                            na.MainState = NaState.Ostanov; /* Установить состоЯние агрегата отключен */
                            Messenger.Send(26); /* ОП. ИДЕТ ПРОГРАММНЫЙ ОСТАНОВ */
                            na.SubState = NaSubstate.Po;
                            Messenger.Send(64); /* ОП. АГРЕГАТ ОТКЛЮЧЕН. РЕЖИМ ИСПЫТАТЕЛЬНЫЙ */
                            na.TaskStepMPNA = 4; /* Перехода к шагу закрытия Задвижек */
                            HIGHVIB = false; /* Сброс режима повышенной вибрации двигателЯ */
                            HIGHVIBNas = false; /* Сброс нестац. режима насоса */
                        }
                        else
                        {
                            /* Если агрегат не в имитационном режиме */
                            if (na.MainState == NaState.Pusk)
                            {
                                Messenger.Send(21);
                            }

                            if (na.MainState == NaState.Vkl || na.MainState == NaState.Pusk || StopNoCmd > 0)
                            {
                                if (!na.flag_PovtorOtkl && !StopAuto2)
                                {
                                    Messenger.Send(26); /* ОП. ИДЕТ ПРОГРАММНЫЙ ОСТАНОВ */
                                }

                                na.SubState = NaSubstate.Po;
                                if (!(StopNoCmd > 0))
                                {
                                    na.MainState = NaState.Ostanov; /* Установить состоЯние агрегата останов */
                                }
                            }

                            if (na.StartErr2 || StopNoCmd > 0 && !diagnoNeedVv)
                            {
                                na.TaskStepMPNA = 4;
                            }
                            else
                            {
                                BlockMsgCurr = !TokControl || !vv.Tok || na.Tok_Ndv;
                                if (!(StopNoCmd > 0 || StartNoCmd))
                                {
                                    BlockMsgBB = BBoff;
                                }
                                else
                                {
                                    BlockMsgBB = false;
                                }

                                //TODO: WTF???
                                if (StartWork || BBon ||
                                    BBoff && !TokControl && na.MainState != NaState.Otkl && !na.StartErr2 ||
                                    StopNoCmd > 0 || StartNoCmd || na.StartErr ||
                                    na.MainState == NaState.Otkl && diagnoNeedVv && !na.StateAlarm)
                                {
                                    Messenger.Send(17); /* ОП.КОМАНДА - ОТКЛЮЧИТЬ МВ */
                                    StartWork = false; /* СнЯть команду на включение МВ */
                                    StopWork = true; /* Команда отключить МВ */

                                    if (BBoff || na.StateAlarm)
                                    {
                                        KeepStopWork = true;
                                    }

                                    BlockMsgState = false;
                                }
                                else
                                {
                                    BlockMsgState = BlockMsgCurr && BlockMsgBB && !(na.StartErr2 || na.StartErr3);
                                }

                                InternalTimers[6].Start();
                                na.TaskStepMPNA = 2; /* Переход к шагу проверке отключенности МВ */
                            }
                        }

                        StartWork = false;
                        InternalTimers[2].Stop();
                        StopNoCmd = StopNoCmdState.None;
                        /* Шаг 2 - проверка отключенности МВ */
                        /* =========================================== */
                        break;
                    case 2:
                        if (BBoff && !KeepStopWork || KeepStopWork && !StopWork && !BBon)
                        {
                            KeepStopWork = false;
                            StopWork = false;
                            InternalTimers[6].Stop();
                            if (TokControl)
                            {
                                /* Если ток контролируется */
                                /* выдаём сообщение о том, что ВВ отключен */
                                if (!BlockMsgBB)
                                {
                                    Messenger.Send(18); /* ОП. ВВ ОТКЛЮЧЕН*/
                                    BlockMsgBB = true;
                                }

                                StopWork = false; // ИЗБЫТОЧНО
                                if (!vv.Tok)
                                {
                                    /* если ток сброшен */
                                    if (!BlockMsgCurr)
                                    {
                                        /* выдаём соответствующее сообщение */
                                        Messenger.Send(7); /* ОП. ТОК СБРОШЕН*/
                                        BlockMsgCurr = true;
                                    }

                                    na.MainState = NaState.Otkl; /* Агрегат успешно остановлен */
                                    if (!BlockMsgState)
                                    {
                                        Messenger.Send(28); /* ОП. ОСТАНОВЛЕН*/
                                    }

                                    na.TaskStepMPNA = 4; /* Переход к шагу закрытия Задвижек */
                                }
                                else
                                {
                                    /* если ток НЕ сброшен */
                                    InternalTimers[12].Start(); /* Запустить Т12 - время снижениЯ тока */
                                    na.TaskStepMPNA = 3; /* Переход к проверке отключенности по току */
                                }
                            }
                            else
                            {
                                /* Если ток НЕ контролируется */
                                StopWork = false;
                                InternalTimers[6].Stop();
                                /* выдаём сообщение о том, что ВВ отключен */
                                if (!BlockMsgBB)
                                {
                                    Messenger.Send(18); /* ОП. ВВ ОТКЛЮЧЕН*/
                                    BlockMsgBB = true;
                                }

                                na.MainState = NaState.Otkl; /* Агрегат успешно остановлен */
                                if (!BlockMsgState)
                                {
                                    Messenger.Send(60); /* ОП. КОНТРОЛЬ ПО ТОКУ НЕ ВЕДЁТСЯ*/
                                    Messenger.Send(28); /* ОП. ОСТАНОВЛЕН*/
                                }

                                na.TaskStepMPNA = 4; /* Переход к шагу закрытия задвижек */
                            }
                        }
                        else if (InternalTimers[6].IsQ)
                        {
                            /* Если сраб Т6 - время контроля отключения ВВ */
                            StopWork = false;
                            if (TokControl)
                            {
                                /* Если ток контролируется */
                                InternalTimers[12].Start(); /* Запустить Т12 - время снижения тока */
                                na.TaskStepMPNA = 3; /* Переход к проверке отключенности по току */
                            }
                            else
                            {
                                /* Если ток НЕ контролируется */
                                na.MainState = NaState.Vkl;
                                if (na.StopErr)
                                {
                                    /* Если была ошибка остановки */
                                    na.StopErr2 = true; /* Переходим в состояние "Ошибка отключения ВВ" */
                                }
                                else
                                {
                                    na.StopErr = true; /* Иначе вывешиваем ошибку остановки */
                                } // и сообщаем о проблемах

                                Messenger.Send(22); /* ОП.МАСЛЯНЫЙ ВЫКЛЮЧАТЕЛЬ НЕ ОТКЛЮЧИЛСЯ */
                                Messenger.Send(60); /* ОП.КОНТРОЛЬ ПО ТОКУ НЕ ВЕДЁТСЯ */
                                Messenger.Send(58); /* ОП.НЕ ПОЛУЧЕНО СОСТОЯНИЕ "ОСТАНОВЛЕН" ЗА ЗАДАННОЕ ВРЕМЯ */
                                if (!na.flag_PovtorOtkl)
                                {
                                    na.TaskStepMPNA = 6;
                                }
                                else
                                {
                                    InternalTimers[10].Start();
                                }
                            }
                        }

                        /*выдача команды повторного отключения ВВ при невыполнении программы остановки*/
                        if (InternalTimers[10].IsQ)
                        {
                            na.TaskStepMPNA = 1;
                        }

                        /* Шаг 3 - проверка отключенности по току  */
                        /* ========================================== */
                        break;
                    case 3:

                        if (!BlockMsgBB && BBoff)
                        {
                            /* Если ВВ отключен и об этом ещё не говорили - говорим */
                            Messenger.Send(18); /* ОП. ВВ ОТКЛЮЧЕН */
                            BlockMsgBB = true;
                        }

                        if (!vv.Tok && BBoff)
                        {

                            if (!BlockMsgCurr)
                            {
                                /* сообщаем о том, что ток снят */
                                Messenger.Send(7); /* ОП. ТОК СБРОШЕН */
                                BlockMsgCurr = true;
                            }

                            na.MainState = NaState.Otkl; /* Агрегат успешно остановлен */

                            if (!BlockMsgState)
                            {
                                Messenger.Send(28); /* ОП. ОСТАНОВЛЕН */
                            }

                            InternalTimers[12].Stop(); /* Сброс Т12 - времЯ снижения тока */
                            na.TaskStepMPNA = 4; /* Перехода к шагу закрытия Задвижек */
                        }
                        else
                        {
                            if (InternalTimers[12].IsQ)
                            {
                                /* Если сраб Т12 - время контроля снижения тока */
                                if (BBon)
                                {
                                    /* если ещё не сказали о том, что ВВ не отключен - говорим */
                                    if (!BlockMsgBB)
                                    {
                                        Messenger.Send(22); /* ОП. ВВ НЕ ОТКЛЮЧЕН*/
                                        BlockMsgBB = true;
                                    }

                                    /* делаем последнюю попытку разобраться с током - снялся или нет */
                                    if (!BlockMsgCurr)
                                    {
                                        if (!vv.Tok)
                                        {
                                            Messenger.Send(7); //ТОК СБРОШЕН
                                        }
                                        else
                                        {
                                            Messenger.Send(57); //ТОК НЕ СБРОШЕН
                                        }

                                        BlockMsgCurr = true;
                                    }

                                    if (!BlockMsgState)
                                    {
                                        Messenger.Send(58); //НЕ ПОЛУЧЕНО СОСТОЯНИЕ "ОСТАНОВЛЕН" ЗА ЗАДАННОЕ ВРЕМЯ
                                    }

                                    na.MainState = NaState.Vkl;
                                    // вывешиваем ошибку отключения ВВ и делаем повторное отключение если что
                                    if (na.StopErr)
                                    {
                                        na.StopErr2 = true;
                                    }
                                    else
                                    {
                                        na.StopErr = true;
                                    }

                                    if (!na.flag_PovtorOtkl)
                                    {
                                        na.TaskStepMPNA = 6;
                                    }
                                    else
                                    {
                                        InternalTimers[10].Start();
                                    }
                                }
                                else if (BBoff && vv.Tok)
                                {
                                    /* Если ВВ отключен, а ток ещё есть, при этом время контроля снижения тока истекло - считаем что агрегат отключен, а значение силы тока - недостоверно */
                                    if (!BlockMsgBB)
                                    {
                                        Messenger.Send(18); /* ОП. ВВ ОТКЛЮЧЕН*/
                                        BlockMsgBB = true;
                                    }

                                    if (!BlockMsgCurr)
                                    {
                                        Messenger.Send(57); /* ОП. ТОК НЕ СБРОШЕН*/
                                        Messenger.Send(5); /* ОП. ЗНАЧЕНИЕ СИЛЫ ТОКА НЕДОСТОВЕРНО*/
                                        BlockMsgCurr = true;
                                    }

                                    na.Tok_Ndv = true;
                                    na.StateAlarm = true;
                                    na.MainState = NaState.Otkl; /* Агрегат успешно остановлен */

                                    if (!BlockMsgState)
                                    {
                                        Messenger.Send(28); /* ОП. ОСТАНОВЛЕН */
                                    }

                                    na.TaskStepMPNA = 4; /*Переходим к закрытию задвижек*/
                                }
                                else if (!InternalTimers[10].IsStarted)/*Если не ждём повторную выдачу команды отключения ВВ */
                                {
                                    /* и не ждём снижения силы тока */
                                    na.TaskStepMPNA = 6; /* считаем задачу остановки завершённой */
                                }
                            }

                            if (InternalTimers[10].IsQ)
                            {
                                na.TaskStepMPNA = 1;
                            }
                        }


                        /*  89  */

                        /* Шаг 4 - ЗАКРЫТИЕ ЗАДВИЖЕК после останова Агрегата */
                        /* ========================================== */
                        break;
                    case 4:
                        na.StopErr = false;
                        na.StopErr2 = false;
                        na.StartErr = false;
                        na.StartErr2 = false;
                        na.StartErr3 = false;
                        na.MainState = NaState.Otkl;
                        /* Установить состоЯние агрегата отключен */
                        na.flag_PovtorOtkl = false;
                        HIGHVIB = false; /* Сброс режима повышенной вибрации двигателЯ */
                        HIGHVIBNas = false; /* Сброс нестац. режима насоса */

                        ZPBlocks = NaZdBlocks.None; /* Команда на снятие запрета закрытия приемной задвижки */
                        ZVBlocks = NaZdBlocks.None; /* Команда на снятие запрета закрытия выходной задвижки */

                        if (na.Prog == NaProg.P2)
                        {
                            ZVCmd = NaZdCmd.Close;
                            Messenger.Send(84); // КОМАНДА - ЗАКРЫТЬ ЗАДВИЖКУ НА ВЫХОДЕ
                        }

                        /* программа пуска не П1 */
                        /* Сброс признака закрытия Задвижек */
                        InternalTimers[8].Start(); //Запустить Т8 - время открытия выход задвижки П2
                        na.TaskStepMPNA = 5; /* Конец Задачи ОСТАНОВ */

                        /*  91  */
                        /* Шаг 5 - Контроль закрытия задвижки */
                        /* =========================================== */
                        break;
                    case 5:
                        if (na.Prog == NaProg.P2)
                        {
                            /* Если программа пуска П2 */
                            if (ZvState == ZdState.Closed)
                            {
                                /* Сигнал выходная задвижка закрылась */
                                InternalTimers[8].Stop(); /* Сброс Т8 - время закрытия Выкидной Задвижки */
                                na.AlreadyStopped = true;
                                ZVCmd = NaZdCmd.None;
                                na.TaskStepMPNA = 6;
                            }
                            else
                            {
                                if (InternalTimers[8].IsQ || ZvStateCrash)
                                {
                                    /* Если сработал Т8 - времЯ открытиЯ Выкидной Задвижки */
                                    Messenger.Send(63); /* ОП. НЕВЫПОЛНЕНИЕ ЗАКРЫТИЯ ЗАДВИЖКИ ПО ПРОГРАММЕ ОСТАНОВКИ */
                                    ZVCmd = NaZdCmd.None;
                                    na.TaskStepMPNA = 6;
                                }
                            }
                        }
                        else
                        {
                            InternalTimers[8].Stop();
                            na.TaskStepMPNA = 6;
                        }


                        /* Шаг 6 - ОКОНЧАНИЕ задачи ОСТАНОВ */
                        /* =========================================== */
                        break;
                    case 6:
                        if (na.MainState == NaState.Otkl)
                        {
                            na.AlreadyStopped = true;
                            if (na.SubState == NaSubstate.Po)
                            {
                                Messenger.Send(27); /* ОП. ПРОГРАММНЫЙ ОСТАНОВ ЗАВЕРШЕН */
                            }
                        }

                        na.SubState = 0;
                        na.ActvTaskMPNA = 0; /* Сброс признака активного модулЯ */
                        na.TaskStepMPNA = 0;
                        break;
                    /* Of na.TaskStepMPNA */
                } /* na.ActvTaskMPNA==1 */
            }

/*  92  */
            if (na.ActvTaskMPNA == 2)
            {

                /* Шаг 1 - ДлЯ АВР - запуск таймера задержки АВР. */

                switch (na.TaskStepMPNA)
                {
                    case 1:
                        na.StartErr = false;
                        na.StartErr2 = false;
                        na.StartErr3 = false;
                        na.StopErr = false;
                        na.StopErr2 = false;
                        StopWork = false;

                        InternalTimers[6].Stop();
                        InternalTimers[12].Stop();
                        InternalTimers[10].Stop();
                        InternalTimers[8].Stop();
                        BlockMsgBB = false;
                        StopNoCmd = StopNoCmdState.None;
                        if (StartRez)
                        {
                            na.TaskStepMPNA = 2;
                        }
                        else
                        {
                            na.TaskStepMPNA = 3;
                        } /* Шаг 2 - пуск по АВР */

                        break;
                    case 2:
                        if (na.Mode == NaMode.Rez)
                        {
                            /* Если агрегат еще в резерве */
                            if (ReadyToStart)
                            {
                                /* Если агрегат готов к пуску */
                                na.Mode = NaMode.Osn /*OSN*/; /* установить режим агрегата ОСН */
                                Messenger.Send(42); /* ОП. НАЗНАЧЕН РЕЖИМ ОСН */
                                Messenger.Send(23); /* ОП. ИДЕТ ПРОГРАММНЫЙ ЗАПУСК */
                                na.SubState = NaSubstate.Pp;
                                /*  96  */
                                if (na.SimAgr)
                                {
                                    /* Если агрегат в симуляции */
                                    na.MainState = NaState.Vkl; /* Установить состояние включен */
                                    Messenger.Send(65); /* ОП. ВКЛЮЧЕН РЕЖИМ ИСПЫТАТЕЛЬНЫЙ */
                                    na.TaskStepMPNA = 9; /* На конец Задачи */
                                    HIGHVIB = true; /* Установить блокировку вибрации */
                                    HIGHVIBNas = IsNM; /* Включить нестационарный режим для насосов типа НМ */
                                    na.SubState = NaSubstate.None;
                                }
                                else
                                {
                                    StartWork = true; /* Выдать команду на включение МВ */
                                    na.MainState = NaState.Pusk; /* Установить состоЯние агрегата пуск */
                                    HIGHVIB = true; /* Установить блокировку вибрации */
                                    HIGHVIBNas = IsNM; /* Включить нестационарный режим для насосов типа НМ */
                                    Messenger.Send(68); /* ОП. КОМАНДА - ВКЛЮЧИТЬ МАСЛЯНЫЙ ВЫКЛЮЧАТЕЛЬ */
                                    InternalTimers[11].Start();
                                    na.TaskStepMPNA = 6; /* На проверку включенности */
                                }
                            }
                            else
                            {
                                /* Если агрегат не готов к пуску */
                                Messenger.Send(29); /* ОП. ПУСК ПО АВР НЕВОЗМОЖЕН. АГРЕГАТ НЕ ГОТОВ К ПУСКУ */
                                na.TaskStepMPNA = 9; /* На конец Задачи */
                            }
                        }
                        else
                        {
                            na.TaskStepMPNA = 9; /* На конец Задачи */
                        }
                        /* Шаг 3 - Пуск по программам   */
                        /* =========================================== */
                        break;
                    case 3:
                        if (na.Prog == NaProg.P1)
                        {
                            /* Если программа пуска П1*/
                            if (ReadyToStart)
                            {
                                /* Если агрегат в имитации */
                                Messenger.Send(23); /* ОП.25 ИДЕТ ПРОГРАММНЫЙ ЗАПУСК */
                                na.MainState = NaState.Pusk;
                                na.SubState = NaSubstate.Pp;
                                ZVBlocks = NaZdBlocks.NoClose; /* Установл запрет закр выкид задв */
                                ZPBlocks = NaZdBlocks.NoClose;
                                SAR_Ramp = false; /*Команда на снижение уставки регулированиЯ*/
                                na.TaskStepMPNA = 5;
                            }
                        }

                        /*  101  */
                        if (na.Prog == NaProg.P2)
                        {
                            /* Если программа пуска П2 */
                            if (ReadyToStart)
                            {
                                Messenger.Send(23); /* ОП.25 ИДЕТ ПРОГРАММНЫЙ ЗАПУСК */
                                na.SubState = NaSubstate.Pp;
                                na.MainState = NaState.Pusk; /* Установить состоЯние агрегата пуск */
                                ZVBlocks = NaZdBlocks.NoClose; /* Установл запрет закр выкид задв */
                                ZPBlocks = NaZdBlocks.NoClose;
                                InternalTimers[5].Start();
                                ZVCmd = NaZdCmd.Open; /* Команда открыть выходную задвижку */
                                InternalTimers[8].Start();
                                na.TaskStepMPNA = 4; /* Переход на проверку Т5 */
                                Messenger.Send(83); /* КОМАНДА - ОТКРЫТЬ ЗАДВИЖКУ НА ВЫХОДЕ АВТОМАТИЧЕСКИ */
                            }
                        }

                        if (!ReadyToStart)
                        {
                            na.MainState = NaState.Otkl; /* Установить состоЯние агрегата отключен */
                            HIGHVIB = false; /* Снять блокировку вибрации */
                            HIGHVIBNas = false; /* Cнять нестационарный режим */
                            na.TaskStepMPNA = 9;
                            na.SubState = NaSubstate.None;
                            Messenger.Send(29); /* ОП. ПУСК НЕВОЗМОЖЕН. АГРЕГАТ НЕ ГОТОВ К ПУСКУ */
                        }
                        /* Шаг 4 - Ожидание приоткрытиЯ Задвижки по П2 */
                        /* =========================================== */
                        break;
                    case 4:
                        if (InternalTimers[5].IsQ)
                        {
                            if (ZvState == ZdState.Opening || ZvState == ZdState.Opened)
                            {
                                if (na.SimAgr)
                                {
                                    na.MainState = NaState.Vkl;
                                    na.TaskStepMPNA = 8;
                                    HIGHVIB = true;
                                    HIGHVIBNas = IsNM;
                                    Messenger.Send(65);
                                }
                                else
                                {
                                    StartWork = true;
                                    InternalTimers[11].Start();
                                    na.TaskStepMPNA = 6;
                                    HIGHVIB = true;
                                    HIGHVIBNas = IsNM;
                                    Messenger.Send(68);
                                }
                            }
                            else
                            {
                                na.SubState = NaSubstate.None;
                                na.StartErr2 = true;
                                Messenger.Send(62); // ВЫХОДНАЯ ЗАДВИЖКА НЕ НАЧАЛА ОТКРЫВАТЬСЯ ПРИ ПУСКЕ ПО ПРОГРАММЕ №2       
                                na.TaskStepMPNA = 9;
                            }
                        }

                        /* Шаг 5 - КОНТРОЛЬ таймера Пусковой Задержки для САР */
                        /* =========================================== */
                        break;
                    case 5:
                        if (InternalTimers[4].IsQ || MnsInWork || MpnaType == false || StartAuto)
                        {
                            if (na.SimAgr)
                            {
                                na.MainState = NaState.Vkl; /* Установить состояние включен */
                                Messenger.Send(65); /* ОП. ВКЛЮЧЕН РЕЖИМ ИМИТАЦИИ */
                                na.TaskStepMPNA = 9; /* На конец Задачи */
                                HIGHVIB = true; /* Установить блокировку вибрации */
                                HIGHVIBNas = IsNM; /* Включить нестационарный режим для насосов типа НМ */
                            }
                            else
                            {
                                StartWork = true; /* Выдать команду на включение МВ */
                                InternalTimers[11].Start();
                                Messenger.Send(68); /* ОП. КОМАНДА - ВКЛЮЧИТЬ МАСЛЯНЫЙ ВЫКЛЮЧАТЕЛЬ */
                                HIGHVIB = true; /* Установить блокировку вибрации */
                                HIGHVIBNas = IsNM; /* Включить нестационарный режим для нетиповых насосов */
                                na.TaskStepMPNA = 6;
                            }
                            /* Если сраб Т4 - времЯ сниж уст рег давл САР */
                            
                            SAR_Ramp = false;
                            InternalTimers[15].Stop();
                            InternalTimers[4].Stop();
                        }
                        else if (InternalTimers[15].IsQ)
                        {
                            SAR_Ramp = false;
                            Messenger.Send(97); // КОМАНДУ ПРИКРЫТИЯ РЕГУЛИРУЮЩИХ ЗАСЛОНОК ПРИ ПУСКЕ ПЕРВОГО ПО СЧЁТК МНС СНЯТЬ АВТОМАТИЧЕСКИ
                        }
                        else if (!SAR_Ramp && !InternalTimers[4].IsStarted && !InternalTimers[15].IsStarted && !MnsInWork && MpnaType == true && !StartAuto)
                        {
                            SAR_Ramp = true;
                            InternalTimers[4].Start();
                            InternalTimers[15].Start();
                            Messenger.Send(96); // КОМАНДУ ПРИКРЫТИЯ РЕГУЛИРУЮЩИХ ЗАСЛОНОК ПРИ ПУСКЕ ПЕРВОГО ПО СЧЁТУ МНА УСТАНОВИТЬ АВТОМАТИЧЕСКИ
                        }

                        /* Шаг 6 - КОНТРОЛЬ ВКЛЮЧЕНИЯ МВ */
                        /* =========================================== */
                        break;
                    case 6:
                        if (BBon)
                        {
                            //StartWork = false;//скинем по Т2
                            InternalTimers[2].Start();
                            BlockMsgBB = true;
                            Messenger.Send(14); // ВВ ВКЛЮЧЕН
                            if (TokControl)
                            {
                                InternalTimers[11].Stop();
                                if (vv.Tok)
                                {
                                    Messenger.Send(6); /* ОП. ТОК ДВИГАТЕЛЯ В НОРМЕ */
                                    Messenger.Send(25); /* ОП.В РАБОТЕ */
                                    na.MainState = NaState.Vkl;
                                    if (na.Prog == NaProg.P2)
                                    {
                                        na.TaskStepMPNA = 8;
                                    }
                                    else
                                    {
                                        na.TaskStepMPNA = 9;
                                    }
                                }
                                else
                                {
                                    InternalTimers[7].Start();
                                    na.TaskStepMPNA = 7;
                                }
                            }
                            else
                            {
                                na.MainState = NaState.Vkl;
                                InternalTimers[11].Stop();
                                InternalTimers[2].Start();
                                Messenger.Send(60); // КОНТРОЛЬ ПО ТОКУ НЕ ВЕДЁТСЯ
                                Messenger.Send(25); // В РАБОТЕ
                                if (na.Prog == NaProg.P2)
                                {
                                    na.TaskStepMPNA = 8;
                                }
                                else
                                {
                                    na.TaskStepMPNA = 9;
                                }
                            }
                        }
                        else
                        {
                            if (InternalTimers[11].IsQ)
                            {
                                if (TokControl)
                                {
                                    StartWork = false;
                                    na.TaskStepMPNA = 7;
                                    InternalTimers[2].Start();
                                    InternalTimers[7].Start();
                                }
                                else
                                {
                                    StartWork = false;
                                    na.StartErr3 = true;
                                    Messenger.Send(99); // ВВ НЕ ВКЛЮЧИЛСЯ
                                    Messenger.Send(60); // КОНТРОЛЬ ПО ТОКУ НЕ ВЕДЁТСЯ
                                    Messenger.Send(16); // НЕ ПОЛУЧЕНО СОСТОЯНИЕ "В РАБОТЕ" ЗА ЗАДАННОЕ ВРЕМЯ
                                    na.TaskStepMPNA = 9;
                                }
                            }
                        }

                        /* Шаг 7 - Проверка включенности по току нагрузки */
                        /* =========================================== */
                        break;
                    case 7:
                        if (BBon && !BlockMsgBB)
                        {
                            Messenger.Send(14); // ВВ ВКЛЮЧЕН
                            BlockMsgBB = true;
                        }

                        if (BBon && vv.Tok)
                        {
                            /* Если есть ток */
                            na.MainState = NaState.Vkl;
                            InternalTimers[7].Stop();
                            Messenger.Send(6); /* ОП. ТОК ДВИГАТЕЛЯ В НОРМЕ */
                            Messenger.Send(25); /* ОП. ДВИГАТЕЛЬ ВКЛЮЧЕН */
                            if (na.Prog == NaProg.P2)
                            {
                                /* Если программа пуска П2 */
                                na.TaskStepMPNA = 8; /* Переход к проверке полного открытия Задвижки */
                            }
                            else
                            {
                                na.TaskStepMPNA = 9;
                            }
                        }
                        else if (InternalTimers[7].IsQ || na.StateAlarm) /* Если тока нет */
                        {
                            /* Если сработал Т7 - время контроля подъема тока */
                            if (BBoff)
                            {
                                Messenger.Send(99); /*ВВ НЕ ВКЛЮЧИЛСЯ*/
                            }

                            if (InternalTimers[7].IsQ)
                            {
                                if (!vv.Tok)
                                {
                                    Messenger.Send(98); /* ТОК НЕ НАБРАЛСЯ */
                                }
                                else
                                {
                                    Messenger.Send(6); /* ТОК НАБРАН */
                                }

                                Messenger.Send(16); // НЕ ПОЛУЧЕНО СОСТОЯНИЕ ОСТАНОВЛЕН ЗА ЗАДАННОЕ ВРЕМЯ
                                if (BBon || vv.Tok)
                                {
                                    na.StartErr = true;
                                }
                                else
                                {
                                    na.StartErr3 = true;
                                }

                                na.TaskStepMPNA = 9;
                            }
                            else if (vv.Tok)
                            {
                                Messenger.Send(6); /* ТОК НАБРАН */
                                na.TaskStepMPNA = 9;
                            }
                        }
                        /* Шаг 8 - Проверка таймера Т8 - открытиЯ выкидной Задвижкик */
                        /* =========================================== */
                        break;
                    case 8:
                        if (ZvState == ZdState.Opened)
                        {
                            /* Сигнал выходнаЯ задвижка открылась */
                            InternalTimers[8].Stop();
                            ZVCmd = NaZdCmd.None;
                            na.TaskStepMPNA = 9;
                        }
                        else if (InternalTimers[8].IsQ || ZvStateCrash)
                        {
                            /* Если сработал Т8 - времЯ открытиЯ Выкидной Задвижки */
                            ZVCmd = NaZdCmd.None;
                            na.StartErr3 = true; /* Выдать команду на защиту не выполнение прогр пуска */
                            na.TaskStepMPNA = 9;
                            Messenger.Send(61); /* Не открылась вых задв пр пуске по П2 ( Таймер 8 ) */
                        }

                        /* Шаг 9 - ОКОНЧАНИЕ задачи ЗАПУСК */
                        /* =========================================== */
                        break;
                    case 9:

                        if (na.SubState == NaSubstate.Pp && !na.StartErr && !na.StartErr2 && !na.StartErr3)
                        {
                            Messenger.Send(24); /* ОП. ПРОГРАММНЫЙ ПУСК ЗАВЕРШЕН */
                        }

                        na.SubState = 0;
                        na.ActvTaskMPNA = 0; /* Сброс признака активной Задачи */
                        na.TaskStepMPNA = 0;
                        break;
                }
            }



            //РАБОТА С КОМАНДАМИ ЗАДВИЖКАМ

            switch (na.Mode)
            {
                case NaMode.Rem:
                    if (ZvState != ZdState.Closed)
                    {
                        ZVCmd = NaZdCmd.Close;
                    }
                    else
                    {
                        ZVCmd = NaZdCmd.None;
                    }

                    if (ZpState != ZdState.Closed)
                    {
                        ZPCmd = NaZdCmd.Close;
                    }
                    else
                    {
                        ZPCmd = NaZdCmd.None;
                    }

                    ZPBlocks = NaZdBlocks.NoOpen;
                    ZVBlocks = NaZdBlocks.NoOpen;

                    break;
                case NaMode.Rez:
                    ZPBlocks = NaZdBlocks.NoClose;
                    ZVBlocks = NaZdBlocks.NoClose;

                    ZVCmd = NaZdCmd.None;
                    ZPCmd = NaZdCmd.None;
                    break;
                case NaMode.Tm:
                case NaMode.Osn:

                    if (na.SubState != NaSubstate.Pp && na.SubState != NaSubstate.Po)
                    {
                        if (na.MainState == NaState.Otkl && !InternalTimers[16].IsStarted && !InternalTimers[16].IsQ)
                        {
                            ZPBlocks = NaZdBlocks.None;
                            ZVBlocks = NaZdBlocks.None;
                            ZVCmd = NaZdCmd.None;
                            ZPCmd = NaZdCmd.None;
                        }

                        if (na.MainState == NaState.Vkl && !StartNoCmd)
                        {
                            ZPBlocks = NaZdBlocks.NoClose;
                            ZVBlocks = NaZdBlocks.NoClose;

                            ZVCmd = NaZdCmd.None;
                            ZPCmd = NaZdCmd.None;

                        }

                    }
                    break;
            }
            /* ============================================================================== */
            /*      УСТАНОВКА И СНЯТИЕ ПЕРЕХОДНЫХ РЕЖИМОВ                 */
            /* ============================================================================== */

            /* ЗАПУСК ТАЙМЕРОВ ПРИ УСТАНОВКЕ ФЛАГА */
            if (HIGHVIB && !InternalTimers[9].IsStarted && !InternalTimers[9].IsQ ||
                HIGHVIBNas && !InternalTimers[14].IsStarted && !InternalTimers[14].IsQ)
            {
                Messenger.Send(33); /* УСТАНОВЛЕН НЕСТАЦИОНАРНЫЙ РЕЖИМ РАБОТЫ НАСОСА */
            }

            /*снЯтие по таймерам или досрочное */
            if (InternalTimers[9].IsQ || !HIGHVIB && InternalTimers[9].IsStarted)
            {
                HIGHVIB = false;
                InternalTimers[9].Stop();
                Messenger.Send(34); /* РЕЖИМ ПОВЫШЕННОЙ ВИБРАЦИИ ЗАКОНЧЕН */
            }
            if (HIGHVIB && !InternalTimers[9].IsStarted)
            {
                InternalTimers[9].Start();
            }


            if (InternalTimers[14].IsQ || !HIGHVIBNas && InternalTimers[14].IsStarted)
            {
                HIGHVIBNas = false;
                InternalTimers[14].Stop();
                Messenger.Send(35); /* ЗАКОНЧЕН НЕСТАЦИОНАРНЫЙ РЕЖИМ РАБОТЫ НАСОСА */
            }
            if (HIGHVIBNas && !InternalTimers[14].IsStarted)
            {
                InternalTimers[14].Start();
            }

            if (InternalTimers[2].IsQ && StartWork)
            {
                StartWork = false;
            }

            if (StopWork && InternalTimers[3].IsQ)
            {
                StopWork = false;
            }
            else if (StopWork && !InternalTimers[3].IsStarted)
            {
                InternalTimers[3].Start();
            }
            else if (!StopWork && InternalTimers[3].IsStarted)
            {
                InternalTimers[3].Stop();
            }

            if (na.MainState == 0)
            {
                na.MainState = NaState.Otkl;
            }

            if (na.MainState == NaState.Otkl)
            {
                na.StopErr = false;
                na.StopErr2 = false;
            }

            if (StopWork && StartWork)
            {
                StartWork = false;
            }

            HighVibrPumpOut = HIGHVIBNas;
            HighVibrEngOut = HIGHVIB;
            StartNoCmdOut = StartNoCmd;
            StopNoCmdOut = StopNoCmd;
            ZvCmdOut = ZVCmd;
            ZpCmdOut = ZPCmd;
            OnVvCmdOut = StartWork;
            OffVvCmdOut = StopWork;
            SardRampOut = SAR_Ramp;
            ZvBlockOut = ZVBlocks;
            ZpBlockOut = ZPBlocks;
            MainStateOut = na.MainState;
            SubstateOut = na.SubState;
            ModeOut = na.Mode;
            ProgOut = na.Prog;
            IsImitOut = na.SimAgr;
            StateAlarmVVOut = na.StateAlarm && !na.SimAgr;
            StopErrOut = na.StopErr;
            StopErr2Out = na.StopErr2;
            StartErrOut = na.StartErr || na.StartErr2 || na.StartErr3;
            SwitchOnOut = BBon;
            SwitchOffOut = BBoff;
        }

    }

}
