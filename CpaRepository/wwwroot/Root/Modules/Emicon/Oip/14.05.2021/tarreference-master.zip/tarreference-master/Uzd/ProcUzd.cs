﻿using System.Linq;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.St;
using TarReferenceSource.Common.Timer;

namespace TarReferenceSource.Uzd
{
    public enum ZdMovementProcessing
    {
        None,
        Init,
        ReverseStop,
        SwitchEnablingInit,
        SwitchEnabling,
        MoveWaitingInit,
        MoveWaiting,
        MovementInit,
        Movement,
        SelfstopInit,
        Selfstop,
        Fail,
        Canceled,
        Success,
    }

    public enum ZdStopProcessing
    {
        None,
        Init,
        Stopping,
        OpenStopping,
        CloseStopping,
        AfterStop,
        WaitingOpeningMestStop,
        WaitingClosingMestStop,
        Fail,
    }

    public enum ZdStateProcessing
    {
        Init,
        Waiting,
        Transition,
        Freeze,
        CommandExecution
    }

    public enum ZdStateSubstate
    {
        None = 0,
        Opening = 1,
        Opened = 2,
        Middle = 3,
        Closing = 4,
        Closed = 5,
        NoEc,
    }

    public enum CheckError
    {
        None,
        NonCrash,
        Crash,
    }
    /// <summary>
    /// Структура сглаженных сигналов
    /// </summary>
    public class ZdNuSmoothed
    {
        /// <summary>
        /// Флаг наличия сигнала Кво
        /// </summary>
        public bool KVO;
        /// <summary>
        /// Флаг наличия сигнала Квз
        /// </summary>
        public bool KVZ;
        /// <summary>
        /// Флаг наличия сигнала Мпо
        /// </summary>
        public bool MPO;
        /// <summary>
        /// Флаг наличия сигнала Мпз
        /// </summary>
        public bool MPZ;
        /// <summary>
        /// Флаг наличия сигнала моментного выключателя на открытие 
        /// </summary>
        public bool VMMO;
        public bool VmmoBlinked;
        /// <summary>
        /// Флаг наличия сигнала моментного выключателя на закрытие 
        /// </summary>
        public bool VMMZ;
        public bool VmmzBlinked;
    }
    /// <summary>
    /// Структура внутреннего состояния задвижки
    /// </summary>
    public class ZdStorage
    {
        /// <summary>
        /// Состояние
        /// </summary>
        public ZdState State;
        public bool Smoothing;
        /// <summary>
        /// Флаг имитации
        /// </summary>
        public bool Imit;
        /// <summary>
        /// Флаг неисправности
        /// </summary>
        public bool Neisprav;
        /// <summary>
        /// Флаг сработки муфты
        /// </summary>
        public bool MomentFail; /*Сработала муфта (моментный выключатель) ДЛЯ TM*/
        /// <summary>
        /// Флаг наличия дистанционного режима
        /// </summary>
        public bool DistKeyPrev;//защелка
        /// <summary>
        /// Флаг отсутствия напряжения
        /// </summary>
        public bool NoEcPrev;
        /// <summary>
        /// Флаг сработки моментного выключателя закрытия
        /// </summary>
        public bool VmmzPrev; //защелка. НУЖНО ПОНЯТЬ ПОЧЕМУ MCO СДЕЛАНО ПО ДРУГОМУ!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        /// <summary>
        /// Флаг сработки моментного выключателя открытия
        /// </summary>
        public bool VmmoPrev; //защелка. НУЖНО ПОНЯТЬ ПОЧЕМУ MCO СДЕЛАНО ПО ДРУГОМУ!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        /// <summary>
        /// Флаг аварии блока управления
        /// </summary>
        public bool BurCrash;
        /// <summary>
        /// Флаг сработки муфты
        /// </summary>
        public bool MuftaPrev;
        /// <summary>
        /// Флаг наличия сигнала цепи управления открытием задвижки исправны
        /// </summary>
        public bool CorrCo; /* 0 – нет сигнала «цепи управления открытием задвижки исправны», 1 – есть сигнал «цепи управления открытием задвижки исправны» */
        /// <summary>
        /// Флаг наличия сигнала цепи управления закрытием задвижки исправны
        /// </summary>
        public bool CorrCz; /* 0 – нет сигнала «цепи управления закрытием задвижки неисправны», 1 - есть сигнал «цепи управления закрытием задвижки исправны» */
        /// <summary>
        /// Флаг необходимости проверки на несанкционированное движение задвижки
        /// </summary>
        public bool NeedCheckUnprompted;
        /// <summary>
        /// Сглаженные сигналы
        /// </summary>
        public ZdNuSmoothed SmoothedNu = new ZdNuSmoothed();
    }
    /// <summary>
    /// Структура команд
    /// </summary>
    public class ZdCommandsProcessing
    {
        /// <summary>
        /// Подача команды стоп с БРУ
        /// </summary>
        public bool nlBRUStopPrev;
        /// <summary>
        /// Подача команды закрыть с БРУ
        /// </summary>
        public bool nlBRUClosePrev;
        /// <summary>
        /// Подача команды на закрытие
        /// </summary>
        public bool nlClosePrev;
        /// <summary>
        /// Подача команды на остановку
        /// </summary>
        public bool nlStopPrev;
        /// <summary>
        /// Подача команды на открытие
        /// </summary>
        public bool nlOpenPrev;
        /// <summary>
        /// Подача команды на закрытие с ЦСПА
        /// </summary>
        public bool nlCSPAClosePrev;
        /// <summary>
        /// Подача команды на остановку с ЦСПА
        /// </summary>
        public bool nlCSPAStopPrev;
        /// <summary>
        /// Подача команды на открытие с ЦСПА
        /// </summary>
        public bool nlCSPAOpenPrev;
        /// <summary>
        /// Подача команды на открытие по ТУ
        /// </summary>
        public bool nlTUOpenPrev;
        /// <summary>
        /// Подача команды на остановку по ТУ
        /// </summary>
        public bool nlTUStopPrev;
        /// <summary>
        /// Подача команды на закрытие по ТУ
        /// </summary>
        public bool nlTUClosePrev;
        /// <summary>
        /// Флаг запрета на открытие задвижки
        /// </summary>
        public bool nlSetNoOpenPrev;                        /* 0 - нет запрета на открытие задвижки, 1 - есть запрет на открытие задвижки */
        /// <summary>
        /// Флаг запрета на закрытие задвижки
        /// </summary>
        public bool nlSetNoClosePrev;                       /* 0 - нет запрета на закрытие задвижки, 1 - есть запрет на закрытие задвижки. */
    }
    /// <summary>
    /// Структура имитации
    /// </summary>
    public class ZdImitStorage
    {
        /// <summary>
        /// Состояние задвижки
        /// </summary>
        public ZdState State;
        /// <summary>
        /// Невыполнение команды на открытие ДЛЯ TM
        /// </summary>
        public bool OpenFail; /*Невыполнение команды на открытие ДЛЯ TM*/
        /// <summary>
        /// Невыполнение команды стоп ДЛЯ TM
        /// </summary>
        public bool CloseFail; /*Невыполнение команды стоп ДЛЯ TM*/
        /// <summary>
        /// Авария задвижки
        /// </summary>
        public bool Crash;
    }

    public partial class ProcUzd : ProcUzdIo
    {
        /// <summary>
        /// Внутренее состояние задвижки
        /// </summary>
        private ZdStorage zd = new ZdStorage();
        /// <summary>
        /// Обработка команд
        /// </summary>
        private ZdCommandsProcessing commands = new ZdCommandsProcessing();
        /// <summary>
        /// Имитация
        /// </summary>
        private ZdImitStorage zdImit = new ZdImitStorage();
        /// <summary>
        /// Внутреннее состояние сигналов нижнего уровня
        /// </summary>
        private ZdAbstractNu nuState;

        public ProcUzd()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(ProcUzdIo.messages));
            InternalTimers = new StArray<ITimer>(1, Enumerable.Range(1, 16).Select(i => new CpaLocalTimer()).ToArray());
        }

        public override void Execute()
        {

            var notEc = !(nu.KVO || nu.KVZ);
            
            if (cfg.SlYesEc)
            {
                notEc = !nu.EC && notEc;
            }

            /*инициализация*/

            /*обнуление флагов команд*/
            var stopCmdAccepted = false;
            var closeCmdAccepted = false;
            var openCmdAccepted = false;


            /* сглаживание сигналов */
            if ((nu.KVO != zd.SmoothedNu.KVO ||
                 nu.KVZ != zd.SmoothedNu.KVZ ||
                 nu.MPO != zd.SmoothedNu.MPO ||
                 nu.MPZ != zd.SmoothedNu.MPZ ||
                 nu.VMMO != zd.SmoothedNu.VMMO ||
                 nu.VMMZ != zd.SmoothedNu.VMMZ)
                && !zd.Smoothing)
            {
                InternalTimers[1].Start();
                zd.Smoothing = true; /* если есть отклонение "сырого" значения от "сглаженного"*/
            }

            if (zd.Smoothing)
            {
                if (!InternalTimers[1].IsStarted)
                {
                    zd.SmoothedNu.KVO = nu.KVO;
                    zd.SmoothedNu.KVZ = nu.KVZ;
                    zd.SmoothedNu.MPO = nu.MPO;
                    zd.SmoothedNu.MPZ = nu.MPZ;
                    zd.SmoothedNu.VMMO = nu.VMMO;
                    zd.SmoothedNu.VMMZ = nu.VMMZ;
                    zd.Smoothing = false; /* считать  "сглаженное значение" ТС равным текущему "сырому"*/
                }
            }

            if (zd.Smoothing && zd.SmoothedNu.VMMO)
            {
                zd.SmoothedNu.VmmoBlinked = true;
            }

            if (zd.Smoothing && zd.SmoothedNu.VMMZ)
            {
                zd.SmoothedNu.VmmzBlinked = true;
            }
            /* ----------------------------- АНАЛИЗ СОСТОЯНИЙ МОМЕНТНЫХ ВЫКЛЮЧАТЕЛЕЙ ------------------------------ */
            if (zd.Imit)
            {
                zd.VmmoPrev = false;
                zd.VmmzPrev = false;
                zd.MuftaPrev = false;
                zd.BurCrash = false;
            }
            else if (!cfg.SlBur)
            {
                /* Если не БУР */
                if (!zd.VmmoPrev && zd.SmoothedNu.VMMO)
                {
                    Messenger.Send(093); /*Сообщение : "СРАБОТАЛ МОМЕНТНЫЙ ВЫКЛЮЧАТЕЛЬ ОТКРЫТИЯ. АВАРИЯ" */
                    zd.VmmoPrev = true;
                }
                else if (!zd.Smoothing && !zd.VmmoPrev && zd.SmoothedNu.VmmoBlinked && zd.SmoothedNu.KVO)
                {
                    Messenger.Send(093); /*Сообщение : "СРАБОТАЛ МОМЕНТНЫЙ ВЫКЛЮЧАТЕЛЬ ОТКРЫТИЯ. АВАРИЯ" */
                    zd.VmmoPrev = true;
                }
                else if (zd.VmmoPrev && !zd.SmoothedNu.VMMO)
                {
                    Messenger.Send(0117); /*Сообщение : "СИГНАЛ РАБОТЫ МОМЕНТНОГО ВЫКЛЮЧАТЕЛЬ ОТКРЫТИЯ СНЯТ" */
                    zd.VmmoPrev = false;
                }

                if (!zd.VmmzPrev && zd.SmoothedNu.VMMZ)
                {
                    Messenger.Send(094); /*Сообщение : "СРАБОТАЛ МОМЕНТНЫЙ ВЫКЛЮЧАТЕЛЬ ЗАКРЫТИЯ. АВАРИЯ." */
                    zd.VmmzPrev = true;
                }
                else if (!zd.Smoothing && !zd.VmmzPrev && zd.SmoothedNu.VmmzBlinked && zd.SmoothedNu.KVZ)
                {
                    Messenger.Send(094); /*Сообщение : "СРАБОТАЛ МОМЕНТНЫЙ ВЫКЛЮЧАТЕЛЬ ЗАКРЫТИЯ. АВАРИЯ." */
                    zd.VmmzPrev = true;
                }
                else if (zd.VmmzPrev && !zd.SmoothedNu.VMMZ)
                {
                    Messenger.Send(0118); /*Сообщение : "СИГНАЛ РАБОТЫ МОМЕНТНОГО ВЫКЛЮЧАТЕЛЬ ЗАКРЫТИЯ СНЯТ" */
                    zd.VmmzPrev = false;
                }

                zd.BurCrash = false;
                zd.MuftaPrev = false;
            }
            else
            {
                /* А вот если БУР.. */
                if (!zd.MuftaPrev && nu.Mufta)
                {
                    Messenger.Send(082); /*Сообщение : "СРАБОТА МУФТА. АВАРИЯ" */
                    zd.MuftaPrev = nu.Mufta;
                    InternalTimers[1].Start();
                    zd.Smoothing = true;
                }
                else if (zd.MuftaPrev && !nu.Mufta)
                {
                    Messenger.Send(058); /*Сообщение : "СИГНАЛ СРАБОТКИ МУФТЫ СНЯТ" */
                    zd.MuftaPrev = false;
                }

                if (!zd.BurCrash && nu.ErrBUR)
                {
                    Messenger.Send(083); /*Сообщение : "АВРИЯ ПРИВОДА" */
                    zd.BurCrash = true;
                    InternalTimers[1].Start();
                    zd.Smoothing = true;
                }
                else if (zd.BurCrash && !nu.ErrBUR)
                {
                    Messenger.Send(059); /*Сообщение : "ПРИВОД ИСПРАВЕН" */
                    zd.BurCrash = false;
                }

                zd.VmmoPrev = false;
                zd.VmmzPrev = false;
            }
            /* ----------------------------- АНАЛИЗ СОСТОЯНИЙ МОМЕНТНЫХ ВЫКЛЮЧАТЕЛЕЙ ------------------------------ */

            if (!zd.Smoothing)
            {
                zd.SmoothedNu.VmmoBlinked = false;
                zd.SmoothedNu.VmmzBlinked = false;
            }

            /*инициализация ключа ДУ/МУ*/

            if (zd.DistKeyPrev != nu.DIST_KEY)
            {
                if (nu.DIST_KEY)
                {
                    Messenger.Send(045); /* Сообщение : "КЛЮЧ В РЕЖИМЕ УПРАВЛЕНИЯ ПО ДИСТАНЦИИ" */
                }
                else
                {
                    Messenger.Send(046); /* Сообщение : "КЛЮЧ В РЕЖИМЕ УПРАВЛЕНИЯ ПО МЕСТУ" */
                }

                zd.DistKeyPrev = nu.DIST_KEY;
            }


            if (zd.NeedCheckUnprompted)
            {
                if (nu.MPO && (!cfg.SlDist || nu.DIST_KEY))
                {
                    Messenger.Send(97);
                    state.UnpromptedOpen = true;
                }

                if (nu.MPZ && (!cfg.SlDist || nu.DIST_KEY))
                {
                    Messenger.Send(85);
                    state.UnpromptedClose = true;
                }

                state.Crash = state.Crash || state.UnpromptedClose || state.UnpromptedOpen;
                zd.NeedCheckUnprompted = false;
            }


            /* ------------------------------------------------------ ОБРАБОТКА КОМАНД ------------------------------------------------------ */
            /* управление из МДП */

            switch (Cmd)
            {
                case ZdCmd.open:

                    openCmdAccepted = true;
                    Messenger.Send(036); /* Сообщение : "КОМАНДА - ОТКРЫТЬ С АРМ" */
                    break;
                case ZdCmd.close:

                    closeCmdAccepted = true;
                    Messenger.Send(050); /* Сообщение : "КОМАНДА - ЗАКРЫТЬ С АРМ" */
                    break;
                case ZdCmd.stop:

                    stopCmdAccepted = true;
                    Messenger.Send(065); /* Сообщение : "КОМАНДА - СТОП C АРМ" */

                    break;
                case ZdCmd.setImit:

                    Messenger.Send(073); /* Сообщение : "КОМАНДА - УСТАНОВИТЬ РЕЖИМ ИМИТАЦИИ" */
                    if (state.openingSubstate != ZdMovementProcessing.None || state.closingSubstate != ZdMovementProcessing.None || nu.MPO || nu.MPZ)
                    {
                        Messenger.Send(
                            030); /* Сообщение : "КОМАНДА - УСТАНОВИТЬ РЕЖИМ ИМИТАЦИИ ОТКЛОНЕНА. ЗАДВИЖКА В ДВИЖЕНИИ" */
                    }
                    else
                    {
                        zd.Imit = true;
                        Messenger.Send(027); /* Сообщение : "РЕЖИМ ИМИТАЦИИ УСТАНОВЛЕН" */
                        zdImit.State = zd.State; /* состояние эмулятора по текущему состоянию задвижки */
                    }

                    break;
                case ZdCmd.dropImit:

                    Messenger.Send(074); /* Сообщение : "КОМАНДА - СНЯТЬ РЕЖИМ ИМИТАЦИИ" */
                    if (zdImit.State == ZdState.Opening || zdImit.State == ZdState.Closing)
                    {
                        Messenger.Send(029); /* Сообщение : "В ДВИЖЕНИИ. СНЯТИЕ РЕЖИМА ИМИТАЦИИ НЕВОЗМОЖНО" */
                    }
                    else if (!(nu.KVZ || nu.KVO))
                    {
                        Messenger.Send(032); /* Сообщение : "ОБЕСТОЧЕНА. СНЯТИЕ РЕЖИМА ИМИТАЦИИ НЕВОЗМОЖНО" */
                    }
                    else
                    {
                        zd.Imit = false;
                        Messenger.Send(028); /* Сообщение : "РЕЖИМ ИМИТАЦИИ СНЯТ" */
                        if (nu.MPO && nu.MPZ)
                        {
                            ;
                        }
                        else if (nu.MPO)
                        {
                            zd.State = ZdState.Closed;
                        }
                        else if (nu.MPZ)
                        {
                            zd.State = ZdState.Opened;
                        }
                        else if (nu.KVO && nu.KVZ)
                        {
                            zd.State = ZdState.Middle;
                            Messenger.Send(012); /*Сообщение : "ПРОМЕЖУТОЧНОЕ СОСТОЯНИЕ" */
                        }
                        else if (nu.KVO)
                        {
                            zd.State = ZdState.Closed;
                            Messenger.Send(022); /*Сообщение : "ЗАКРЫТА" */
                        }
                        else if (nu.KVZ)
                        {
                            zd.State = ZdState.Opened;
                            Messenger.Send(007); /*Сообщение : "ОТКРЫТА" */
                        }
                    }

                    break;
                case ZdCmd.deblock:

                    Messenger.Send(077); /* Сообщение : "КОМАНДА - ДЕБЛОКИРОВАТЬ НЕИСПРАВНОСТЬ" */
                    if (zd.VmmoPrev || zd.VmmzPrev || zd.MuftaPrev || zd.BurCrash ||
                        state.ErrMpo || state.ErrMpz || state.UnpromptedOpen && nu.MPO || state.UnpromptedClose && nu.MPZ)
                    {
                        Messenger.Send(078); /* "КОМАНДА - ДЕБЛОКИРОВКА НЕВОЗМОЖНА. АВАРИЙНЫЙ СИГНАЛ НЕ СНЯТ*/
                    }
                    else
                    {
                        Messenger.Send(079); /* Сообщение : "НЕИСПРАВНОСТЬ ДЕБЛОКИРОВАНА" */
                        state.Crash = false;
                        zdImit.Crash = false;
                    }

                    state.OpenFail = false;
                    state.CloseFail = false;
                    state.StopFail = false;

                    zd.NeedCheckUnprompted = state.UnpromptedOpen || state.UnpromptedClose;

                    state.UnpromptedOpen = false;
                    state.UnpromptedClose = false;

                    break;
            }

            /* управление по ТМ */
            if (nlTUStop && !commands.nlTUStopPrev)
            {
                Messenger.Send(066); /* Сообщение : "КОМАНДА - СТОП ТМ" */
                if (!TmModeDist)
                {
                    Messenger.Send(072); /* Сообщение : "КОМАНДА ОТКЛОНЕНА - НПС В МЕСТНОМ УПРАВЛЕНИИ" */
                }
                else
                {
                    stopCmdAccepted = true;
                }
            }

            if (nlTUClose && !commands.nlTUClosePrev)
            {
                Messenger.Send(051); /* Сообщение : "КОМАНДА - ЗАКРЫТЬ ПО ТМ" */
                if (!TmModeDist)
                {
                    Messenger.Send(072); /* Сообщение : "КОМАНДА ОТКЛОНЕНА - НПС В МЕСТНОМ УПРАВЛЕНИИ" */
                }
                else
                {
                    closeCmdAccepted = true;
                }
            }

            if (nlTUOpen && !commands.nlTUOpenPrev)
            {
                Messenger.Send(037); /* Сообщение : "КОМАНДА ОТКРЫТЬ ПО ТМ" */
                if (!TmModeDist)
                {
                    Messenger.Send(072); /* Сообщение : "КОМАНДА ОТКЛОНЕНА - НПС В МЕСТНОМ УПРАВЛЕНИИ" */
                }
                else
                {
                    openCmdAccepted = true;
                }
            }


            commands.nlTUOpenPrev = nlTUOpen;
            commands.nlTUStopPrev = nlTUStop;
            commands.nlTUClosePrev = nlTUClose;

            if (nlSetNoOpen ^ commands.nlSetNoOpenPrev)
            {
                if (nlSetNoOpen)
                {
                    Messenger.Send(014); /* Сообщение : "БЛОКИРОВКА ОТКРЫТИЯ УСТАНОВЛЕНА" */
                }
                else
                {
                    Messenger.Send(080); /* Сообщение : "БЛОКИРОВКА ОТКРЫТИЯ СНЯТА" */
                }
            }

            if (nlSetNoClose ^ commands.nlSetNoClosePrev)
            {
                if (nlSetNoClose)
                {
                    Messenger.Send(015); /* Сообщение : "БЛОКИРОВКА ЗАКРЫТИЯ УСТАНОВЛЕНА" */
                }
                else
                {
                    Messenger.Send(081); /* Сообщение : "БЛОКИРОВКА ЗАКРЫТИЯ СНЯТА" */
                }
            }

            commands.nlSetNoOpenPrev = nlSetNoOpen;
            commands.nlSetNoClosePrev = nlSetNoClose;

            var needOpen = false;
            var needClose = false;
            var needStop = false;

            /*СТОП автоматически / СТОП от ЦСПА*/
            if (nlStop || nlCSPAStop)
            {

                if (nlStop && !commands.nlStopPrev)
                {
                    stopCmdAccepted = true;
                    Messenger.Send(064); /* Сообщение : "КОМАНДА - СТОП АВТОМАТИЧЕСКИ" */
                }

                if (nlCSPAStop && !commands.nlCSPAStopPrev)
                {
                    stopCmdAccepted = true;
                    Messenger.Send(060); /* Сообщение : "КОМАНДА - СТОП ОТ ЦСПА" */
                }

                if (!(nlClose || nlOpen) && // нет команд открытия/закрытия И
                    (!cfg.SlDist || nu.DIST_KEY || zd.Imit) && // в дистанции или в имитации И
                    (nu.MPO || nu.MPZ || zd.Imit && zd.State == ZdState.Opening ||
                        zd.Imit && zd.State == ZdState.Closing))
                {
                    // есть пускатели или двигаемся в имитации
                    if (nlStop && commands.nlStopPrev)
                    {
                        stopCmdAccepted = true;
                        Messenger.Send(064); /* Сообщение : "КОМАНДА - СТОП АВТОМАТИЧЕСКИ" */
                    }

                    if (nlCSPAStop && commands.nlCSPAStopPrev)
                    {
                        stopCmdAccepted = true;
                        Messenger.Send(060); /* Сообщение : "КОМАНДА - СТОП ОТ ЦСПА" */
                    }
                }
            }

            commands.nlStopPrev = nlStop;
            commands.nlCSPAStopPrev = nlCSPAStop;


            /*ЗАКРЫТЬ автоматически / ЗАКРЫТЬ от ЦСПА*/
            if (nlClose || nlCSPAClose && !nlCSPAOpen && !nlCSPAStop)
            {
                needClose = true;
                if (zd.State != ZdState.Closed && state.closingSubstate == ZdMovementProcessing.None || state.openingSubstate != ZdMovementProcessing.None)
                {
                    if (nlClose && !commands.nlClosePrev)
                    {
                        
                        closeCmdAccepted = true;
                        Messenger.Send(049); /* Сообщение : "КОМАНДА - ЗАКРЫТЬ АВТОМАТИЧЕСКИ" */
                    }

                    if (nlCSPAClose && !commands.nlCSPAClosePrev)
                    {
                        closeCmdAccepted = true;
                        Messenger.Send(057); /* Сообщение : "КОМАНДА - ЗАКРЫТЬ ОТ ЦСПА" */
                    }
                }
            }

            commands.nlClosePrev = nlClose;
            commands.nlCSPAClosePrev = nlCSPAClose;


            /*ОТКРЫТЬ автоматически / ОТКРЫТЬ от ЦСПА*/
            if (nlOpen || nlCSPAOpen && !nlCSPAClose && !nlCSPAStop)
            {
                needOpen = true;
                if (zd.State != ZdState.Opened && state.openingSubstate == ZdMovementProcessing.None || state.closingSubstate != ZdMovementProcessing.None)
                {
                    if (nlOpen && !commands.nlOpenPrev)
                    {
                        openCmdAccepted = true;
                        Messenger.Send(035); /* Сообщение : "КОМАНДА - ОТКРЫТЬ АВТОМАТИЧЕСКИ" */
                    }

                    if (nlCSPAOpen && !commands.nlCSPAOpenPrev)
                    {
                        openCmdAccepted = true;
                        Messenger.Send(043); /* Сообщение : "КОМАНДА - ОТКРЫТЬ ОТ ЦСПА" */
                    }
                }
            }

            commands.nlOpenPrev = nlOpen;
            commands.nlCSPAOpenPrev = nlCSPAOpen;

            /*время, через которое сбрасывается флаг управления с БРУ*/
            if (nu.nlBRUStop && !commands.nlBRUStopPrev)
            {
                commands.nlBRUStopPrev = nu.nlBRUStop;
            }

            if (!nu.nlBRUStop && commands.nlBRUStopPrev)
            {
                if (!InternalTimers[10].IsStarted && !InternalTimers[10].IsQ)
                {
                    InternalTimers[10].Start();
                }
                if (InternalTimers[10].IsQ)
                {
                    commands.nlBRUStopPrev = false;
                }
            }
            

            if (nu.nlBRUClose && !commands.nlBRUClosePrev)
            {
                commands.nlBRUClosePrev = nu.nlBRUClose;
            }
            if (!nu.nlBRUClose && commands.nlBRUClosePrev)
            {
                if (!InternalTimers[10].IsStarted && !InternalTimers[10].IsQ)
                {
                    InternalTimers[10].Start();
                }
                if (InternalTimers[10].IsQ)
                {
                    commands.nlBRUClosePrev = false;
                }
            }
            
            

            /*контроль напряжения схемы управления*/
            var wait_stop = !(state.stoppingSubstate == ZdStopProcessing.None || state.stoppingSubstate == ZdStopProcessing.Fail 
                                || state.stoppingSubstate == ZdStopProcessing.WaitingClosingMestStop || state.stoppingSubstate == ZdStopProcessing.WaitingOpeningMestStop) && !zd.Imit;// || InternalTimers[6].IsStarted;
            var movement_processing = InternalTimers[2].IsStarted || InternalTimers[3].IsStarted || InternalTimers[4].IsStarted || state.stoppingSubstate == ZdStopProcessing.Fail;
            if (notEc && !zd.NoEcPrev && !wait_stop)
            {
                if (zd.Imit || !nu.ZD_EC_KTP)
                {
                    InternalTimers[6].Stop();
                    Messenger.Send(0104); /* Сообщение : "НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ" */
                    zd.NoEcPrev = notEc;
                }
                else if (InternalTimers[6].IsStarted)
                {

                }
                else if (InternalTimers[6].IsQ)
                {
                    zd.NoEcPrev = notEc;
                }
                else if (!movement_processing && !zd.Smoothing)
                {
                    InternalTimers[6].Stop();
                    Messenger.Send(0104); /* Сообщение : "НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ" */
                    zd.NoEcPrev = notEc;
                }
                else if (movement_processing && !InternalTimers[6].IsStarted)
                {
                    InternalTimers[6].Start();
                }
            }

            bool StopButtonPressed = commands.nlBRUStopPrev;
            if (!notEc)
            {
                if (InternalTimers[6].IsStarted && !zd.Smoothing)
                {
                    StopButtonPressed = true;
                    if (commands.nlBRUStopPrev)
                    {
                        Messenger.Send(061); /* Сообщение : "ВЫПОЛНЕНА КОМАНДА СТОП С БРУ" */
                    }
                    else
                    {
                        Messenger.Send(069); /* Сообщение : "ВЫПОЛНЕНА КОМАНДА СТОП ПО МЕСТУ" */
                    }
                    InternalTimers[6].Stop();
                }
                else if (zd.NoEcPrev)
                {
                    Messenger.Send(0105); /* Сообщение : "ЕСТЬ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ" */
                }
                zd.NoEcPrev = notEc;
            }


            Open = false;
            Close = false;
            Stop = false;
            StopOpen = false;
            StopClose = false;


            if (!zd.Imit)
            {
                nuState = new ZdAbstractNu();

                nuState.OpenSwitchOn = zd.SmoothedNu.MPO;
                nuState.CloseSwitchOn = zd.SmoothedNu.MPZ;
                nuState.NotOpened = zd.SmoothedNu.KVO;
                nuState.NotClosed = zd.SmoothedNu.KVZ;
                nuState.AllowDistControl = !cfg.SlDist || nu.DIST_KEY;
                nuState.AllowMestControl = !cfg.SlDist || !nu.DIST_KEY;
                nuState.NoEc = !nu.KVO && !nu.KVZ;
                nuState.HasCrashSignals = zd.BurCrash || zd.MuftaPrev || zd.VmmoPrev || zd.VmmzPrev;
                nuState.NoEcSsh = !nu.ZD_EC_KTP;
                nuState.StopButtonPressed = StopButtonPressed;
                nuState.CloseButtonPressed = commands.nlBRUClosePrev;
                nuState.EcFall = zd.NoEcPrev;

                /*сброс флага ожидания восстановления СШ*/
                if (!nuState.NoEcSsh)
                {
                    state.WaitSsh = false;
                }

                if (state.state != ZdStateProcessing.CommandExecution && zd.State == ZdState.Opened)
                {
                    if (InternalTimers[5].IsStarted && zd.VmmoPrev)
                    {
                        Messenger.Send(101);/* ПОПЫТКА ВКЛЮЧЕНИЯ МПО ИЗ ЩСУ. АВАРИЯ */
                        Messenger.Send(007); /* Сообщение : "ОТКРЫТА" */
                        InternalTimers[5].Stop();
                        state.ErrMpo = true;
                    }

                    if (nuState.OpenSwitchOn && !nuState.CloseSwitchOn)
                    {
                        if (!state.ErrMpo)
                        {
                            if (InternalTimers[5].IsQ)
                            {
                                state.ErrMpo = true;
                                state.Crash = true;
                                Messenger.Send(100); /* Сообщение : "ЦЕПИ КОНТРОЛЯ МПО НЕИСПРАВНЫ. АВАРИЯ" */
                                Messenger.Send(007); /* Сообщение : "ОТКРЫТА" */
                            }
                            else if (!InternalTimers[5].IsStarted)
                            {
                                Messenger.Send(120); /* Сообщение : "ПОЛУЧЕН СИГНАЛ «МПО ВКЛЮЧЕН»" */
                                InternalTimers[5].Start();
                            }
                        }

                    }
                    else if (InternalTimers[5].IsStarted)
                    {
                        if (!nuState.OpenSwitchOn)
                        {
                            Messenger.Send(116); /* Сообщение : "ПОЛУЧЕН СИГНАЛ «МПО ОТКЛЮЧЕН»" */
                        }
                        InternalTimers[5].Stop();
                    }
                }

                if (state.state != ZdStateProcessing.CommandExecution && zd.State == ZdState.Closed)
                {
                    if (InternalTimers[5].IsStarted && zd.VmmzPrev)
                    {
                        Messenger.Send(099);/* ПОПЫТКА ВКЛЮЧЕНИЯ МПЗ ИЗ ЩСУ. АВАРИЯ */
                        Messenger.Send(022); /* Сообщение : "ЗАКРЫТА" */
                        InternalTimers[5].Stop();
                        state.ErrMpz = true;
                    }

                    if (nuState.CloseSwitchOn && !nuState.OpenSwitchOn)
                    {
                        if (!state.ErrMpz)
                        {
                            if (InternalTimers[5].IsQ)
                            {
                                state.ErrMpz = true;
                                state.Crash = true;
                                Messenger.Send(098); /*Сообщение : "ЦЕПИ КОНТРОЛЯ МПЗ НЕИСПРАВНЫ. АВАРИЯ" */
                                Messenger.Send(022); /*Сообщение : "ЗАКРЫТА" */

                            }
                            else if (!InternalTimers[5].IsStarted)
                            {
                                Messenger.Send(119); /* Сообщение : "ПОЛУЧЕН СИГНАЛ «МПЗ ВКЛЮЧЕН»" */
                                InternalTimers[5].Start();
                            }
                        }

                    }
                    else if (InternalTimers[5].IsStarted)
                    {
                        if (!nuState.CloseSwitchOn)
                        {
                            Messenger.Send(115); /* Сообщение : "ПОЛУЧЕН СИГНАЛ «МПЗ ОТКЛЮЧЕН»" */
                        }
                        InternalTimers[5].Stop();
                    }
                }

                if (state.ErrMpo && !nuState.OpenSwitchOn)
                {
                    Messenger.Send(116); /* Сообщение : "ПОЛУЧЕН СИГНАЛ «МПО ОТКЛЮЧЕН»" */
                    state.ErrMpo = false;
                }

                if (state.ErrMpz && !nuState.CloseSwitchOn)
                {
                    Messenger.Send(115); /* Сообщение : "ПОЛУЧЕН СИГНАЛ «МПЗ ОТКЛЮЧЕН»" */
                    state.ErrMpz = false;
                }

                /* ОБРАБОТКА ТРЕБОВАНИЯ ОТКРЫТИЯ/ЗАКРЫТИЯ */
                if (needClose)
                {
                    if (zd.State != ZdState.Closed && state.closingSubstate == ZdMovementProcessing.None || state.openingSubstate != ZdMovementProcessing.None)
                    {
                        if (closeCmdAccepted)
                        {
                            
                        }
                        else if (state.closingSubstate != ZdMovementProcessing.None)
                        {
                            
                        }
                        else if (state.Crash)
                        {
                            
                        }
                        else if (nuState.NoEc)
                        {
                            
                        }
                        else if (state.WaitSsh)
                        {
                            
                        }
                        else if (!nuState.AllowDistControl)
                        {
                            
                        }
                        else if (nlSetNoClose || nlOpen || nlStop)
                        {
                            
                        }
                        else if (zd.State == ZdState.None)
                        {
                            
                        }
                        else
                        {
                            closeCmdAccepted = true;
                            Messenger.Send(049); /* Сообщение : "КОМАНДА - ЗАКРЫТЬ АВТОМАТИЧЕСКИ" */
                        }
                    }
                }

                if (needOpen)
                {
                    if (zd.State != ZdState.Opened && state.openingSubstate == ZdMovementProcessing.None || state.closingSubstate != ZdMovementProcessing.None)
                    {
                        if (openCmdAccepted)
                        {

                        }
                        else if (state.openingSubstate != ZdMovementProcessing.None)
                        {
                            
                        }
                        else if (state.Crash)
                        {
                            
                        }
                        else if (nuState.NoEc)
                        {
                            
                        }
                        else if (state.WaitSsh)
                        {
                            
                        }
                        else if (!nuState.AllowDistControl)
                        {
                            
                        }
                        else if (nlSetNoOpen || nlClose || nlStop)
                        {
                            
                        }
                        else if (zd.State == ZdState.None)
                        {
                            
                        }
                        else
                        {
                            // нет команд стоп или закрыть и нет блокировки открытия
                            openCmdAccepted = true;
                            Messenger.Send(035); /* Сообщение : "КОМАНДА - ОТКРЫТЬ АВТОМАТИЧЕСКИ" */
                        }
                    }
                }

                /* ОБРАБОТКА ПРИНЯТЫХ КОМАНД */
                if (closeCmdAccepted)
                {
                    closeCmdAccepted = false;
                    {
                        if (state.closingSubstate != ZdMovementProcessing.None)
                        {
                            Messenger.Send(018); /* Сообщение : "ЗАКРЫВАЕТСЯ. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ" */
                        }
                        else if (zd.State == ZdState.Closed && state.openingSubstate == ZdMovementProcessing.None)
                        {
                            Messenger.Send(025); /* Сообщение : "ЗАКРЫТА. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ" */
                        }
                        else if (state.Crash)
                        {
                            Messenger.Send(019); /* Сообщение : "ЗАКРЫТИЕ НЕВОЗМОЖНО. АВАРИЯ ЗАДВИЖКИ" */
                        }
                        else if (nuState.NoEc)
                        {
                            Messenger.Send(020); /* Сообщение : "ЗАКРЫТИЕ НЕВОЗМОЖНО. НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ" */
                        }
                        else if (state.WaitSsh)
                        {
                            Messenger.Send(020); /* Сообщение : !!! "ЗАКРЫТИЕ НЕВОЗМОЖНО. НЕТ НАПРЯЖЕНИЯ НА СШ ЩСУ" */
                        }
                        else if (!nuState.AllowDistControl)
                        {
                            Messenger.Send(055); /* Сообщение : "КОМАНДА - ЗАКРЫТИЕ НЕВОЗМОЖНО. КЛЮЧ В РЕЖИМЕ УПРАВЛЕНИЯ ПО МЕСТУ" */
                        }
                        else if (nlSetNoClose || nlOpen || nlStop)
                        {
                            Messenger.Send(056); /* Сообщение : "БЛОКИРОВКА ЗАКРЫТИЯ" */
                        }
                        else if (zd.State == ZdState.None)
                        {
                            Messenger.Send(054); /* Сообщение : "КОМАНДА - ЗАКРЫТЬ ОТКЛОНЕНА. ЗАДВИЖКА В НЕОПРЕДЕЛЕННОМ СОСТОЯНИИ" */
                        }
                        else
                        {
                            closeCmdAccepted = true;
                        }
                    }
                }
                else if (openCmdAccepted)
                {
                    openCmdAccepted = false;
                    if (state.openingSubstate != ZdMovementProcessing.None)
                    {
                        Messenger.Send(003); /* Сообщение : "ОТКРЫВАЕТСЯ. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ" */
                    }
                    else if (zd.State == ZdState.Opened && state.closingSubstate == ZdMovementProcessing.None)
                    {
                        Messenger.Send(010); /* Сообщение : "ОТКРЫТА. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ" */
                    }
                    else if (state.Crash)
                    {
                        Messenger.Send(004); /* Сообщение : "ОТКРЫТИЕ НЕВОЗМОЖНО. АВАРИЯ ЗАДВИЖКИ" */
                    }
                    else if (nuState.NoEc)
                    {
                        Messenger.Send(005); /* Сообщение : "ОТКРЫТИЕ НЕВОЗМОЖНО. НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ" */
                    }
                    else if (state.WaitSsh)
                    {
                        Messenger.Send(005); /* Сообщение :!!! "ОТКРЫТИЕ НЕВОЗМОЖНО. НЕТ НАПРЯЖЕНИЯ НА СШ ЩСУ" */
                    }
                    else if (!nuState.AllowDistControl)
                    {
                        Messenger.Send(041); /* Сообщение : "ОТКРЫТИЕ НЕВОЗМОЖНО. КЛЮЧ В РЕЖИМЕ УПРАВЛЕНИЯ ПО МЕСТУ" */
                    }
                    else if (nlSetNoOpen || nlClose || nlStop)
                    {
                        Messenger.Send(042); /* Сообщение : "БЛОКИРОВКА ОТКРЫТИЯ" */
                    }
                    else if (zd.State == ZdState.None)
                    {
                        Messenger.Send(040); /* Сообщение : "КОМАНДА - ОТКРЫТЬ ОТКЛОНЕНА. ЗАДВИЖКА В НЕОПРЕДЕЛЕННОМ СОСТОЯНИИ" */
                    }
                    else
                    {
                        openCmdAccepted = true;
                    }
                }
                else if (stopCmdAccepted)
                {
                    stopCmdAccepted = false;
                    if (state.closingSubstate == ZdMovementProcessing.None && state.openingSubstate == ZdMovementProcessing.None &&
                        state.stoppingSubstate != ZdStopProcessing.Fail)
                    {
                        Messenger.Send(122); /* Сообщение : "НЕ ДВИЖЕТСЯ. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ" */
                    }
                    else if (!nuState.AllowDistControl)
                    {
                        Messenger.Send(067); /* Сообщение : "КОМАНДА - СТОП ОТКЛОНЕНА. КЛЮЧ В РЕЖИМЕ УПРАВЛЕНИЯ ПО МЕСТУ" */
                    }
                    else if (nlClose || nlOpen)
                    {
                        Messenger.Send(071); /* Сообщение : "БЛОКИРОВКА КОМАНДЫ СТОП" */
                    }
                    else
                    {
                        stopCmdAccepted = true;
                    }
                }
                /* ------------------------------------------------------ ОБРАБОТКА КОМАНД ------------------------------------------------------ */

                StateProcessing(stopCmdAccepted, closeCmdAccepted, openCmdAccepted, nuState);

                /* вывод команд на реле */
                Open = state.openingSubstate == ZdMovementProcessing.SwitchEnabling;
                Close = state.closingSubstate == ZdMovementProcessing.SwitchEnabling;

                if (cfg.Sl2Stop)
                {
                    if (state.UnpromptedOpen && !zd.NeedCheckUnprompted || nlSetNoOpen || state.stoppingSubstate == ZdStopProcessing.OpenStopping)
                    {
                        StopOpen = true;
                    }

                    if (state.UnpromptedClose && !zd.NeedCheckUnprompted || nlSetNoClose || state.stoppingSubstate == ZdStopProcessing.CloseStopping)
                    {
                        StopClose = true;
                    }
                }
                else
                {
                    if ((state.UnpromptedOpen || state.UnpromptedClose) && !zd.NeedCheckUnprompted || state.stoppingSubstate == ZdStopProcessing.Stopping)
                    {
                        Stop = true;
                    }
                }
            }
            else /* -------------------------------------- РЕЖИМ ИМИТАЦИИ ЗАДВИЖКИ ------------------------------------- */
            {
                if (needClose)
                {
                    if (zdImit.State != ZdState.Closed && zdImit.State != ZdState.Closing)
                    {
                        if (closeCmdAccepted)
                        {

                        }
                        else if (nlSetNoClose || nlOpen || nlStop)
                        {
                            
                        }
                        else
                        {
                            closeCmdAccepted = true;
                            Messenger.Send(049); /* Сообщение : "КОМАНДА - ЗАКРЫТЬ АВТОМАТИЧЕСКИ" */
                        }
                    }
                }

                if (needOpen)
                {
                    if (zdImit.State != ZdState.Opened && zdImit.State != ZdState.Opening)
                    {
                        if (openCmdAccepted)
                        {

                        }
                        else if (nlSetNoOpen || nlClose || nlStop)
                        {

                        }
                        else
                        {
                            openCmdAccepted = true;
                            Messenger.Send(035); /* Сообщение : "КОМАНДА - ОТКРЫТЬ АВТОМАТИЧЕСКИ" */
                        }
                    }
                }

                if (closeCmdAccepted)
                {
                    closeCmdAccepted = false;
                    if (zdImit.State == ZdState.Closing)
                    {
                        Messenger.Send(018); /* Сообщение : "ЗАКРЫВАЕТСЯ. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ" */
                    }
                    else if (zdImit.State == ZdState.Closed)
                    {
                        Messenger.Send(025); /* Сообщение : "ЗАКРЫТА. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ" */
                    }
                    else if (nlSetNoClose || nlOpen || nlStop)
                    {
                        Messenger.Send(056); /* Сообщение : "БЛОКИРОВКА ЗАКРЫТИЯ" */
                    }
                    else
                    {
                        closeCmdAccepted = true;
                    }
                }
                else if (openCmdAccepted)
                {
                    openCmdAccepted = false;
                    if (zdImit.State == ZdState.Opening)
                    {
                        Messenger.Send(003); /* Сообщение : "ОТКРЫВАЕТСЯ. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ" */
                    }
                    else if (zdImit.State == ZdState.Opened)
                    {
                        Messenger.Send(010); /* Сообщение : "ОТКРЫТА. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ" */
                    }
                    else if (nlSetNoOpen || nlClose || nlStop)
                    {
                        Messenger.Send(042); /* Сообщение : "БЛОКИРОВКА ОТКРЫТИЯ" */
                    }
                    else
                    {
                        openCmdAccepted = true;
                    }
                }
                else if (stopCmdAccepted)
                {
                    stopCmdAccepted = false;
                    if (nlClose || nlOpen)
                    {
                        Messenger.Send(071); /* Сообщение : "БЛОКИРОВКА КОМАНДЫ СТОП" */
                    }
                    else if (zdImit.State == ZdState.Opened || zdImit.State == ZdState.Middle || zdImit.State == ZdState.Closed)
                    {
                        Messenger.Send(122); /* Сообщение : "НЕ ДВИЖЕТСЯ. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ" */
                    }
                    else
                    {
                        stopCmdAccepted = true;
                    }
                }

                switch (zdImit.State)
                {
                    case ZdState.Opening:
                        /* ОТКРЫВАЕТСЯ*/
                        if (stopCmdAccepted)
                        {
                            InternalTimers[7].Stop();
                            InternalTimers[4].Stop();
                            zdImit.State = ZdState.Middle;
                            Messenger.Send(013); /* Сообщение : "ПРОМЕЖУТОЧНОЕ. РЕЖИМ ИМИТАЦИИ" */
                        }
                        else if (closeCmdAccepted)
                        {
                            zdImit.State = ZdState.Closing;
                            InternalTimers[7].Start();
                            InternalTimers[4].Start();
                            Messenger.Send(064); /* Сообщение : "КОМАНДА - СТОП АВТОМАТИЧЕСКИ" */
                            Messenger.Send(013); /* Сообщение : "ПРОМЕЖУТОЧНОЕ. РЕЖИМ ИМИТАЦИИ" */
                            Messenger.Send(049); /* Сообщение : "КОМАНДА - ЗАКРЫТЬ АВТОМАТИЧЕСКИ" */
                            Messenger.Send(017); /* Сообщение : "ЗАКРЫВАЕТСЯ. В РЕЖИМЕ ИМИТАЦИИ" */

                        }
                        else if (!InternalTimers[7].IsStarted)
                        {
                            zdImit.State = ZdState.Opened;
                            Messenger.Send(008); /* Сообщение : "ОТКРЫТА. РЕЖИМ ИМИТАЦИИ" */
                            InternalTimers[4].Stop();
                        }
                        else if (!InternalTimers[4].IsStarted)
                        {
                            zdImit.OpenFail = true;
                            Messenger.Send(092); /*Сообщение : "НЕ ОТКРЫЛАСЬ. АВАРИЯ" */
                            zdImit.Crash = true;
                            InternalTimers[7].Stop();
                        }

                        break;
                    case ZdState.Opened:
                        /* ОТКРЫТА*/
                        if (closeCmdAccepted)
                        {
                            zdImit.State = ZdState.Closing;
                            InternalTimers[7].Start();
                            InternalTimers[4].Start();
                        }

                        break;
                    case ZdState.Middle:
                        /* ПРОМЕЖУТОЧНОЕ*/
                        if (closeCmdAccepted)
                        {
                            zdImit.State = ZdState.Closing;
                            InternalTimers[7].Start();
                            InternalTimers[4].Start();
                            Messenger.Send(017); /*Сообщение : "ЗАКРЫВАЕТСЯ. В РЕЖИМЕ ИМИТАЦИИ" */
                        }
                        else if (openCmdAccepted)
                        {
                            zdImit.State = ZdState.Opening;
                            InternalTimers[7].Start();
                            InternalTimers[4].Start();
                            Messenger.Send(002); /* Сообщение : "ОТКРЫВАЕТСЯ В РЕЖИМЕ ИМИТАЦИИ" */
                        }

                        break;
                    case ZdState.Closing:
                        /* ЗАКРЫВАЕТСЯ*/
                        if (stopCmdAccepted)
                        {
                            InternalTimers[7].Stop();
                            InternalTimers[4].Stop();
                            zdImit.State = ZdState.Middle;
                            Messenger.Send(013); /* Сообщение : "ПРОМЕЖУТОЧНОЕ. РЕЖИМ ИМИТАЦИИ" */
                        }
                        else if (openCmdAccepted)
                        {
                            zdImit.State = ZdState.Opening;
                            InternalTimers[7].Start();
                            InternalTimers[4].Start();
                            Messenger.Send(064); /* Сообщение : "КОМАНДА - СТОП АВТОМАТИЧЕСКИ" */
                            Messenger.Send(013); /* Сообщение : "ПРОМЕЖУТОЧНОЕ. РЕЖИМ ИМИТАЦИИ" */
                            Messenger.Send(035); /* Сообщение : "КОМАНДА - ОТКРЫТЬ АВТОМАТИЧЕСКИ" */
                            Messenger.Send(002); /* Сообщение : "ОТКРЫВАЕТСЯ В РЕЖИМЕ ИМИТАЦИИ" */

                        }
                        else if (!InternalTimers[7].IsStarted)
                        {
                            zdImit.State = ZdState.Closed;
                            Messenger.Send(023); /* Сообщение : "ЗАКРЫТА. РЕЖИМ ИМИТАЦИИ" */
                            InternalTimers[4].Stop();
                        }
                        else if (!InternalTimers[4].IsStarted)
                        {
                            zdImit.CloseFail = true;
                            Messenger.Send(090); /*Сообщение : "НЕ ЗАКРЫЛАСЬ. АВАРИЯ" */
                            zdImit.Crash = true;
                            InternalTimers[7].Stop();
                        }

                        break;
                    case ZdState.Closed:
                        /* ЗАКРЫТА*/
                        if (openCmdAccepted)
                        {
                            zdImit.State = ZdState.Opening;
                            InternalTimers[7].Start();
                            InternalTimers[4].Start();
                            Messenger.Send(002); /* Сообщение : "ОТКРЫВАЕТСЯ В РЕЖИМЕ ИМИТАЦИИ" */
                        }

                        break;
                    default:
                    {
                        zdImit.State = ZdState.Middle;
                        break;
                    }
                }
            }
            /* -------------------------------------- РЕЖИМ ИМИТАЦИИ ЗАДВИЖКИ ------------------------------------- */



            /* ----------------------------------АНАЛИЗ ЦЕПЕЙ УПРАВЛЕНИЯ ЗАДВИЖКИ --------------------------------- */
            if (zd.Imit)
            {
                zd.CorrCo = true;
                zd.CorrCz = true;
                InternalTimers[11].Stop();
                InternalTimers[12].Stop();
            }
            else
            {
                if (!cfg.SlCo)
                {
                    zd.CorrCo = true; /*задвижка без контроля ЦО*/
                }
                else
                {
                    if (nu.CorrCO)
                    {
                        /*есть сигнал ЦО*/
                        InternalTimers[11].Stop();
                        if (!zd.CorrCo)
                        {
                            zd.CorrCo = true;
                            Messenger.Send(108); /* Сообщение : "ЦЕПЬ ОТКРЫТИЯ ИСПРАВНА" */
                        }

                        /*задвижка закрыта или в промежуточном положении*/
                    }
                    else if (zd.CorrCo && nu.KVO && !Open)//TODO
                    {
                        if (InternalTimers[11].IsQ)
                        {
                            zd.CorrCo = false;
                            Messenger.Send(107); /* Сообщение : "НЕИСПРАВНОСТЬ ЦЕПИ ОТКРЫТИЯ" */
                        }
                        else if (!InternalTimers[11].IsStarted)
                        {
                            InternalTimers[11].Start();
                        }
                    }
                    else
                    {
                        InternalTimers[11].Stop();
                    }

                    /*задвижка открыта, ЦО - исправна*/
                    if (zd.State == ZdState.Opened)
                    {
                        zd.CorrCo = true;
                    }
                }

                if (!cfg.SlCz)
                {
                    zd.CorrCz = true; /*задвижка без контроля ЦЗ*/
                }
                else
                {
                    if (nu.CorrCZ)
                    {
                        /*есть сигнал ЦЗ*/
                        InternalTimers[12].Stop();
                        if (!zd.CorrCz)
                        {
                            zd.CorrCz = true;
                            Messenger.Send(110); /* Сообщение : "ЦЕПЬ ЗАКРЫТИЯ ИСПРАВНА" */
                        }

                        /*задвижка открыта или в промежуточном положении*/
                    }
                    else if (zd.CorrCz && nu.KVZ && !Close)
                    {
                        if (InternalTimers[12].IsQ)
                        {
                            zd.CorrCz = false;
                            Messenger.Send(109); /* Сообщение : "НЕИСПРАВНОСТЬ ЦЕПИ ЗАКРЫТИЯ" */
                        }
                        else if (!InternalTimers[12].IsStarted)
                        {
                            InternalTimers[12].Start();
                        }
                    }
                    else
                    {
                        InternalTimers[12].Stop();
                    }

                    /*задвижка закрыта, ЦЗ - исправна*/
                    if (zd.State == ZdState.Closed)
                    {
                        zd.CorrCz = true;
                    }
                }
            }
            /* ----------------------------------АНАЛИЗ ЦЕПЕЙ УПРАВЛЕНИЯ ЗАДВИЖКИ --------------------------------- */


            /* --------------------------------- ДОПОЛНИТЕЛЬНЫЕ ФЛАГИ СОСТОЯНИЯ ----------------------------------- */

            /* флаг сработки моментного выключателя задвижки */
            zd.MomentFail = zd.VmmoPrev || zd.VmmzPrev || zd.MuftaPrev;
            /* флаги неисправности задвижки */
            zd.Neisprav = zd.NoEcPrev || !(zd.CorrCo && zd.CorrCz);

            /* --------------------------------- ДОПОЛНИТЕЛЬНЫЕ ФЛАГИ СОСТОЯНИЯ ----------------------------------- */


            /*сохранение флагов и регистров состояния алгоритма*/
            if (zd.Imit)
            {
                CommonData.State = zdImit.State;
                CommonData.OpenFail = zdImit.OpenFail;
                CommonData.CloseFail = zdImit.CloseFail;
                CommonData.Crash = zdImit.Crash;

                CommonData.StopFail = false;
                CommonData.UnpromtedOpen = false;
                CommonData.UnpromtedClose = false;
            }
            else
            {
                CommonData.State = zd.State;
                CommonData.OpenFail = state.OpenFail;
                CommonData.CloseFail = state.CloseFail;
                CommonData.Crash = state.Crash;

                CommonData.StopFail = state.StopFail;
                CommonData.UnpromtedOpen = state.UnpromptedOpen;
                CommonData.UnpromtedClose = state.UnpromptedClose;
            }

            CommonData.Imit = zd.Imit;

            CommonData.MomentFail = zd.MomentFail;
            CommonData.CorrCo = zd.CorrCo;
            CommonData.CorrCz = zd.CorrCz;
            CommonData.Vmmo = zd.VmmoPrev;
            CommonData.Vmmz = zd.VmmzPrev;
            CommonData.Mufta = zd.MuftaPrev;
            CommonData.ErrBur = zd.BurCrash;
            CommonData.Neisp = zd.Neisprav;
            CommonData.Dist = nu.DIST_KEY;
            CommonData.NoEc = zd.NoEcPrev;

        }

    }
}
