﻿using TarFoundation.St;
using TarReferenceSource.Common.Timer;

namespace TarReferenceSource.Ktprs.Ktprs_1
{
    public class Ktprs_1 : Ktprs_Xio
    {
        private ITimer T01;
        /// <summary>
        /// Модуль Ktprs0
        /// </summary>
        private Ktprs_0.Ktprs_0 Ktprs0;
        /// <summary>
        /// Флаг выполнения инициализации модуля
        /// </summary>
        private bool initDone;
        public Ktprs_1(Ktprs_0.Ktprs_0 ktprs)
        {
            Messenger = ktprs.Messenger;
            Ktprs0 = ktprs;
            T01 = new CpaLocalTimer();
            InternalTimers = new StArray<ITimer>(1, new []{T01});
        }

        public override void Execute()
        {
            Ktprs0.Input = Input;
            Ktprs0.Execute();
            P = Ktprs0.P;
            N = Ktprs0.N;
            F = Ktprs0.F;

            if (!initDone)
            {
                initDone = true;
                T01.Start();
            }

            if (!Input)
            {
                T01.Start();
            }
            P = !T01.IsStarted && Input;
        }
    }
}
