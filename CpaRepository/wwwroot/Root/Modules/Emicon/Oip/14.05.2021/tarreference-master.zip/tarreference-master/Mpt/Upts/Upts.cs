﻿using System;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.St;
using TarReferenceSource.Common.Timer;

namespace TarReferenceSource.Mpt.Upts
{
    internal class UptsStorage
    {
        public bool CorrCv;
        public bool PrevInput;
        public bool On;
    }
    public class Upts : UptsIo
    {
        private ITimer Timer;
        private UptsStorage storage = new UptsStorage();

        public Upts()
        {
            Timer = new CpaLocalTimer();
            InternalTimers = new StArray<ITimer>(1, new []{Timer});
        }

        public override void Execute()
        {
            if (Cmd == Decimal.MaxValue && storage.On && IsSiren)
            {
                if (EnableCmd)
                {
                    storage.On = false;
                    Messenger.Send(9);
                }
                else
                {
                    Messenger.Send(8);
                }
            }
            else if (Cmd == 1)
            {
                Messenger.Send(2);
                if (EnableCmd)
                {
                    storage.On = true;
                }
                else
                {
                    Messenger.Send(8);
                }
            }
            else if (Cmd == 2)
            {
                Messenger.Send(3);
                if (EnableCmd)
                {
                    storage.On = false;
                }
                else
                {
                    Messenger.Send(8);
                }
            }

            if (!EnableCmd || (Input ^ storage.PrevInput))
            {
                if (Input && !storage.On)
                {
                    Messenger.Send(4);
                    storage.On = true;
                }

                if (!Input && storage.On)
                {
                    Messenger.Send(5);
                    storage.On = false;
                }
            }

            storage.PrevInput = Input;

            if (!EnableCvCheck)
            {
                storage.CorrCv = true;
            }
            else
            {
                if (storage.On)
                {
                    Timer.Stop();
                }
                else
                {
                    if (!CorrCv && storage.CorrCv)
                    {
                        if (Timer.IsQ)
                        {
                            Messenger.Send(7);
                            storage.CorrCv = false;
                        }
                        else if (storage.CorrCv && !Timer.IsStarted)
                        {
                            Timer.Start();
                        }
                    }
                    else if (CorrCv && !storage.CorrCv)
                    {
                        Messenger.Send(6);
                        Timer.Stop();
                        storage.CorrCv = true;
                    }
                }
            }

            CorrCvOut = storage.CorrCv;
            OnCmdOut = storage.On;

        }
    }
}
