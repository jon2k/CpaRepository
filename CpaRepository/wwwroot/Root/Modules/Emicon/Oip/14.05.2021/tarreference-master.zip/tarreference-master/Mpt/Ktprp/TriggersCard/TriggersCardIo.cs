﻿using System.Collections.Generic;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;

namespace TarReferenceSource.Mpt.TriggersCard
{
    /// <summary>
    /// Данные с пускового устройства
    /// </summary>
    public class TriggerData
    {
        /// <summary>
        /// Сработка пускогого устройства
        /// </summary>
        public bool Triggered { get; set; } // Сработал
        /// <summary>
        /// Недостоверность пускогого устройства
        /// </summary>
        public bool Ndv { get; set; } // Недостоверность/неисправность
    }
    /// <summary>
    /// Входные данные для модуля TriggerCard
    /// </summary>
    public class TriggersCardInput
    {
        /// <summary>
        /// Количество пусковых устройств
        /// </summary>
        public int TriggersCount { get; set; } // Кол-во АПУ.
        /// <summary>
        /// Флаг зоны в ремонте
        /// </summary>
        public bool InRem { get; set; } //От SPZ
        /// <summary>
        /// Массив всех пусковых устройств
        /// </summary>
        public StArray<TriggerData> Triggers { get; set; } // Недостоверность/неисправность
    }
    /// <summary>
    /// Выходные данные для модуля TriggerCard
    /// </summary>
    public class TriggersCardOutput
    {
        /// <summary>
        /// Флаг сработки пускового устройства
        /// </summary>
        public bool AnyOfTriggersIsTriggered { get; set; } // Сработка любого АПУ.
        /// <summary>
        /// Массив состояний всех пусковых устройств
        /// </summary>
        public StArray<TriggerData> Triggers { get; set; }      
    }

    public abstract class TriggersCardIo:IFunctionBlock
    {
        // in
        /// <summary>
        /// input Входные данные для модуля
        /// </summary>
	    public TriggersCardInput Input;         
        
        // out
        /// <summary>
        /// output Выходные данные для модуля
        /// </summary>
        public TriggersCardOutput Output;

        public TriggersCardIo(int countTrigger)
        {
            Input = new TriggersCardInput() { Triggers = new StArray<TriggerData>(1, new TriggerData[countTrigger]) };
            Output = new TriggersCardOutput() { Triggers = new StArray<TriggerData>(1, new TriggerData[countTrigger]) };
            Input.TriggersCount = countTrigger;
            for (int i = 1; i <= countTrigger; i++)
            {
                Input.Triggers[i] = new TriggerData();
                Output.Triggers[i] = new TriggerData();
            }
        }
        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
            {
                {1, new MessageDescription{Text = "АПУ №Х НЕИСПРАВЕН", Type = MessageType.Attention} },
                {2, new MessageDescription{Text = "АПУ №Х ИСПРАВЕН", Type = MessageType.Neutral} },
                {3, new MessageDescription{Text = "АПУ №Х СРАБОТАЛ", Type = MessageType.Alarm} },
                {4, new MessageDescription{Text = "АПУ №Х В НОРМЕ", Type = MessageType.Neutral} },              
            };
    }
}
