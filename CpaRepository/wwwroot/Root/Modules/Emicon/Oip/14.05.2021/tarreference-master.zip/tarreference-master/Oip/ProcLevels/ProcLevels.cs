﻿using System.Linq;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;

namespace TarReferenceSource.Oip
{

    /*
     * Вывод сообщений по уровням перенесен в ProcMin/Max
     * Задан новый порядок сообщений по уровням
     */
    public class ProcLevels : ProcLevelsIo
    {
        /// <summary>
        /// Массив максимальных уровней
        /// </summary>
        private LevelState[] maxs = Enumerable.Range(1, 6).Select(i=>new LevelState()).ToArray();
        /// <summary>
        /// Массив минимальных уровней
        /// </summary>
        private LevelState[] mins = Enumerable.Range(1, 6).Select(i => new LevelState()).ToArray();
        /// <summary>
        /// Номер зоны
        /// </summary>
        private int zone;
        /// <summary>
        /// Значение сигнала
        /// </summary>
        private float val;
        
        public ProcLevels(ISignalDataSource signalSource) : base(signalSource)
        {
            
        }

        public override void Execute()
        {
            /* Обработка уровней измеряемого параметра */

            if (!Signal.Ndv)
            {       
                /*если сигнал недостоверен, то не обрабатываем*/
                val = Signal.VisualValue;
            }
            var normMsgFl = zone != 0;
            zone = 0;
            /* Обработка минимумов */
            int MIN_COUNT = 6;
            int MAX_COUNT = 6;

            for (int i = MIN_COUNT - 1; i >= 0; i--)
            {
                OipHelpers.ProcMin(val, MinCfgs[i], Hist, mins[i], false, true, false, i, Messenger);
            }

            for (int i = MAX_COUNT - 1; i >= 0; i--)
            {
                OipHelpers.ProcMax(val, MaxCfgs[i], Hist, maxs[i], false, true, false, 6 + i, Messenger);
            }


            for (int i = 0; i < MIN_COUNT; i++)
            {
                OipHelpers.ProcMin(val, MinCfgs[i], Hist, mins[i], true, false,  true, i, Messenger);
            }

            /* Обработка максимумов */
            for (int i = 0; i < MAX_COUNT; i++)
            {
                OipHelpers.ProcMax(val, MaxCfgs[i], Hist, maxs[i], true, false, true, 6 + i, Messenger);
            }


            for (int i = 0; i < MIN_COUNT; i++)
            {
                if (mins[i].Level)
                {
                    zone = -(i + 1);
                }
            }

            for (int i = 0; i < MAX_COUNT; i++)
            {
                if (maxs[i].Level)
                {
                    zone = i + 1;
                }
            }


            if (normMsgFl && (zone == 0) && NeedNormMsg) {
                Messenger.Send(20);
            }
            Norm = (zone == 0);

            Maxs[5] = maxs[5].Level;
            Maxs[4] = maxs[4].Level;
            Maxs[3] = maxs[3].Level;
            Maxs[2] = maxs[2].Level;
            Maxs[1] = maxs[1].Level;
            Maxs[0] = maxs[0].Level;
            Mins[0] = mins[0].Level;
            Mins[1] = mins[1].Level;
            Mins[2] = mins[2].Level;
            Mins[3] = mins[3].Level;
            Mins[4] = mins[4].Level;
            Mins[5] = mins[5].Level;
        }
        
    }
}
