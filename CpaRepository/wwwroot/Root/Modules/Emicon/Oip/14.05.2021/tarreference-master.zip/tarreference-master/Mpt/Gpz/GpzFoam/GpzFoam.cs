﻿using Friday.Helpers;
using Friday.Runtime.CpaLocal;

namespace TarReferenceSource.Mpt.Gpz.GpzFoam
{
    public class GpzFoam : GpzFoamIo
    {
		/// <summary>
		/// Обобщенный флаг готовности защищаемого резервуара к водоорошению.
		/// </summary>
		private bool _flReady; // Обобщенный флаг готовности защищаемого резервуара к водоорошению.
		/// <summary>
		/// Входной параметр блока ProcGpz.
		/// </summary>
		private bool _procInput; // Входной параметр блока ProcGpz.

		public GpzFoam()
		{
			Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
		}

        public override void Execute()
        {
			if (Source.IsRem || Source.SuccessfulStart)
			{
				Out = GpzState.NoControl;
				for (int i = 1; i <= Source.ReadinesCount; i++)
				{
					Output[i] = true;
				}
			}
			else
			{
				_flReady = true;
				for (int i = 1; i <= Source.ReadinesCount; i++)
				{ // Цикл по параметрам готовности
					if (!Source.CfgDisabled[i])
					{  // Флаг необходимости проверки готовности
						switch (i)
						{
							case 1:
								_procInput = Source.OsnIsprCount >= Source.CfgPumpsNeeded;                       // ОТСУТСТВИЕ ИСПРАВНЫХ ПЕНОНАСОСОВ В РЕЖИМЕ ОСНОВНОЙ
								break;
							case 2:
								_procInput = !Source.GeneralFoamLineAnyErr;                                        // ЗАДВИЖКА ПЕНОТУШЕНИЯ ОБЩЕЙ ПЕНОЛИНИИ НЕИСПРАВНА
								break;
							case 3:
								_procInput = !Source.GeneralFoamLineAnyImit;                                       // ЗАДВИЖКА ПЕНОТУШЕНИЯ ОБЩЕЙ ПЕНОЛИНИИ В РЕЖИМЕ «ИМИТ»
								break;
							case 4:
								_procInput = Source.BdsNonCrash || Source.BdsReadyCount >= Source.CfgBDCount;    // НЕИСПРАВНОСТЬ ЗАДВИЖЕК БАКОВ-ДОЗАТОРОВ
								break;
							case 5:
								_procInput = Source.BdsNonImit || Source.BdsReadyCount >= Source.CfgBDCount; // ЗАДВИЖКИ БАКОВ-ДОЗАТОРОВ В РЕЖИМЕ «ИМИТ»
								break;
							case 6:
								_procInput = Source.BdsLowFull || Source.BdsReadyCount >= Source.CfgBDCount; // БАКИ-ДОЗАТОРЫ НЕ ЗАПОЛНЕНЫ
								break;
							case 7:
								_procInput = !Source.TanksAnyMin;                                              // МИНИМАЛЬНЫЙ УРОВЕНЬ РЕЗЕРВУАРА ПРОТИВОПОЖАРНОГО ЗАПАСА ВОДЫ
								break;
							case 8:
								_procInput = !Source.SelfFoamLineAnyErr;                                           // ЗАДВИЖКА ПЕНОЛИНИИ СООРУЖЕНИЯ НЕИСПРАВНА
								break;
							case 9:
								_procInput = !Source.SelfFoamLineAnyImit;                                          // ЗАДВИЖКА ПЕНОЛИНИИ СООРУЖЕНИЯ В РЕЖИМЕ «ИМИТ»
								break;
							case 10:
								_procInput = !Source.SensorsNotEnoughSensors;                                  // НЕДОСТАТОЧНО ИСПРАВНЫХ ПОЖАРНЫХ ИЗВЕЩАТЕЛЕЙ
								break;
							case 11:
								_procInput = Source.SupIsAuto;                                                 // РЕЖИМ АВТОМАТИЧЕСКОГО ПЕНОТУШЕНИЯ ОТКЛЮЧЕН
								break;
							case 12:
								_procInput = true;
								for (int j = 1; j <= Source.CountProt; j++)
								{
									_procInput = _procInput && !Source.ProtM;                               // МАСКИРОВАНИЕ ЗАЩИТЫ ПО ПОЖАРУ
								}
								break;
							case 13:														
									_procInput = Source.BdsReadyCount>=Source.CfgBDCount;                   // НЕОБХОДИМОЕ КОЛИЧЕСТВО БАКОВ-ДОЗАТОРОВ								
								break;
						}

						if (_procInput && !Output[i])
						{
							Output[i] = true;
							Messenger.Send(1 + i * 2);
						}
						else if (!_procInput && Output[i])
						{
							Output[i] = false;
							Messenger.Send(2 + i * 2);
						}

						_flReady = _flReady && Output[i]; // Обобщенный флаг tготовности защищаемого сооружения к пенотушению
					}
				}


				if (_flReady && Out != GpzState.Ready)
				{
					Messenger.Send(1);       // ГОТОВ К АВТОМАТИЧЕСКОМУ ПЕНОТУШЕНИЮ
				}
				if (!_flReady && Out != GpzState.NotReady)
				{
					Messenger.Send(2);       // НЕ ГОТОВ К АВТОМАТИЧЕСКОМУ ПЕНОТУШЕНИЮ
				}
				Out = _flReady ? GpzState.Ready : GpzState.NotReady;                // Флаг готовности
			}
		}
    }
}
