﻿using Friday.Helpers;
using Friday.Runtime.CpaLocal;

namespace TarReferenceSource.Mpt.Gpz.ProcGpz
{
    public class ProcGpz : ProcGpzIo
    {

        public ProcGpz()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }
        public override void Execute()
        {

        }
    }
}
