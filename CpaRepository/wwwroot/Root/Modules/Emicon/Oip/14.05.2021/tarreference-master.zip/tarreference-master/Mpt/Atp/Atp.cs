﻿using System;
using System.Linq;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.St;
using TarReferenceSource.Common.Timer;

namespace TarReferenceSource.Mpt.Atp
{
    public class Atp : AtpIo
    {
        // public IMessenger Messenger;
        /// <summary>
        /// Хранение состояний алгоритма
        /// </summary>
        private AtpStorage storage;
        /// <summary>
        /// Флаг паузы пожаротушения
        /// </summary>
        private bool pause;

        public Atp()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(AtpIo.messages));
            InternalTimers = new StArray<ITimer>(1, Enumerable.Range(1, 5).Select(i => new CpaLocalTimer()).ToArray());
        }

        public override void Execute()
        {

            var flAutoStart = false;
            var flDoStart = false;
            var flDoStop = false;

            /*=============================== принятие решения об управлении ======================================*/

            if (cfg.MaxFires != 0)
            {
                //условие автоматического запуска алгоритма пожаротушения 
                flAutoStart = (storage.MainState == enumATPMainState.Idle) && doFirefight;

                if (NewFireProtection && storage.MainState != enumATPMainState.Idle)
                {
                    Messenger.Send(1); // КОМАНДА ПУСК АВТОМАТИЧЕСКИ
                    if (storage.MainState == enumATPMainState.DoStart || storage.MainState == enumATPMainState.ProcStart || InternalTimers[1].IsStarted)
                    {
                        Messenger.Send(7); // ПУСК НЕ ТРЕБУЕТСЯ. ИДЕТ ПУСК ПОЖАРОТУШЕНИЯ
                    }
                    else if (storage.MainState == enumATPMainState.Work || storage.MainState == enumATPMainState.WaitWork)
                    {
                        Messenger.Send(8); // ПУСК НЕ ТРЕБУЕТСЯ. ПОЖАРОТУШЕНИЕ В РАБОТЕ
                    }
                    else if (!canFirefight)
                    {
                        Messenger.Send(2); // ПУСК НЕВОЗМОЖЕН. РЕЖИМ АВТОМАТИЧЕСКИЙ СБРОШЕН
                    }
                    else
                    {
                        flDoStart = true;
                    }
                } /* пуск автоматический */

                if (flAutoStart && !storage.prevFire && !canFirefight)
                {
                    Messenger.Send(1); // КОМАНДА ПУСК АВТОМАТИЧЕСКИ
                    Messenger.Send(2); // ПУСК НЕВОЗМОЖЕН. РЕЖИМ АВТОМАТИЧЕСКИЙ СБРОШЕН
                }
                else if (InternalTimers[1].IsQ)
                {
                    Messenger.Send(4); // ЗАДЕРЖКА ПУСКА ЗАВЕРШЕНА
                    flDoStart = true;
                }
                else if (InternalTimers[1].IsStarted && !doFirefight)
                {
                    Messenger.Send(28); // ПУСК ПЕНОТУШЕНИЯ ОТМЕНЕН
                    flDoStart = false;
                    InternalTimers[1].Stop();
                }
                else if (flAutoStart && canFirefight && !InternalTimers[1].IsStarted)
                {
                    if (!output.flFire)
                    {
                        Messenger.Send(1); // КОМАНДА ПУСК АВТОМАТИЧЕСКИ
                    }

                    if (InternalTimers[1].Ust == TimeSpan.Zero)
                    {
                        flDoStart = true;
                    }
                    else
                    {
                        Messenger.Send(3); // ВЫПОЛНЯЕТСЯ ЗАДЕРЖКА ПУСКА ПЕНОТУШЕНИЯ
                        InternalTimers[1].Start();
                    }
                }

            }

            output.flFire = false;

            /* Т1 - команды */
            switch (cmd)
            {
                case enumATPCmd.StartCmd:
                    Messenger.Send(5); // КОМАНДА ПУСК С АРМ
                    if (storage.MainState == enumATPMainState.DoStart || storage.MainState == enumATPMainState.ProcStart || InternalTimers[1].IsStarted)
                    {
                        Messenger.Send(7); // ПУСК НЕ ТРЕБУЕТСЯ. ИДЕТ ПУСК ПОЖАРОТУШЕНИЯ
                    }
                    else if (storage.MainState == enumATPMainState.Work || storage.MainState == enumATPMainState.WaitWork)
                    {
                        Messenger.Send(8); // ПУСК НЕ ТРЕБУЕТСЯ. ПОЖАРОТУШЕНИЕ В РАБОТЕ
                    }
                    else 
                    {
                        if (!doFirefight)
                        {
                            output.flFire = true;
                        }
                        else if (cfg.MaxFires!=0)
                        {
                            flDoStart = true;
                        } 
                    }

                    break;
                case enumATPCmd.StopCmd:
                    Messenger.Send(9); // КОМАНДА СТОП С АРМ
                    if (storage.MainState == enumATPMainState.Paused || (storage.MainState == enumATPMainState.Idle && !InternalTimers[1].IsStarted))
                    {
                        Messenger.Send(10); // СТОП НЕ ТРЕБУЕТСЯ. ПОЖАРОТУШЕНИЕ ОСТАНОВЛЕНО
                    }
                    else if (storage.MainState == enumATPMainState.DoStop || storage.MainState == enumATPMainState.ProcStop)
                    {
                        Messenger.Send(11); // СТОП НЕ ТРЕБУЕТСЯ. ИДЕТ ОСТАНОВКА ПОЖАРОТУШЕНИЯ
                    }
                    else
                    {
                        flDoStop = true;
                    } /* Т2 */

                    break;
                case enumATPCmd.ContinueCmd:
                    Messenger.Send(12); // КОМАНДА - ПРОДОЛЖНИТЬ ПОЖАРОТУШЕНИЕ
                    if (output.flContinueCheck || output.flStopCheck)
                    {
                        output.flContinueCheck = false;
                        output.flStopCheck = false;
                        storage.ContinuationConfirmed = true;
                        storage.StopConfirmed = false;
                        Messenger.Send(14); // ПРИНЯТО РЕШЕНИЕ ПРОДОЛЖИТЬ ТУШЕНИЕ
                    }
                    else
                    {
                        Messenger.Send(13); // КОМАНДА ОТКЛОНЕНА
                    }

                    break;
                case enumATPCmd.NonContinueCmd:
                    Messenger.Send(15); // КОМАНДА - ЗАКОНЧИТЬ ПОЖАРОТУШЕНИЕ
                    if (output.flContinueCheck || output.flStopCheck)
                    {
                        output.flContinueCheck = false;
                        output.flStopCheck = false;
                        storage.ContinuationConfirmed = false;
                        storage.StopConfirmed = true;
                        Messenger.Send(16); // ПРИНЯТО РЕШЕНИЕ ЗАКОНЧИТЬ ТУШЕНИЕ
                    }
                    else
                    {
                        Messenger.Send(13); // КОМАНДА ОТКЛОНЕНА
                    }

                    break;
            } /*стоп автоматический по таймеру из Check?*/


            /*=============================== обработка основного состояния ===================================*/

            if (storage.MainState != enumATPMainState.Idle)
            {
                InternalTimers[1].Stop();
            }

            if (storage.MainState != enumATPMainState.Work && !pause)
            {
                InternalTimers[2].Stop();
                InternalTimers[3].Stop();

                storage.ContinuationConfirmed = false;
                storage.StopConfirmed = false;
                output.flContinueCheck = false;
                output.flStopCheck = false;

            } /* Т4 */

            if (storage.MainState != enumATPMainState.ProcStart)
            {
                InternalTimers[4].Stop();
            }

            if (storage.MainState != enumATPMainState.ProcStop)
            {
                InternalTimers[5].Stop();
            }

            switch (storage.MainState)
            {
                case enumATPMainState.Idle: //10 не начиналось
                    storage.Counter = 1;
                    if (flDoStop)
                    {
                        storage.MainState = enumATPMainState.DoStop;
                        InternalTimers[1].Stop();
                    }
                    else if (flDoStart)
                    {
                        storage.MainState = enumATPMainState.DoStart;
                    }

                    break;
                case enumATPMainState.Paused: //15 остановлено по команде оператора
                    //если пожар не зарегистрирован, переходим в норму 
                    if (flDoStart)
                    {
                        storage.MainState = enumATPMainState.DoStart;
                    }
                    else if (!doFirefight)
                    {
                        storage.MainState = enumATPMainState.Idle;
                        Messenger.Send(17); // ПОЖАРОТУШЕНИЕ ОСТАНОВЛЕНО
                    }

                    break;
                case enumATPMainState.DoStart: //30 Пуск пожаротушения
                    if (flDoStop)
                    {
                        storage.MainState = enumATPMainState.DoStop;
                    }
                    else
                    {
                        Messenger.Send(18); // ЗАПУСК ПОЖАРОТУШЕНИЯ
                        storage.MainState = enumATPMainState.ProcStart;
                        InternalTimers[4].Start();
                    } /* Т5 */

                    break;
                case enumATPMainState.ProcStart: //35 Пуск пожаротушения
                    //Если определили запущенность пожаротушения
                    if (flDoStop)
                    {
                        storage.MainState = enumATPMainState.DoStop;
                    }
                    else if (flWorkState)
                    {
                        Messenger.Send(19); // ПОЖАРОТУШЕНИЕ В РАБОТЕ
                        storage.MainState = enumATPMainState.Work;
                        if (storage.Counter <= cfg.MaxFires)
                        {
                            InternalTimers[2].Start();
                            InternalTimers[3].Start();
                        }
                    }
                    else if (InternalTimers[4].IsQ)
                    {
                        Messenger.Send(20); //ЗАПУСК ПОЖАРОТУШЕНИЯ НЕ ОКОНЧЕН ЗА ЗАДАННОЕ ВРЕМЯ       
                    }

                    break;
                case enumATPMainState.DoStop: //20 остановка пожаротушения
                    if (flDoStart)
                    {
                        storage.MainState = enumATPMainState.DoStart;
                    }
                    else
                    {
                        Messenger.Send(21); //ОСТАНОВКА ПОЖАРОТУШЕНИЯ 
                        InternalTimers[5].Start();
                        storage.MainState = enumATPMainState.ProcStop;
                    } /* Т7 */
                    break;
                case enumATPMainState.ProcStop: //25 остановка пожаротушения
                    if (flDoStart)
                    {
                        storage.MainState = enumATPMainState.DoStart;
                    }
                    else if (flStopState)
                    {
                        storage.MainState = enumATPMainState.Paused;
                    }
                    else if (InternalTimers[5].IsQ)
                    {
                        Messenger.Send(22); //ОСТАНОВКА ПОЖАРОТУШЕНИЯ НЕ ОКОНЧЕНА ЗА ЗАДАННОЕ ВРЕМЯ   
                        storage.MainState = enumATPMainState.Paused;
                    } //40 пожаротушение   

                    break;
                case enumATPMainState.Work:

                    if (flDoStop)
                    {
                        storage.MainState = enumATPMainState.DoStop;
                        storage.Counter = storage.Counter + 1;
                    }
                    else if (InternalTimers[2].IsQ)
                    {
                        if (storage.Counter < cfg.MaxFires)
                        {
                            output.flContinueCheck = true;
                            Messenger.Send(23); // ОКОНЧАНИЕ РЕГЛАМЕНТНОГО ВРЕМЕНИ ТУШЕНИЯ. ОПЕРАТОРУ НЕОБХОДИМО ПРИНЯТЬ РЕШЕНИЕ
                        }
                        else if (!cfg.stopAfterMaxFires)
                        {
                            output.flStopCheck = true;
                            Messenger.Send(23); // ОКОНЧАНИЕ РЕГЛАМЕНТНОГО ВРЕМЕНИ ТУШЕНИЯ. ОПЕРАТОРУ НЕОБХОДИМО ПРИНЯТЬ РЕШЕНИЕ
                        }

                        storage.ContinuationConfirmed = false;
                        storage.StopConfirmed = false;
                    }
                    else if (InternalTimers[3].IsQ)
                    {
                        if (storage.StopConfirmed)
                        {
                            storage.MainState = enumATPMainState.DoStop;
                        }
                        else if (storage.Counter < cfg.MaxFires)
                        {
                            InternalTimers[2].Start();
                            InternalTimers[3].Start();
                            if (storage.ContinuationConfirmed)
                            {
                                Messenger.Send(24); // ПРОДОЛЖЕНИЕ ПОЖАРОТУШЕНИЯ.
                            }
                            else
                            {
                                Messenger.Send(25); // ПОДТВЕРЖДЕНИЕ ПРОДОЛЖЕНИЯ ПОЖАРОТУШЕНИЯ НЕ ПОЛУЧЕНО. ПРОДОЛЖЕНИЕ ПОЖАРОТУШЕНИЯ
                            }
                        }
                        else
                        {
                            if (storage.ContinuationConfirmed)
                            {
                                Messenger.Send(24); // ПРОДОЛЖЕНИЕ ПОЖАРОТУШЕНИЯ.
                            }
                            else if (cfg.stopAfterMaxFires)
                            {
                                Messenger.Send(26); // ВРЕМЯ ТУШЕНИЯ ОБЪЕКТА ЗАКОНЧИЛОСЬ. ОСТАНОВКА ПОЖАРОТУШЕНИЯ
                                storage.MainState = enumATPMainState.DoStop;
                            }
                            else
                            {
                                Messenger.Send(27); // ПОДТВЕРЖДЕНИЕ ОСТАНОВКИ ПОЖАРОТУШЕНИЯ НЕ ПОЛУЧЕНО. ПРОДОЛЖЕНИЕ ПОЖАРОТУШЕНИЯ
                            }
                        }

                        storage.Counter = storage.Counter + 1;

                        storage.ContinuationConfirmed = false;
                        storage.StopConfirmed = false;
                        output.flContinueCheck = false;
                        output.flStopCheck = false;
                    }
                    else if (!flWorkState)
                    {
                        // storage.Counter = storage.Counter + 1;
                        
                        if (storage.Counter <= cfg.MaxFires)
                        {
                            storage.MainState = enumATPMainState.WaitWork;
                            InternalTimers[2].Pause();
                            InternalTimers[3].Pause();
                            pause = true;
                        }
                        else
                        {
                            storage.MainState = enumATPMainState.DoStop;
                        }
                    } //40 пожаротушение   

                    break;
                case enumATPMainState.WaitWork:
                    if (flDoStop)
                    {
                        storage.MainState = enumATPMainState.DoStop;
                    }
                    else if (flWorkState)
                    {
                        storage.MainState = enumATPMainState.Work;
                        if (pause)
                        {
                            InternalTimers[2].Continue();
                            InternalTimers[3].Continue();
                        }
                        else
                        {
                            InternalTimers[2].Start();
                            InternalTimers[3].Start();
                        }
                    }
                    break;
                default:
                    {
                        storage.MainState = enumATPMainState.Idle;
                        break;
                    }
            }

            if (storage.MainState != enumATPMainState.WaitWork && pause)
            {
                pause = false;
            }

            output.flStop = storage.MainState == enumATPMainState.ProcStop;
            output.flStart = storage.MainState == enumATPMainState.ProcStart
                             || storage.MainState == enumATPMainState.Work
                             || storage.MainState == enumATPMainState.WaitWork;

            storage.prevFire = doFirefight;
            Counter = storage.Counter - 1;
        }
    }
}