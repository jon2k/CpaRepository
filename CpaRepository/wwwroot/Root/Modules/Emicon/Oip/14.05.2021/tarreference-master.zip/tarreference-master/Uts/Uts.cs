﻿using System;
using System.Linq;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.St;
using TarReferenceSource.Common.Timer;

namespace TarReferenceSource.Uts
{
    /// <summary>
    /// Структура внутреннего состояния Uts
    /// </summary>
    internal class UtsStorage
    {
        /// <summary>
        /// Флаг, показывающий, что включение произошло с АРМ
        /// </summary>
        public bool checking_ARM;//Флаг, показывающий, что включение произошло с АРМ
        /// <summary>
        /// Флаг, показывающий необходимость работы табло/сирены по источнику включения на предыдущем цикле работы программы
        /// </summary>
        public bool input_Prev;//Флаг, показывающий необходимость работы табло/сирены по источнику включения на предыдущем цикле работы программы
        /// <summary>
        /// Флаг, показывающий, что происходит проверка
        /// </summary>
        public bool cheking; //Флаг, показывающий, что происходит проверка
        /// <summary>
        /// Флаг, показывающий, что происходила проверка на предыдущем цикле работы программы
        /// </summary>
        public bool Cheking_Prev; //Флаг, показывающий, что происходила проверка на предыдущем цикле работы программы
        /// <summary>
        /// Флаг, показывающий, что получено подтверждение сработки сигнализации
        /// </summary>
        public bool kvit; //Флаг, показывающий, что получено подтверждение сработки сигнализации
        /// <summary>
        /// Флаг, показывающий, что табло/сирена была включена на предидущем цикле работы
        /// </summary>
        public bool Val_Prev; //Флаг, показывающий, что табло/сирена была включена на предидущем цикле работы
    }

    public class Uts : UtsIo
    {
        /// <summary>
        /// Внутренее состояние модуля
        /// </summary>
        private UtsStorage storage = new UtsStorage();

        public Uts()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
            InternalTimers = new StArray<ITimer>(1, Enumerable.Range(1, 2).Select(i => new CpaLocalTimer()).ToArray());
        }

        public override void Execute()
        {

            if (Cmd == UtsCmds.enable)
            {
                Messenger.Send(5); //Команда включить с АРМ
                storage.checking_ARM = true;
            }
            else if (Cmd == UtsCmds.disable)
            {
                Messenger.Send(6);   //Команда отключить с АРМ
                storage.checking_ARM = false;
            }
            if (!storage.input_Prev && Input)
            {
                Messenger.Send(1);   //Команда включить автоматически
            }
            else if (storage.input_Prev && !Input)
            {
                Messenger.Send(2);   //Команда отключить автоматически
            }

            if (!Input)
            {
                if (CheckEnabled)
                {            //Если разрешена проверка
                    storage.cheking = CheckInput;       //Нажата проверка

                    // Изменил условие.
                    //if (storage.cheking || storage.Cheking_Prev)
                    if (storage.cheking)
                    {
                        checking = true;
                    }
                    else if (!KvitEnabled)
                    {
                        checking = false;
                    }

                }
                // Добавил условие.
                else
                { 
                    checking = false;
                }
                if (KvitEnabled)
                {         //Если разрешено квитирование
                    storage.kvit = KvitInput;      //Нажато квитирование
                    if (!CheckInput && KvitInput)
                    {
                        checking = false;
                    }
                }
                if (!storage.Cheking_Prev && checking)
                {
                    Messenger.Send(3); //Проверка сигнализации
                }
                else if (storage.Cheking_Prev && !checking)
                {
                    Messenger.Send(4); //Квитирование сигнализации
                }
            }

            if (Input || checking || storage.checking_ARM)
            {
                //Включить автоматически, включить с кнопки проверка или включить с АРМ
                if (InternalTimers[1].Ust != TimeSpan.Zero && InternalTimers[2].Ust != TimeSpan.Zero)
                { //Если уставки больше нуля, то делаем мигание
                    
                    if (InternalTimers[1].IsQ)
                    {
                        InternalTimers[2].Start();
                        InternalTimers[1].Stop();
                    }
                    else if (InternalTimers[2].IsQ)
                    {
                        InternalTimers[1].Start();
                        InternalTimers[2].Stop();
                    }
                    else if (!InternalTimers[1].IsStarted && !InternalTimers[2].IsStarted)
                    {
                        InternalTimers[1].Start();
                    }

                    if (InternalTimers[1].IsStarted)
                    {
                        EnableNuCmd = true;
                    }
                    else if (InternalTimers[2].IsStarted)
                    {
                        EnableNuCmd = false;
                    }
                }
                else
                {    // иначе включаем без мигания
                    EnableNuCmd = true;
                }
                if (!storage.Val_Prev)
                {
                    Messenger.Send(7); //Включено
                }
                IsEnabled = true;     //Включено для сигнализации на ВУ
            }
            else
            {
                if (storage.Val_Prev)
                {
                    Messenger.Send(8); //Отключено
                }
                InternalTimers[1].Stop();
                InternalTimers[2].Stop();
                IsEnabled = false;
                EnableNuCmd = false;
            }
            storage.input_Prev = Input;
            storage.Cheking_Prev = checking;
            storage.Val_Prev = IsEnabled;

        }
    }
}
