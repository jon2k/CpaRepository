﻿namespace TarReferenceSource.Ktpra
{
    public enum NaStopType : ushort
    {
        None = 0,
        ManageStop = 1,
        ElectricStop = 2,
        ManageStopOffVV = 3,
        ChRPAlarmStop = 4,
        StopAuto = 5,
        StopAuto2 = 6,
        PovtorOtkl = 7
    }
    public enum ProcKtpraCmd : ushort
    {
        None=0,
        Mask=1,
        UnMask=2,
        Deblock=3
    }
    /// <summary>
    /// Выходные даные из модуля ProcKtpra
    /// </summary>
    public class ProcKtpraResult
    {
        /// <summary>
        /// Флаг аварийного параметра агрегатной защиты
        /// </summary>
        public bool F;
        /// <summary>
        /// Флаг маскирования агрегатной защиты
        /// </summary>
        public bool M;
        /// <summary>
        /// Флаг срабатывание агрегатной защиты
        /// </summary>
        public bool P;
        /// <summary>
        /// Настроечный флаг запрета маскирования защиты.
        /// </summary>
        public bool NotMasked;
    }
    /// <summary>
    /// Выходные даные из модуля Ktpra
    /// </summary>
    public class KtpraResult
    {
        /// <summary>
        /// Способ остановки агрегатов 
        /// </summary>
        public NaStopType StopType;
        /// <summary>
        /// Флаг необходимости автоматического повтора включения
        /// </summary>
        public bool Avr;
        /// <summary>
        /// Флаг срабатывание агрегатной защиты
        /// </summary>
        public bool P;
    }
    /// <summary>
    /// Данные для конфигурации модуля ProcKtpra
    /// </summary>
    public class ProcKtpraConfig
    {
        /// <summary>
        /// Способ остановки агрегатов 
        /// </summary>
        public NaStopType StopType;
        /// <summary>
        /// Флаг необходимости автоматического повтора включения
        /// </summary>
        public bool Avr;
        /// <summary>
        /// Настроечный флаг запрета маскирования защиты.
        /// </summary>
        public bool NotMasked;      
    }

   
    
}
