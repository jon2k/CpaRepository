﻿using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using System.Linq;
using TarFoundation.St;
using TarReferenceSource.Common.Timer;

namespace TarReferenceSource.Uzd
{
    public class Uzd : UzdIo
    {
        /// <summary>
        /// Рассинхронизация даных между физичиским и интерфейсным каналом.
        /// </summary>
        private bool channelsDesync;
        /// <summary>
        /// Наличие связи по интерфейсному каналу
        /// </summary>
        private bool rsOk;
        public Uzd()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(UzdIo.messages));
            InternalTimers = new StArray<ITimer>(1, Enumerable.Range(1, 1).Select(i => new CpaLocalTimer()).ToArray());
        }
        public override void Execute()
        {
            if (!RsOff)
            {
                if (!RsLink && rsOk)
                {
                    Messenger.Send(113); // Нет данных по интерфейсу
                    rsOk = false;
                }
                if (RsLink && !rsOk)
                {
                    Messenger.Send(114); // Есть данные по интерфейсу
                    rsOk = true;
                }
            }
            var useRs = !RsOff && rsOk;
            if (useRs)
            {
                Nu.KVO = IvarKVO;
                Nu.KVZ = IvarKVZ;
                Nu.MPO = IvarMPO;
                Nu.MPZ = IvarMPZ;
                Nu.DIST_KEY = IvarDist;
                Nu.Mufta = IvarMufta;
                Nu.ErrBUR = IvarErrBUR;

                var isSync = IvarKVO == DvarKVO && IvarKVZ == DvarKVZ &&
                    IvarMPO == DvarMPO && IvarMPZ == DvarMPZ &&
                    IvarDist == DvarDist && IvarMufta == DvarMufta &&
                    IvarErrBUR == DvarErrBUR;
                if (isSync)
                {
                    if (channelsDesync)
                    {
                        Messenger.Send(128); // Данные по физическому и интерфейсному каналу синхронизированы
                    }
                    InternalTimers[1].Stop();
                    channelsDesync = false;
                }
                else if (!InternalTimers[1].IsStarted && !InternalTimers[1].IsQ && !channelsDesync)
                {
                    InternalTimers[1].Start();
                }

                if (InternalTimers[1].IsQ)
                {
                    channelsDesync = true;
                    Messenger.Send(129); // Данные по физическому каналу отличаются от интерфейсных
                }
            }
            else
            {
                Nu.KVO = DvarKVO;
                Nu.KVZ = DvarKVZ;
                Nu.MPO = DvarMPO;
                Nu.MPZ = DvarMPZ;
                Nu.DIST_KEY = DvarDist;
                Nu.Mufta = DvarMufta;
                Nu.ErrBUR = DvarErrBUR;

                InternalTimers[1].Stop();
                channelsDesync = false;
            }

            ChannelsDesync = channelsDesync;
            RsOk = rsOk;
        }
    }
}
