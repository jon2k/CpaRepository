﻿using TarReferenceSource.Uzd;

namespace TarReferenceSource.Mpt.Gpz.ZdLine
{
    public class ZdLine : ZdLineIo
    {
        private int i;
        public ZdLine(ZdOut[] zdOuts):base(zdOuts)
        {

        }

        public override void Execute()
        {
            AnyErr = false;
            AnyImit = false;
            for ( i = 1; i <= MaxZdLineCount; i++)
            {
                if (Zds[i].Crash == true || Zds[i].Neisp == true)
                    AnyErr = true;
                if (Zds[i].Imit == true)
                    AnyImit = true;
            }
        }
    }
}
