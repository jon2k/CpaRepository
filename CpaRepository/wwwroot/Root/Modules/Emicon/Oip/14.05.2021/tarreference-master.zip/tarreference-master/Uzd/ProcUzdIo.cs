﻿using System;
using System.Collections.Generic;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;

namespace TarReferenceSource.Uzd
{
    /// <summary>
    /// Структура, хранящая сигналы с нижнего уровня
    /// </summary>
    public class ZdNu
    {
        /// <summary>
        /// Сигнал с конечного выключателя открытия
        /// </summary>
        public bool KVO;
        /// <summary>
        /// Сигнал с конечного выключателя закрытия
        /// </summary>
        public bool KVZ;
        /// <summary>
        /// Сигнал с магнитного пускателя открытия
        /// </summary>
        public bool MPO;
        /// <summary>
        /// Сигнал с магнитного пускателя закрытия
        /// </summary>
        public bool MPZ;
        /// <summary>
        /// Сигнал положения ключа местный/дистанция (при наличии)
        /// </summary>
        public bool DIST_KEY;
        /// <summary>
        /// Сигнал наличия напряжения на задвижке (при наличии)
        /// </summary>
        public bool EC;
        /// <summary>
        /// Сигнал о срабатывании моментного выключателя открытия
        /// </summary>
        public bool VMMO;
        /// <summary>
        /// Сигнал о срабатывании моментного выключателя закрытия
        /// </summary>
        public bool VMMZ;
        /// <summary>
        /// Сигнал о срабатывании муфты
        /// </summary>
        public bool Mufta;
        /// <summary>
        /// Сигналы о неисправности БУРа
        /// </summary>
        public bool ErrBUR;
        /// <summary>
        /// Сигнал наличия напряжения на секции ЩСУ
        /// </summary>
        public bool ZD_EC_KTP;
        /// <summary>
        /// Сигнал «цепи управления открытием задвижки исправны»
        /// </summary>
        public bool CorrCO;
        /// <summary>
        /// Сигнал «цепи управления закрытием задвижки исправны»
        /// </summary>
        public bool CorrCZ;
        /// <summary>
        /// Сигнализация о закрытии задвижки с БРУ
        /// </summary>
        public bool nlBRUClose;
        /// <summary>
        /// Сигнализация об останове задвижки с БРУ
        /// </summary>
        public bool nlBRUStop;

    }
    /// <summary>
    /// Структура, хранящая настроечные флаги алгоритма
    /// </summary>
    public class ZdCfg
    {
        /// <summary>
        /// Задвижка с ключом «Дистанция/По месту»
        /// </summary>
        public bool SlDist;
        /// <summary>
        /// Задвижка без пускателей
        /// </summary>
        public bool SlNoMp;
        /// <summary>
        /// Инверсия значений на концевых выключателей.
        /// </summary>
        public bool SlInvKv;
        /// <summary>
        /// Задвижка с раздельными кнопками «СТОП ОТКРЫТИЯ» и «СТОП ЗАКРЫТИЯ»
        /// </summary>
        public bool Sl2Stop;
        /// <summary>
        /// Задвижка с электронным блоком управления
        /// </summary>
        public bool SlBur;
        /// <summary>
        /// Наличие контроля цепей открытия
        /// </summary>
        public bool SlCo;
        /// <summary>
        /// Наличие контроля цепей закрытия
        /// </summary>
        public bool SlCz;
        /// <summary>
        /// Отдельный сигнал наличия напряжения на задвижки
        /// </summary>
        public bool SlYesEc;
        /// <summary>
        /// Замораживать обработку при подозрительном изменении состояния
        /// </summary>
        public bool SlCheckState;
    }
    /// <summary>
    /// Структура, хранящая данные о состоянии задвижки
    /// </summary>
    public class ZdOut
    {
        /// <summary>
        /// Флаг аварии открытия
        /// </summary>
        public bool OpenFail;
        /// <summary>
        /// Флаг аварии закрытия
        /// </summary>
        public bool CloseFail;
        /// <summary>
        /// Флаг аварии остановки
        /// </summary>
        public bool StopFail;
        /// <summary>
        /// Флаг несанкционированного открытия
        /// </summary>
        public bool UnpromtedOpen;
        /// <summary>
        /// Флаг несанкционированного закрытия
        /// </summary>
        public bool UnpromtedClose;
        /// <summary>
        /// Флаг аварии по моменту
        /// </summary>
        public bool MomentFail;
        /// <summary>
        /// Флаг неисправности цепей управления открытием задвижки
        /// </summary>
        public bool CorrCo;
        /// <summary>
        /// Флаг неисправности цепей управления закрытием задвижки
        /// </summary>
        public bool CorrCz;
        /// <summary>
        /// Флаг срабатывания моментного выключателя открытия
        /// </summary>
        public bool Vmmo;
        /// <summary>
        /// Флаг срабатывания моментного выключателя закрытия
        /// </summary>
        public bool Vmmz;
        /// <summary>
        /// Флаг срабатывания муфты
        /// </summary>
        public bool Mufta;
        /// <summary>
        /// Флаг аварии блока управления задвижки
        /// </summary>
        public bool ErrBur;
        /// <summary>
        /// Флаг поломки
        /// </summary>
        public bool Crash;
        /// <summary>
        /// Флаг неисправности
        /// </summary>
        public bool Neisp;
        /// <summary>
        /// Флаг наличия дистанционного режима
        /// </summary>
        public bool Dist;
        /// <summary>
        /// Флаг включения имитационного режима
        /// </summary>
        public bool Imit;
        /// <summary>
        /// Флаг отсутствия напряжения на задвижке
        /// </summary>
        public bool NoEc;
        /// <summary>
        /// Состояние задвижки
        /// </summary>
        public ZdState State;
    }
    /// <summary>
    /// Структура управления задвижкой
    /// </summary>
    public class ZdControl
    {
        /// <summary>
        /// Команда на открытие от других модулей. 0 – нет команды, 1 - есть команда
        /// </summary>
        public bool nlOpen; /* 0 – нет команды от других модулей на открытие задвижки, 1 - есть команды от других модулей на открытие задвижки */
        /// <summary>
        /// Команда на остановку от других модулей. 0 – нет команды, 1 - есть команда
        /// </summary>
        public bool nlStop; /* 0 – нет команды «СТОП» задвижки от других модулей, 1 - есть команда «СТОП» задвижки от других модулей */
        /// <summary>
        /// Команда на закрытие от других модулей. 0 – нет команды, 1 - есть команда
        /// </summary>
        public bool nlClose; /* 0 – нет команды от других модулей на закрытие задвижки, 1 - есть команды от других модулей на закрытие задвижки */
        /// <summary>
        /// Запрет на открытие задвижки, 1 - есть запрет, 0 - нет запрета
        /// </summary>
        public bool nlSetNoOpen; /* 0 - нет запрета на открытие задвижки, 1 - есть запрет на открытие задвижки */
        /// <summary>
        /// Запрет на закрытие задвижки, 1 - есть запрет, 0 - нет запрета
        /// </summary>
        public bool nlSetNoClose; /* 0 - нет запрета на закрытие задвижки, 1 - есть запрет на закрытие задвижки. */
    }

    public abstract class ProcUzdIo : IFunctionBlock
    {
        public ProcUzdIo()
        {
            Description.TimerDescriptions = TimerDescriptions;
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }
        /// <summary>
        /// input Команда с АРМ
        /// </summary>
        public ZdCmd Cmd;
        /// <summary>
        /// input Данные с нижнего уровня
        /// </summary>
        public ZdNu nu = new ZdNu();
        /// <summary>
        /// input Конфигурация модуля 
        /// </summary>
        public ZdCfg cfg = new ZdCfg();
        /// <summary>
        /// input Команда по ТУ на открытие задвижки, 0 – нет команды, 1 - есть команда
        /// </summary>
        public bool nlTUOpen; /* 0 – нет команды по ТУ на открытие задвижки, 1 - есть команды по ТУ на открытие задвижки */
        /// <summary>
        /// input Команда по ТУ на остановку задвижки, 0 – нет команды, 1 - есть команда
        /// </summary>
        public bool nlTUStop; /* 0 – нет команды «СТОП» задвижки по ТУ, 1 - есть команда «СТОП» задвижки по ТУ */
        /// <summary>
        /// input Команда по ТУ на закрытие задвижки, 0 – нет команды, 1 - есть команда
        /// </summary>
        public bool nlTUClose; /* 0 – нет команды по ТУ на закрытие задвижки, 1 - есть команды по ТУ на закрытие задвижки */
        /// <summary>
        /// input Команда от других модулей на открытие задвижки, 0 – нет команды, 1 - есть команда
        /// </summary>
        public bool nlOpen; /* 0 – нет команды от других модулей на открытие задвижки, 1 - есть команды от других модулей на открытие задвижки */
        /// <summary>
        /// input Команда от других модулей на остановку задвижки, 0 – нет команды, 1 - есть команда
        /// </summary>
        public bool nlStop; /* 0 – нет команды «СТОП» задвижки от других модулей, 1 - есть команда «СТОП» задвижки от других модулей */
        /// <summary>
        /// input Команда от других модулей на закрытие задвижки, 0 – нет команды, 1 - есть команда
        /// </summary>
        public bool nlClose; /* 0 – нет команды от других модулей на закрытие задвижки, 1 - есть команды от других модулей на закрытие задвижки */
        /// <summary>
        /// input Команда от ЦСПА на открытие задвижки, 0 – нет команды, 1 - есть команда
        /// </summary>
        public bool nlCSPAOpen; /* 0 – нет команды от ЦСПА на открытие задвижки, 1 - есть команды от ЦСПА на открытие задвижки */
        /// <summary>
        /// input Команда от ЦСПА на закрытие задвижки, 0 – нет команды, 1 - есть команда
        /// </summary>
        public bool nlCSPAClose; /* 0 – нет команды от ЦСПА на закрытие задвижки, 1 - есть команды от ЦСПА на закрытие задвижки */
        /// <summary>
        /// input Команда от ЦСПА на остановку задвижки, 0 – нет команды, 1 - есть команда
        /// </summary>
        public bool nlCSPAStop; /* 0 – нет команды «СТОП» задвижки от ЦСПА, 1 - есть команда «СТОП» задвижки от ЦСПА */
        /// <summary>
        /// input Флаг запрета на открытие задвижки
        /// </summary>
        public bool nlSetNoOpen; /* 0 - нет запрета на открытие задвижки, 1 - есть запрет на открытие задвижки */
        /// <summary>
        /// input Флаг запрета на закрытие задвижки
        /// </summary>
        public bool nlSetNoClose; /* 0 - нет запрета на закрытие задвижки, 1 - есть запрет на закрытие задвижки. */
        /// <summary>
        /// output Состояние задвижки
        /// </summary>
        public ZdOut CommonData = new ZdOut();
        /// <summary>
        /// output Команда на закрытие задвижки
        /// </summary>
        public bool Close;
        /// <summary>
        /// output Команда на открытие задвижки
        /// </summary>
        public bool Open;
        /// <summary>
        /// output Команда на остановку задвижки
        /// </summary>
        public bool Stop;
        /// <summary>
        /// output Команда на остановку открытия задвижки
        /// </summary>
        public bool StopOpen;
        /// <summary>
        /// output Команда на остановку закрытия задвижки
        /// </summary>
        public bool StopClose;
        /// <summary>
        /// output Флаг дистанционного управления по ТМ
        /// </summary>
        public bool TmModeDist;

        public override void AfterCall()
        {
            Cmd = ZdCmd.none;
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {
            {1, new MessageDescription{Text = "ОТКРЫВАЕТСЯ", Type = MessageType.Neutral} },
            {2, new MessageDescription{Text = "ОТКРЫВАЕТСЯ В РЕЖИМЕ ИМИТАЦИИ", Type = MessageType.Neutral} },
            {3, new MessageDescription{Text = "ОТКРЫВАЕТСЯ. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {4, new MessageDescription{Text = "ОТКРЫТИЕ НЕВОЗМОЖНО. АВАРИЯ ЗАДВИЖКИ", Type = MessageType.Neutral} },
            {5, new MessageDescription{Text = "ОТКРЫТИЕ НЕВОЗМОЖНО. НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ", Type = MessageType.Neutral} },
            {7, new MessageDescription{Text = "ОТКРЫТА", Type = MessageType.Neutral} },
            {8, new MessageDescription{Text = "ОТКРЫТА В РЕЖИМЕ ИМИТАЦИИ", Type = MessageType.Neutral} },
            {10, new MessageDescription{Text = "ОТКРЫТА. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {12, new MessageDescription{Text = "В ПРОМЕЖУТОЧНОМ ПОЛОЖЕНИИ", Type = MessageType.Neutral} },
            {13, new MessageDescription{Text = "В ПРОМЕЖУТОЧНОМ ПОЛОЖЕНИИ. РЕЖИМ ИМИТАЦИИ", Type = MessageType.Neutral} },
            {14, new MessageDescription{Text = "БЛОКИРОВКА ОТКРЫТИЯ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {15, new MessageDescription{Text = "БЛОКИРОВКА ЗАКРЫТИЯ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {16, new MessageDescription{Text = "ЗАКРЫВАЕТСЯ", Type = MessageType.Neutral} },
            {17, new MessageDescription{Text = "ЗАКРЫВАЕТСЯ В РЕЖИМЕ ИМИТАЦИИ", Type = MessageType.Neutral} },
            {18, new MessageDescription{Text = "ЗАКРЫВАЕТСЯ. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {19, new MessageDescription{Text = "ЗАКРЫТИЕ НЕВОЗМОЖНО. АВАРИЯ ЗАДВИЖКИ    ", Type = MessageType.Neutral} },
            {20, new MessageDescription{Text = "ЗАКРЫТИЕ НЕВОЗМОЖНО. НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ", Type = MessageType.Neutral} },
            {22, new MessageDescription{Text = "ЗАКРЫТА", Type = MessageType.Neutral} },
            {23, new MessageDescription{Text = "ЗАКРЫТА В РЕЖИМЕ ИМИТАЦИИ", Type = MessageType.Neutral} },
            {25, new MessageDescription{Text = "ЗАКРЫТА. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {27, new MessageDescription{Text = "РЕЖИМ ИМИТАЦИИ УСТАНОВЛЕН", Type = MessageType.Neutral} },
            {28, new MessageDescription{Text = "РЕЖИМ ИМИТАЦИИ СНЯТ", Type = MessageType.Neutral} },
            {29, new MessageDescription{Text = "В ДВИЖЕНИИ. СНЯТИЕ РЕЖИМА ИМИТАЦИИ НЕВОЗМОЖНО", Type = MessageType.Neutral} },
            {30, new MessageDescription{Text = "В ДВИЖЕНИИ. УСТАНОВКА РЕЖИМА ИМИТАЦИИ НЕВОЗМОЖНА", Type = MessageType.Neutral} },
            {32, new MessageDescription{Text = "ОБЕСТОЧЕНА. СНЯТИЕ РЕЖИМА ИМИТАЦИИ НЕВОЗМОЖНО", Type = MessageType.Neutral} },
            {34, new MessageDescription{Text = "КОМАНДА - ОТКРЫТЬ ОТ КНОПКИ ПО МЕСТУ", Type = MessageType.Information} },
            {35, new MessageDescription{Text = "КОМАНДА - ОТКРЫТЬ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
            {36, new MessageDescription{Text = "КОМАНДА - ОТКРЫТЬ С АРМ", Type = MessageType.Information} },
            {37, new MessageDescription{Text = "КОМАНДА - ОТКРЫТЬ ПО ТМ", Type = MessageType.Information} },
            {38, new MessageDescription{Text = "КОМАНДА - ОТКРЫТЬ С БРУ", Type = MessageType.Information} },
            {40, new MessageDescription{Text = "КОМАНДА - ОТКРЫТЬ ОТКЛОНЕНА. ЗАДВИЖКА В НЕОПРЕДЕЛЕННОМ СОСТОЯНИИ", Type = MessageType.Neutral} },
            {41, new MessageDescription{Text = "ОТКРЫТИЕ НЕВОЗМОЖНО. КЛЮЧ В РЕЖИМЕ УПРАВЛЕНИЯ ПО МЕСТУ", Type = MessageType.Neutral} },
            {42, new MessageDescription{Text = "БЛОКИРОВКА УПРАВЛЕНИЯ ОТКРЫТИЯ", Type = MessageType.Neutral} },
            {43, new MessageDescription{Text = "КОМАНДА - ОТКРЫТЬ ОТ ЦСПА", Type = MessageType.Information} },
            {45, new MessageDescription{Text = "КЛЮЧ В РЕЖИМЕ УПРАВЛЕНИЯ ПО ДИСТАНЦИИ", Type = MessageType.Information} },
            {46, new MessageDescription{Text = "КЛЮЧ В РЕЖИМЕ УПРАВЛЕНИЯ ПО МЕСТУ", Type = MessageType.Information} },
            {48, new MessageDescription{Text = "КОМАНДА - ЗАКРЫТЬ ОТ КНОПКИ ПО МЕСТУ", Type = MessageType.Information} },
            {49, new MessageDescription{Text = "КОМАНДА - ЗАКРЫТЬ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
            {50, new MessageDescription{Text = "КОМАНДА - ЗАКРЫТЬ С АРМ", Type = MessageType.Information} },
            {51, new MessageDescription{Text = "КОМАНДА - ЗАКРЫТЬ ПО ТМ", Type = MessageType.Information} },
            {52, new MessageDescription{Text = "КОМАНДА - ЗАКРЫТЬ С БРУ", Type = MessageType.Information} },
            {54, new MessageDescription{Text = "ЗАКРЫТИЕ НЕВОЗМОЖНО. ЗАДВИЖКА В НЕОПРЕДЕЛЕННОМ СОСТОЯНИИ", Type = MessageType.Neutral} },
            {55, new MessageDescription{Text = "ЗАКРЫТИЕ НЕВОЗМОЖНО. КЛЮЧ В РЕЖИМЕ УПРАВЛЕНИЯ ПО МЕСТУ", Type = MessageType.Neutral} },
            {56, new MessageDescription{Text = "БЛОКИРОВКА УПРАВЛЕНИЯ ЗАКРЫТИЯ", Type = MessageType.Neutral} },
            {57, new MessageDescription{Text = "КОМАНДА - ЗАКРЫТЬ ОТ ЦСПА", Type = MessageType.Information} },
            {58, new MessageDescription{Text = "СИГНАЛ СРАБОТКИ МУФТЫ СНЯТ", Type = MessageType.Neutral} },
            {59, new MessageDescription{Text = "ПРИВОД ИСПРАВЕН", Type = MessageType.Neutral} },
            {60, new MessageDescription{Text = "КОМАНДА - СТОП ОТ ЦСПА", Type = MessageType.Information} },
            {61, new MessageDescription{Text = "КОМАНДА - СТОП С БРУ", Type = MessageType.Information} },
            {62, new MessageDescription{Text = "КОМАНДА - СТОП ОТКРЫТИЯ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
            {63, new MessageDescription{Text = "КОМАНДА - СТОП ЗАКРЫТИЯ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
            {64, new MessageDescription{Text = "КОМАНДА - СТОП АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
            {65, new MessageDescription{Text = "КОМАНДА - СТОП C АРМ", Type = MessageType.Information} },
            {66, new MessageDescription{Text = "КОМАНДА - СТОП ПО ТМ", Type = MessageType.Information} },
            {67, new MessageDescription{Text = "КОМАНДА - СТОП ОТКЛОНЕНА. КЛЮЧ В РЕЖИМЕ УПРАВЛЕНИЯ ПО МЕСТУ", Type = MessageType.Neutral} },
            {69, new MessageDescription{Text = "ВЫПОЛНЕНА КОМАНДА СТОП ПО МЕСТУ", Type = MessageType.Information} },
            {70, new MessageDescription{Text = "КОМАНДА СТОП НЕ ВЫПОЛНЕНА. АВАРИЯ", Type = MessageType.Alarm} },
            {71, new MessageDescription{Text = "БЛОКИРОВКА КОМАНДЫ СТОП", Type = MessageType.Neutral} },
            {72, new MessageDescription{Text = "КОМАНДА ОТКЛОНЕНА – НПС В МЕСТНОМ РЕЖИМЕ УПРАВЛЕНИЯ", Type = MessageType.Neutral} },
            {73, new MessageDescription{Text = "КОМАНДА - УСТАНОВИТЬ РЕЖИМ ИМИТАЦИИ", Type = MessageType.Information} },
            {74, new MessageDescription{Text = "КОМАНДА - СНЯТЬ РЕЖИМ ИМИТАЦИИ", Type = MessageType.Information} },
            {77, new MessageDescription{Text = "КОМАНДА - ДЕБЛОКИРОВАТЬ АВАРИЮ ЗАДВИЖКИ", Type = MessageType.Information} },
            {78, new MessageDescription{Text = "ДЕБЛОКИРОВКА НЕВОЗМОЖНА. АВАРИЙНЫЙ СИГНАЛ НЕ СНЯТ", Type = MessageType.Neutral} },
            {79, new MessageDescription{Text = "АВАРИЯ ДЕБЛОКИРОВАНА", Type = MessageType.Neutral} },
            {80, new MessageDescription{Text = "БЛОКИРОВКА ОТКРЫТИЯ СНЯТА", Type = MessageType.Neutral} },
            {81, new MessageDescription{Text = "БЛОКИРОВКА ЗАКРЫТИЯ СНЯТА", Type = MessageType.Neutral} },
            {82, new MessageDescription{Text = "СРАБОТАЛА МУФТА. АВАРИЯ", Type = MessageType.Alarm} },
            {83, new MessageDescription{Text = "АВАРИЯ ПРИВОДА", Type = MessageType.Alarm} },
            {84, new MessageDescription{Text = "ВКЛЮЧЕНЫ МПО И МПЗ. АВАРИЯ", Type = MessageType.Alarm} },
            {85, new MessageDescription{Text = "САМОПРОИЗВОЛЬНОЕ ИЗМЕНЕНИЕ СОСТОЯНИЯ МПЗ. АВАРИЯ", Type = MessageType.Alarm} },
            {86, new MessageDescription{Text = "НЕ ВКЛЮЧИЛСЯ МАГНИТНЫЙ ПУСКАТЕЛЬ. АВАРИЯ", Type = MessageType.Alarm} },
            {87, new MessageDescription{Text = "САМОПРОИЗВОЛЬНОЕ ИЗМЕНЕНИЕ СОСТОЯНИЯ. АВАРИЯ", Type = MessageType.Alarm} },
            {88, new MessageDescription{Text = "МПО ОТКЛЮЧИЛСЯ ПО НЕУСТАНОВЛЕННОЙ ПРИЧИНЕ. АВАРИЯ", Type = MessageType.Alarm} },
            {89, new MessageDescription{Text = "МПЗ ОТКЛЮЧИЛСЯ ПО НЕУСТАНОВЛЕННОЙ ПРИЧИНЕ. АВАРИЯ", Type = MessageType.Alarm} },
            {90, new MessageDescription{Text = "НЕ ЗАКРЫЛАСЬ. АВАРИЯ", Type = MessageType.Alarm} },
            {91, new MessageDescription{Text = "НЕ ВЫШЛА ИЗ КРАЙНЕГО ПОЛОЖЕНИЯ. АВАРИЯ", Type = MessageType.Alarm} },
            {92, new MessageDescription{Text = "НЕ ОТКРЫЛАСЬ. АВАРИЯ", Type = MessageType.Alarm} },
            {93, new MessageDescription{Text = "СРАБОТАЛ МОМЕНТНЫЙ ВЫКЛЮЧАТЕЛЬ ОТКРЫТИЯ. АВАРИЯ", Type = MessageType.Alarm} },
            {94, new MessageDescription{Text = "СРАБОТАЛ МОМЕНТНЫЙ ВЫКЛЮЧАТЕЛЬ ЗАКРЫТИЯ. АВАРИЯ", Type = MessageType.Alarm} },
            {95, new MessageDescription{Text = "НЕ ВКЛЮЧИЛСЯ МАГНИТНЫЙ ПУСКАТЕЛЬ. НЕТ НАПРЯЖЕНИЯ НА СШ ЩСУ", Type = MessageType.Attention} },
            {97, new MessageDescription{Text = "САМОПРОИЗВОЛЬНОЕ ИЗМЕНЕНИЕ СОСТОЯНИЯ МПО. АВАРИЯ", Type = MessageType.Alarm} },
            {98, new MessageDescription{Text = "ЦЕПИ КОНТРОЛЯ МПЗ НЕИСПРАВНЫ. АВАРИЯ", Type = MessageType.Alarm} },
            {99, new MessageDescription{Text = "ПОПЫТКА ВКЛЮЧЕНИЯ МПЗ ИЗ ЩСУ. АВАРИЯ", Type = MessageType.Alarm} },
            {100, new MessageDescription{Text = "ЦЕПИ КОНТРОЛЯ МПО НЕИСПРАВНЫ. АВАРИЯ", Type = MessageType.Alarm} },
            {101, new MessageDescription{Text = "ПОПЫТКА ВКЛЮЧЕНИЯ МПО ИЗ ЩСУ. АВАРИЯ", Type = MessageType.Alarm} },
            {102, new MessageDescription{Text = "МПЗ ОТКЛЮЧИЛСЯ. НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ", Type = MessageType.Attention} },
            {103, new MessageDescription{Text = "МПО ОТКЛЮЧИЛСЯ. НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ", Type = MessageType.Attention} },
            {104, new MessageDescription{Text = "НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ", Type = MessageType.Attention} },
            {105, new MessageDescription{Text = "ЕСТЬ НАПРЯЖЕНИЕ В СХЕМЕ УПРАВЛЕНИЯ", Type = MessageType.Attention} },
            {107, new MessageDescription{Text = "НЕИСПРАВНОСТЬ ЦЕПИ ОТКРЫТИЯ", Type = MessageType.Attention} },
            {108, new MessageDescription{Text = "ЦЕПЬ ОТКРЫТИЯ ИСПРАВНА", Type = MessageType.Neutral} },
            {109, new MessageDescription{Text = "НЕИСПРАВНОСТЬ ЦЕПИ ЗАКРЫТИЯ", Type = MessageType.Attention} },
            {110, new MessageDescription{Text = "ЦЕПЬ ЗАКРЫТИЯ ИСПРАВНА", Type = MessageType.Neutral} },
            {111, new MessageDescription{Text = "МПЗ ОТКЛЮЧИЛСЯ. НЕТ НАПРЯЖЕНИЯ НА СШ ЩСУ", Type = MessageType.Attention} },
            {112, new MessageDescription{Text = "МПО ОТКЛЮЧИЛСЯ. НЕТ НАПРЯЖЕНИЯ НА СШ ЩСУ", Type = MessageType.Attention} },
            {113, new MessageDescription{Text = "НЕТ ДАННЫХ ПО ИНТЕРФЕЙСНОМУ КАНАЛУ", Type = MessageType.Attention} },
            {114, new MessageDescription{Text = "ЕСТЬ ДАННЫЕ ПО ИНТЕРФЕЙСНОМУ КАНАЛУ", Type = MessageType.Neutral} },
            {115, new MessageDescription{Text = "ПОЛУЧЕН СИГНАЛ «МПЗ ОТКЛЮЧЕН»", Type = MessageType.Neutral} },
            {116, new MessageDescription{Text = "ПОЛУЧЕН СИГНАЛ «МПО ОТКЛЮЧЕН»", Type = MessageType.Neutral} },
            {117, new MessageDescription{Text = "СИГНАЛ РАБОТЫ МОМЕНТНОГО ВЫКЛЮЧАТЕЛЯ ОТКРЫТИЯ СНЯТ", Type = MessageType.Neutral} },
            {118, new MessageDescription{Text = "СИГНАЛ РАБОТЫ МОМЕНТНОГО ВЫКЛЮЧАТЕЛЯ ЗАКРЫТИЯ СНЯТ", Type = MessageType.Neutral} },
            {119, new MessageDescription{Text = "ПОЛУЧЕН СИГНАЛ «МПЗ ВКЛЮЧЕН»", Type = MessageType.Neutral} },
            {120, new MessageDescription{Text = "ПОЛУЧЕН СИГНАЛ «МПО ВКЛЮЧЕН»", Type = MessageType.Neutral} },
            {122, new MessageDescription{Text = "НЕ ДВИЖЕТСЯ. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {123, new MessageDescription{Text = "ИЗМЕНЕНИЕ СОСТОЯНИЯ С ПОМОЩЬЮ МЕХАНИЧЕСКОГО ДУБЛЁРА", Type = MessageType.Neutral} },
            {124, new MessageDescription{Text = "СОСТОЯНИЕ СТОП", Type = MessageType.Neutral} },
            {128, new MessageDescription{Text = "ДАННЫЕ ПО ФИЗИЧЕСКОМУ И ИНТЕРФЕЙСНОМУ КАНАЛУ СИНХРОНИЗИРОВАНЫ", Type = MessageType.Neutral} },
            {129, new MessageDescription{Text = "ДАННЫЕ ПО ФИЗИЧЕСКОМУ КАНАЛУ ОТЛИЧАЮТСЯ ОТ ИНТЕРФЕЙСНЫХ", Type = MessageType.Neutral} },
        };
        protected static Dictionary<int, TimerDescription> TimerDescriptions = new Dictionary<int, TimerDescription>
        {
            {1, new TimerDescription("Время переходных процессов", TimeSpan.FromMilliseconds(0)) },
            {2, new TimerDescription("Ожидание прихода сигнала от МП после команды на открытия/закрытие", TimeSpan.FromMilliseconds(3000)) },
            {3, new TimerDescription("Время схода с КВЗ/КВО", TimeSpan.FromMilliseconds(5000)) },
            {4, new TimerDescription("Время хода вала", TimeSpan.FromMilliseconds(180000)) },
            {5, new TimerDescription("Время на отключение МП в крайних положениях", TimeSpan.FromMilliseconds(1000)) },
            {6, new TimerDescription("Время на возврат напряжения при стопе по месту", TimeSpan.FromMilliseconds(3000)) },
            {7, new TimerDescription("Время \"выполнения\" команды на открытие при имитации задвижки", TimeSpan.FromMilliseconds(10000)) },
            {8, new TimerDescription("Время на подачу команды СТОП", TimeSpan.FromMilliseconds(1000)) },
            {9, new TimerDescription("Время на ожидание возврата концевиков после команды стоп", TimeSpan.FromMilliseconds(1000)) },
            {10, new TimerDescription("Время на выполнение команд с БРУ", TimeSpan.FromMilliseconds(1000)) },
            {11, new TimerDescription("Время на проверку неисправности цепей включения", TimeSpan.FromMilliseconds(3000)) },
            {12, new TimerDescription("Время на проверку неисправности цепей отключения", TimeSpan.FromMilliseconds(3000)) },
            {13, new TimerDescription("Время рассогласования между сигналами по физическому и интерфейсному каналу", TimeSpan.FromMilliseconds(3000)) },
            {14, new TimerDescription("Время на задержку при подозрительных переходах", TimeSpan.FromMilliseconds(5000)) },
        };

    }
}
