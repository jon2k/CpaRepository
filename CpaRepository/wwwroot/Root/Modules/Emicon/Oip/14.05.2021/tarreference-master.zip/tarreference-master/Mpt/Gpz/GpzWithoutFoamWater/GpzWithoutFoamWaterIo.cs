﻿using System.Collections.Generic;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;
using TarReferenceSource.Mpt.Gpz.GpzFoam;

namespace TarReferenceSource.Mpt.Gpz.GpzWithoutFoamWater
{
    /// <summary>
    /// Входные данные для модуля GpzWithoutFoamWater
    /// </summary>
    public class GpzWithoutFoamWaterIoInput
    {
        /// <summary>
        /// Флаг отсутствия необходимого количества исправных ПИ на защищаемом сооружении (по результатам работы модуля SensorCard).
        /// </summary>
        public bool SensorsNotEnoughSensors; // Флаг отсутствия необходимого количества исправных ПИ на защищаемом сооружении (по результатам работы модуля SensorCard).
        /// <summary>
        ///  Флаг наличия маскирования агрегатной защиты по пожару защищаемого сооружения (по результатам работы модуля KTPRP).
        /// </summary>
        public bool ProtM; // Флаг наличия маскирования агрегатной защиты по пожару защищаемого сооружения (по результатам работы модуля KTPRP).
        /// <summary>
        /// Флаг наличия ремонтного режима сооружения.
        /// </summary>
        public bool IsRem; // Флаг наличия ремонтного режима сооружения.
        /// <summary>
        /// Флаг наличия требования запуска и успешного включения оборудования.
        /// </summary>
        public bool SuccessfulStart; // Флаг наличия требования запуска и успешного включения оборудования.
        /// <summary>
        /// Количество параметров готовности.
        /// </summary>
        public int ReadinesCount; // Количество параметров готовности.
        /// <summary>
        /// Массив флагов отключенности обработки готовностей.
        /// </summary>
        public StArray<bool> CfgDisabled; // Массив флагов отключенности обработки готовностей.
        /// <summary>
        /// Количество защит по пожару сооружения. 
        /// </summary>
        public uint CountProt; // Количество защит по пожару сооружения. 
    }
    public abstract class GpzWithoutFoamWaterIo : IFunctionBlock
    {
        // in
        /// <summary>
        ///  input Входные данные для модуля
        /// </summary>
        public GpzWithoutFoamWaterIoInput Source;

        // out
        /// <summary>
        /// output Массив флагов готовности по каждому фактору готовности.
        /// </summary>
        public StArray<bool> Output; // Массив флагов готовности по каждому фактору готовности.
        /// <summary>
        /// output Статус готовности защищаемого сооружения: 0 – нет готовности, 1 – готово, 2 – не контролируется . 
        /// </summary>
        public GpzState Out; // Статус готовности защищаемого сооружения: 0 – нет готовности, 1 – готово, 2 – не контролируется . 

        public GpzWithoutFoamWaterIo()
        {
            Source = new GpzWithoutFoamWaterIoInput();
            Source.CfgDisabled = new StArray<bool>(1, new bool[2]);
            Source.ReadinesCount = 2;
            Output = new StArray<bool>(1, new bool[2]);
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {         
            {1, new MessageDescription{Text = "НЕДОСТАТОЧНО ИСПРАВНЫХ ПОЖАРНЫХ ИЗВЕЩАТЕЛЕЙ. ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {2, new MessageDescription{Text = "НЕДОСТАТОЧНО ИСПРАВНЫХ ПОЖАРНЫХ ИЗВЕЩАТЕЛЕЙ. ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },          
            {3, new MessageDescription{Text = "МАСКИРОВАНИЕ ЗАЩИТЫ ПО ПОЖАРУ. ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {4, new MessageDescription{Text = "МАСКИРОВАНИЕ ЗАЩИТЫ ПО ПОЖАРУ. ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },       
        };
    }
}
