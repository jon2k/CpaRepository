﻿using System.Collections.Generic;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;

namespace TarReferenceSource.Mpt.Upts
{
    public abstract class UptsIo : IFunctionBlock
    {
        public UptsIo()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }
        //in
        public ushort Cmd;
        public bool Input;

        public bool CorrCv;
        public bool EnableCmd;
        public bool EnableCvCheck;
        public bool IsSiren;
        //out
        public bool OnCmdOut;
        public bool CorrCvOut;

        public override void AfterCall()
        {
            Cmd = 0;
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {
            {1, new MessageDescription{Text = "ОТКЛЮЧИТЬ ВСЕ СИРЕНЫ ИЗ МДП", Type = MessageType.Neutral} },
            {2, new MessageDescription{Text = "ВКЛЮЧИТЬ ИЗ МДП", Type = MessageType.Neutral} },
            {3, new MessageDescription{Text = "ОТКЛЮЧИТЬ ИЗ МДП", Type = MessageType.Neutral} },
            {4, new MessageDescription{Text = "ВКЛЮЧИТЬ АВТОМАТИЧЕСКИ", Type = MessageType.Neutral} },
            {5, new MessageDescription{Text = "ОТКЛЮЧИТЬ АВТОМАТИЧЕСКИ", Type = MessageType.Neutral} },
            {6, new MessageDescription{Text = "ЦЕПЬ ВКЛЮЧЕНИЯ ИСПРАВНА", Type = MessageType.Neutral} },
            {7, new MessageDescription{Text = "ЦЕПЬ ВКЛЮЧЕНИЯ НЕИСПРАВНА", Type = MessageType.Neutral} },
            {8, new MessageDescription{Text = "ВЫПОЛНЕНИЕ КОМАНДЫ НЕВОЗМОЖНО. БЛОКИРОВКА", Type = MessageType.Neutral} },
            {9, new MessageDescription{Text = "ОТКЛЮЧЕНА ПО КОМАНДЕ «ОТКЛЮЧИТЬ ВСЕ СИРЕНЫ»", Type = MessageType.Neutral} },
            {20, new MessageDescription{Text = "таймер", Type = MessageType.Neutral} },
        };
    }
}
