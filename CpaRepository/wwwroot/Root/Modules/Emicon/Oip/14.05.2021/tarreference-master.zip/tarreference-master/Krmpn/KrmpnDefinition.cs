﻿namespace TarReferenceSource.Krmpn
{
    class KrmpnDefinition
    {
    }
}
