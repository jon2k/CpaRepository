﻿using System.Collections.Generic;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;

namespace TarReferenceSource.Mpt.Gpz.ProcGpz
{
    public abstract class ProcGpzIo:IFunctionBlock
    {
        // in
        public bool Input;
        public uint X;
        // out
        public bool Output;

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {
            {1, new MessageDescription{Text = "ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Information} },
            {2, new MessageDescription{Text = "ГОТОВНОСТЬ СНЯТА", Type = MessageType.Information} },
        };
    }
}
