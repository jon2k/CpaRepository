﻿using Friday.Helpers;
using Friday.Runtime.CpaLocal;

namespace TarReferenceSource.Mpt.Ktprp.ProcKtprp
{
    public class ProcKtprp : ProcKtprpIo
    {
        public ProcKtprp()
        {

        }

        public override void Execute()
        {
            /*распаковочка*/
            Result.NP = false;

            if (cmd == enumFireProtCmd.Mask)
            {
                Messenger.Send(1);     // КОМАНДА - УСТАНОВИТЬ МАСКИРОВАНИЕ 
                if (Result.M)
                {
                    Messenger.Send(3); // МАСКИРОВАНИЕ УСТАНОВЛЕНО. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ
                }
                else
                {
                    Messenger.Send(2); // МАСКИРОВАНИЕ УСТАНОВЛЕНО
                    Result.M = true;
                }
            }
            if (cmd == enumFireProtCmd.Unmask)
            {
                Messenger.Send(4);      //  КОМАНДА - СНЯТЬ МАСКИРОВАНИЕ 
                if (!Result.M)
                {
                    Messenger.Send(6); //  МАСКИРОВАНИЕ СНЯТО. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ
                }
                else
                {
                    Messenger.Send(5); //  МАСКИРОВАНИЕ СНЯТО
                    Result.M = false;
                }
            }
            if (cmd == enumFireProtCmd.Deblock)
            {
                Messenger.Send(7);         //  КОМАНДА - ДЕБЛОКИРОВАТЬ 
                if (!Result.P)
                {
                    Messenger.Send(10); //  ДЕБЛОКИРОВКА НЕ ТРЕБУЕТСЯ. ЗАЩИТА НЕ СРАБОТАНА
                }
                else if ((Result.F && !Result.M))
                {
                    Messenger.Send(8); //   ДЕБЛОКИРОВКА НЕВОЗМОЖНА. АВАРИЙНЫЙ СИГНАЛ НЕ СНЯТ
                }
                else if (FirefightInProgress)
                {
                    Messenger.Send(12);//ДЕБЛОКИРОВКА НЕВОЗМОЖНА. ИДЕТ ТУШЕНИЕ ПОЖАРА
                }
                else
                {
                    Messenger.Send(9); //   ДЕБЛОКИРОВАНА
                    Result.P = false;
                }
            }

            if (Input && !Result.F && Result.M)
            {
                Messenger.Send(15);//игнорирована по причине маскирования
            }

            if (Input && !Result.P && !Result.M)
            {
                Messenger.Send(14);//
                Result.P = true;
                Result.NP = true;
            }

            if (!Input && Result.F)
            {
                Messenger.Send(13);//аварийный параметр снят
            }

            Result.F = Input;
        }
    }
}
