﻿using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarReferenceSource.Mpt.Ubd.ProcUbd;

namespace TarReferenceSource.Mpt.Ubd.UbdGrp
{
    internal class structUbdGrpStorage
    {
        public ushort needOpenCountPrev;
    }
    public class UbdGrp : UbdGrpIo
    {
        /// <summary>
        /// Внутреннее состояние модуля
        /// </summary>
        private structUbdGrpStorage storage;

        public UbdGrp(ProcUbdIo[] bds) : base(bds)
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(ProcUbdIo.messages));
            storage = new structUbdGrpStorage();
        }

        public override void Execute()
        {
            
            int needOpenCount = input.NeedOpenCount;

            output.allLowFull = true;
            output.allNotCrashed = true;
            output.allNotImit = true;
            output.haveNotEmpty = false;
            output.allClose = true;
            output.openCount = 0;
            output.readyCount = 0;
            output.osnRezCount = 0;
            var osnCount = 0;
            var RezIndex = 1;
            for (int NumBD = 1; NumBD <= UbdCount; NumBD++)
            {                            
                if (bd[NumBD].mode != UbdMode.rem)
                {
                    output.osnRezCount = (ushort)(output.osnRezCount + 1);
                }

                if (bd[NumBD].mode == UbdMode.osn)
                {
                    osnCount = (ushort)(osnCount + 1);
                }
                if (bd[NumBD].ready)
                {
                    output.readyCount = output.readyCount + 1;
                }
                else
                {
                    output.allLowFull = output.allLowFull && (bd[NumBD].full || bd[NumBD].low);
                    output.allNotCrashed = output.allNotCrashed && !bd[NumBD].err;
                    output.allNotImit = output.allNotImit && !(bd[NumBD].input.ZdStateIn.Imit || bd[NumBD].input.ZdStateOut.Imit);
                }
                output.allClose = output.allClose && (bd[NumBD].state == UbdState.closed || bd[NumBD].mode == UbdMode.rem);
                if (!bd[NumBD].empty && bd[NumBD].mode != UbdMode.rem)
                {
                    output.haveNotEmpty = true;
                }
                if (bd[NumBD].state == UbdState.opened && bd[NumBD].mode == UbdMode.osn)
                {
                    output.openCount = (ushort)(output.openCount + 1);
                }
                
            }

            for (int NumBD = 1; NumBD <= UbdCount; NumBD++)
            {
                if (osnCount == 0)
                {
                    bd[NumBD].canBeRez = false;
                    if (bd[NumBD].mode == UbdMode.rez)
                    {
                        osnCount = 1;
                    }
                }
                else
                {
                    bd[NumBD].canBeRez = (bd[NumBD].mode != UbdMode.osn && osnCount == 1) || (osnCount > 1);
                }
            }

            var numBD = 1;
            if (input.FirefightStart)
            {
                for (int i = 1; i < 2; i++)//вначале обрабатываем готовые, потом остальные
                {
                    var processingReady = i == 1;
                    var rezIndex = 1;
                    //АВР
                    for (int NumBD = 1; NumBD <= UbdCount; NumBD++)
                    {
                        for (; rezIndex <= UbdCount; rezIndex++)
                        {
                            if (bd[numBD].mode == UbdMode.rez && bd[rezIndex].ready == processingReady)
                            {
                                Messenger.Send(14);//автоматическое включение резерва
                                bd[numBD].openCmd = true;
                                bd[numBD].closeCmd = false;
                                bd[numBD].needRezOn = false;
                                break;
                            }
                        }
                        bd[NumBD].needRezOn = bd[NumBD].needRezOn && processingReady;
                    }
                    /*2*/
                    //считаем те, на которых уже висит команда
                    for (int NumBD = 1; NumBD <= UbdCount; NumBD++)
                    {
                        if (bd[numBD].mode != UbdMode.rem)
                        {
                            if (processingReady)
                            {
                                if (needOpenCount > 0)
                                {
                                    if (bd[numBD].openCmd)
                                    {
                                        needOpenCount = needOpenCount - 1;
                                    }
                                }
                                else
                                {
                                    bd[NumBD].openCmd = false;
                                }
                            }
                            else if (needOpenCount > 0)
                            {
                                if (bd[numBD].mode == UbdMode.rez && !bd[numBD].ready)
                                {
                                    if (bd[numBD].openCmd)
                                    {
                                        needOpenCount = needOpenCount - 1;
                                    }
                                    else
                                    {
                                        bd[numBD].openCmd = false;
                                    }
                                }
                            }
                        }
                    }
                    //вешаем команды на те, что уже открыты
                    for (int NumBD = 1; NumBD <= UbdCount; NumBD++)
                    {
                        if (bd[NumBD].mode == UbdMode.osn && !bd[NumBD].openCmd &&
                            bd[NumBD].state == UbdState.opened && bd[NumBD].ready == processingReady)
                        {
                            if (needOpenCount > 0)
                            {
                                bd[NumBD].openCmd = true;
                                bd[NumBD].closeCmd = false;
                                needOpenCount = needOpenCount - 1;
                            }
                            else if (!bd[NumBD].closeCmd)
                            {
                                bd[NumBD].closeCmd = true;
                                Messenger.Send(24);//автоматическое закрытие избыточного бака дозатора
                            }
                        }
                    }
                    //вешаем команды на остальные в ОСН
                    for (int NumBD = 1; NumBD <= UbdCount; NumBD++)
                    {
                        if (bd[NumBD].mode == UbdMode.osn && !bd[NumBD].openCmd &&
                            bd[NumBD].state != UbdState.opened && bd[NumBD].ready == processingReady)
                        {
                            if (needOpenCount > 0)
                            {
                                bd[NumBD].openCmd = true;
                                bd[NumBD].closeCmd = false;
                                needOpenCount = needOpenCount - 1;
                            }
                            else if (!bd[NumBD].closeCmd)
                            {
                                bd[NumBD].closeCmd = true;
                                Messenger.Send(24);//автоматическое закрытие избыточного бака дозатора
                            }
                        }
                    }

                    if (needOpenCount > 0 && storage.needOpenCountPrev != input.NeedOpenCount && !processingReady)
                    {
                        Messenger.Send(15);//недостаточное количество БД в режиме основной
                    }

                    for (int NumBD = 1; NumBD <= UbdCount; NumBD++)
                    {
                        if (needOpenCount > 0)
                        {
                            if (bd[NumBD].mode == UbdMode.rez &&
                                !bd[NumBD].openCmd && bd[NumBD].ready == processingReady)
                            {
                                bd[NumBD].openCmd = true;
                                bd[NumBD].closeCmd = false;
                                needOpenCount = needOpenCount - 1;
                            }
                        }
                    }

                    if (needOpenCount > 0 && storage.needOpenCountPrev != input.NeedOpenCount && !processingReady)
                    {
                        Messenger.Send(16);//недостаточное количество БД в режиме резервный
                    }
                }
                
            }
            else if (input.FirefightStop)
            {
                for (int NumBD = 1; NumBD <= UbdCount; NumBD++)
                {
                    if (bd[NumBD].mode == UbdMode.osn)
                    {
                        bd[NumBD].closeCmd = true;
                        bd[NumBD].openCmd = false;
                        bd[NumBD].needRezOn = false;
                    }
                }
            }
            else
            {
                for (int NumBD = 1; NumBD <= UbdCount; NumBD++)
                {
                    if (bd[NumBD].mode == UbdMode.osn)
                    {
                        bd[NumBD].closeCmd = false;
                        bd[NumBD].openCmd = false;
                        bd[NumBD].needRezOn = false;
                    }
                }
            }
            storage.needOpenCountPrev = input.NeedOpenCount;
        }
    }
}
