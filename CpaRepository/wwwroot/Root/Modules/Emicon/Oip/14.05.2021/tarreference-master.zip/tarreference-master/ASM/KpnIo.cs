﻿using TarReferenceSource.ASM;
using TarReferenceSource.Uzd;
using TarFoundation.St;

namespace KPN
{
    public abstract class KpnIo : IFunctionBlock
    {
        // Input.
        /// <summary>
        /// input Матрица смежности задвижек.
        /// </summary>
        public StArray<StArray<uint>> MSM;
        /// <summary>
        /// input Количество задвижек в рассчитываемом маршруте.
        /// </summary>
        public uint ElementSize => (uint)States.Count;
        /// <summary>
        /// input Массив начальных точек рассчитываемого маршрута.
        /// </summary>
        public StArray<uint> StartPointCount;
        /// <summary>
        /// input Максимальная связность задвижек маршрута.
        /// </summary>
        public uint Connectivy;
        /// <summary>
        /// input Массив состояний задвижек маршрута.
        /// </summary>
        public StArray<ZdState> States;

        // Output.
        /// <summary>
        /// output Массив массивов состояний маршрутов.
        /// </summary>
        public StArray<StArray<PathState>> Results;
        public KpnIo(StArray<StArray<uint>> msm, StArray<uint> startPointCount)
        {
            MSM = msm;
            StartPointCount = startPointCount;
            States = new StArray<ZdState>(1, new ZdState[startPointCount.Count]);
        }
    }
}
