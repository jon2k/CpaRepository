﻿using System.Collections.Generic;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarReferenceSource.CommonNa;

namespace TarReferenceSource.Oip
{
    public abstract class ProcVibrLevelsIo : AbstractProcLevels
    {
        private readonly NaIo _na;

        public ProcVibrLevelsIo(ISignalDataSource signalSource, NaIo na) : base(signalSource)
        {
            _na = na;
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(message));
        }
        //интерфейс модуля

        public override bool IsLevel(int lvlNum)
        {
            var levels = new List<bool>
            {
                IsMT10Perc,
                IsNdv2ndParam,
                IsHighVibNoStat,
                IsAvarVibNoStat,
                IsHighVibStat,
                IsAvarVibStat,
                IsHighVibStatNMNWR,
                IsAvarVibStatNMNWR,
                IsAvar2Vib,
            };

            return levels[lvlNum - 1];
        }

        public override LevelConfig GetLevelsConfig(int lvlNum)
        {
            return LevelCfgs[lvlNum - 1];
        }

        /// <summary>
        /// input Признак работы в нестационарном режиме. 1 –работа в нестационарном режиме. 0 –работа в стационарном режиме
        /// </summary>
        public bool HighVib { get; set; }
        /// <summary>
        /// input Признак работы в неноминальном интервале подач. 1 –работа в номинальном интервале подач. 0 –работа в неноминальном интервале подач
        /// </summary>
        public bool NeNomIntervalPodach { get; set; }
        /// <summary>
        /// input состояние насосного агрегата. 1 – НА в работе. 2 – НА не в работе
        /// </summary>
        public bool NaIsOn { get; set; }
        /// <summary>
        /// input Конфигурации уровней вибрации 
        /// </summary>
        public LevelConfig[] LevelCfgs { get; set; } = { new LevelConfig(), new LevelConfig(), new LevelConfig(), new LevelConfig(), new LevelConfig(), new LevelConfig(), new LevelConfig(), new LevelConfig(), new LevelConfig(), };
        /// <summary>
        /// output Уставка 10% от диапазона измерений (готовность НА). 1 – вибрация превышает заданный порог. 0 – вибрация не превышает заданный порог
        /// </summary>
        public bool IsMT10Perc { get; set; }
        /// <summary>
        /// output 7,1 мм/с (для обработки недостоверности измерения вибрации в группе датчиков). 1 – вибрация превышает заданный порог. 0 – вибрация не превышает заданный порог
        /// </summary>
        public bool IsNdv2ndParam { get; set; }
        /// <summary>
        /// output Повышенная вибрация НА в пусковом режиме. 1 – вибрация превышает заданный порог. 0 – вибрация не превышает заданный порог
        /// </summary>
        public bool IsHighVibNoStat { get; set; }
        /// <summary>
        /// output Аварийная максимальная вибрация в пусковом режиме. 1 – вибрация превышает заданный порог. 0 – вибрация не превышает заданный порог
        /// </summary>
        public bool IsAvarVibNoStat { get; set; }
        /// <summary>
        /// output Повышенная вибрация в непусковом режиме (для насосов типа НМ – в рабочем интервале подач). 1 – вибрация превышает заданный порог. 0 – вибрация не превышает заданный порог
        /// </summary>
        public bool IsHighVibStat { get; set; }
        /// <summary>
        /// output Аварийная максимальная вибрация в непусковом режиме (для насосов типа НМ – в рабочем интервале подач). 1 – вибрация превышает заданный порог. 0 – вибрация не превышает заданный порог
        /// </summary>
        public bool IsAvarVibStat { get; set; }
        /// <summary>
        /// output Повышенная вибрация в непусковом режиме для насосов типа НМ в нерабочем интервале подач. 1 – вибрация превышает заданный порог. 0 – вибрация не превышает заданный порог
        /// </summary>
        public bool IsHighVibStatNMNWR { get; set; }
        /// <summary>
        /// output Аварийная максимальная вибрация в непусковом режиме для насосов типа НМ в нерабочем интервале подач. 1 – вибрация превышает заданный порог. 0 – вибрация не превышает заданный порог
        /// </summary>
        public bool IsAvarVibStatNMNWR { get; set; }
        /// <summary>
        /// output Аварийная максимальная вибрация (порог 2). 1 – вибрация превышает заданный порог. 0 – вибрация не превышает заданный порог
        /// </summary>
        public bool IsAvar2Vib { get; set; }

        public override void BeforeCall()
        {
            base.BeforeCall();
            if (_na != null)
            {
                HighVib = _na.HighVibrEngOut || _na.HighVibrPumpOut;
                NeNomIntervalPodach = _na.NeNomIntervalPodach;
                NaIsOn = _na.MainStateOut == NaState.Vkl;
            }
        }

        public static Dictionary<uint, MessageDescription> message = new Dictionary<uint, MessageDescription>
        {
            {1, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ ИМИТАЦИИ", Type = MessageType.Neutral} },
            {2, new MessageDescription{Text = "РЕЖИМ ИМИТАЦИИ СНЯТ", Type = MessageType.Neutral} },
            {3, new MessageDescription{Text = "НЕДОСТОВЕРЕН. ИЗМЕРИТЕЛЬНЫЙ КАНАЛ НЕИСПРАВЕН", Type = MessageType.Neutral} },
            {4, new MessageDescription{Text = "НЕДОСТОВЕРНОСТЬ. НПД", Type = MessageType.Neutral} },
            {5, new MessageDescription{Text = "НЕДОСТОВЕРНОСТЬ. ВПД", Type = MessageType.Neutral} },
            {6, new MessageDescription{Text = "ДОСТОВЕРЕН (РЕЖИМ ИМИТАЦИИ)", Type = MessageType.Neutral} },
            {7, new MessageDescription{Text = "ДОСТОВЕРЕН", Type = MessageType.Neutral} },
            {20, new MessageDescription{Text = "НОРМА", Type = MessageType.Neutral} },
            {21, new MessageDescription{Text = "«10% от диапазона измерений» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
            {22, new MessageDescription{Text = "«10% от диапазона измерений» СНЯТ", Type = MessageType.Neutral} },
            {23, new MessageDescription{Text = "«10% от диапазона измерений»", Type = MessageType.Neutral} },
            {24, new MessageDescription{Text = "«7,1 мм/с» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
            {25, new MessageDescription{Text = "«7,1 мм/с» СНЯТ", Type = MessageType.Neutral} },
            {26, new MessageDescription{Text = "«7,1 мм/с»", Type = MessageType.Neutral} },
            {27, new MessageDescription{Text = "«повышенная вибрация НА в пусковом режиме» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
            {28, new MessageDescription{Text = "«повышенная вибрация НА в пусковом режиме» СНЯТ", Type = MessageType.Neutral} },
            {29, new MessageDescription{Text = "«повышенная вибрация НА в пусковом режиме»", Type = MessageType.Neutral} },
            {30, new MessageDescription{Text = "«аварийная максимальная вибрация в пусковом режиме» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
            {31, new MessageDescription{Text = "«аварийная максимальная вибрация в пусковом режиме» СНЯТ", Type = MessageType.Neutral} },
            {32, new MessageDescription{Text = "«аварийная максимальная вибрация в пусковом режиме»", Type = MessageType.Neutral} },
            {33, new MessageDescription{Text = "«повышенная вибрация в непусковом режиме» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
            {34, new MessageDescription{Text = "«повышенная вибрация в непусковом режиме» СНЯТ", Type = MessageType.Neutral} },
            {35, new MessageDescription{Text = "«повышенная вибрация в непусковом режиме»", Type = MessageType.Neutral} },
            {36, new MessageDescription{Text = "«аварийная максимальная вибрация в непусковом режиме» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
            {37, new MessageDescription{Text = "«аварийная максимальная вибрация в непусковом режиме» СНЯТ", Type = MessageType.Neutral} },
            {38, new MessageDescription{Text = "«аварийная максимальная вибрация в непусковом режиме»", Type = MessageType.Neutral} },
            {39, new MessageDescription{Text = "«повышенная вибрация в непусковом режиме для насосов типа НМ в нерабочем интервале подач» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
            {40, new MessageDescription{Text = "«повышенная вибрация в непусковом режиме для насосов типа НМ в нерабочем интервале подач» СНЯТ", Type = MessageType.Neutral} },
            {41, new MessageDescription{Text = "«повышенная вибрация в непусковом режиме для насосов типа НМ в нерабочем интервале подач»", Type = MessageType.Neutral} },
            {42, new MessageDescription{Text = "«аварийная максимальная вибрация в непусковом режиме для насосов типа НМ в нерабочем интервале подач» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
            {43, new MessageDescription{Text = "«аварийная максимальная вибрация в непусковом режиме для насосов типа НМ в нерабочем интервале подач» СНЯТ", Type = MessageType.Neutral} },
            {44, new MessageDescription{Text = "«аварийная максимальная вибрация в непусковом режиме для насосов типа НМ в нерабочем интервале подач»", Type = MessageType.Neutral} },
            {45, new MessageDescription{Text = "«аварийная максимальная вибрация (порог 2)» СНЯТ (БЛОКИРОВКА)", Type = MessageType.Neutral} },
            {46, new MessageDescription{Text = "«аварийная максимальная вибрация (порог 2)» СНЯТ", Type = MessageType.Neutral} },
            {47, new MessageDescription{Text = "«аварийная максимальная вибрация (порог 2)»", Type = MessageType.Neutral} },
        };
    }
}
