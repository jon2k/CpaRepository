﻿using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TarReferenceSource.Mpt.ManualFire
{
    public class ManualFire : ManualFireIo
    {
        public ManualFire()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }
        public override void Execute()
        {
            if (ButtonFire)
            {
                Messenger.Send(1);
                Fire = true;
            }
            else
                Fire = false;
        }
    }
}
