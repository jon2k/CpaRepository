﻿using TarFoundation.St;
using TarReferenceSource.Uzd;

namespace TarReferenceSource.ASM
{
   
    class Asm : AsmIo
    {
        /// <summary>
        /// Массив помеченных для обхода узлов графа.
        /// </summary>
        private StArray<bool> vizitBuf;
        /// <summary>
        /// Указатель на вершину стека помеченных для обхода узлов графа (задвижек).
        /// </summary>
        private int sz;
        /// <summary>
        /// Стек помеченных для обхода узлов графа (задвижек).
        /// </summary>
        private StArray<int> toVizit;
        /// <summary>
        /// Текущий узел (задвижка), назначенная для обхода.
        /// </summary>
        private int cur;
        /// <summary>
        /// Состояние маршрута от начальной точки до текущего узла (задвижки).
        /// </summary>
        private PathState path;
        /// <summary>
        /// Индексатор массива
        /// </summary>
        private int i;
        /// <summary>
        /// Индексатор массива
        /// </summary>
        private int k;
        /// <summary>
        /// Индексатор массива
        /// </summary>
        private int k2;
        /// <summary>
        /// Массив состояний задвижек, приведенный к виду PathState.
        /// </summary>
        private StArray<PathState> valveState;


        public Asm(int elementSize)
        {
            valveState = new StArray<PathState>(1, new PathState[elementSize]);
            vizitBuf = new StArray<bool>(1, new bool[elementSize]);
            toVizit = new StArray<int>(1, new int[elementSize]);
        }

        public override void Execute()
        {
            // Изменяем массив состояния задвижек с типа ZdState на тип PathState. 
            for (i = 1; i <= ElementSize; i++)
            {
                switch (States[i])
                {
                    case ZdState.Closed:
                        valveState[i] = PathState.Close;
                        break;
                    case ZdState.Opened:
                        valveState[i] = PathState.Open;
                        break;
                    default:
                        valveState[i] = PathState.Other;
                        break;
                }
            }

            for (k = 1; k <= ElementSize; k++)
            {
                Result[k] = PathState.Close;
            }

            toVizit[1] = (int)StartPoint;
            Result[(int)StartPoint] = PathState.Open;
            sz = 1;

            while (sz > 0)
            {
                cur = toVizit[sz];
                sz = sz - 1;

                for (k = 1; k <= Connectivy; k++)
                {
                    if (MSM[cur][k] != 0)
                    {
                        // path = Math.Min(_valveState[_cur], _valveState[(int)MSM[_cur][_k] -1]);
                        // path = Math.Min(path, Result[_cur]);
                        if (valveState[cur] <= valveState[(int)MSM[cur][k]])
                        {
                            path = valveState[cur];
                        }
                        else
                        {
                            path = valveState[(int)MSM[cur][k]];
                        }
                        if (path > Result[cur])
                        {
                            path = Result[cur];
                        }

                        if (path > Result[(int)MSM[cur][k]])
                        {
                            vizitBuf[(int)MSM[cur][k]] = true;
                            Result[(int)MSM[cur][k]] = path;
                        }
                    }

                    for (i = 1; i <= sz; i++)
                    {
                        vizitBuf[(int)toVizit[i]] = false;
                    }

                    for (k2 = 1; k2 <= ElementSize; k2++)
                    {
                        if (vizitBuf[k2])
                        {
                            toVizit[sz + 1] = k2;
                            sz = sz + 1;
                            vizitBuf[(int)k2] = false;
                        }
                    }
                }
            }
        }
    }
}
