﻿using System.Linq;
using TarReferenceSource.CommonNa;

namespace TarReferenceSource.Oip
{
    /*
     * Реализован без использования ProcLevels, только ProcMax => не храним уровни, которые не используем
     * Задан новый порядок сообщений по уровням
     */
    public class ProcVibrLevels : ProcVibrLevelsIo
    {
        /// <summary>
        /// Не используется в коде. Проверить!
        /// </summary>
        private readonly OipElectric _oipElectric;
        /// <summary>
        /// Массив уровней.
        /// </summary>
        private LevelState[] levels = Enumerable.Range(1, 9).Select(i=>new LevelState()).ToArray();
        /// <summary>
        /// Цифровое отображение текущего уровня измеряемого параметра
        /// </summary>
        private int zone;
        /// <summary>
        /// Значение параметра
        /// </summary>
        private float val;

        public ProcVibrLevels(ISignalDataSource signalSource, NaIo na) : base(signalSource, na)
        {
            
        }

        public override void Execute()
        {
            if (!Signal.Ndv)
            {
                /*если сигнал недостоверен, то не обрабатываем*/
                val = Signal.VisualValue;
            }

            var normMsgFl = zone != 0;
            zone = 0;

            for (int i = 0; i < 9; i++)
            {
                levels[i].Block = true;
            }
            levels[1].Block = false ;
            levels[8].Block = false ;

            if (HighVib)
            {
                levels[2].Block = false;
                levels[3].Block = false;
            }
            else if (NaIsOn)
            {
                if (NeNomIntervalPodach)
                {
                    levels[6].Block = false;
                    levels[7].Block = false;
                }
                else
                {
                    levels[4].Block = false;
                    levels[5].Block = false;
                }
            }
            else
            {
                levels[0].Block = false;
            }

            //снимаем уровни по блокировкам
            for (int i = 0; i < 9; i++)
            {
                OipHelpers.ProcMax(val, LevelCfgs[i], Hist, levels[i], false, false, true, i, Messenger);
            }

            //устанавливаем уровни с порядком сообщений от меньшего к большему
            for (int i = 0; i < 9; i++)
            {
                OipHelpers.ProcMax(val, LevelCfgs[i], Hist, levels[i], true, false, false, i, Messenger);
            }

            //снимаем уровни с порядком сообщений от большего к меньшему
            for (int i = 8; i >= 0; i--)
            {
                OipHelpers.ProcMax(val, LevelCfgs[i], Hist, levels[i], false, true, false, i, Messenger);
            }

            for (int i = 0; i < 9; i++)
            {
                if (levels[i].Level)
                {
                    zone = i + 1;
                }
            }

            if (normMsgFl && (zone == 0) && NeedNormMsg) {
                Messenger.Send(20);
            }

            Norm = zone == 0;
            IsMT10Perc = levels[0].Level;
            IsNdv2ndParam = levels[1].Level;
            IsHighVibNoStat = levels[2].Level;
            IsAvarVibNoStat = levels[3].Level;
            IsHighVibStat = levels[4].Level;
            IsAvarVibStat = levels[5].Level;
            IsHighVibStatNMNWR = levels[6].Level;
            IsAvarVibStatNMNWR = levels[7].Level;
            IsAvar2Vib = levels[8].Level;
        }
    }
}
