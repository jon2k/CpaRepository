﻿using System;
using System.Collections.Generic;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;
using TarReferenceSource.Ktpra;

namespace TarReferenceSource.Ktpr
{
    public abstract class ProcKtpraIo: IFunctionBlock
    {
        public ProcKtpraIo()
        {
            Description.TimerDescriptions = TimerDescriptions;
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }
        //in
        /// <summary>
        /// input Команда с АРМ
        /// </summary>
        public ProcKtpraCmd Cmd;
        /// <summary>
        /// input Флаг аварийного параметра
        /// </summary>
        public bool Input;
        /// <summary>
        /// input Флаг отключенного состояния насосного агрегата
        /// </summary>
        public bool NaIsOff;

        //out  
        /// <summary>
        /// output Выходные данные модуля
        /// </summary>
        public ProcKtpraResult Result = new ProcKtpraResult();

        //cfg
        /// <summary>
        /// cfg Конфигурация модуля
        /// </summary>
        public ProcKtpraConfig Cfg = new ProcKtpraConfig();

        public override void AfterCall()
        {
            Cmd = 0;
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {
            {1, new MessageDescription{Text = "КОМАНДА – УСТАНОВИТЬ МАСКИРОВАНИЕ", Type = MessageType.Information} },
            {2, new MessageDescription{Text = "НЕ МАСКИРУЕТСЯ. ВЫПОЛНЕНИЕ НЕВОЗМОЖНО", Type = MessageType.Neutral} },
            {3, new MessageDescription{Text = "МАСКИРОВАНИЕ УСТАНОВЛЕНО", Type = MessageType.Neutral} },
            {4, new MessageDescription{Text = "МАСКИРОВАНИЕ УСТАНОВЛЕНО. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {5, new MessageDescription{Text = "КОМАНДА – СНЯТЬ МАСКИРОВАНИЕ", Type = MessageType.Information} },
            {6, new MessageDescription{Text = "МАСКИРОВАНИЕ СНЯТО", Type = MessageType.Neutral} },
            {7, new MessageDescription{Text = "МАСКИРОАВНИЕ СНЯТО. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {8, new MessageDescription{Text = "КОМАНДА - ДЕБЛОКИРОВАТЬ", Type = MessageType.Information} },
            {9, new MessageDescription{Text = "ДЕБЛОКИРОВАНИЕ НЕВОЗМОЖНО. СИГНАЛ НЕ СНЯТ", Type = MessageType.Neutral} },
            {10, new MessageDescription{Text = "ДЕБЛОКИРОВАНА", Type = MessageType.Neutral} },
            {11, new MessageDescription{Text = "ДЕБЛОКИРОВАНИЕ НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {12, new MessageDescription{Text = "АВАРИЙНЫЙ ПАРАМЕТР УСТАНОВЛЕН", Type = MessageType.Alarm} },
            {13, new MessageDescription{Text = "АВАРИЙНЫЙ ПАРАМЕТР СНЯТ", Type = MessageType.Neutral} },
            {14, new MessageDescription{Text = "*", Type = MessageType.Alarm} },
            {15, new MessageDescription{Text = "ИГНОРИРОВАНА ПО ПРИЧИНЕ МАСКИРОВАНИЯ", Type = MessageType.Alarm} },
            {16, new MessageDescription{Text = "ДЕБЛОКИРОВАНИЕ НЕВОЗМОЖНА. АГРЕГАТ НЕ ОСТАНОВЛЕН", Type = MessageType.Neutral} },
            {17, new MessageDescription{Text = "ВРЕМЕННАЯ УСТАВКА ИЗМЕНЕНА. НОВОЕ ЗНАЧЕНИЕ T01.Ust", Type = MessageType.Neutral} },

        };
        protected static Dictionary<int, TimerDescription> TimerDescriptions = new Dictionary<int, TimerDescription>
        {
            {1, new TimerDescription("Время задержки срабатывания защиты", TimeSpan.FromMilliseconds(500)) }
        };
    }
}
