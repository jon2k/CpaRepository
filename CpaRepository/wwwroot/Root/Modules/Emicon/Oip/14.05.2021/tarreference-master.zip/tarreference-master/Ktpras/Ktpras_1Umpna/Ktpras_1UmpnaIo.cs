﻿using System.Collections.Generic;
using System.Linq;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;

namespace TarReferenceSource.Ktpras.Ktpras_1
{
    public abstract class Ktpras_1UmpnaIo : Ktpras_1Io
    {
        // in
        /// <summary>
        /// input Исправность цепей включения.
        /// </summary>
        public bool ECB; // Исправность цепей включения.
        /// <summary>
        /// input Факт выдачи команды «Пуск» МНА (ПНА) модулем UMPNA
        /// </summary>
        public bool StartCmd; // Факт выдачи команды «Пуск» МНА (ПНА) модулем UMPNA (факт выдачи команды «Подготовить ЧРП к пуску» модулем CMNA)

        // out
        /// <summary>
        /// output Флаг недостоверности сигнала «Исправность цепей включения» 
        /// </summary>
        public bool ECB_Ndv; // Флаг недостоверности сигнала «Исправность цепей включения» 
        /// <summary>
        /// output Флаг неисправности цепей включения МНА (ПНА)
        /// </summary>
        public bool ECB_Err; // Флаг неисправности цепей включения МНА (ПНА)
    }
}
