﻿using Friday.Helpers;
using Friday.Runtime.CpaLocal;

namespace TarReferenceSource.Ktprs.Ktprs_0
{
    public class Ktprs_0 : Ktprs_Xio
    {
        /// <summary>
        /// Флаг выполнения инициализации модуля
        /// </summary>
        private bool initDone = false;
        public Ktprs_0()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }

        public override void Execute()
        {
            if (!initDone)
            {
                initDone = true;
                P = false;
                F = false;
                N = true;
            }

            if (!Input && F)
            {
                Messenger.Send(1);//предельный параметр снят
            }
            else if (Input && !F)
            {
                Messenger.Send(2);//предельный параметр установлен
            }

            P = Input;
            N = !Input;
            F = Input;
        }
    }
}
