﻿using System;
using TarFoundation.St;

namespace TarReferenceSource.Common.Timer
{
    public enum TimerState
    {
        Stopped = 0,
        Started = 1
    }
    public class CpaLocalTimer : ITimer
    {
        private bool startCmd;
        private bool stopCmd;

        public void Start()
        {
            if (Ust > TimeSpan.Zero)
            {
                startCmd = true;
                stopCmd = false;
                IsStarted = true;
                IsQ = false;
                Et = Ust.TotalMilliseconds;
            }
            else
            {
                startCmd = false;
                stopCmd = false;
                IsQ = true;
                IsStarted = false;
                Et = 0.0;
            }
        }

        public void Stop()
        {
            startCmd = false;
            stopCmd = true;
            IsStarted = false;
            IsQ = false;
            Et = 0;
        }

        public void Pause()
        {
            IsStarted = false;
        }

        public void Continue()
        {
            if (Et > 0)
            {
                IsStarted = true;
            }
        }

        public void Process(double ms)
        {
            IsQ = false;
            if (IsStarted)
            {
                Et -= ms;

                if (Et <= 0)
                {
                    IsQ = true;
                    IsStarted = false;
                    Et = 0;
                }
            }
        }

        public bool IsStarted { get; set; }
        public bool IsQ { get; set; }
        public TimeSpan Ust { get; set; }
        public double Et { get; protected set; }

        public override string ToString()
        {
            return $"Timer: et = {Et}, Q = {IsQ}, state = {IsStarted}, ust = {Ust}";
        }
    }
}
