﻿using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using System;
using System.Linq;
using TarReferenceSource.Common.Timer;
using TarFoundation.St;

namespace TarReferenceSource.Mpt.Upts
{
    public class UptsNew : UptsNewIo
	{
		public UptsNew(uint cMaxNumUPTS, uint numUpts):base(cMaxNumUPTS, numUpts)
		{
			Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
			InternalTimers = new StArray<ITimer>(1, Enumerable.Range(1, (int)cMaxNumUPTS).Select(i => new CpaLocalTimer()).ToArray());
		}
        public override void Execute()
        {
			//п.6.5.3.1 МПСА ПТ должны обеспечивать:
			// - контроль исправности световой и звуковой сигнализации (в том числе линий) на каждом защищаемом сооружении (по вызову)
			//п.6.5.3.3 МПСА ПТ при обнаружении пожара на защищаемом сооружении должна обеспечивать:
			// - автоматическое включение световой и звуковой сигнализации на защищаемом сооружении
			//п.6.5.4.5 МПСА ПТ не должна допускать отключения табло и сирен на защищаемом сооружении во время пожара

			/*	v.2.0.0.0   26.12.2019
			1.	добавлена входная переменная CmdAll - для групповой команды (в частности 'Отключить все сирены')
			2.	добавлена вsходная переменная Ringer (сигнализация при неисправности цепи)
			3.	в структуру TU добавил настройку Enabled (и IsRinger, Lock - пока на перспективу)

				- необходимо добавить проверку по команде (инверсия выхода на время)
				- добавить команды на блокировку/разблокировку работы звонков

				v.2.0.0.1   05.02.2020
			1.	если происходит отключение звонка (с АРМ), то воизбежании лишнего сообщения об автоматическом отключении
				выполняется присвоение TU[i].prevEn= TU[i].En;
			2.	свершилось! блокировка и разблокировка происходит теперь в блоке (осталось только проверку предусмотреть.. реально нужная команда + РД требует (см.выше))
			3.	блокировка выходного сигнала при блокировке самого устройства
			4.	добавлено отключение контроля цепей при нулевой уставке таймера

				- примечание: ни на одну команду нет подтверждения о выполнении.. в UTS - есть. Я не знаю, важно это или нет, просто обращаю внимание. 
			*/


			//NumMsg = 0;
			Ringer = false;


			if (NumUPTS <= cMaxNumUPTS)
			{

				/* отключить ВСЕ Сирены */
				if (CmdAll == enUPTSCmd.OffAllCmd)
				{
					Messenger.Send(1);               /* ОТКЛЮЧИТЬ ВСЕ СИРЕНЫ ИЗ МДП *//* формируется для 0-го(!) элемента */
					for (int i = 1; i <= NumUPTS; i++) 
					{
						Cmd[i]= CmdAll;
					}
				}
				CmdAll = enUPTSCmd.None;


				for (int i = 1; i <= NumUPTS; i++)
				{
					if (!TU[i].Enabled)
					{
						Cmd[i]= enUPTSCmd.None;
						TU[i].FlOn = false;
					}
					else
					{
						/* Обработка таймера */
						//Tim(T = TU[i].T[1], D = DTim);

						/* Команды от АРМ */
						if (Cmd[i] != enUPTSCmd.None)
						{
							switch (Cmd[i])
							{
								case enUPTSCmd.OnCmd:
									Messenger.Send(2);          /* ВКЛЮЧИТЬ ИЗ МДП */
									if (TU[i].EnableCmd && !TU[i].Block)
									{
										TU[i].FlOn = true;
									}
									else
									{
										Messenger.Send(8);      /* ВЫПОЛНЕНИЕ КОМАНДЫ НЕВОЗМОЖНО. БЛОКИРОВКА */
									}
									break;
								case enUPTSCmd.OffCmd:
									Messenger.Send(3);          /* ОТКЛЮЧИТЬ ИЗ МДП */
									if (TU[i].EnableCmd)
									{
										TU[i].FlOn = false;
										if (TU[i].IsRinger) 
										{
											TU[i].prevEn = TU[i].En; 
										} /*05.02.2020*/
									}
									else
									{
										Messenger.Send(8);      /* ВЫПОЛНЕНИЕ КОМАНДЫ НЕВОЗМОЖНО. БЛОКИРОВКА */
									}
									break;
								case enUPTSCmd.OffAllCmd:
									if ((TU[i].IsSiren || TU[i].IsRinger) && TU[i].FlOn)
									{ /*05.02.2020*/
										if (TU[i].EnableCmd)
										{
											TU[i].FlOn = false;
										}
										else
										{
											Messenger.Send(9);  /* ОТКЛЮЧИТЬ НЕВОЗМОЖНО, УСТАНОВЛЕНА БЛОКИРОВКА */
										}
									}
									break;
								case enUPTSCmd.BlockCmd: /*05.02.2020*/
									if (TU[i].IsRinger && !TU[i].Block)
									{
										TU[i].FlOn = false;
										TU[i].Block = true;
										Messenger.Send(10);     /* ЗАБЛОКИРОВАТЬ ВКЛЮЧЕНИЕ */
									}
									break;
								case enUPTSCmd.UnBlockCmd: /*05.02.2020*/
									if (TU[i].IsRinger && TU[i].Block)
									{
										TU[i].Block = false;
										Messenger.Send(11);     /* РАЗБЛОКИРОВАТЬ ВКЛЮЧЕНИЕ */
									}
									break;
							}
							Cmd[i]= enUPTSCmd.None;
						}

						/* Автоматическое управление */
						if (!TU[i].EnableCmd || (TU[i].En ^ TU[i].prevEn))
						{                               //управление от АРМ запрещено или есть изменение авт.команды
							if (TU[i].En == true && TU[i].FlOn == false)
							{
								TU[i].FlOn = true;
								Messenger.Send(4);  /* ВКЛЮЧИТЬ АВТОМАТИЧЕСКИ */
							}
							else if (TU[i].En == false && TU[i].FlOn == true)
							{
								TU[i].FlOn = false; 
								Messenger.Send(5);  /* ОТКЛЮЧИТЬ АВТОМАТИЧЕСКИ */
							}
						}
						TU[i].prevEn = TU[i].En;

						/*включение выходного сигнала при отсутствии блокировки*//*05.02.2020*/
						TU[i].FlOn = TU[i].FlOn && !TU[i].Block;

						/* Контроль целостности цепей включения */
						if (TU[i].EnableCheckCV && InternalTimers[i].Ust != new TimeSpan(0))
						{ /*05.02.2020*/
							if (!TU[i].FlOn)
							{
								if (!CorrCV[i] && TU[i].CorrCV)
								{
									if (InternalTimers[i].IsQ) // таймер сработал
									{
										TU[i].CorrCV = false;
										Messenger.Send(7); /* ЦЕПЬ ВКЛЮЧЕНИЯ НЕИСПРАВНА */
										Ringer = true;
									}
									else if (!InternalTimers[i].IsStarted)
									{
										InternalTimers[i].Start();
										//StartUst(D = DTim, T = TU[i].T[1], PT = T1Ust); // Пуск таймера
									}
								}
								else if (CorrCV[i] && !TU[i].CorrCV)
								{
									TU[i].CorrCV = true;
									InternalTimers[i].Stop();
									//Stop(T = TU[i].T[1]); // стоп таймера
									Messenger.Send(6);                      /* ЦЕПЬ ВКЛЮЧЕНИЯ ИСПРАВНА */
								}
							}
							else
							{
								InternalTimers[i].Stop();
								//Stop(T = TU[i].T[1]); // стоп таймера.
							}
						}
						else
						{
							TU[i].CorrCV = true;
						}
					}
				}
			}
		}
	}
}
