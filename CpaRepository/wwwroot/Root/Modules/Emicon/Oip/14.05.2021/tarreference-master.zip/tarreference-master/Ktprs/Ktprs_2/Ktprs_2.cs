﻿using TarFoundation.St;
using TarReferenceSource.Common.Timer;

namespace TarReferenceSource.Ktprs.Ktprs_2
{
    public class Ktprs_2 : Ktprs_Xio
    {
        private ITimer T02;
        /// <summary>
        /// Модуль Ktprs1
        /// </summary>
        private Ktprs_1.Ktprs_1 ktprs1;
        public Ktprs_2(Ktprs_1.Ktprs_1 ktprs)
        {
            Messenger = ktprs1.Messenger;
            ktprs1 = ktprs;
            T02 = new CpaLocalTimer();
            InternalTimers = new StArray<ITimer>(1, new []{ktprs1.Timers[1] as ITimer, T02});
        }

        public override void Execute()
        {
            ktprs1.Input = Input;
            ktprs1.Execute();
            P = ktprs1.P;
            N = ktprs1.N;
            F = ktprs1.F;

            if (F)
            {
                N = false;
                T02.Start();
            }
            else
            {
                N = !T02.IsStarted;
            }
        }
    }
}
