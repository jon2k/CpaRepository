﻿using System.Collections.Generic;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;
using TarReferenceSource.Mpt.Spz;

namespace TarReferenceSource.Mpt.Sup
{
    public enum enumSUPCmd : ushort
    {
        NOTHING = 0,
        SetAutoMode,  //установить режим автоматическому пожаротушения/водоорашения
        DropAutoMode  //сброс режима
    }

    public enum enumSUPfromSPZState : ushort
    {
        //Состояние защищаемого сооружения
        NOTHING = 0,
        Norm,         //Норма
        Attention,    //Внимание
        Fire          //ПОЖАР!
    }

    public enum enumSUPMode : ushort
    {
        NONE = 0,
        AUTO
    }
    /// <summary>
    /// Структура данных от Spz в Sup
    /// </summary>
    public struct structSPZFromSUP
    {
        /// <summary>
        /// Наличие автоматического режима
        /// </summary>
        public bool IsAuto;
        /// <summary>
        /// Флаг наличия пожара
        /// </summary>
        public bool IsFireProc;
    }
    /// <summary>
    /// Входные данные модуля Sup
    /// </summary>
    public class structSUPInputs
    {
        /// <summary>
        /// данные от модуля Spz
        /// </summary>
        public structSPZtoSUPCmd szs = new structSPZtoSUPCmd();
        /// <summary>
        /// Флаг наличия тушения пожара
        /// </summary>
        public bool atpInProgress; //идет тушение пожара
        /// <summary>
        /// Команда с АРМ на установку автоматического режима
        /// </summary>
        public enumSUPCmd cmd;
        /// <summary>
        /// Автоматическая команда сброса режима
        /// </summary>
        public bool NeedDropMode;
    }
    /// <summary>
    /// Выходные данные модуля
    /// </summary>
    public struct structSUPOutputs
    {
        /// <summary>
        /// Готовность к пожаротушению
        /// </summary>
        public bool CanFirefight;
        /// <summary>
        /// Необходимость пожаротушения
        /// </summary>
        public bool NeedFirefight;
        /// <summary>
        /// Режим
        /// </summary>
        public enumSUPMode Mode;
    }
    public abstract class SupIo : IFunctionBlock
    {
        public SupIo()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }
        /// <summary>
        /// input Входные данные модуля
        /// </summary>
        public structSUPInputs inp = new structSUPInputs();
        /// <summary>
        /// output Выходные данные модуля
        /// </summary>
        public structSUPOutputs output;

        public override void AfterCall()
        {
            inp.cmd = enumSUPCmd.NOTHING;
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {
            {1, new MessageDescription{Text = "КОМАНДА - СБРОСИТЬ РЕЖИМ", Type = MessageType.Information} },
            {2, new MessageDescription{Text = "СБРОС НЕ ТРЕБУЕТСЯ. РЕЖИМ АВТ НЕ НАЗНАЧЕН", Type = MessageType.Neutral} },
            {3, new MessageDescription{Text = "СБРОС НЕВОЗМОЖЕН. ПОЖАР!", Type = MessageType.Neutral} },
            {4, new MessageDescription{Text = "СБРОС НЕВОЗМОЖЕН. ИДЕТ ТУШЕНИЕ ПОЖАРА", Type = MessageType.Neutral} },
            {5, new MessageDescription{Text = "РЕЖИМ СБРОШЕН", Type = MessageType.Neutral} },
            {6, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ РЕЖИМ АВТОМАТИЧЕСКИЙ", Type = MessageType.Information} },
            {7, new MessageDescription{Text = "НАЗНАЧЕНИЕ НЕВОЗМОЖНО. СООРУЖЕНИЕ В РЕМОНТЕ", Type = MessageType.Neutral} },
            {8, new MessageDescription{Text = "НАЗНАЧЕНИЕ НЕВОЗМОЖНО. МАСКИРОВАНИЕ ЗАШИТЫ ПО ПОЖАРУ", Type = MessageType.Neutral} },
            {9, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ АВТ.", Type = MessageType.Neutral} },
            {10, new MessageDescription{Text = "КОМАНДА - СБРОСИТЬ РЕЖИМ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
            {11, new MessageDescription{Text = "РЕЖИМ СБРОШЕН АВТОМАТИЧЕСКИ", Type = MessageType.Neutral} },

        };
    }
}
