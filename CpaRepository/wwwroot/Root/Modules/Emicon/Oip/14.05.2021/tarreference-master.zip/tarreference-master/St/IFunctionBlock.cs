﻿using System.Collections.Generic;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.Runtime;
using System.Linq;

namespace TarFoundation.St
{
    public abstract class IFunctionBlock : ICallable, IMessageProducer
    {

        public IFunctionBlock()
        {
            Description = new FunctionBlockDescription();
        }

        public FunctionBlockDescription Description { get; protected set; }
        protected StArray<ITimer> InternalTimers { get; set; }
        public IMessenger Messenger { get; protected set; }

        public List<ITimeTraveler> Timers => InternalTimers != null ? InternalTimers.ToList().Cast<ITimeTraveler>().ToList() : new List<ITimeTraveler>();

        public abstract void Execute();

        public virtual void Call()
        {
            BeforeCall();
            Execute();
            AfterCall();
        }

        public virtual void BeforeCall()
        {

        }

        public virtual void AfterCall()
        {

        }
    }
}
