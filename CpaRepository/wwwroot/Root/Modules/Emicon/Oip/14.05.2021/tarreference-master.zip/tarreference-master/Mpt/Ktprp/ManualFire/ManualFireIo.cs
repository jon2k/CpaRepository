﻿using System.Collections.Generic;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;

namespace TarReferenceSource.Mpt.ManualFire
{
    public abstract class ManualFireIo:IFunctionBlock
    {  
        //in
        /// <summary>
        /// input Команда запуска пожарооповещения с АРМ
        /// </summary>
        public bool ButtonFire { get; set; }
        //out
        /// <summary>
        /// output Флаг запуска пожарооповещения
        /// </summary>
        public bool Fire { get; set; }

        public override void AfterCall()
        {
            ButtonFire = false;
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {      
            {1, new MessageDescription{Text = "КОМАНДА ПУСК С АРМ", Type = MessageType.Information} }
        };
    }
}
