﻿using System;
using System.Collections.Generic;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarReferenceSource.CommonNa;

namespace TarReferenceSource.Cmna
{
    /// <summary>
    /// Структура данных из модуля Cmna в ЧРП 
    /// </summary>
    public struct ChrpOut
    {
        /// <summary>
        /// Команда разрешения на запуск ЧРП по месту
        /// </summary>
        public bool GrantMestCmd;
        /// <summary>
        /// Команда подготовки ЧРП к пуску
        /// </summary>
        public bool PrepareCmd;
        /// <summary>
        /// Запуск ЧРП (Пока 1 чрп в работе, когда 0 - стоп)
        /// </summary>
        public bool StartDistCmd; // пока 1 чрп в работе, когда 0 - стоп
    }
    /// <summary>
    /// Структура данных из ЧРП в модуль Cmna
    /// </summary>
    public struct ChrpNu
    {
        /// <summary>
        /// Флаг наличия вращения двигателя
        /// </summary>
        public bool SpinForward;
        /// <summary>
        /// Текущая частоты вращения двигателя
        /// </summary>
        public ushort CurFreq;
        /// <summary>
        /// Флаг дистанционного режима.
        /// </summary>
        public bool Dist;
        /// <summary>
        /// Заданная частота вращения двигателя
        /// </summary>
        public ushort TaskFreq;
        /// <summary>
        /// Флаг готовности ЧРП к пуску
        /// </summary>
        public bool Ready;
        /// <summary>
        /// Флаг неисправности ЧРП
        /// </summary>
        public bool Crach;
        /// <summary>
        /// Флаг аварии ЧРП
        /// </summary>
        public bool Err;
    }

    public abstract class CmnaIo : NaIo
    {
        public CmnaIo()
        {
            Description.MessageDescription = messages;
            Description.TimerDescriptions = TimerDescriptions;
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }
        /// <summary>
        /// input Необходимость выполнения программы управляемой остановки. 1 - выполнение программы управляемой остановки. 0 - выполнение программы неуправляемой остановки
        /// </summary>
        public bool ManageStop;
        /// <summary>
        /// input Флаг управляемой остановки с отключением воздушного выключателя
        /// </summary>
        public bool ManagesStopWithOffVv;
        /// <summary>
        /// input Минимальная частота работы НА
        /// </summary>
        public ushort MinWorkFreq;
        /// <summary>
        /// input Минимальная частота при которой определяется невыполнение команд регулирования
        /// </summary>
        public ushort MaxFreqDiff;
        /// <summary>
        /// input 
        /// </summary>
        public ushort MinRegFreq;
        /// <summary>
        /// input Флаг наличия защиты «авария ЧРП»
        /// </summary>
        public bool StopAvarChrp; // из krmpn из StopType
        /// <summary>
        /// input Входные данные от ЧРП
        /// </summary>
        public ChrpNu ChRP_In = new ChrpNu();
        /// <summary>
        /// output Управляющие команды в ЧРП
        /// </summary>
        public ChrpOut ChRP_Out = new ChrpOut();
        // out
        /// <summary>
        /// output Команда остановки ЧРП
        /// </summary>
        public bool SpinStopCmd;
        /// <summary>
        /// output Флаг обнаружения ошибки регулирования 
        /// </summary>
        public bool ChrpRegError;
        /// <summary>
        /// output Флаг программно определенной аварии ЧРП
        /// </summary>
        public bool LogicalChrpError;
        /// <summary>
        /// output Флаг аварии ЧРП
        /// </summary>
        public bool StateAlarmChrp;

        public override void AfterCall()
        {
            Cmd = NaCmd.none;
        }


        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {
            {1, new MessageDescription{Text = "СИГНАЛ ВВ ВКЛЮЧЕН В УСО 1.1 НЕДОСТОВЕРЕН", Type = MessageType.Attention} },
            {2, new MessageDescription{Text = "СИГНАЛ ВВ ОТКЛЮЧЕН В УСО 1.1 НЕДОСТОВЕРЕН", Type = MessageType.Attention} },
            {3, new MessageDescription{Text = "СИГНАЛ ВВ ВКЛЮЧЕН В УСО 3 НЕДОСТОВЕРЕН", Type = MessageType.Attention} },
            {4, new MessageDescription{Text = "СИГНАЛ ВВ ОТКЛЮЧЕН В УСО 3 НЕДОСТОВЕРЕН", Type = MessageType.Attention} },
            {5, new MessageDescription{Text = "ЗНАЧЕНИЕ СИЛЫ ТОКА НЕДОСТОВЕРНО", Type = MessageType.Attention} },
            {6, new MessageDescription{Text = "ТОК ДВИГАТЕЛЯ НАБРАН", Type = MessageType.Neutral} },
            {7, new MessageDescription{Text = "ТОК СБРОШЕН", Type = MessageType.Neutral} },
            {14, new MessageDescription{Text = "ВВ ВКЛЮЧЕН", Type = MessageType.Neutral} },
            {16, new MessageDescription{Text = "НЕ ПОЛУЧЕНО СОСТОЯНИЕ \"В РАБОТЕ\" ЗА ЗАДАННОЕ ВРЕМЯ", Type = MessageType.Alarm} },
            {17, new MessageDescription{Text = "КОМАНДА - ОТКЛЮЧИТЬ ВВ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
            {18, new MessageDescription{Text = "ВВ ОТКЛЮЧЕН", Type = MessageType.Neutral} },
            {19, new MessageDescription{Text = "КОМАНДА НА ОТКЛЮЧЕНИЕ ВВ В ЯЧЕЙКУ ЗРУ ДОСТАВЛЕНА", Type = MessageType.Neutral} },
            {21, new MessageDescription{Text = "ПРОЦЕСС ЗАПУСКА ОТМЕНЕН", Type = MessageType.Neutral} },
            {22, new MessageDescription{Text = "ВВ НЕ ОТКЛЮЧИЛСЯ", Type = MessageType.Alarm} },
            {23, new MessageDescription{Text = "ИДЕТ ПРОГРАММНЫЙ ПУСК", Type = MessageType.Neutral} },
            {24, new MessageDescription{Text = "ПРОГРАММНЫЙ ПУСК ЗАВЕРШЕН", Type = MessageType.Neutral} },
            {25, new MessageDescription{Text = "В РАБОТЕ", Type = MessageType.Neutral} },
            {26, new MessageDescription{Text = "ИДЕТ ПРОГРАММНАЯ ОСТАНОВКА", Type = MessageType.Neutral} },
            {27, new MessageDescription{Text = "ПРОГРАММНАЯ ОСТАНОВКА ЗАВЕРШЕНА", Type = MessageType.Neutral} },
            {28, new MessageDescription{Text = "ОСТАНОВЛЕН", Type = MessageType.Neutral} },
            {29, new MessageDescription{Text = "ПУСК НЕВОЗМОЖЕН. АГРЕГАТ НЕ ГОТОВ К ПУСКУ", Type = MessageType.Neutral} },
            {30, new MessageDescription{Text = "ПУСК НЕВОЗМОЖЕН. РЕЖИМ ОСН НЕ ВЫБРАН", Type = MessageType.Neutral} },
            {31, new MessageDescription{Text = "ПУСК НЕВОЗМОЖЕН. РЕЖИМ ТМ НЕ ВЫБРАН", Type = MessageType.Neutral} },
            {33, new MessageDescription{Text = "НАЧАЛО НЕСТАЦИОНАРНОГО РЕЖИМА", Type = MessageType.Neutral} },//TODO: ПУСКОВОЙ
            {34, new MessageDescription{Text = "НЕСТАЦИОНАРНЫЙ РЕЖИМ ДВИГАТЕЛЯ ЗАКОНЧЕН", Type = MessageType.Neutral} },//TODO: ПУСКОВОЙ
            {35, new MessageDescription{Text = "НЕСТАЦИОНАРНЫЙ РЕЖИМ НАСОСА ЗАКОНЧЕН", Type = MessageType.Neutral} },//TODO: ПУСКОВОЙ
            {42, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ ОСНОВНОЙ", Type = MessageType.Neutral} },
            {43, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ ТЕЛЕМЕХАНИЧЕСКИЙ", Type = MessageType.Neutral} },
            {44, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ РЕЗЕРВНЫЙ", Type = MessageType.Neutral} },
            {45, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ РЕМОНТНЫЙ", Type = MessageType.Neutral} },
            {46, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ ИМИТАЦИИ", Type = MessageType.Neutral} },
            {47, new MessageDescription{Text = "РЕЖИМ ИМИТАЦИИ СНЯТ", Type = MessageType.Neutral} },
            {48, new MessageDescription{Text = "НАЗНАЧЕНИЕ НЕ ТРЕБУЕТСЯ. РЕЖИМ УЖЕ НАЗНАЧЕН", Type = MessageType.Neutral} },
            {49, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА ТМ НЕВОЗМОЖНО. СТАНЦИЯ В МЕСТНОМ РЕЖИМЕ УПРАВЛЕНИЯ", Type = MessageType.Neutral} },
            {50, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. АГРЕГАТ НЕ ОСТАНОВЛЕН", Type = MessageType.Neutral} },
            {51, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ПРИЕМНАЯ ЗАДВИЖКА НЕ ОТКРЫТА", Type = MessageType.Neutral} },
            {52, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ВЫХОДНАЯ ЗАДВИЖКА НЕ ОТКРЫТА", Type = MessageType.Neutral} },
            {54, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. В ПЛЕЧЕ УЖЕ ИМЕЕТСЯ МНА В РЕЖИМЕ РЕЗ", Type = MessageType.Neutral} },
            {55, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. НЕТ АГРЕГАТОВ В РЕЖИМЕ ОСН ИЛИ ТМ", Type = MessageType.Neutral} },
            {56, new MessageDescription{Text = "ВКЛЮЧЕНИЕ РЕЗЕРВА", Type = MessageType.Information} },
            {57, new MessageDescription{Text = "ТОК НЕ СБРОШЕН", Type = MessageType.Alarm} },
            {58, new MessageDescription{Text = "НЕ ПОЛУЧЕНО СОСТОЯНИЕ \"ОСТАНОВЛЕН\" ЗА ЗАДАННОЕ ВРЕМЯ", Type = MessageType.Alarm} },
            {59, new MessageDescription{Text = "КОМАНДА ОТКЛЮЧИТЬ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
            {60, new MessageDescription{Text = "КОНТРОЛЬ ПО ТОКУ НЕ ВЕДЁТСЯ", Type = MessageType.Neutral} },
            {64, new MessageDescription{Text = "АГРЕГАТ ОТКЛЮЧЕН В РЕЖИМЕ ИМИТАЦИИ", Type = MessageType.Neutral} },
            {65, new MessageDescription{Text = "В РАБОТЕ В РЕЖИМЕ ИМИТАЦИИ", Type = MessageType.Neutral} },
            {66, new MessageDescription{Text = "УСТАНОВЛЕН РЕЖИМ РАБОТЫ НАСОСА \"В РАБОЧЕМ ИНТЕРВАЛЕ ПОДАЧ\"", Type = MessageType.Neutral} },
            {67, new MessageDescription{Text = "УСТАНОВЛЕН РЕЖИМ РАБОТЫ НАСОСА \"В НЕ РАБОЧЕГО ИНТЕРВАЛА ПОДАЧ\"", Type = MessageType.Neutral} },
            {70, new MessageDescription{Text = "КОМАНДА - ЗАПУСК С АРМ", Type = MessageType.Information} },
            {71, new MessageDescription{Text = "КОМАНДА - ЗАПУСК ПО ТМ", Type = MessageType.Information} },
            {72, new MessageDescription{Text = "КОМАНДА - ОТКЛЮЧИТЬ С АРМ", Type = MessageType.Information} },
            {73, new MessageDescription{Text = "КОМАНДА - ОТКЛЮЧИТЬ ПО ТМ", Type = MessageType.Information} },
            {76, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ РЕЖИМ ОСНОВНОЙ С АРМ", Type = MessageType.Information} },
            {77, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ РЕЖИМ ОСНОВНОЙ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
            {78, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ РЕЖИМ ТЕЛЕМЕХАНИЧЕСКИЙ С АРМ", Type = MessageType.Information} },
            {79, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ РЕЖИМ РЕЗЕРВНЫЙ С АРМ", Type = MessageType.Information} },
            {80, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ РЕЖИМ РЕМОНТНЫЙ С АРМ", Type = MessageType.Information} },
            {81, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ РЕЖИМ ИМИТАЦИИ С АРМ", Type = MessageType.Information} },
            {82, new MessageDescription{Text = "КОМАНДА - СНЯТЬ РЕЖИМ ИМИТАЦИИ С АРМ", Type = MessageType.Information} },
            {94, new MessageDescription{Text = "КОМАНДА - УСТАНОВИТЬ РЕЖИМ РАБОТЫ НАСОСА \"В РАБОЧЕМ ИНТЕРВАЛЕ ПОДАЧ\" С АРМ", Type = MessageType.Information} },
            {95, new MessageDescription{Text = "КОМАНДА - УСТАНОВИТЬ РЕЖИМ РАБОТЫ НАСОСА \"В НЕ РАБОЧЕГО ИНТЕРВАЛА ПОДАЧ\" С АРМ", Type = MessageType.Information} },
            {98, new MessageDescription{Text = "ТОК ДВИГАТЕЛЯ НЕ НАБРАН", Type = MessageType.Alarm} },
            {100, new MessageDescription{Text = "ОСТАНОВЛЕН. КОМАНДА НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {101, new MessageDescription{Text = "В РАБОТЕ. КОМАНДА НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {102, new MessageDescription{Text = "ОСТАНАВЛИВАЕТСЯ. КОМАНДА НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {103, new MessageDescription{Text = "ЗАПУСКАЕТСЯ. КОМАНДА НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {104, new MessageDescription{Text = "АВТОМАТИЧЕСКОЕ ВКЛЮЧЕНИЕ", Type = MessageType.Information} },
            {110, new MessageDescription{Text = "ЧАСТОТА ВРАЩЕНИЯ ВАЛА ЭД МЕНЕЕ 30 ОБ/МИН", Type = MessageType.Neutral} },
            {111, new MessageDescription{Text = "СИГНАЛ ОТ ЧРП \"ВРАЩЕНИЕ ВПЕРЕД\" СБРОШЕН", Type = MessageType.Neutral} },
            {112, new MessageDescription{Text = "ЧАСТОТА ВРАЩЕНИЯ ВАЛА ЭД НЕ СНИЖЕНА ДО 30 ОБ/МИН", Type = MessageType.Alarm} },
            {113, new MessageDescription{Text = "СИГНАЛ ОТ ЧРП \"ВРАЩЕНИЕ ВПЕРЕД\" НЕ СБРОШЕН", Type = MessageType.Alarm} },
            {114, new MessageDescription{Text = "ОТМЕНИТЬ ПОДГОТОВКУ ЧРП К ПУСКУ", Type = MessageType.Information} },
            {115, new MessageDescription{Text = "ИДЕТ УПРАВЛЯЕМАЯ ОСТАНОВКА", Type = MessageType.Neutral} },
            {116, new MessageDescription{Text = "ИДЕТ НЕУПРАВЛЯЕМАЯ ОСТАНОВКА", Type = MessageType.Neutral} },
            {117, new MessageDescription{Text = "СИГНАЛ ОТ ЧРП \"ВРАЩЕНИЕ ВПЕРЕД\" ПОЛУЧЕН", Type = MessageType.Neutral} },
            {118, new MessageDescription{Text = "ЧАСТОТА ВРАЩЕНИЯ ВАЛА ЭД БОЛЕЕ 30 ОБ/МИН", Type = MessageType.Neutral} },
            {119, new MessageDescription{Text = "СИГНАЛ ОТ ЧРП \"ВРАЩЕНИЕ ВПЕРЕД\" НЕ ПОЛУЧЕН", Type = MessageType.Alarm} },
            {120, new MessageDescription{Text = "ЧАСТОТА ВРАЩЕНИЯ ВАЛА ЭД НЕ ПРЕВЫСИЛА 30 ОБ/МИН", Type = MessageType.Alarm} },
            {122, new MessageDescription{Text = "ЧАСТОТА ВРАЩЕНИЯ ВАЛА ЭД НЕ ПРЕВЫСИЛА МИНИМАЛЬНОЙ ЧАСТОТЫ РЕГУЛИРОВАНИЯ", Type = MessageType.Alarm} },
            {123, new MessageDescription{Text = "ИДЕТ ПОДГОТОВКА ЧРП К ПУСКУ. КОМАНДА НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {124, new MessageDescription{Text = "ЧРП ГОТОВ К ПУСКУ. КОМАНДА НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {125, new MessageDescription{Text = "ПОДГОТОВКА ЧРП К ПУКСУ НЕВОЗМОЖНА. АВАРИЯ ЧРП", Type = MessageType.Neutral} },
            {126, new MessageDescription{Text = "ПОДГОТОВКА ЧРП К ПУКСУ НЕВОЗМОЖНА. АГРЕГАТ НЕ ОСТАНОВЛЕН", Type = MessageType.Neutral} },
            {127, new MessageDescription{Text = "КОМАНДА - ПОДГОТОВИТЬ ЧРП К ПУСКУ", Type = MessageType.Information} },
            {128, new MessageDescription{Text = "ГОТОВНОСТЬ ЧРП К ПУСКУ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {129, new MessageDescription{Text = "ГОТОВНОСТЬ ЧРП К ПУСКУ НЕ ПОЛУЧЕНА. АВАРИЯ ЧРП", Type = MessageType.Neutral} },
            {130, new MessageDescription{Text = "ГОТОВНОСТЬ ЧРП К ПУСКУ НЕ ПОЛУЧЕНА ЗА ЗАДАННОЕ ВРЕМЯ", Type = MessageType.Neutral} },
            {131, new MessageDescription{Text = "КОМАНДА - СНИЗИТЬ ЧАСТОТУ ВРАЩЕНИЯ ВАЛА ЭД ДО НУЛЯ", Type = MessageType.Information} },
            {132, new MessageDescription{Text = "КОМАНДА - СТОП В ЧРП", Type = MessageType.Information} },
            {133, new MessageDescription{Text = "РАЗРЕШЕНИЕ ЧРП НА ПУСК ДВИГАТЕЛЯ В МЕСТНОМ РЕЖИМЕ УПРАВЛЕНИЯ СНЯТО", Type = MessageType.Neutral} },
            {134, new MessageDescription{Text = "КОМАНДА - ПУСК В ЧРП", Type = MessageType.Information} },
            {135, new MessageDescription{Text = "КРИТИЧЕСКИЙ ОТКАЗ ЧРП", Type = MessageType.Alarm} },
            {136, new MessageDescription{Text = "НЕИСПРАВНОСТЬ ЧРП", Type = MessageType.Attention} },
            {137, new MessageDescription{Text = "КОМАНДА - ВЫДАТЬ РАЗРЕШЕНИЕ НА ПУСК ДВИГАТЕЛЯ В МЕСТНОМ РЕЖИМЕ УПРАВЛЕНИЯ", Type = MessageType.Information} },
            {138, new MessageDescription{Text = "ЧРП В ДИСТАНЦИОННОМ РЕЖИМЕ УПРАВЛЕНИЯ. КОМАНДА НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {139, new MessageDescription{Text = "ВЫДАТЬ РАЗРЕШЕНИЕ НЕВОЗМОЖНО. АГРЕГАТ НЕ ГОТОВ К ПУСКУ", Type = MessageType.Neutral} },
            {140, new MessageDescription{Text = "РАЗРЕШЕНИЕ НА ПУСК ДВИГАТЕЛЯ В МЕСТНОМ РЕЖИМЕ УПРАВЛЕНИЯ ВЫДАНО", Type = MessageType.Neutral} },
            {141, new MessageDescription{Text = "КОМАНДА - CНЯТЬ РАЗРЕШЕНИЕ НА ПУСК ДВИГАТЕЛЯ В МЕСТНОМ РЕЖИМЕ УПРАВЛЕНИЯ", Type = MessageType.Information} },
            {142, new MessageDescription{Text = "РАЗРЕШЕНИЕ НА ПУСК ДВИГАТЕЛЯ В МЕСТНОМ РЕЖИМЕ УПРАВЛЕНИЯ СНЯТО", Type = MessageType.Neutral} },
            {143, new MessageDescription{Text = "СИГНАЛ ОТ ЧРП \"ДИСТАНЦИОННОЕ УПРАВЛЕНИЕ\" СНЯТ", Type = MessageType.Neutral} },
            {144, new MessageDescription{Text = "РАЗРЕШЕНИЕ ОТСУТСТВУЕТ. КОМАНДА НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {145, new MessageDescription{Text = "ПУСК НЕВОЗМОЖЕН. ЧРП НЕ В ДИСТАНЦИОННОМ РЕЖИМЕ УПРАВЛЕНИЯ", Type = MessageType.Neutral} },
            {146, new MessageDescription{Text = "СВЯЗЬ С ЧРП ПО ИНТЕРФЕЙСНОМУ КАНАЛУ ПОТЕРЯНА", Type = MessageType.Attention} },
            {147, new MessageDescription{Text = "СВЯЗЬ С ЧРП ПО ИНТЕРФЕЙСНОМУ КАНАЛУ ВОССТАНОВЛЕНА", Type = MessageType.Neutral} },
            {148, new MessageDescription{Text = "СИГНАЛ ОТ ЧРП \"ДИСТАНЦИОННОЕ УПРАВЛЕНИЕ\" УСТАНОВЛЕН", Type = MessageType.Neutral} },
            {149, new MessageDescription{Text = "ПОДГОТОВКА ЧРП К ПУСКУ НЕВОЗМОЖНА. ЧРП НЕ В ДИСТАНЦИОННОМ РЕЖИМЕ УПРАВЛЕНИЯ", Type = MessageType.Neutral} },
            {150, new MessageDescription{Text = "ПОДГОТОВКА ЧРП К ПУСКУ НЕВОЗМОЖНА. ТРЕБОВАНИЕ ОТКЛЮЧЕНИЯ ВВ ", Type = MessageType.Neutral} },
            {151, new MessageDescription{Text = "СИГНАЛ ОТ ЧРП \"ТЕКУЩАЯ ЧАСТОТА ВРАЩЕНИЯ ВАЛА ЭД\" НЕДОСТОВЕРЕН", Type = MessageType.Attention} },
            {152, new MessageDescription{Text = "СИГНАЛ ОТ ЧРП \"ВРАЩЕНИЕ ВПЕРЕД\" НЕДОСТОВЕРЕН", Type = MessageType.Attention} },
            {154, new MessageDescription{Text = "МНА ОТКЛЮЧИЛСЯ ПО НЕУСТАНОВЛЕННОЙ ПРИЧИНЕ", Type = MessageType.Alarm} },
            {155, new MessageDescription{Text = "МНА ВКЛЮЧИЛСЯ ПО НЕУСТАНОВЛЕННОЙ ПРИЧИНЕ", Type = MessageType.Alarm} },
            {156, new MessageDescription{Text = "РАЗРЕШЕНИЕ НА ПУСК В МЕСТНОМ РЕЖИМЕ УПРАВЛЕНИЯ УСТАНОВЛЕНО. КОМАНДА НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {157, new MessageDescription{Text = "СИГНАЛ \"НЕИСПРАВНОСТЬ ЧРП\" СНЯТ", Type = MessageType.Neutral} },
            {158, new MessageDescription{Text = "ПОДГОТОВКА ЧРП К ПУСКУ НЕВОЗМОЖНА. ИДЕТ ОТКЛЮЧЕНИЕ ВВ ПО ПРОГРАММЕ УПРАВЛЯЕМОЙ ОСТАНОВКИ С ПОСЛЕДУЮЩИМ ОТКЛЮЧЕНИЕМ ВВ", Type = MessageType.Neutral} },
            {159, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА ТМ НЕВОЗМОЖНО. АГРЕГАТ НЕ В ДИСТАНЦИОННОМ РЕЖИМЕ УПРАВЛЕНИЯ", Type = MessageType.Neutral} },
            {160, new MessageDescription{Text = "ПУСК НЕВОЗМОЖЕН. АГРЕГАТ НАЗНАЧЕН НА ЗАПУСК ПРИ ПЕРЕХОДЕ", Type = MessageType.Neutral} },
            {161, new MessageDescription{Text = "КОМАНДА – ОТКЛЮЧИТЬ ОТ ЦСПА", Type = MessageType.Information} },
            {162, new MessageDescription{Text = "ПУСК НЕВОЗМОЖЕН. АГРЕГАТ НЕ ОСТАНОВЛЕН", Type = MessageType.Neutral} },
            {200, new MessageDescription{Text = "ИЗМЕНЕНА ВРЕМЕННАЯ УСТАВКА I. НОВОЕ ЗНАЧЕНИЕ Uts[I]", Type = MessageType.Neutral} }
        };
        protected static Dictionary<int, TimerDescription> TimerDescriptions = new Dictionary<int, TimerDescription>
        {
            {1, new TimerDescription("Время на проверку корректности состояния цепей контроля ВВ", TimeSpan.FromMilliseconds(3000), "Значение уставки данного таймера может быть увеличено по результатам наладочных работ при эксплуатации НА с включенным контролем значения силы тока ЭД") },
            {2, new TimerDescription("Не используется", TimeSpan.FromMilliseconds(0)) },
            {3, new TimerDescription("максимальное время удержания команды «Отключить ВВ»;", TimeSpan.FromMilliseconds(1000)) },
            {4, new TimerDescription("Не используется", TimeSpan.FromMilliseconds(0)) },
            {5, new TimerDescription("Не используется", TimeSpan.FromMilliseconds(0)) },
            {6, new TimerDescription("Не используется", TimeSpan.FromMilliseconds(0)) },
            {7, new TimerDescription("Время подъема силы тока ЭД после включения ВВ НА", TimeSpan.FromMilliseconds(5000)) },
            {8, new TimerDescription("Не используется", TimeSpan.FromMilliseconds(0)) },
            {9, new TimerDescription("Время нестационарного режима работы ЭД при пуске", TimeSpan.FromMilliseconds(30000)) },
            {10, new TimerDescription("Время, перед выдачей команды повторного отключения ВВ при невыполнении программы остановки", TimeSpan.FromMilliseconds(3000)) },
            {11, new TimerDescription("Контрольное время на выполнение процесса отключения ВВ НА", TimeSpan.FromMilliseconds(4000)) },
            {12, new TimerDescription("Время снижения силы тока ЭД после отключения ВВ НА", TimeSpan.FromMilliseconds(5000)) },
            {13, new TimerDescription("Время фильтрации сигналов цепей включения и отключения", TimeSpan.FromMilliseconds(0)) },
            {14, new TimerDescription("Длительность нестационарного режима работы насоса", TimeSpan.FromMilliseconds(31000)) },
            {15, new TimerDescription("Не используется", TimeSpan.FromMilliseconds(0)) },
            {16, new TimerDescription("задержка отключения ВВ НА при выполнении программы неуправляемой остановки", TimeSpan.FromMilliseconds(2000)) },
            {17, new TimerDescription("Время снижения частоты вращения вала ЭД НА при выполнении программы управляемой остановки", TimeSpan.FromMilliseconds(7000)) },
            {18, new TimerDescription("Время снижения силы тока ЭД при выполнении программы управляемой остановки", TimeSpan.FromMilliseconds(5000)) },
            {19, new TimerDescription("Время сброса сигнала ЧРП «вращение вперед» при выполнении программы управляемой остановки", TimeSpan.FromMilliseconds(3000)) },
            {20, new TimerDescription("Время получения сигнала ЧРП «вращение вперед»;", TimeSpan.FromMilliseconds(3000)) },
            {21, new TimerDescription("Время на достижение стартовой частоты вращения вала ЭД НА ", TimeSpan.FromMilliseconds(5000)) },
            {22, new TimerDescription("Время на достижение частоты вращения вала ЭД НА, соответствующей минимальной частоте диапазона регулирования", TimeSpan.FromMilliseconds(10000)) },
            {23, new TimerDescription("Время получения сигнала ЧРП «готов к пуску»;", TimeSpan.FromMilliseconds(5000)) },
            {24, new TimerDescription("Время контроля выполнения команд регулирования ЧПР включенного МНА;  ", TimeSpan.FromMilliseconds(11000)) },
            {25, new TimerDescription("Время отсутствия контроля выполнения команд регулирования после включения НА", TimeSpan.FromMilliseconds(5000)) },
            {26, new TimerDescription("Время на проверку корректности состояния цепей контроля МНА", TimeSpan.FromMilliseconds(3000), "Значение уставки данного таймера может быть увеличено по результатам наладочных работ при эксплуатации НА с включенным контролем значения силы тока ЭД;") },
            {27, new TimerDescription("Время на остановку вала ЭД НА после выполнения программы неуправляемой остановки;", TimeSpan.FromMilliseconds(70000)) },
            {28, new TimerDescription("Время на выполнение АВР при получении сигналов «электрозащита», «авария ЧРП», после получения состояния «ВВ отключен»; ", TimeSpan.FromMilliseconds(3000)) },
            {29, new TimerDescription("Время, через которое будет выдана команда стоп при отсутствии электрозащиты", TimeSpan.FromMilliseconds(3000)) }
        };
    }
}
