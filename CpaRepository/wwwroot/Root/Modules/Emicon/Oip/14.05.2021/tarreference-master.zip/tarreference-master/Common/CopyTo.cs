﻿using System.Linq;
using System.Reflection;

namespace TarReferenceSource.Common
{
    public static class ObjectCopyExtensions
    {
        public static void CopyTo<T>(this T source, T dest) where T : class
        {
            var type = typeof(T);

            foreach (var field in type.GetRuntimeFields())//.Where(f => !f.IsInitOnly)
            {
                if (field.FieldType.IsValueType)
                    field.SetValue(dest, field.GetValue(source));
                else
                {
                    field.GetValue(source).CopyTo(field.GetValue(dest));
                }
            }
            foreach (var field in type.GetRuntimeProperties().Where(p => p.CanWrite))
            {
                if (field.PropertyType.IsValueType)
                    field.SetValue(source, field.GetValue(dest));
                else
                {
                    field.GetValue(source).CopyTo(field.GetValue(dest));
                }
            }
        }
    }
}
