﻿using TarFoundation.St;
using TarReferenceSource.Kgmpna.Gmpna;

namespace TarReferenceSource.Kgmpna
{
    public abstract class KgmpnaIo:IFunctionBlock
    {
        // in
        /// <summary>
        /// input Массив данных от модулей Gmpna
        /// </summary>
        public StArray<GmpnaResult> Input;

        // out
        /// <summary>
        /// output Количество готовностей
        /// </summary>
        public int CountReady=>Input.Count;
        /// <summary>
        /// output Обобщенный результат работы модуля
        /// </summary>
        public KgmpnaResult Result;


        public KgmpnaIo(uint count)
        {
            Input = new StArray<GmpnaResult>(1, new GmpnaResult[count]);
            Result = new KgmpnaResult();
        }
    }
}
