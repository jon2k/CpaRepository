﻿using TarReferenceSource.Ktpr;
using TarReferenceSource.Ktpra;

namespace TarReferenceSource.Shoulder
{
    public class ShoulderStopCmd
    {
        public NsStopType StopNsCmd;
        public NaStopType StopNaMethod;
        public bool P;
    }

    public class ShoulderIo
    {
        public readonly ShoulderStopCmd Cmd = new ShoulderStopCmd();
        public readonly ShoulderStopCmd AutoCmd = new ShoulderStopCmd();
        //public NsStopType StopCmd;
        //public NaStopType StopCmdMethod;
        //public NsStopType AutoStopCmd;
        //public NaStopType AutoStopCmdMethod;
        public bool IsSafety;
        public ushort OffNaShoulderCount;
    }
}
