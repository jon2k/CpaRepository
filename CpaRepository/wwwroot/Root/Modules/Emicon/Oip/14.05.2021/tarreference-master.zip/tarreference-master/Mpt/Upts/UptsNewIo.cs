﻿using System;
using System.Collections.Generic;
using System.Linq;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;

namespace TarReferenceSource.Mpt.Upts
{
    public enum enUPTSCmd:byte
    {
        None=			0,
        OnCmd=			1, //(*Команда - включить*)
        OffCmd=		2, //(*Команда - отключить*)
        OffAllCmd=		3, //(*Команда - отключить ВСЕ сирены*)
        BlockCmd=		4, //(*Команда - Заблокировать звонок*)
        UnBlockCmd=	5  //(*Команда - Разблокировать звонок*)
    }
    public class tUPTS
    {
        // (* оперативные флаги*)
        public bool CorrCV; //	(* 0 – флаг «цепь включения неисправна», 1 – флаг «цепь включения исправна» *)
        public bool FlOn;    //	(* дискретный выходной сигнал табло/сирены включен *)
        public bool En;         //		(* автоматическая команда включения табло/сирены*)
        public bool prevEn;//	(* автоматическая команда включения табло/сирены за прошлый цикл *)
        public bool Block;	//	(* флаг блокировки включения звонка/зуммера*)

	//	(* статические флаги конфигурации*)
		public bool IsSiren;		//	(* признак сирены *)
        public bool IsRinger;		//	(* признак звонка/зуммера*)
		public bool EnableCmd;		//	(* признак возможности управления от АРМ*)
		public bool EnableCheckCV;	//	(* наличие контроля цепи включения *)
        public bool Enabled;		//	(* признак использования табло/сирены*)
    }
    public abstract class UptsNewIo:IFunctionBlock
    {
        public UptsNewIo()
        {
            Description.TimerDescriptions = TimerDescriptions;
        }
        public uint NumUPTS; //	(* Актуальное количество Табло/Сирен в системе*)
        public StArray<bool> CorrCV; //(* Сигнал цепи включения*)
        public enUPTSCmd CmdAll; //(* Команда оператора всем Табло/Сиренам в системе*)
        public StArray<enUPTSCmd> Cmd; //(* Команды оператора *)
        public StArray<tUPTS> TU;
        public uint cMaxNumUPTS;
        public UptsNewIo(uint cMaxNumUPTS, uint numUpts)
        {
            Description.TimerDescriptions = TimerDescriptions;
            CorrCV = new StArray<bool>(1, new bool[cMaxNumUPTS]) ;
            Cmd = new StArray<enUPTSCmd>(1, Enumerable.Range(1, (int)cMaxNumUPTS).Select(n => enUPTSCmd.None).ToArray());
            TU = new StArray<tUPTS>(1, Enumerable.Range(1, (int)cMaxNumUPTS).Select(n => new tUPTS()).ToArray());
            this.cMaxNumUPTS = cMaxNumUPTS;
            NumUPTS = numUpts;
        }

        public bool Ringer;	//(* Флаг звуковой сигнализации*)

        public override void AfterCall()
        {
            CmdAll = enUPTSCmd.None;
            for (int i = 1; i <= Cmd.Count; i++)
            {
                Cmd[i] = enUPTSCmd.None;
            }
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {
            {1, new MessageDescription{Text = "ОТКЛЮЧИТЬ ВСЕ СИРЕНЫ ИЗ МДП", Type = MessageType.Information} },
            {2, new MessageDescription{Text = "ВКЛЮЧИТЬ ИЗ МДП", Type = MessageType.Information} },
            {3, new MessageDescription{Text = "ОТКЛЮЧИТЬ ИЗ МДП", Type = MessageType.Information} },
            {4, new MessageDescription{Text = "ВКЛЮЧИТЬ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
            {5, new MessageDescription{Text = "ОТКЛЮЧИТЬ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
            {6, new MessageDescription{Text = "ЦЕПЬ ВКЛЮЧЕНИЯ ИСПРАВНА", Type = MessageType.Neutral} },
            {7, new MessageDescription{Text = "ЦЕПЬ ВКЛЮЧЕНИЯ НЕИСПРАВНА", Type = MessageType.Alarm} },
            {8, new MessageDescription{Text = "ВЫПОЛНЕНИЕ КОМАНДЫ НЕВОЗМОЖНО. БЛОКИРОВКА", Type = MessageType.Attention} },
            {9, new MessageDescription{Text = "ОТКЛЮЧЕНА ПО КОМАНДЕ «ОТКЛЮЧИТЬ ВСЕ СИРЕНЫ»", Type = MessageType.Information} },
            {10, new MessageDescription{Text = "ЗАБЛОКИРОВАТЬ ВКЛЮЧЕНИЕ»", Type = MessageType.Information} },
            {11, new MessageDescription{Text = "РАЗБЛОКИРОВАТЬ ВКЛЮЧЕНИЕ»", Type = MessageType.Information} },
            {20, new MessageDescription{Text = "таймер»", Type = MessageType.Neutral} },
        };
        protected static Dictionary<int, TimerDescription> TimerDescriptions = new Dictionary<int, TimerDescription>
        {
            {1, new TimerDescription("Задержка на установку неисправности цепи включения", TimeSpan.FromMilliseconds(500)) }
           
        };
    }
}
