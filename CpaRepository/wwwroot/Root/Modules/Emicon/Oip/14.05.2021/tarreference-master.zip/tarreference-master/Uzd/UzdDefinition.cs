﻿namespace TarReferenceSource.Uzd
{
    public enum ZdCmd : ushort
    {
        none = 0,
        open = 1,
        close = 2,
        stop = 3,
        setImit = 4,
        dropImit = 5,
        deblock = 6,
    }
    public enum ZdState : ushort
    {
        None = 0,
        Opening = 1,
        Opened = 2,
        Middle = 3,
        Closing = 4,
        Closed = 5
    }
}
