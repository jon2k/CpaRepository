﻿using System.Linq;
using TarFoundation.St;
using TarReferenceSource.Ktpra;
using TarReferenceSource.Shoulder;

namespace TarReferenceSource.Ktpr
{
    public class Ktpr : KtprResultIo
    {
        /// <summary>
        /// 
        /// </summary>
        private StArray<bool> PrevPs;

        public Ktpr(int count)
        {
            Input = new StArray<ProcKtprResult>(1, Enumerable.Range(1, count).Select(i=>new ProcKtprResult()).ToArray());
            Cfg=new StArray<ProcKtprConfig>(1, Enumerable.Range(1, count).Select(i => new ProcKtprConfig()).ToArray());
            Shoulders = new StArray<ShoulderIo>(1, Enumerable.Range(1, count).Select(i => new ShoulderIo()).ToArray());
            Subshoulders = new StArray<SubshoulderIo>(1, Enumerable.Range(1, count).Select(i => new SubshoulderIo()).ToArray());
            PrevPs = new StArray<bool>(1, new bool[count]);
        }

        public override void Execute()
        {
            var incOnlyFirst = new StArray<bool>(1, new bool[Input.Count]);
            for (int i = 1; i < Input.Count; i++)
            {
                Subshoulders[i].AutoCmd.StopNsCmd = NsStopType.None;
                Subshoulders[i].AutoCmd.StopNaMethod = NaStopType.None;
                Subshoulders[i].AutoCmd.P = false;
                Shoulders[i].AutoCmd.StopNsCmd = NsStopType.None;
                Shoulders[i].AutoCmd.StopNaMethod = NaStopType.None;
                Shoulders[i].AutoCmd.P = false;
                incOnlyFirst[i]=false;
            }
            for (int i = 1; i <= Input.Count; i++)
            {
                if (Input[i].P && Cfg[i].AutoStopCmd != NsStopType.StopAllInSubShoulder)
                {
                    for (int j = 1; j <= Shoulders.Count; j++)
                    {
                        if ((Cfg[i].GroupMap & 1 << (j - 1)) > 0)
                        {
                            //KtprResult.Shoulder[j].P = true;
                            if (!PrevPs[i] && Input[i].P)
                            {
                                incOnlyFirst[j] = true;
                            }
                            if (Shoulders[j].AutoCmd.StopNsCmd > Cfg[i].AutoStopCmd)
                            {
                                Shoulders[j].AutoCmd.StopNsCmd = Cfg[i].AutoStopCmd;
                                Shoulders[j].AutoCmd.StopNaMethod = Cfg[i].AutoStopCmdMethod;
                                //Added 
                                Shoulders[j].AutoCmd.P = Input[i].P;
                            }
                        }
                    }
                }
                else if (Input[i].P && Cfg[i].AutoStopCmd == NsStopType.StopAllInSubShoulder)
                {
                    for (int j = 1; j <= Subshoulders.Count; j++)
                    {
                        if ((Cfg[i].GroupMap & 1 << (j - 1)) > 0)
                        {
                            //KtprResult.SubShoulder[j].P = true;
                            if (Subshoulders[j].AutoCmd.StopNsCmd > Cfg[i].AutoStopCmd)
                            {
                                Subshoulders[j].AutoCmd.StopNsCmd = Cfg[i].AutoStopCmd;
                                Subshoulders[j].AutoCmd.StopNaMethod = Cfg[i].AutoStopCmdMethod;
                                //Added 
                                Subshoulders[j].AutoCmd.P = Input[i].P;
                            }
                        }
                    }
                }
                PrevPs[i] = Input[i].P;
            }
            for (int i = 1; i < Shoulders.Count; i++)
            {
                if (Shoulders[i].AutoCmd.StopNsCmd == NsStopType.StopOnlyFirstInShoulder)
                {
                    if (incOnlyFirst[i])
                    {
                        Shoulders[i].OffNaShoulderCount++;
                    }
                }
                else
                {
                    Shoulders[i].OffNaShoulderCount = 0;
                }
            }
        }
    }
}
