﻿using System;
using System.Collections.Generic;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;
using TarReferenceSource.CommonNa;

namespace TarReferenceSource.Kgmpna.Gmpna
{

    public abstract class GmpnaIo : IFunctionBlock
    {
        public GmpnaIo()
        {
            Description.TimerDescriptions = TimerDescriptions;
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }
        //in
        /// <summary>
        /// input Флаг параметра, по которому проверяется готовность
        /// </summary>
        public bool Input;
        /// <summary>
        /// input Команда с АРМ
        /// </summary>
        public GmpnaCmd Cmd;
        /// <summary>
        /// input Состояние агрегата
        /// </summary>
        public NaState MainState;
        //out
        /// <summary>
        /// output Выходные данные модуля
        /// </summary>
        public GmpnaResult Result = new GmpnaResult();
        //cfg
        /// <summary>
        /// cfg Конфигурация модуля
        /// </summary>
        public GmpnaConfig Cfg = new GmpnaConfig();

        public override void AfterCall()
        {
            Cmd = GmpnaCmd.None;
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {
            {1, new MessageDescription{Text = "КОМАНДА - УСТАНОВИТЬ МАСКИРОВАНИЕ", Type = MessageType.Information} },
            {2, new MessageDescription{Text = "НЕ МАСКИРУЕТСЯ. ВЫПОЛНЕНИЕ НЕВОЗМОЖНО", Type = MessageType.Neutral} },
            {3, new MessageDescription{Text = "МАСКИРОВАНИЕ УСТАНОВЛЕНО", Type = MessageType.Neutral} },
            {4, new MessageDescription{Text = "МАСКИРОВАНИЕ УСТАНОВЛЕНО. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {5, new MessageDescription{Text = "КОМАНДА - СНЯТЬ МАСКИРОВАНИЕ", Type = MessageType.Information} },
            {6, new MessageDescription{Text = "МАСКИРОВАНИЕ СНЯТО", Type = MessageType.Neutral} },
            {7, new MessageDescription{Text = "МАСКИРОВАНИЕ СНЯТО. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
            {8, new MessageDescription{Text = "УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {9, new MessageDescription{Text = "СНЯТА", Type = MessageType.Attention} },
            {10, new MessageDescription{Text = "Изменена уставка времени на определение состояния готовности по параметру. Новое значение Ust1", Type = MessageType.Neutral} },
        };
        protected static Dictionary<int, TimerDescription> TimerDescriptions = new Dictionary<int, TimerDescription>
        {
            {1, new TimerDescription("Время на определение состояния готовности по параметру", TimeSpan.FromMilliseconds(500)) }
        };
    }
}
