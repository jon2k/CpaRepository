﻿using System.Collections.Generic;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;
using TarReferenceSource.Mpt.Ktprp;
using TarReferenceSource.Mpt.Sup;

namespace TarReferenceSource.Mpt.Spz
{
    public enum enumSPZCmd : ushort
    {
        NOTHING = 0,
        ResetRepairMode, //снять ремонт
        SetRepairMode   //установить ремонт
    }

    public enum enumSPZState : ushort
    {
        NOTHING = 0,
        Norm,         //Норма
        Attention,    //Внимание
        Fire          //ПОЖАР!
    }
    /// <summary>
    /// Струкрура данных для модуля SUP
    /// </summary>
    public class structSPZtoSUPCmd
    {
        /// <summary>
        /// Состояние пожарной зоны (внимание/пожар)
        /// </summary>
        public enumSPZState State;
        /// <summary>
        /// Флаг ремонта пожарной зоны
        /// </summary>
        public bool IsRem;
        /// <summary>
        /// Флаг маскирования пожарной зоны
        /// </summary>
        public bool ZoneInMask;   //сброс режима автоматически
    }
    /// <summary>
    /// Структура выходных данных модуля SPZ
    /// </summary>
    public class structSPZOutputs
    {
        /// <summary>
        /// Флаг наличия пожара. Используется для оповещения.
        /// </summary>
        public bool Alarm;
        /// <summary>
        /// Струкрура данных для модуля SUP
        /// </summary>
        public structSPZtoSUPCmd ToSUP = new structSPZtoSUPCmd();
    }
    /// <summary>
    /// Структура входных данных для модуля SPZ
    /// </summary>
    public class structSPZInputs
    {
        /// <summary>
        /// команда защищаемому сооружению (вывод в ремонт)
        /// </summary>
        public enumSPZCmd structCmd;
        /// <summary>
        /// Защиты сооружения от KTPRP
        /// </summary>
        public structSPZFireProtOut KTPRP = new structSPZFireProtOut();
        /// <summary>
        /// Сработка одного из SensorCard или AnalogueBusCard
        /// </summary>
        public bool OneSensorTriggered;
        /// <summary>
        /// Данные от модуля SUP
        /// </summary>
        public structSPZFromSUP facilities; //от спз и атп
        //public ushort count;        //конфиг
    }

    public abstract class SpzIo : IFunctionBlock
    {
        public SpzIo()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }
        /// <summary>
        /// input Входные данные модуля 
        /// </summary>
        public structSPZInputs inp = new structSPZInputs();
        /// <summary>
        /// output Выходные данные модуля
        /// </summary>
        public structSPZOutputs output = new structSPZOutputs();

        public override void AfterCall()
        {
            inp.structCmd = enumSPZCmd.NOTHING;
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {
            {1, new MessageDescription{Text = "ПОЖАР", Type = MessageType.Alarm} },
            {2, new MessageDescription{Text = "ВНИМАНИЕ", Type = MessageType.Attention} },
            {3, new MessageDescription{Text = "НОРМА", Type = MessageType.Information} },
            {4, new MessageDescription{Text = "КОМАНДА – НАЗНАЧИТЬ РЕЖИМ РЕМ", Type = MessageType.Information} },
            {5, new MessageDescription{Text = "НАЗНАЧЕНИЕ НЕВОЗМОЖНО. СОСТОЯНИЕ НЕ НОРМА", Type = MessageType.Neutral} },
            {6, new MessageDescription{Text = "НАЗНАЧЕНИЕ НЕВОЗМОЖНО. РЕЖИМ «АВТ» НЕ СБРОШЕН", Type = MessageType.Neutral} },
            {7, new MessageDescription{Text = "НАЗНАЧЕНИЕ НЕВОЗМОЖНО. ИДЕТ ТУШЕНИЕ ПОЖАРА", Type = MessageType.Neutral} },
            {8, new MessageDescription{Text = "НАЗНАЧЕНИЕ НЕ ТРЕБУЕТСЯ. РЕЖИМ РЕМ НАЗНАЧЕН", Type = MessageType.Neutral} },
            {9, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ «РЕМ»", Type = MessageType.Neutral} },
            {10, new MessageDescription{Text = "КОМАНДА – СНЯТЬ РЕЖИМ «РЕМ»", Type = MessageType.Neutral} },
            {11, new MessageDescription{Text = "КОМАНДА НЕ ТРЕБУЕТСЯ. РЕЖИМ РЕМ СНЯТ", Type = MessageType.Neutral} },
            {12, new MessageDescription{Text = "РЕЖИМ РЕМ СНЯТ", Type = MessageType.Neutral} },
        };
    }
}
