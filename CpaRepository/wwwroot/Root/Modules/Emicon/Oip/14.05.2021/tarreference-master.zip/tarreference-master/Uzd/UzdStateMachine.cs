﻿using TarFoundation.St;

namespace TarReferenceSource.Uzd
{
    /// <summary>
    /// Структура данных с нижнего уровня
    /// </summary>
    public struct ZdAbstractNu
    {
        /// <summary>
        /// Флаг не открытия
        /// </summary>
        public bool NotOpened;
        /// <summary>
        /// Флаг не закрытия
        /// </summary>
        public bool NotClosed;
        /// <summary>
        /// Флаг отсуствия напряжения в схеме управления
        /// </summary>
        public bool NoEc;
        /// <summary>
        /// Флаг отсуствия напряжения на секци шин
        /// </summary>
        public bool NoEcSsh;
        /// <summary>
        /// Флаг дистанцилнного контроля
        /// </summary>
        public bool AllowDistControl;
        /// <summary>
        /// Флаг мстного контроля
        /// </summary>
        public bool AllowMestControl;
        /// <summary>
        /// Флаг включения переключателя открытия
        /// </summary>
        public bool OpenSwitchOn;
        /// <summary>
        /// Флаг включения переключателя закрытия
        /// </summary>
        public bool CloseSwitchOn;
        /// <summary>
        /// Флаг аварийного сигнала
        /// </summary>
        public bool HasCrashSignals;
        /// <summary>
        /// Флаг аварии в цепях управления
        /// </summary>
        public bool EcFall;
        /// <summary>
        /// Флаг нажатия кнопки стоп
        /// </summary>
        public bool StopButtonPressed;
        /// <summary>
        /// Флаг нажатия кнопки закрыть
        /// </summary>
        public bool CloseButtonPressed;
    }
    /// <summary>
    /// Структура обработки внутреннего состояния
    /// </summary>
    public class StateProcessingStorage
    {
        /// <summary>
        /// Основное состояние задвижки
        /// </summary>
        public ZdStateProcessing state = ZdStateProcessing.Init;
        /// <summary>
        /// Дополнительное состояние задвижки
        /// </summary>
        public ZdStateSubstate substate = ZdStateSubstate.None;

        public bool MpCheckEnabled;
        public bool InverseMpCheckEnabled;
        public bool MoveCheckEnabled;

        public ZdStopProcessing stoppingSubstate = ZdStopProcessing.None;
        public ZdMovementProcessing openingSubstate = ZdMovementProcessing.None;
        public ZdMovementProcessing closingSubstate = ZdMovementProcessing.None;

        /// <summary>
        /// Невыполнение команды на закрытие ДЛЯ TM
        /// </summary>
        public bool CloseFail; /*   Невыполнение команды на закрытие ДЛЯ TM*/
        /// <summary>
        /// Невыполнение команды на открытие ДЛЯ TM
        /// </summary>
        public bool OpenFail; /*Невыполнение команды на открытие ДЛЯ TM*/
        /// <summary>
        /// Невыполнение команды стоп ДЛЯ TM
        /// </summary>
        public bool StopFail; /*Невыполнение команды стоп ДЛЯ TM*/
        /// <summary>
        /// Самопроизвольное открытие задвижки ДЛЯ TM
        /// </summary>
        public bool UnpromptedOpen; /*Самопроизвольное открытие задвижки ДЛЯ TM*/
        /// <summary>
        /// Самопроизвольное закрытие задвижки ДЛЯ TM
        /// </summary>
        public bool UnpromptedClose; /*Самопроизвольное закрытие задвижки ДЛЯ TM*/
        /// <summary>
        /// Авария магнитного пускателя открытия
        /// </summary>
        public bool ErrMpo;
        /// <summary>
        /// Авария магнитного пускателя закрытия
        /// </summary>
        public bool ErrMpz;
        /// <summary>
        /// Ожидание появления напряжения на секции шин
        /// </summary>
        public bool WaitSsh;
        /// <summary>
        /// Авария
        /// </summary>
        public bool Crash;
    }

    public partial class ProcUzd
    {
        public bool EnableSwitchOperation(ZdAbstractNu NuState, CheckError error, ITimer timer)
        {

            if (state.openingSubstate == ZdMovementProcessing.SwitchEnabling)
            {
                if (NuState.OpenSwitchOn)
                {
                    return true;
                }
                
                if (NuState.NotClosed && !NuState.NotOpened && state.openingSubstate != ZdMovementProcessing.None ||
                    !NuState.NotClosed && NuState.NotOpened && state.closingSubstate != ZdMovementProcessing.None)
                {
                    return true;
                }

                if (NuState.HasCrashSignals)
                {
                    //сообщение выдаст алгоритм обработки аварийный сигналов
                    state.openingSubstate = ZdMovementProcessing.Fail;
                }
                else if (error == CheckError.Crash)
                {
                    state.openingSubstate = ZdMovementProcessing.Fail;
                }
                else if (error == CheckError.NonCrash)
                {
                    state.openingSubstate = ZdMovementProcessing.Canceled;
                }
                else if (NuState.NoEcSsh && (NuState.NoEc || !timer.IsStarted))
                {
                    Messenger.Send(95);//НЕ ВКЛЮЧИЛСЯ МАГНИТНЫЙ ПУСКАТЕЛЬ. НЕТ НАПРЯЖЕНИЯ НА СШ ЩСУ
                    state.openingSubstate = ZdMovementProcessing.Canceled;
                    state.WaitSsh = true;
                    if (!NuState.NoEc)
                    {
                        NeedCrashStop = true;
                    }
                }
                else if (NuState.NoEc)
                {
                    //Messenger.Send(104);//НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ
                    state.openingSubstate = ZdMovementProcessing.Canceled;
                }
                else if (timer.IsStarted)
                {
                    //давим открыть
                }
                else
                {
                    //сообщение "мп не включился"
                    Messenger.Send(86);
                    state.openingSubstate = ZdMovementProcessing.Fail;
                    NeedCrashStop = true;
                }
            }

            if (state.closingSubstate == ZdMovementProcessing.SwitchEnabling)
            {
                if (NuState.CloseSwitchOn && state.closingSubstate != ZdMovementProcessing.None)
                {
                    return true;
                }
                else if (NuState.NotClosed && !NuState.NotOpened && state.openingSubstate != ZdMovementProcessing.None ||
                    !NuState.NotClosed && NuState.NotOpened && state.closingSubstate != ZdMovementProcessing.None)
                {
                    return true;
                }
                else if (NuState.HasCrashSignals)
                {
                    //сообщение выдаст алгоритм обработки аварийный сигналов
                    state.closingSubstate = ZdMovementProcessing.Fail;
                }
                else if (error == CheckError.Crash)
                {
                    state.closingSubstate = ZdMovementProcessing.Fail;
                }
                else if (error == CheckError.NonCrash)
                {
                    state.closingSubstate = ZdMovementProcessing.Canceled;
                }
                else if (NuState.NoEcSsh && (NuState.NoEc || !timer.IsStarted))
                {
                    Messenger.Send(95);//НЕ ВКЛЮЧИЛСЯ МАГНИТНЫЙ ПУСКАТЕЛЬ. НЕТ НАПРЯЖЕНИЯ НА СШ ЩСУ
                    state.closingSubstate = ZdMovementProcessing.Canceled;
                    state.WaitSsh = true;
                    if (!NuState.NoEc)
                    {
                        NeedCrashStop = true;
                    }
                }
                else if (NuState.NoEc)
                {
                    //Messenger.Send(104);//НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ
                    state.closingSubstate = ZdMovementProcessing.Canceled;
                }
                else if (timer.IsStarted)
                {
                    //давим открыть
                }
                else
                {
                    //сообщение "мп не включился"
                    Messenger.Send(86);
                    state.closingSubstate = ZdMovementProcessing.Fail;
                    NeedCrashStop = true;
                }
            }

            return false;
        }

        public void MpEnableChecker(ZdAbstractNu NuState, ref CheckError error)
        {
            if (state.MpCheckEnabled && error == CheckError.None)
            {
                if (state.Crash)
                {
                    error = CheckError.NonCrash;
                    NeedCrashStop = true;
                }
                else if (NuState.OpenSwitchOn && state.openingSubstate != ZdMovementProcessing.None)
                {
                    ;
                }
                else if (NuState.CloseSwitchOn && state.closingSubstate != ZdMovementProcessing.None)
                {
                    ;
                }
                else if (NuState.HasCrashSignals)
                {
                    //сообщение выдаст алгоритм обработки аварийный сигналов
                    error = CheckError.Crash;
                }
                else if (!NuState.NotOpened && NuState.NotClosed && state.openingSubstate != ZdMovementProcessing.None)
                {

                }
                else if (NuState.NotOpened && !NuState.NotClosed && state.closingSubstate != ZdMovementProcessing.None)
                {

                }
                else if (NuState.NoEcSsh)
                {
                    if (state.openingSubstate != ZdMovementProcessing.None)
                        Messenger.Send(112);//МПО ОТКЛЮЧИЛСЯ. НЕТ НАПРЯЖЕНИЯ НА СШ ЩСУ
                    else
                        Messenger.Send(111); //МПЗ ОТКЛЮЧИЛСЯ. НЕТ НАПРЯЖЕНИЯ НА СШ ЩСУ

                    error = CheckError.NonCrash;
                    state.WaitSsh = true;
                }

                else if (NuState.StopButtonPressed)
                {
                    //сообщение выдадим в обработчике стопа
                    error = CheckError.NonCrash;
                }
                else if (NuState.NoEc)
                {
                    error = CheckError.NonCrash;
                    if (state.openingSubstate != ZdMovementProcessing.None)
                        state.stoppingSubstate = ZdStopProcessing.WaitingOpeningMestStop;
                    else
                        state.stoppingSubstate = ZdStopProcessing.WaitingClosingMestStop;
                }
                else
                {
                    if (state.openingSubstate != ZdMovementProcessing.None)
                        Messenger.Send(88);//МПО ОТКЛЮЧИЛСЯ ПО НЕУСТАНОВЛЕННОЙ ПРИЧИНЕ. АВАРИЯ
                    else
                        Messenger.Send(089);//МПЗ ОТКЛЮЧИЛСЯ ПО НЕУСТАНОВЛЕННОЙ ПРИЧИНЕ. АВАРИЯ
                    
                    error = CheckError.Crash;
                }
            }
        }

        public void InverseMpDisableChecker(ZdAbstractNu NuState, ref CheckError error)
        {
            if (state.InverseMpCheckEnabled && error == CheckError.None)
            {
                if (NuState.CloseSwitchOn && NuState.OpenSwitchOn)
                {
                    Messenger.Send(084);//ВКЛЮЧЕНЫ МПО И МПЗ. АВАРИЯ
                    error = CheckError.Crash;
                    NeedCrashStop = true;
                }
                else if (NuState.CloseSwitchOn && state.openingSubstate != ZdMovementProcessing.None)
                {
                    Messenger.Send(92);//НЕ ОТКРЫЛАСЬ. АВАРИЯ
                    error = CheckError.Crash;
                    NeedCrashStop = true;
                }
                else if (NuState.OpenSwitchOn && state.closingSubstate != ZdMovementProcessing.None)
                {
                    Messenger.Send(90);//НЕ ЗАКРЫЛАСЬ. АВАРИЯ
                    error = CheckError.Crash;
                    NeedCrashStop = true;
                }
            }
        }

        public bool WaitMoveOperation(ZdAbstractNu NuState, CheckError error, ITimer timer)
        {
            if (state.openingSubstate == ZdMovementProcessing.MoveWaiting)
            {
                if (NuState.NotClosed)
                {
                    return true;
                }
                if (error == CheckError.Crash)
                {
                    state.openingSubstate = ZdMovementProcessing.Fail;
                }
                else if (error == CheckError.NonCrash)
                {
                    state.openingSubstate = ZdMovementProcessing.Canceled;
                }
                else if (!timer.IsStarted)
                {
                    state.openingSubstate = ZdMovementProcessing.Fail;
                    Messenger.Send(91); //НЕ ВЫШЛА ИЗ КРАЙНЕГО ПОЛОЖЕНИЯ.АВАРИЯ
                    NeedCrashStop = true;
                }
            }

            if (state.closingSubstate == ZdMovementProcessing.MoveWaiting)
            {
                if (NuState.NotOpened)
                {
                    return true;
                }
                if (error == CheckError.Crash)
                {
                    state.closingSubstate = ZdMovementProcessing.Fail;
                }
                else if (error == CheckError.NonCrash)
                {
                    state.closingSubstate = ZdMovementProcessing.Canceled;
                }
                else if (!timer.IsStarted)
                {
                    state.closingSubstate = ZdMovementProcessing.Fail;
                    Messenger.Send(91); //НЕ ВЫШЛА ИЗ КРАЙНЕГО ПОЛОЖЕНИЯ.АВАРИЯ
                    NeedCrashStop = true;
                }
            }

            return false;
        }

        public void MoveChecker(ZdAbstractNu NuState, ref CheckError error)
        {
            if (state.MoveCheckEnabled && error == CheckError.None)
            {
                if (NuState.NoEc)
                {
                    ;
                }
                else if (NuState.NotOpened && state.closingSubstate != ZdMovementProcessing.None)
                {
                    ;
                }
                else if(NuState.NotClosed && state.openingSubstate != ZdMovementProcessing.None)
                {
                    ;
                }
                else
                {
                    if (state.openingSubstate != ZdMovementProcessing.None)
                        Messenger.Send(92);//НЕ ОТКРЫЛАСЬ. АВАРИЯ
                    else
                        Messenger.Send(090);//НЕ ЗАКРЫЛАСЬ. АВАРИЯ

                    error = CheckError.Crash;
                }
            }
        }

        public bool MovementOperation(ZdAbstractNu NuState, CheckError error, ITimer timer)
        {

            if (state.openingSubstate == ZdMovementProcessing.Movement)
            {
                if (error == CheckError.Crash)
                {
                    state.openingSubstate = ZdMovementProcessing.Fail;
                }
                else if (error == CheckError.NonCrash)
                {
                    state.openingSubstate = ZdMovementProcessing.Canceled;
                }
                else if (!NuState.NotOpened && !NuState.NoEc)
                {
                    return true;
                }
                else if (NuState.HasCrashSignals)
                {
                    state.openingSubstate = ZdMovementProcessing.Fail;
                    NeedCrashStop = true;
                }
                else if (!timer.IsStarted)
                {
                    Messenger.Send(92); //НЕ ОТКРЫЛАСЬ. АВАРИЯ
                    state.openingSubstate = ZdMovementProcessing.Fail;
                    NeedCrashStop = true;
                }
            }

            if (state.closingSubstate == ZdMovementProcessing.Movement)
            {
                if (error == CheckError.Crash)
                {
                    state.closingSubstate = ZdMovementProcessing.Fail;
                }
                else if (error == CheckError.NonCrash)
                {
                    state.closingSubstate = ZdMovementProcessing.Canceled;
                }
                else if (!NuState.NotClosed && !NuState.NoEc)
                {
                    return true;
                }
                else if (NuState.HasCrashSignals)
                {
                    state.closingSubstate = ZdMovementProcessing.Fail;
                    NeedCrashStop = true;
                }
                else if (!timer.IsStarted)
                {
                    Messenger.Send(90); //НЕ ЗАКРЫЛАСЬ. АВАРИЯ
                    state.closingSubstate = ZdMovementProcessing.Fail;
                    NeedCrashStop = true;
                }
            }

            return false;
        }

        public bool SelfStopOperation(ZdAbstractNu NuState, CheckError error, ITimer timer)
        {
            if (state.openingSubstate == ZdMovementProcessing.Selfstop)
            {
                if (!NuState.OpenSwitchOn)
                {
                    return true;
                }
                if (error == CheckError.Crash)
                {
                    state.openingSubstate = ZdMovementProcessing.Fail;
                }
                else if (error == CheckError.NonCrash)
                {
                    state.openingSubstate = ZdMovementProcessing.Canceled;
                }
                else if (!timer.IsStarted)
                {
                    state.ErrMpo = true;
                    Messenger.Send(100); /* Сообщение : "ЦЕПИ КОНТРОЛЯ МПО НЕИСПРАВНЫ. АВАРИЯ" */
                    state.Crash = true;//т.к. это не является невыполнением команды, то выставляем аварию здесь и отменяем
                    state.openingSubstate = ZdMovementProcessing.Canceled;
                }
            }

            if (state.closingSubstate == ZdMovementProcessing.Selfstop)
            {
                 if (!NuState.CloseSwitchOn)
                {
                    return true;
                }
                if (error == CheckError.Crash)
                {
                    state.closingSubstate = ZdMovementProcessing.Fail;
                }
                else if (error == CheckError.NonCrash)
                {
                    state.closingSubstate = ZdMovementProcessing.Canceled;
                }
                else if (!timer.IsStarted)
                {
                    state.ErrMpz = true;
                    Messenger.Send(098); /*Сообщение : "ЦЕПИ КОНТРОЛЯ МПЗ НЕИСПРАВНЫ. АВАРИЯ" */
                    state.Crash = true;//т.к. это не является невыполнением команды, то выставляем аварию здесь и отменяем
                    state.closingSubstate = ZdMovementProcessing.Canceled;
                }
            }

            return false;
        }

        /// <summary>
        /// НЕобходимость аварийной остановки
        /// </summary>
        private bool NeedCrashStop;
        /// <summary>
        /// Необходимость обновить состояния
        /// </summary>
        private bool needUpdateState;
        /// <summary>
        /// Состояние задвижки
        /// </summary>
        StateProcessingStorage state = new StateProcessingStorage();
        /// <summary>
        /// Дополнительное состояние задвижки
        /// </summary>
        ZdStateSubstate substate = ZdStateSubstate.None;

        private void StateProcessing(bool stopCmdAccepted, bool closeCmdAccepted, bool openCmdAccepted, ZdAbstractNu nuState)
        {
            NeedCrashStop = false;
            if (stopCmdAccepted)
            {
                if (state.stoppingSubstate == ZdStopProcessing.None || state.stoppingSubstate == ZdStopProcessing.Fail)
                {
                    state.stoppingSubstate = ZdStopProcessing.Init;
                    state.state = ZdStateProcessing.CommandExecution;
                }

                if (state.openingSubstate != ZdMovementProcessing.None)
                {
                    state.openingSubstate = ZdMovementProcessing.Canceled;
                }

                if (state.closingSubstate != ZdMovementProcessing.None)
                {
                    state.closingSubstate = ZdMovementProcessing.Canceled;
                }
            }

            if (openCmdAccepted)
            {
                state.openingSubstate = ZdMovementProcessing.Init;
                state.state = ZdStateProcessing.CommandExecution;
            }

            if (closeCmdAccepted)
            {
                state.closingSubstate = ZdMovementProcessing.Init;
                state.state = ZdStateProcessing.CommandExecution;
            }


            #region State processing


            if (nuState.NoEc)
            {
                substate = ZdStateSubstate.NoEc;
            }
            else if (nuState.NotOpened && nuState.NotClosed)
            {
                substate = ZdStateSubstate.Middle;
            }
            else if (nuState.NotOpened)
            {
                substate = ZdStateSubstate.Closed;
            }
            else if (nuState.NotClosed)
            {
                substate = ZdStateSubstate.Opened;
            }
            else
            {
                substate = ZdStateSubstate.NoEc;
            }

            if (nuState.CloseSwitchOn && nuState.OpenSwitchOn)
            {
                substate = ZdStateSubstate.None;
            }

            if (substate == ZdStateSubstate.Middle)
            {
                if (nuState.CloseSwitchOn)
                {
                    substate = ZdStateSubstate.Closing;
                }
                else if (nuState.OpenSwitchOn)
                {
                    substate = ZdStateSubstate.Opening;
                }
            }

            var okChangeState = substate == ZdStateSubstate.NoEc || /*Если технические переходы - норм*/
                                zd.State == ZdState.None ||
                                zd.State == ZdState.Closed && (substate == ZdStateSubstate.Closed || substate == ZdStateSubstate.Opening) || /*Из закрыта мы можем перейти только в закрыта, открывается*/
                                zd.State == ZdState.Closing && (substate == ZdStateSubstate.Closing || substate == ZdStateSubstate.Middle || substate == ZdStateSubstate.Closed) || /*Из закрывается мы можем перейти только в промежуток, закрывается, закрыта*/
                                zd.State == ZdState.Middle && (substate == ZdStateSubstate.Middle || substate == ZdStateSubstate.Opening || substate == ZdStateSubstate.Closing) || /*Из промежутка мы можем перейти только в открывается,закрывается,промежуток*/
                                zd.State == ZdState.Opened && (substate == ZdStateSubstate.Opened || substate == ZdStateSubstate.Closing) || /*Из открыта мы можем перейти только в  открыта, закрывается*/
                                zd.State == ZdState.Opening && (substate == ZdStateSubstate.Opening || substate == ZdStateSubstate.Middle || substate == ZdStateSubstate.Opened); /*Из открывается мы можем перейти только в промежуток, открывается, открыта*/


            needUpdateState = false;

            if (state.state == ZdStateProcessing.Init)
            {
                if (substate != ZdStateSubstate.NoEc)
                {
                    state.state = ZdStateProcessing.Transition;
                }
            }

            if (state.state == ZdStateProcessing.Waiting)
            {
                //появление пускателя открытия
                if (state.substate == ZdStateSubstate.Closed ||
                    state.substate == ZdStateSubstate.Middle)
                {
                    if (nuState.OpenSwitchOn && !nuState.CloseSwitchOn && !state.ErrMpo)
                    {
                        state.state = ZdStateProcessing.Transition;
                    }
                }

                if (state.substate == ZdStateSubstate.Opened ||
                    state.substate == ZdStateSubstate.Middle)
                {
                    if (nuState.CloseSwitchOn && !nuState.OpenSwitchOn && !state.ErrMpz)
                    {
                        state.state = ZdStateProcessing.Transition;
                    }
                }

                if (substate != state.substate)
                {
                    if (okChangeState || !cfg.SlCheckState)
                    {
                        state.state = ZdStateProcessing.Transition;
                    }
                    else
                    {
                        state.state = ZdStateProcessing.Freeze;
                    }

                }
            }

            if (state.state == ZdStateProcessing.Freeze)
            {
                if (okChangeState || !cfg.SlCheckState)
                {
                    state.state = ZdStateProcessing.Transition;
                    InternalTimers[14].Stop();
                }
                else if (InternalTimers[14].IsQ)
                {
                    state.state = ZdStateProcessing.Transition;
                    InternalTimers[14].Stop();
                }
                else if (!InternalTimers[14].IsStarted)
                {
                    InternalTimers[14].Start();
                }

                if (InternalTimers[14].IsQ)
                {
                    state.state = ZdStateProcessing.Transition;
                    InternalTimers[14].Stop();
                }
            }
            else
            {
                InternalTimers[14].Stop();
            }

            if (state.state == ZdStateProcessing.Transition)
            {
                //появление пускателя открытия

                if (nuState.OpenSwitchOn && nuState.CloseSwitchOn)
                {
                    Messenger.Send(084); /* Сообщение : "ВКЛЮЧЕНЫ МПО И МПЗ. АВАРИЯ" */
                    state.Crash = true;
                    state.state = ZdStateProcessing.Waiting;
                }
                else
                {
                    if (state.substate == ZdStateSubstate.Closed ||
                        state.substate == ZdStateSubstate.Middle ||
                        state.substate == ZdStateSubstate.Closing ||
                        state.substate == ZdStateSubstate.NoEc ||
                        state.substate == ZdStateSubstate.None)
                    {
                        if (nuState.OpenSwitchOn && !state.ErrMpo && !state.UnpromptedOpen)
                        {
                            if (nuState.AllowMestControl)
                            {
                                Messenger.Send(34);
                                state.openingSubstate = ZdMovementProcessing.Init;
                                state.state = ZdStateProcessing.CommandExecution;
                            }
                            else
                            {
                                Messenger.Send(97);
                                state.UnpromptedOpen = true;
                                state.Crash = true;
                                state.stoppingSubstate = ZdStopProcessing.Init;
                                state.state = ZdStateProcessing.CommandExecution;
                            }
                        }
                    }

                    if (state.substate == ZdStateSubstate.Opened ||
                        state.substate == ZdStateSubstate.Middle ||
                        state.substate == ZdStateSubstate.Opening ||
                        state.substate == ZdStateSubstate.NoEc ||
                        state.substate == ZdStateSubstate.None)
                    {
                        if (nuState.CloseSwitchOn && !state.ErrMpz && !state.UnpromptedClose)
                        {
                            if (nuState.CloseButtonPressed)
                            {
                                Messenger.Send(52);//"КОМАНДА - ЗАКРЫТЬ С БРУ"
                                state.closingSubstate = ZdMovementProcessing.Init;
                                state.state = ZdStateProcessing.CommandExecution;
                            }
                            else if (nuState.AllowMestControl)
                            {
                                Messenger.Send(48);
                                state.closingSubstate = ZdMovementProcessing.Init;
                                state.state = ZdStateProcessing.CommandExecution;
                            }
                            else
                            {
                                Messenger.Send(85);
                                state.UnpromptedClose = true;
                                state.Crash = true;
                                state.stoppingSubstate = ZdStopProcessing.Init;
                                state.state = ZdStateProcessing.CommandExecution;
                            }
                        }
                    }
                }
                

                if (state.state == ZdStateProcessing.CommandExecution)
                {

                }
                else
                {
                    if (state.substate == ZdStateSubstate.Opened &&
                        (substate == ZdStateSubstate.Middle || substate == ZdStateSubstate.Closed) ||
                        state.substate == ZdStateSubstate.Middle &&
                        (substate == ZdStateSubstate.Opened || substate == ZdStateSubstate.Closed) ||
                        state.substate == ZdStateSubstate.Closed &&
                        (substate == ZdStateSubstate.Opened || substate == ZdStateSubstate.Middle))
                    {
                        Messenger.Send(123);
                    }
                    state.state = ZdStateProcessing.Waiting;
                }

                needUpdateState = true;

            }

            if (state.state == ZdStateProcessing.CommandExecution)
            {

                needUpdateState = true;
            }

            #endregion

            #region Open Processing

            CheckError checkError = CheckError.None;

            if (state.openingSubstate == ZdMovementProcessing.Canceled ||
                state.closingSubstate == ZdMovementProcessing.Canceled)
            {
                checkError = CheckError.NonCrash;
            }

                if (state.openingSubstate == ZdMovementProcessing.Init ||
                state.closingSubstate == ZdMovementProcessing.Init)
            {
                state.MpCheckEnabled = false;
                state.MoveCheckEnabled = false;
                state.InverseMpCheckEnabled = false;
            }

            if (state.openingSubstate == ZdMovementProcessing.Init)
            {
                if (state.closingSubstate != ZdMovementProcessing.None)
                {
                    state.openingSubstate = ZdMovementProcessing.ReverseStop;
                    state.closingSubstate = ZdMovementProcessing.Canceled;
                    if (state.stoppingSubstate == ZdStopProcessing.None)
                    {
                        state.stoppingSubstate = ZdStopProcessing.Init;
                    }
                }
                else if (state.stoppingSubstate == ZdStopProcessing.None)
                {
                    state.openingSubstate = ZdMovementProcessing.SwitchEnablingInit;
                }
            }

            if (state.closingSubstate == ZdMovementProcessing.Init)
            {
                if (state.openingSubstate != ZdMovementProcessing.None)
                {
                    state.closingSubstate = ZdMovementProcessing.ReverseStop;
                    state.openingSubstate = ZdMovementProcessing.Canceled;
                    if (state.stoppingSubstate == ZdStopProcessing.None)
                    {
                        state.stoppingSubstate = ZdStopProcessing.Init;
                    }
                }
                else if (state.stoppingSubstate == ZdStopProcessing.None)
                {
                    state.closingSubstate = ZdMovementProcessing.SwitchEnablingInit;
                }
            }

            if (state.openingSubstate == ZdMovementProcessing.ReverseStop)
            {

                if (state.stoppingSubstate == ZdStopProcessing.None)
                {
                    if (zd.State != ZdState.Opened)
                    {
                        state.openingSubstate = ZdMovementProcessing.SwitchEnablingInit;
                        Messenger.Send(035); /* Сообщение : "КОМАНДА - ОТКРЫТЬ АВТОМАТИЧЕСКИ" */
                    }
                    else
                    {
                        state.openingSubstate = ZdMovementProcessing.Success;
                    }
                }
                else if (state.stoppingSubstate == ZdStopProcessing.Fail)
                {
                    state.openingSubstate = ZdMovementProcessing.Fail;
                }
            }

            if (state.closingSubstate == ZdMovementProcessing.ReverseStop)
            {

                if (state.stoppingSubstate == ZdStopProcessing.None)
                {
                    if (zd.State != ZdState.Closed)
                    {
                        state.closingSubstate = ZdMovementProcessing.SwitchEnablingInit;
                        Messenger.Send(049); /* Сообщение : "КОМАНДА - ЗАКРЫТЬ АВТОМАТИЧЕСКИ" */
                    }
                    else
                    {
                        state.closingSubstate = ZdMovementProcessing.Success;
                    }
                    
                }
                else if (state.stoppingSubstate == ZdStopProcessing.Fail)
                {
                    state.closingSubstate = ZdMovementProcessing.Fail;
                }
            }

            InverseMpDisableChecker(nuState, ref checkError);

            /*
             * Ожидание включения магнитного пускателя
             */
            //ожидание МПО
            if (state.openingSubstate == ZdMovementProcessing.SwitchEnablingInit)
            {
                InternalTimers[2].Start();
                state.InverseMpCheckEnabled = true;
                state.openingSubstate = ZdMovementProcessing.SwitchEnabling;
            }

            if (state.openingSubstate == ZdMovementProcessing.SwitchEnabling)
            {
                if (EnableSwitchOperation(nuState, checkError, InternalTimers[2]))//дождались
                {
                    state.openingSubstate = ZdMovementProcessing.MoveWaitingInit;
                    state.MpCheckEnabled = true;
                }
            }

            //Ожидание МПЗ
            if (state.closingSubstate == ZdMovementProcessing.SwitchEnablingInit)
            {
                InternalTimers[2].Start();
                state.InverseMpCheckEnabled = true;
                state.closingSubstate = ZdMovementProcessing.SwitchEnabling;
            }

            if (state.closingSubstate == ZdMovementProcessing.SwitchEnabling)
            {
                if (EnableSwitchOperation(nuState, checkError, InternalTimers[2]))//дождались
                {
                    state.closingSubstate = ZdMovementProcessing.MoveWaitingInit;
                    state.MpCheckEnabled = true;

                }
            }

            if (state.openingSubstate != ZdMovementProcessing.SwitchEnabling && state.closingSubstate != ZdMovementProcessing.SwitchEnabling)
            {
                InternalTimers[2].Stop();
            }


            MpEnableChecker(nuState, ref checkError);

            /*
             * Ожидание схода с концевика
             */
             //Сход с КВО
            if (state.openingSubstate == ZdMovementProcessing.MoveWaitingInit)
            {
                InternalTimers[3].Start();
                state.openingSubstate = ZdMovementProcessing.MoveWaiting;
            }

            if (state.openingSubstate == ZdMovementProcessing.MoveWaiting)
            {
                if (WaitMoveOperation(nuState, checkError, InternalTimers[3]))//дождались
                {
                    state.openingSubstate = ZdMovementProcessing.MovementInit;
                    state.MoveCheckEnabled = true;
                }
            }

            //сход с КВЗ
            if (state.closingSubstate == ZdMovementProcessing.MoveWaitingInit)
            {
                InternalTimers[3].Start();
                state.closingSubstate = ZdMovementProcessing.MoveWaiting;
            }

            if (state.closingSubstate == ZdMovementProcessing.MoveWaiting)
            {
                if (WaitMoveOperation(nuState, checkError, InternalTimers[3]))//дождались
                {
                    state.closingSubstate = ZdMovementProcessing.MovementInit;
                    state.MoveCheckEnabled = true;
                }
            }

            if (state.closingSubstate != ZdMovementProcessing.MoveWaiting &&
                state.openingSubstate != ZdMovementProcessing.MoveWaiting)
            {
                InternalTimers[3].Stop();
            }

            MoveChecker(nuState, ref checkError);
            /*
             * Движение после схода с концевика
             */
             //открытие
            if (state.openingSubstate == ZdMovementProcessing.MovementInit)
            {
                InternalTimers[4].Start();
                state.openingSubstate = ZdMovementProcessing.Movement;
            }

            if (state.openingSubstate == ZdMovementProcessing.Movement)
            {
                if (MovementOperation(nuState, checkError, InternalTimers[4]))//дождались
                {
                    state.openingSubstate = ZdMovementProcessing.SelfstopInit;
                }
            }
            //закрытие
            if (state.closingSubstate == ZdMovementProcessing.MovementInit)
            {
                InternalTimers[4].Start();
                state.closingSubstate = ZdMovementProcessing.Movement;
            }

            if (state.closingSubstate == ZdMovementProcessing.Movement)
            {
                if (MovementOperation(nuState, checkError, InternalTimers[4]))//дождались
                {
                    state.closingSubstate = ZdMovementProcessing.SelfstopInit;
                }
            }

            if (state.openingSubstate != ZdMovementProcessing.Movement &&
                state.closingSubstate != ZdMovementProcessing.Movement)
            {
                InternalTimers[4].Stop();
            }

            /*
             * ожидание отключения МП после захода на концевик
             */
            //ожидание отключения МПО
            if (state.openingSubstate == ZdMovementProcessing.SelfstopInit)
            {
                InternalTimers[5].Start();
                state.openingSubstate = ZdMovementProcessing.Selfstop;
            }

            if (state.openingSubstate == ZdMovementProcessing.Selfstop)
            {
                if (SelfStopOperation(nuState, checkError, InternalTimers[5]))//дождались
                {
                    state.openingSubstate = ZdMovementProcessing.Success;
                }
            }
            //ожидание отключения МПЗ
            if (state.closingSubstate == ZdMovementProcessing.SelfstopInit)
            {
                InternalTimers[5].Start();
                state.closingSubstate = ZdMovementProcessing.Selfstop;
            }

            if (state.closingSubstate == ZdMovementProcessing.Selfstop)
            {
                if (SelfStopOperation(nuState, checkError, InternalTimers[5]))//дождались
                {
                    state.closingSubstate = ZdMovementProcessing.Success;
                }
            }

            if (state.openingSubstate != ZdMovementProcessing.Selfstop &&
                state.closingSubstate != ZdMovementProcessing.Selfstop)
            {
                if (state.state == ZdStateProcessing.CommandExecution)
                {
                    InternalTimers[5].Stop();
                }
            }

            if (state.openingSubstate == ZdMovementProcessing.Fail)
            {
                state.OpenFail = !nuState.HasCrashSignals;
                state.Crash = true;
                state.openingSubstate = ZdMovementProcessing.Canceled;
            }

            if (state.closingSubstate == ZdMovementProcessing.Fail)
            {
                state.CloseFail = true;
                state.Crash = true;
                state.closingSubstate = ZdMovementProcessing.Canceled;
            }


            #endregion

            if (nuState.HasCrashSignals)
            {
                state.Crash = true;
            }

            if (state.Crash)
            {
                if (state.closingSubstate != ZdMovementProcessing.None)
                {
                    state.closingSubstate = ZdMovementProcessing.Canceled;
                }
                if (state.openingSubstate != ZdMovementProcessing.None)
                {
                    state.openingSubstate = ZdMovementProcessing.Canceled;
                }
            }

            if (NeedCrashStop)
            {
                state.stoppingSubstate = ZdStopProcessing.Init;
                state.state = ZdStateProcessing.CommandExecution;
            }

            #region StopProcessing

            if (state.stoppingSubstate == ZdStopProcessing.Init)
            {
                if (!stopCmdAccepted)
                {
                    if (cfg.Sl2Stop && state.closingSubstate == ZdMovementProcessing.Canceled)
                    {
                        Messenger.Send(063); /* Сообщение : "КОМАНДА - СТОП ЗАКРЫТИЯ АВТОМАТИЧЕСКИ" */
                    }
                    else if (cfg.Sl2Stop && state.openingSubstate == ZdMovementProcessing.Canceled)
                    {
                        Messenger.Send(062); /* Сообщение : "КОМАНДА - СТОП ОТКРЫТИЯ АВТОМАТИЧЕСКИ" */
                    }
                    else
                    {
                        Messenger.Send(064); /* Сообщение : "КОМАНДА - СТОП АВТОМАТИЧЕСКИ" */
                    }


                }

                if (cfg.Sl2Stop && state.closingSubstate == ZdMovementProcessing.Canceled)
                {
                    state.stoppingSubstate = ZdStopProcessing.CloseStopping;
                }
                else if (cfg.Sl2Stop && state.openingSubstate == ZdMovementProcessing.Canceled)
                {
                    state.stoppingSubstate = ZdStopProcessing.OpenStopping;
                }
                else
                {
                    state.stoppingSubstate = ZdStopProcessing.Stopping;
                }

                InternalTimers[8].Start();//время стопа
            }

            if (state.stoppingSubstate == ZdStopProcessing.Stopping || 
                state.stoppingSubstate == ZdStopProcessing.OpenStopping || 
                state.stoppingSubstate == ZdStopProcessing.CloseStopping)
            {
                if (InternalTimers[8].IsStarted)
                {
                    //давим стоп
                }
                else
                {
                    if (!nuState.CloseSwitchOn && !nuState.OpenSwitchOn)//успешная остановка
                    {
                        state.stoppingSubstate = ZdStopProcessing.AfterStop;
                        InternalTimers[9].Start();
                    }
                    else
                    {
                        Messenger.Send(070); /*Сообщение : "КОМАНДА СТОП НЕ ВЫПОЛНЕНА. АВАРИЯ" */
                        state.stoppingSubstate = ZdStopProcessing.Fail;
                        state.StopFail = true;
                        state.Crash = true;
                        state.ErrMpo = nuState.OpenSwitchOn;
                        state.ErrMpz = nuState.CloseSwitchOn;
                    }
                }
            }

            if (state.stoppingSubstate == ZdStopProcessing.WaitingOpeningMestStop ||
                state.stoppingSubstate == ZdStopProcessing.WaitingClosingMestStop)
            {
                if (!InternalTimers[6].IsStarted)
                {
                    state.stoppingSubstate = ZdStopProcessing.None;
                    if (nuState.EcFall)
                    {
                        if (state.stoppingSubstate != ZdStopProcessing.WaitingOpeningMestStop)
                            Messenger.Send(103);//МПО ОТКЛЮЧИЛСЯ. НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ
                        else
                            Messenger.Send(0102);//МПЗ ОТКЛЮЧИЛСЯ. НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ
                    }
                }
            }

            if (state.stoppingSubstate == ZdStopProcessing.Fail)
            {
                if (!nuState.CloseSwitchOn && !nuState.OpenSwitchOn)
                {
                    state.stoppingSubstate = ZdStopProcessing.None;
                    state.ErrMpo = false;
                    state.ErrMpz = false;
                }
            }

            if (state.stoppingSubstate == ZdStopProcessing.AfterStop)
            {
                if (!InternalTimers[9].IsStarted)
                {
                    state.stoppingSubstate = ZdStopProcessing.None;
                }
            }

            #endregion

            if (state.state == ZdStateProcessing.CommandExecution)
            {
                if (state.openingSubstate == ZdMovementProcessing.None && state.closingSubstate == ZdMovementProcessing.None &&
                    state.stoppingSubstate == ZdStopProcessing.None)
                {
                    state.state = ZdStateProcessing.Waiting;
                }
            }

            if (state.openingSubstate == ZdMovementProcessing.Canceled ||
                state.openingSubstate == ZdMovementProcessing.Success)
            {
                state.openingSubstate = ZdMovementProcessing.None;
                state.MpCheckEnabled = false;
                state.MoveCheckEnabled = false;
                state.InverseMpCheckEnabled = false;
            }


            if (state.closingSubstate == ZdMovementProcessing.Canceled ||
                state.closingSubstate == ZdMovementProcessing.Success)
            {
                state.closingSubstate = ZdMovementProcessing.None;
                state.MpCheckEnabled = false;
                state.MoveCheckEnabled = false;
                state.InverseMpCheckEnabled = false;
            }


            if (needUpdateState)
            {
                if (state.substate != substate)
                {
                    switch (substate)
                    {
                        case ZdStateSubstate.None:
                            zd.State = ZdState.None;
                            break;
                        case ZdStateSubstate.Opened:
                            zd.State = ZdState.Opened;
                            Messenger.Send(7);
                            break;
                        case ZdStateSubstate.Opening:
                            zd.State = ZdState.Opening;
                            Messenger.Send(1);
                            break;
                        case ZdStateSubstate.Middle:
                            zd.State = ZdState.Middle;
                            Messenger.Send(12);
                            break;
                        case ZdStateSubstate.Closing:
                            zd.State = ZdState.Closing;
                            Messenger.Send(16);
                            break;
                        case ZdStateSubstate.Closed:
                            zd.State = ZdState.Closed;
                            Messenger.Send(22);
                            break;
                        case ZdStateSubstate.NoEc:
                            if (zd.State == ZdState.Closing || zd.State == ZdState.Opening)
                            {
                                zd.State = ZdState.Middle;
                            }
                            /*
                         * пропажа ЕС
                         * стоп по месту
                         */
                            break;
                    }
                    state.substate = substate;
                }
            }
        }
    }
}
