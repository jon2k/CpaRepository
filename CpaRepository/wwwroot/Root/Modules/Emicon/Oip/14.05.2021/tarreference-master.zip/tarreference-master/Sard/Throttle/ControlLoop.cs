﻿using System;
using System.Collections.Generic;
using TarFoundation.Description;
using TarFoundation.St;
using TarReferenceSource.Common.Timer;
using TarReferenceSource.Oip;

namespace TarReferenceSource.Sard.Throttle
{
    public abstract class ControlLoopIo : IFunctionBlock
    {
        public ControlLoopIo()
        {
            Description.TimerDescriptions = TimerDescriptions;
        }
        //in
        /// <summary>
        /// input Входной сигнал от датчика
        /// </summary>
        public AnalogSignal InputSignal;
        /// <summary>
        /// input Уставка
        /// </summary>
        public float ust;
        /// <summary>
        /// input Значение скорости
        /// </summary>
        public float InputValueSpeed;
        /// <summary>
        /// cfg Конфигурация модуля
        /// </summary>
        public ControlLoopCfg cfg = new ControlLoopCfg();
        //out
        /// <summary>
        /// output Выходное воздействие
        /// </summary>
        public ControlLoopOutput Output = new ControlLoopOutput();

        protected static Dictionary<int, TimerDescription> TimerDescriptions = new Dictionary<int, TimerDescription>
        {
            {1, new TimerDescription("Время импульса", TimeSpan.FromMilliseconds(1000)) }          
        };
    }
    public class ControlLoop : ControlLoopIo
    {
        private ITimer timer;

        /// <summary>
        /// Интегральная ошибка
        /// </summary>
        private float IntegralError;

        public ControlLoop()
        {
            timer = new CpaLocalTimer();
            InternalTimers = new StArray<ITimer>(1, new []{timer});
        }

        public override void Execute()
        {
            Output.NormalizedOutput = 0.0f;
            ControlLoopZone zone;
            //вычисление ошибки регулирования (6.3.17)
            Output.Crash = false;
            float error;
            if (InputSignal.Ndv)
            {
                error = 0.0f;
                Output.Crash = true;
            }
            else if (Math.Abs(InputSignal.Value - InputSignal.VisualValue) > cfg.LpfZone || cfg.LpfZone == 0)
            {
                if (InputValueSpeed < 0)
                {
                    error = InputSignal.Value - ust + InputValueSpeed * cfg.KdFall;
                }
                else
                {
                    error = InputSignal.Value - ust + InputValueSpeed * cfg.KdRise;
                }
            }
            else
            {
                error = InputSignal.VisualValue - ust;
            }

            if (cfg.IsReverse)
            {
                error = -error;
            }
            
            //модуль нормализации ошибки регулирования и расчета скорости задания (6.3.20)

            if (error >= cfg.CloseZone)
            {
                Output.NormalizedOutput = 1.0f;
                zone = ControlLoopZone.CloseOutZone;
            }
            else if (error > cfg.CloseOffZone)
            {
                Output.NormalizedOutput = (error - cfg.CloseOffZone) / (cfg.CloseZone - cfg.CloseOffZone);
                zone = ControlLoopZone.CloseRegulationZone;
            }
            else if (error > cfg.IntegrOffCloseZone)
            {
                zone = ControlLoopZone.CloseIntergrationZone;
                if (!timer.IsStarted)
                {
                    IntegralError = IntegralError + cfg.KIClose * error;
                }

                if (IntegralError > cfg.NeedImpulseError && !timer.IsStarted)
                {
                    timer.Start();
                    IntegralError = 0;
                }

                if (timer.IsStarted)
                {
                    Output.NormalizedOutput = cfg.ImpulseValue;
                }
            }
            else if (error > -cfg.IntegrOffOpenZone)
            {
                Output.NormalizedOutput = 0.0f;
                zone = ControlLoopZone.OffZone;
            }
            else if (error >= -cfg.OpenOffZone)
            {
                zone = ControlLoopZone.OpenIntergrationZone;
                if (!timer.IsStarted)
                {
                    IntegralError = IntegralError + cfg.KIOpen * error;
                }

                if (-IntegralError > cfg.NeedImpulseError && !timer.IsStarted)
                {
                    timer.Start();
                    IntegralError = 0;
                }

                if (timer.IsStarted)
                {
                    Output.NormalizedOutput = -cfg.ImpulseValue;
                }
            }
            else if (error > -cfg.OpenZone)
            {
                Output.NormalizedOutput = (error + cfg.OpenOffZone) / (cfg.OpenZone - cfg.OpenOffZone);
                zone = ControlLoopZone.OpenRegulationZone;
            }
            else
            {
                Output.NormalizedOutput = -1.0f;
                zone = ControlLoopZone.OpenOutZone;
            }

            if (zone != ControlLoopZone.OpenIntergrationZone && zone != ControlLoopZone.CloseIntergrationZone)
            {
                if (zone != ControlLoopZone.OffZone)
                {
                    IntegralError = 0.0f;
                }
                timer.Stop();
            }

            Output.AllowLinearCorrections = zone == ControlLoopZone.OpenRegulationZone || zone == ControlLoopZone.CloseRegulationZone;
            Output.zone = zone;
            Output.Used = cfg.Enable;
            Output.IsCritical = cfg.IsCritical;
        }

    }
}
