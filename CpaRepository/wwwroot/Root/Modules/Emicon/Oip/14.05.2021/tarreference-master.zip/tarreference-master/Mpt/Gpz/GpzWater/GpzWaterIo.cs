﻿using System.Collections.Generic;
using TarFoundation.Description;
using TarReferenceSource.Mpt.Gpz.GpzFoam;
using TarFoundation.Messenger;
using TarFoundation.St;

namespace TarReferenceSource.Mpt.Gpz.GpzWater
{
    /// <summary>
    /// Входные данные для модуля GpzWater
    /// </summary>
    public struct GpzWaterIoInput
    {
        /// <summary>
        /// Количество исправных насосов водоорошения в основном режиме (по результатам работы модуля UVS).
        /// </summary>
        public int OsnIsprCount; // Количество исправных насосов водоорошения в основном режиме (по результатам работы модуля UVS).
        /// <summary>
        /// Флаг наличия неисправных задвижек на общей линии водоорошения (по результатам работы модуля ZDLine).
        /// </summary>
        public bool GeneralWaterLineAnyErr; // Флаг наличия неисправных задвижек на общей линии водоорошения (по результатам работы модуля ZDLine).
        /// <summary>
        /// Флаг наличия задвижек с назначенным режимом «ИМИТ» задвижек на общей линии водоорошения (по результатам работы модуля ZDLine).
        /// </summary>
        public bool GeneralWaterLineAnyImit; // Флаг наличия задвижек с назначенным режимом «ИМИТ» задвижек на общей линии водоорошения (по результатам работы модуля ZDLine).
        /// <summary>
        /// Флаг наличия неисправных задвижек на линии водоорошения защищаемого резервуара (по результатам работы модуля ZDLine).
        /// </summary>
        public bool SelfWaterLineAnyErr; // Флаг наличия неисправных задвижек на линии водоорошения защищаемого резервуара (по результатам работы модуля ZDLine).
        /// <summary>
        /// Флаг наличия задвижек с назначенным режимом «ИМИТ» на линии водоорошения защищаемого резервуара (по результатам работы модуля ZDLine).
        /// </summary>
        public bool SelfWaterLineAnyImit; // Флаг наличия задвижек с назначенным режимом «ИМИТ» на линии водоорошения защищаемого резервуара (по результатам работы модуля ZDLine).
        /// <summary>
        /// Флаг назначения режима автоматического водоорошения защищаемого резервуара (по результатам работы модуля SUP).
        /// </summary>
        public bool SupIsAuto; // Флаг назначения режима автоматического водоорошения защищаемого резервуара (по результатам работы модуля SUP).
        /// <summary>
        /// Флаг наличия маскирования агрегатной защиты по пожару защищаемого резервуара (по результатам работы модуля KTPRP).
        /// </summary>
        public bool ProtM; // Флаг наличия маскирования агрегатной защиты по пожару защищаемого резервуара (по результатам работы модуля KTPRP).
        /// <summary>
        /// Флаг наличия ремонтного режима сооружения.
        /// </summary>
        public bool IsRem; // Флаг наличия ремонтного режима сооружения.
        /// <summary>
        /// Флаг наличия требования запуска и успешного включения оборудования.
        /// </summary>
        public bool SuccessfulStart; // Флаг наличия требования запуска и успешного включения оборудования.
        /// <summary>
        /// Количество параметров готовности к автоматическому водоорошению резервуара.
        /// </summary>
        public int ReadinesCount; // Количество параметров готовности к автоматическому водоорошению резервуара.
        /// <summary>
        /// Массив флагов отключенности обработки готовностей.
        /// </summary>
        public StArray<bool> CfgDisabled; // Массив флагов отключенности обработки готовностей.
        /// <summary>
        /// Необходимое количество исправных насосов водоорошения.
        /// </summary>
        public uint CfgPumpsNeeded; // Необходимое количество исправных насосов водоорошения.
        /// <summary>
        /// Количество защит по пожару сооружения.
        /// </summary>
        public uint CountProt; // Количество защит по пожару сооружения. 
    }
    public abstract class GpzWaterIo:IFunctionBlock
    {
        // in
        /// <summary>
        /// input Входные данные для модуля
        /// </summary>
        public GpzWaterIoInput Source;

        // out
        /// <summary>
        /// output Массив флагов готовности к водоорошению резервуара по каждому фактору готовности.
        /// </summary>
        public StArray<bool> Output; // Массив флагов готовности к водоорошению резервуара по каждому фактору готовности.
        /// <summary>
        /// output Статус готовности защищаемого сооружения к водоорошению: 0 – нет готовности, 1 – готово, 2 – не контролируется .
        /// </summary>
        public GpzState Out; // Статус готовности защищаемого сооружения к водоорошению: 0 – нет готовности, 1 – готово, 2 – не контролируется . 

        public GpzWaterIo()
        {
            Source = new GpzWaterIoInput();
            Source.CfgDisabled = new StArray<bool>(1, new bool[7]);
            Source.ReadinesCount = 7;
            Output = new StArray<bool>(1, new bool[7]);
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {
            {1, new MessageDescription{Text = "ГОТОВ К АВТОМАТИЧЕСКОМУ ПЕНОТУШЕНИЮ", Type = MessageType.Information} },
            {2, new MessageDescription{Text = "НЕ ГОТОВ К АВТОМАТИЧЕСКОМУ ПЕНОТУШЕНИЮ", Type = MessageType.Alarm} },
            {3, new MessageDescription{Text = "ОТСУТСТВИЕ ИСПРАВНЫХ НАСОСОВ ВОДООРОШЕНИЯ В РЕЖИМЕ ОСНОВНОЙ. ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {4, new MessageDescription{Text = "ОТСУТСТВИЕ ИСПРАВНЫХ НАСОСОВ ВОДООРОШЕНИЯ В РЕЖИМЕ ОСНОВНОЙ. ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
            {5, new MessageDescription{Text = "ЗАДВИЖКА ОБЩЕЙ ЛИНИИ ВОДООРОШЕНИЯ НЕИСПРАВНА. ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {6, new MessageDescription{Text = "ЗАДВИЖКА ОБЩЕЙ ЛИНИИ ВОДООРОШЕНИЯ НЕИСПРАВНА. ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
            {7, new MessageDescription{Text = "ЗАДВИЖКА ОБЩЕЙ ЛИНИИ ВОДООРОШЕНИЯ В РЕЖИМЕ «ИМИТ». ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {8, new MessageDescription{Text = "ЗАДВИЖКА ОБЩЕЙ ЛИНИИ ВОДООРОШЕНИЯ В РЕЖИМЕ «ИМИТ». ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
            {9, new MessageDescription{Text = "ЗАДВИЖКА ВОДООРОШЕНИЯ РЕЗЕРВУАРА НЕИСПРАВНА. ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {10, new MessageDescription{Text = "ЗАДВИЖКА ВОДООРОШЕНИЯ РЕЗЕРВУАРА НЕИСПРАВНА. ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
            {11, new MessageDescription{Text = "ЗАДВИЖКА ВОДООРОШЕНИЯ РЕЗЕРВУАРА В РЕЖИМЕ «ИМИТ». ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {12, new MessageDescription{Text = "ЗАДВИЖКА ВОДООРОШЕНИЯ РЕЗЕРВУАРА В РЕЖИМЕ «ИМИТ». ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
            {13, new MessageDescription{Text = "РЕЖИМ АВТОМАТИЧЕСКОГО ВОДООРОШЕНИЯ ОТКЛЮЧЕН. ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {14, new MessageDescription{Text = "РЕЖИМ АВТОМАТИЧЕСКИЙ АВТОМАТИЧЕСКОГО ВОДООРОШЕНИЯ ОТКЛЮЧЕН. ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
            {15, new MessageDescription{Text = "МАСКИРОВАНИЕ ЗАЩИТЫ ПО ПОЖАРУ. ГОТОВНОСТЬ УСТАНОВЛЕНА", Type = MessageType.Neutral} },
            {16, new MessageDescription{Text = "МАСКИРОВАНИЕ ЗАЩИТЫ ПО ПОЖАРУ. ГОТОВНОСТЬ СНЯТА", Type = MessageType.Alarm} },
        };
    }
}
