using System;
using System.Collections.Generic;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;
using TarReferenceSource.Uvs;

namespace TarReference.InteractionStorages
{
    /// <summary>
    /// Структура данных состояния агрегата вспомсистемы
    /// </summary>
    public class AvsOuterState
    {
        /// <summary>
        /// Состояние агрегата вспомсистемы 
        /// </summary>
        public VsState State;
        /// <summary>
        /// Режим агрегата вспомсистемы
        /// </summary>
        public VsMode Mode;
        /// <summary>
        /// Флаг аварии
        /// </summary>
        public bool Crash;
        /// <summary>
        /// Флаг необходимости АВР
        /// </summary>
        public bool NeedAvr;
        /// <summary>
        /// Флаг блокировки работы
        /// </summary>
        public bool WorkBlocked;
        /// <summary>
        /// 
        /// </summary>
        public bool StopBlocked;
        /// <summary>
        /// Флгаг включения как дополнительного
        /// </summary>
        public bool StartedAsDop;
        /// <summary>
        /// Флаг ожидания АПВ
        /// </summary>
        public bool WaitApv;
        /// <summary>
        /// Флаг ожидания будущего старта
        /// </summary>
        public bool WaitFutureStart;
    }
    public abstract class ProcAvsIo : IFunctionBlock
    {
        public ProcAvsIo()
        {
            //Timers = new StArray<ITimer>(1, Enumerable.Range(1, 8).Select(x => new CpaLocalTimer()).ToArray());
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
            Description.TimerDescriptions = TimerDescriptions;
        }
        //public GrpvsIo Group { get; set; }
        /// <summary>
        /// input Команды с АРМ
        /// </summary>
        public VsCmds Cmd;
        /// <summary>
        /// input Входные данные с нижнего уровня
        /// </summary>
        public AvsNu Nu = new AvsNu();
        /// <summary>
        /// input Структура данных от модуля Ugrpvs
        /// </summary>
        public AvsAutoCmds AutoCmd = new AvsAutoCmds();

        //cfg
        /// <summary>
        /// cfg флаг использования контроля давления. Указывает необходимость использования данных с датчика давления(сигнализатора)
        /// </summary>
        public bool PcUse;
        /// <summary>
        /// cfg Флаг наличия цепей контроля включения
        /// </summary>
        public bool UseOpc;

        //out
        /// <summary>
        /// output Состояние агрегата
        /// </summary>
        public AvsOuterState OuterState = new AvsOuterState();
        /// <summary>
        /// output Структура аварий вспомсистемы
        /// </summary>
        public AvsCrashes Crashes = new AvsCrashes();
        /// <summary>
        /// output Команда на остановку вспомсистемы
        /// </summary>
        public bool StopCmd;
        /// <summary>
        /// output Команда на запуск вспомсистемы
        /// </summary>
        public bool StartCmd;

        public override void AfterCall()
        {
            Cmd = 0;
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
            {
                {1, new MessageDescription{Text = "КОМАНДА - ВКЛЮЧИТЬ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
                {2, new MessageDescription{Text = "ПУСК НЕВОЗМОЖЕН. БЛОКИРОВКА ПО РЕЖИМУ", Type = MessageType.Neutral} },
                {3, new MessageDescription{Text = "ВКЛЮЧЕН. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
                {4, new MessageDescription{Text = "РЕЗЕРВ ", Type = MessageType.Neutral} },
                {5, new MessageDescription{Text = "МАГНИТНЫЙ ПУСКАТЕЛЬ ВКЛЮЧЕН. РУЧНОЙ РЕЖИМ", Type = MessageType.Neutral} },
                {6, new MessageDescription{Text = "ВКЛЮЧЕН. НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО", Type = MessageType.Neutral} },
                {7, new MessageDescription{Text = "ПУСК НЕВОЗМОЖЕН. НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ", Type = MessageType.Neutral} },
                {8, new MessageDescription{Text = "КОМАНДА - ВКЛЮЧИТЬ РЕЗЕРВНЫЙ АГРЕГАТ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
                {9, new MessageDescription{Text = "РЕЗЕРВ ", Type = MessageType.Neutral} },
                {10, new MessageDescription{Text = "КОМАНДА - ОТКЛЮЧИТЬ АВТОМАТИЧЕСКИ", Type = MessageType.Neutral} },
                {11, new MessageDescription{Text = "АВАРИЯ. НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО", Type = MessageType.Neutral} },
                {12, new MessageDescription{Text = "ОТКЛЮЧЕН. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
                {13, new MessageDescription{Text = "РЕЗЕРВ", Type = MessageType.Neutral} },
                {14, new MessageDescription{Text = "ЗАПУСКАЕТСЯ. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
                {15, new MessageDescription{Text = "ПУСК НЕВОЗМОЖЕН. БЛОКИРОВКА ПО ЗАЩИТЕ", Type = MessageType.Neutral} },
                {16, new MessageDescription{Text = "ПУСК НЕВОЗМОЖЕН. НЕТ НАПРЯЖЕНИЯ НА СШ ЩСУ", Type = MessageType.Neutral} },
                {17, new MessageDescription{Text = "ВЫПОЛНЕН СТОП ПО МЕСТУ", Type = MessageType.Neutral} },
                {18, new MessageDescription{Text = "КОМАНДА - ВКЛЮЧИТЬ РЕЗЕРВНЫЙ АГРЕГАТ КАК ДОПОЛНИТЕЛЬНЫЙ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
                {19, new MessageDescription{Text = "ПОЛУЧЕН ЛОЖНЫЙ СИГНАЛ «МП ВКЛЮЧЕН»", Type = MessageType.Attention} },
                {20, new MessageDescription{Text = "ПОЛУЧЕН ЛОЖНЫЙ СИГНАЛ НАЛИЧИЯ ДАВЛЕНИЯ", Type = MessageType.Attention} },
                {21, new MessageDescription{Text = "ВКЛЮЧЕН", Type = MessageType.Neutral} },
                {22, new MessageDescription{Text = "ОТКЛЮЧЕН", Type = MessageType.Neutral} },
                {23, new MessageDescription{Text = "АВАРИЯ. ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ", Type = MessageType.Alarm} },
                {24, new MessageDescription{Text = "ОТКЛЮЧЕНИЕ НЕВОЗМОЖНО. АВТОМАТИЧЕСКАЯ БЛОКИРОВКА", Type = MessageType.Neutral} },
                {25, new MessageDescription{Text = "ОСТАНАВЛИВАЕТСЯ. НЕТ НАПРЯЖЕНИЯ НА СШ ЩСУ", Type = MessageType.Alarm} },
                {26, new MessageDescription{Text = "АВАРИЯ. МАГНИТНЫЙ ПУСКАТЕЛЬ НЕИСПРАВЕН", Type = MessageType.Alarm} },
                {27, new MessageDescription{Text = "АВАРИЯ. МАГНИТНЫЙ ПУСКАТЕЛЬ НЕ ВКЛЮЧИЛСЯ", Type = MessageType.Alarm} },
                {28, new MessageDescription{Text = "АВАРИЯ. НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ", Type = MessageType.Alarm} },
                {29, new MessageDescription{Text = "АВАРИЯ. МАГНИТНЫЙ ПУСКАТЕЛЬ НЕ ОТКЛЮЧИЛСЯ", Type = MessageType.Alarm} },
                {30, new MessageDescription{Text = "АВАРИЯ. ВНЕШНЯЯ АВАРИЯ", Type = MessageType.Alarm} },
                {31, new MessageDescription{Text = "АВАРИЯ. ДАТЧИК ДАВЛЕНИЯ НЕИСПРАВЕН", Type = MessageType.Alarm} },
                {32, new MessageDescription{Text = "РЕЗЕРВ", Type = MessageType.Neutral} },
                {33, new MessageDescription{Text = "РЕЗЕРВ", Type = MessageType.Neutral} },
                {34, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ ОСНОВНОЙ", Type = MessageType.Neutral} },
                {35, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ РЕЗЕРВНЫЙ", Type = MessageType.Neutral} },
                {36, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ РУЧНОЙ", Type = MessageType.Neutral} },
                {37, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ РЕМОНТНЫЙ", Type = MessageType.Neutral} },
                {38, new MessageDescription{Text = "НЕИСПРАВНЫ ЦЕПИ ОТКЛЮЧЕНИЯ МАГНИТНОГО ПУСКАТЕЛЯ", Type = MessageType.Alarm} },
                {39, new MessageDescription{Text = "НАЗНАЧИТЬ РЕЖИМ РЕМОНТНЫЙ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
                {40, new MessageDescription{Text = "НАЗНАЧИТЬ РЕЖИМ ОСНОВНОЙ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
                {41, new MessageDescription{Text = "НАЗНАЧИТЬ РЕЖИМ РЕЗЕРВНЫЙ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
                {42, new MessageDescription{Text = "РЕЗЕРВ", Type = MessageType.Neutral} },
                {43, new MessageDescription{Text = "КОМАНДА АВТОМАТИЧЕСКОГО ПОВТОРНОГО ВКЛЮЧЕНИЯ", Type = MessageType.Information} },
                {44, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. НЕТ АГРЕГАТОВ В ОСНОВНОМ РЕЖИМЕ", Type = MessageType.Neutral} },
                {45, new MessageDescription{Text = "НАЗНАЧИТЬ РЕЖИМ РУЧНОЙ АВТОМАТИЧЕСКИ", Type = MessageType.Neutral} },
                {46, new MessageDescription{Text = "КОМАНДА - ВКЛЮЧИТЬ С АРМ", Type = MessageType.Information} },
                {47, new MessageDescription{Text = "КОМАНДА - ОТКЛЮЧИТЬ С АРМ", Type = MessageType.Information} },
                {48, new MessageDescription{Text = "РЕЗЕРВ", Type = MessageType.Neutral} },
                {49, new MessageDescription{Text = "РЕЗЕРВ", Type = MessageType.Neutral} },
                {50, new MessageDescription{Text = "РЕЗЕРВ", Type = MessageType.Neutral} },
                {51, new MessageDescription{Text = "РЕЗЕРВ", Type = MessageType.Neutral} },
                {52, new MessageDescription{Text = "РЕЗЕРВ", Type = MessageType.Neutral} },
                {53, new MessageDescription{Text = "РЕЗЕРВ", Type = MessageType.Neutral} },
                {54, new MessageDescription{Text = "ЕСТЬ НАПРЯЖЕНИЕ В СХЕМЕ УПРАВЛЕНИЯ", Type = MessageType.Neutral} },
                {55, new MessageDescription{Text = "НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ", Type = MessageType.Neutral} },
                {56, new MessageDescription{Text = "ЦЕПИ ВКЛЮЧЕНИЯ НЕИСПРАВНЫ", Type = MessageType.Alarm} },
                {57, new MessageDescription{Text = "ЦЕПИ ВКЛЮЧЕНИЯ ИСПРАВНЫ", Type = MessageType.Neutral} },
                {58, new MessageDescription{Text = "РЕЗЕРВ", Type = MessageType.Neutral} },
                {59, new MessageDescription{Text = "РЕЗЕРВ", Type = MessageType.Neutral} },
                {60, new MessageDescription{Text = "АВАРИЯ. ДАВЛЕНИЕ НА ВЫКИДЕ АГРЕГАТА СНИЗИЛОСЬ", Type = MessageType.Alarm} },
                {61, new MessageDescription{Text = "ДАВЛЕНИЕ НА ВЫКИДЕ АГРЕГАТА УСТАНОВИЛОСЬ", Type = MessageType.Neutral} },
                {62, new MessageDescription{Text = "РЕЗЕРВ", Type = MessageType.Neutral} },
                {63, new MessageDescription{Text = "ЗАПУСКАЕТСЯ. НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО", Type = MessageType.Neutral} },
                {64, new MessageDescription{Text = "КОМАНДА - ДЕБЛОКИРОВАТЬ АВАРИЮ С АРМ", Type = MessageType.Information} },
                {65, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ РЕЖИМ ОСНОВНОЙ С АРМ", Type = MessageType.Information} },
                {66, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ РЕЖИМ РЕЗЕРВНЫЙ С АРМ", Type = MessageType.Information} },
                {67, new MessageDescription{Text = "ОСТАНАВЛИВАЕТСЯ. НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО", Type = MessageType.Neutral} },
                {68, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ РЕЖИМ РУЧНОЙ С АРМ", Type = MessageType.Information} },
                {69, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ РЕЖИМ РЕМОНТНЫЙ С АРМ", Type = MessageType.Information} },
                {70, new MessageDescription{Text = "ВКЛЮЧЕНИЕ НЕВОЗМОЖНО. АГРЕГАТ НЕ В РЕЗЕРВЕ", Type = MessageType.Neutral} },
                {71, new MessageDescription{Text = "АВАРИЯ. ЦЕПИ КОНТРОЛЯ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ НЕИСПРАВНЫ", Type = MessageType.Alarm} },
                {72, new MessageDescription{Text = "ВКЛЮЧЕНИЕ ПРОЦЕДУРЫ ОТЛОЖЕННОГО ПУСКА", Type = MessageType.Alarm} },
                {73, new MessageDescription{Text = "ОТМЕНА ПРОЦЕДУРЫ ОТЛОЖЕННОГО ПУСКА", Type = MessageType.Alarm} },
                {74, new MessageDescription{Text = "АВАРИЙНЫЙ СИГНАЛ НЕ СНЯТ. ДЕБЛОКИРОВКА НЕИСПРАВНОСТИ НЕВОЗМОЖНА", Type = MessageType.Neutral} },
                {75, new MessageDescription{Text = "ЦЕПИ КОНТРОЛЯ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ ИСПРАВНЫ", Type = MessageType.Alarm} },
                {76, new MessageDescription{Text = "ВКЛЮЧИЛСЯ ПРИ НАЛИЧИИ БЛОКИРОВКИ", Type = MessageType.Alarm} },
                {77, new MessageDescription{Text = "АВАРИЯ. НЕ НАБРАЛ ДАВЛЕНИЕ ", Type = MessageType.Alarm} },
                {78, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ЦЕПИ КОНТРОЛЯ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ НЕИСПРАВНЫ", Type = MessageType.Neutral} },
                {79, new MessageDescription{Text = "АВАРИЯ ДЕБЛОКИРОВАНА", Type = MessageType.Neutral} },
                {80, new MessageDescription{Text = "НЕ ОТКЛЮЧЕН. ДЕБЛОКИРОВКА АВАРИИ НЕВОЗМОЖНА", Type = MessageType.Neutral} },
                {81, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ЕСТЬ АГРЕГАТ В РЕЗЕРВЕ", Type = MessageType.Neutral} },
                {82, new MessageDescription{Text = "ВЫПОЛНЕН ПУСК ПО МЕСТУ", Type = MessageType.Information} },
                {83, new MessageDescription{Text = "ДАВЛЕНИЕ ЕСТЬ. РУЧНОЙ РЕЖИМ", Type = MessageType.Neutral} },
                {84, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ", Type = MessageType.Neutral} },
                {85, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ", Type = MessageType.Neutral} },
                {86, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ДАТЧИК ДАВЛЕНИЯ НЕИСПРАВЕН", Type = MessageType.Neutral} },
                {87, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕ ТРЕБУЕТСЯ. РЕЖИМ УЖЕ НАЗНАЧЕН", Type = MessageType.Neutral} },
                {88, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ЦЕПИ ВКЛЮЧЕНИЯ НЕИСПРАВНЫ", Type = MessageType.Neutral} },
                {89, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ВНЕШНЯЯ АВАРИЯ", Type = MessageType.Neutral} },
            };
        protected static Dictionary<int, TimerDescription> TimerDescriptions = new Dictionary<int, TimerDescription>
        {
            {1, new TimerDescription("Выдержка времени на ожидание срабатывания/исчезновения МП после включения/отключения", TimeSpan.FromMilliseconds(3000)) },
            {2, new TimerDescription("Выдержка времени на ожидание набора давления после появления сигнала МП в процессе пуска агрегата вспомсистемы", TimeSpan.FromMilliseconds(10000)) },
            {3, new TimerDescription("Выдержка времени на ожидание спада давления после снятия сигнала МП в процессе остановки агрегата вспомсистемы", TimeSpan.FromMilliseconds(10000)) },
            {4, new TimerDescription("Выдержка времени на возврат напряжения при стопе по месту", TimeSpan.FromMilliseconds(3000)) },
            {5, new TimerDescription("Выдержка времени на контроль давления во время работы", TimeSpan.FromMilliseconds(5000)) },
            {6, new TimerDescription("Выдержка времени для перевода неработающего агрегата вспомсистемы в режим ремонтный при исчезновении напряжения в схеме управления;", TimeSpan.FromMilliseconds(40000)) },
            {7, new TimerDescription("Выдержка времени на запаздывание сигналов исчезновения МП и сигнала наличия напряжения от СШ (при кратковременных исчезновениях напряжения на секциях шин).", TimeSpan.FromMilliseconds(14000)) },
            {8, new TimerDescription("Выдержка времени на перевод пожарного насоса в ремонтный режим при неисправности цепей включения", TimeSpan.FromMilliseconds(3000)) }      
        };
    }

}
