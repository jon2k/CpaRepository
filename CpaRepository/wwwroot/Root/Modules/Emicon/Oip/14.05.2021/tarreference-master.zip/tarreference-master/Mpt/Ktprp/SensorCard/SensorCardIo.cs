﻿using TarFoundation.St;

namespace TarReferenceSource.Mpt.Gpz.SensorCard
{
    /// <summary>
    /// Данные от пожарного извещателя
    /// </summary>
    public class SensorsInfo
    {
        /// <summary>
        /// Сработал пожарный извещатель
        /// </summary>
        public bool Triggered; // ПИ исправен. 1 - параметр установлен. 0 - параметр снят.
        /// <summary>
        /// Пожарный извещатель неисправен
        /// </summary>
        public bool Failure; //  ПИ неисправен. 1 - параметр установлен. 0 - параметр снят.

    }
    public abstract class SensorCardIo : IFunctionBlock
    {
        // in
        /// <summary>
        /// input Пожарные извещатели
        /// </summary>
        public StArray<SensorsInfo> Sensors; // Массив информации ПИ зоны.
        /// <summary>
        /// input Флаг ремонта зоны
        /// </summary>
        public bool InRem; //От SPZ
        /// <summary>
        /// input Количество пожарных извещателей зоны
        /// </summary>
        public uint SensorsCount => (uint)Sensors.Count; // Количество ПИ зоны.
        /// <summary>
        /// input Необходимое кол-во пожарных извещателей.
        /// </summary>
        public uint EnoughtSensorsCount; // Необходимое кол-во пожарных извещателей.

        // out
        /// <summary>
        /// output Флаг отсутствия необходимого количества исправных пожарных извещателей
        /// </summary>
        public bool NotEnoughtSensors; // Отсутствие необходимого количества исправных ПИ	1 – параметр установлен, 0 – параметр снят
        /// <summary>
        /// output Флаг срабатывания одного или более пожарных извещетелей
        /// </summary>
        public bool OneSensorsTriggered; // Сработал один или более ПИ	1 – параметр установлен, 0 – параметр снят
        /// <summary>
        /// output Флаг срабатывания двух или более пожарных извещетелей
        /// </summary>
        public bool TwoSensorsTriggered; // Сработало два или более ПИ	1 – параметр установлен, 0 – параметр снят
        public SensorCardIo(int countSensor)
        {
            Sensors = new StArray<SensorsInfo>(1, new SensorsInfo[countSensor]);
            for (int i = 1; i <= Sensors.Count; i++)
            {
                Sensors[i] = new SensorsInfo();
            }
        }
    }
}
