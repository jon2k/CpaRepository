﻿using System;
using System.Collections.Generic;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;

namespace TarReferenceSource.Uts
{
    public enum UtsCmds : ushort
    {
        none = 0,
        enable = 1,
        disable = 2,
    }
    public abstract class UtsIo : IFunctionBlock
    {
        public UtsIo()
        {
            Description.TimerDescriptions = TimerDescriptions;
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }
        /// <summary>
        /// input Команда с АРМ оператора на включение и отключение сирены
        /// </summary>
        public UtsCmds Cmd;
        /// <summary>
        /// input Сигнал для проверки работы сирены
        /// </summary>
        public bool CheckInput;//  источник проверки
        /// <summary>
        /// input Сигнал квитирования
        /// </summary>
        public bool KvitInput; // источник квитирования
        /// <summary>
        /// input Входной сигнал включения табло/сирены
        /// </summary>
        public bool Input; // источнику включения
        /// <summary>
        /// input Флаг определяющий возможность проверки
        /// </summary>
        public bool CheckEnabled; //Флаг определяющий возможность проверки
        /// <summary>
        /// input Флаг определяющий возможность получения подтверждения проверки
        /// </summary>
        public bool KvitEnabled; //Флаг определяющий возможность получения подтверждения проверки
        /// <summary>
        /// output Флаг, принимающий значение 1 при необходимости подачи напряжения на табло/сирену. (Мигание табло).
        /// </summary>
        public bool EnableNuCmd; //Флаг, принимающий значение 1 при необходимости подачи напряжения на табло/сирену
        /// <summary>
        /// output Флаг, принимающий значение 1 при включении табло/сирены по какому-либо источнику или по команде. (Не мигает).
        /// </summary>
        public bool IsEnabled; //Флаг, принимающий значение 1 при включении табло/сирены по какому-либо источнику или по команде
        /// <summary>
        /// output output Флаг проверки сигнализации 
        /// </summary>
        public bool checking;

        public override void AfterCall()
        {
            Cmd = UtsCmds.none;
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {
            {1, new MessageDescription{Text = "КОМАНДА - ВКЛЮЧИТЬ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
            {2, new MessageDescription{Text = "КОМАНДА - ОТКЛЮЧИТЬ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
            {3, new MessageDescription{Text = "ПРОВЕРКА СИГНАЛИЗАЦИИ", Type = MessageType.Information} },
            {4, new MessageDescription{Text = "КВИТИРОВАНИЕ СИГНАЛИЗАЦИИ", Type = MessageType.Information} },
            {5, new MessageDescription{Text = "КОМАНДА ВКЛЮЧИТЬ С АРМ", Type = MessageType.Information} },
            {6, new MessageDescription{Text = "КОМАНДА ОТКЛЮЧИТЬ С АРМ", Type = MessageType.Information} },
            {7, new MessageDescription{Text = "ВКЛЮЧЕНО", Type = MessageType.Neutral} },
            {8, new MessageDescription{Text = "ОТКЛЮЧЕНО", Type = MessageType.Neutral} },
            {20, new MessageDescription{Text = "таймер 1", Type = MessageType.Neutral} },
            {21, new MessageDescription{Text = "таймер 2", Type = MessageType.Neutral} },
        };
        protected static Dictionary<int, TimerDescription> TimerDescriptions = new Dictionary<int, TimerDescription>
        {
            {1, new TimerDescription("Время непрерывной работы", TimeSpan.FromSeconds(1)) },
            {2, new TimerDescription("Время паузы работы", TimeSpan.FromSeconds(1)) }
            
        };
    }
}
