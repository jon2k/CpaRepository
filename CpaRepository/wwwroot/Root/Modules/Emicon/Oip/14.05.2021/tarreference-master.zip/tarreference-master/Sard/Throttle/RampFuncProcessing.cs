﻿using System;
using System.Collections.Generic;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;
using TarReferenceSource.Common.Timer;
using TarReferenceSource.Oip;

namespace TarReferenceSource.Sard.Generic
{

    public abstract class RampFuncProcessingIo : IFunctionBlock
    {
        /// <summary>
        /// input Необходимость рампы
        /// </summary>
        public bool RampNeed;
        /// <summary>
        /// input Рампа включена
        /// </summary>
        public bool RampEnable;
        /// <summary>
        /// input
        /// </summary>
        public AnalogSignal PColl;
        /// <summary>
        /// input
        /// </summary>
        public AnalogSignal dP;
        /// <summary>
        /// input
        /// </summary>
        public float PCollCancelUst;
        /// <summary>
        /// input
        /// </summary>
        public float DpCancelUst;
        /// <summary>
        /// output Рамповая функция в работе
        /// </summary>
        public bool RampInWork;

        public RampFuncProcessingIo(AnalogSignal pColl, AnalogSignal dp)
        {
            PColl = pColl;
            dP = dp;
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
            Description.TimerDescriptions = TimerDescriptions;
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {
            {1, new MessageDescription{Text = "ПРИНЯТ ЗАПРОС НА ВКЛЮЧЕНИЕ РАМПОВОЙ ФУНКЦИИ ПО ВХОДНОМУ ДАВЛЕНИЮ", Type = MessageType.Information} },
            {2, new MessageDescription{Text = "ВКЛЮЧЕНА РАМПОВАЯ ФУНКЦИЯ", Type = MessageType.Information} },
            {3, new MessageDescription{Text = "ЗАПРОС НА ВКЛЮЧЕНИЕ РАМПОВОЙ ФУНКЦИИ ОТКЛОНЕН. РАМПОВАЯ ФУНКЦИЯ ОТКЛЮЧЕНА", Type = MessageType.Attention} },
            {4, new MessageDescription{Text = "РАБОТА РАМПОВОЙ ФУНКЦИИ ОКОНЧЕНА ПО ТАЙМЕРУ", Type = MessageType.Information} },
            {5, new MessageDescription{Text = "РАБОТА РАМПОВОЙ ФУНКЦИИ ОКОНЧЕНА ПО МАКСИМАЛЬНОМУ ДАВЛЕНИЮ В КОЛЛЕКТОРЕ", Type = MessageType.Information} },
            {6, new MessageDescription{Text = "РАБОТА РАМПОВОЙ ФУНКЦИИ ОКОНЧЕНА ПО МАКСИМАЛЬНОМУ ПЕРЕПАДУ ДАВЛЕНИЯ НА РД", Type = MessageType.Information} },
            //{7, new MessageDescription{Text = "РАБОТА РАМПОВОЙ ФУНКЦИИ ОКОНЧЕНА ПО КОМАНДЕ ОТ МПСА", Type = MessageType.Neutral} },//нет такой команды от мпса
        };
        protected static Dictionary<int, TimerDescription> TimerDescriptions = new Dictionary<int, TimerDescription>
        {
            {1, new TimerDescription("Максимальное время работы рамповой функции", TimeSpan.FromMilliseconds(1000)) }         
        };
    }

    public class RampFuncProcessing : RampFuncProcessingIo
    {
        private ITimer timer;
        /// <summary>
        /// НЕобходимость рампы
        /// </summary>
        private bool RampNeedPrev;


        public RampFuncProcessing(AnalogSignal pColl, AnalogSignal dp) : base(pColl, dp)
        {
            timer = new CpaLocalTimer();
            InternalTimers = new StArray<ITimer>(1, new []{timer});
        }

        public override void Execute()
        {
            if (RampNeed && !RampNeedPrev)
            {
                Messenger.Send(1);
                if (RampEnable)
                {
                    Messenger.Send(2);
                    timer.Start();
                }
                else
                {
                    Messenger.Send(3);
                }
            }

            RampNeedPrev = RampNeed;

            if (timer.IsQ)
            {
                Messenger.Send(4);
            }
            else if (timer.IsStarted)
            {
                if (PColl.VisualValue > PCollCancelUst)
                {
                    Messenger.Send(5);
                    timer.Stop();
                }
                else if (dP.VisualValue > DpCancelUst)
                {
                    Messenger.Send(6);
                    timer.Stop();
                }
            }

            RampInWork = timer.IsStarted;
        }
    }
}
