﻿using System.Linq;
using TarFoundation.St;

namespace TarReferenceSource.Ktpra
{
	public class Ktpra : KtpraIo
    {
        public Ktpra(int count=100)
        {
            Input = new StArray<ProcKtpraResult>(1, Enumerable.Range(1, count).Select(n=>new ProcKtpraResult()).ToArray());
			Cfg = new StArray<ProcKtpraConfig>(1, Enumerable.Range(1, count).Select(n => new ProcKtpraConfig()).ToArray());
			Result = new KtpraResult();
        }
        public override void Execute()
        {
			Result.P = false;
			Result.Avr = true;

			for (int i = 1; i <= Input.Count; i++)
			{
				Result.P = Input[i].P || Result.P;
				if (Input[i].P)
				{
					Result.Avr = Cfg[i].Avr && Result.Avr;

					if (Result.StopType < Cfg[i].StopType)
					{
						Result.StopType = Cfg[i].StopType;
					}
				}
			}		
		}
    }
}
