﻿using System.Collections.Generic;
using System.Linq;
using Friday.Helpers;
using TarFoundation.Messenger;

namespace Friday.Runtime.CpaLocal
{
    public class CpaLocalMessageBuffer : IMessenger
    {
        private readonly MessageDecoder _decoder;
        private readonly List<Message> _messagesList;
        private object _lock = new object();

        public CpaLocalMessageBuffer(MessageDecoder decoder)
        {
            _decoder = decoder;
            _messagesList = new List<Message>();
        }

        public List<Message> MessagesList
        {
            get
            {
                lock (_lock)
                {
                    return _messagesList.ToList();
                }
            }
        }

        public void Send(Message msg)
        {
            lock (_lock)
            {
                _messagesList.Add(msg);
            }
        }

        public void Clean()
        {
            lock (_lock)
            {
                _messagesList.Clear();
            }
        }

        public void Send(int msgId)
        {
            var msg = new Message { msgId = (uint)msgId };
            _decoder.Decode(msg);
            Send(msg);
        }
    }
}
