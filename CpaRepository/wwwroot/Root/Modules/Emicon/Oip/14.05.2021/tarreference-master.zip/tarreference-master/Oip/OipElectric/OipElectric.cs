﻿using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.St;
using TarReferenceSource.Common.Timer;

namespace TarReferenceSource.Oip
{
    /// <summary>
    /// Структура, хранящая данные о значении с датчика
    /// </summary>
    public class FieldSignal
    {
        /// <summary>
        /// Значение с прошлого цикла
        /// </summary>
        public float PrevValue;
        /// <summary>
        /// Текущее значение
        /// </summary>
        public float Value;
        /// <summary>
        /// Флаг, показывающий необходимость инициализации фильтра. 0 – инициализация не требуется. 1 – требуется инициализация
        /// </summary>
        public bool NeedInitFilter;
    }

    public static class SignalProcessingExtention
    {
        

        public static void LinearFiltration(this FieldSignal signal, bool enable, float K)
        {
            /* Фильтрация измеряемого значения */
            if (enable && !signal.NeedInitFilter)
            {
                signal.Value = signal.PrevValue + K * (signal.Value - signal.PrevValue);
            }
            signal.NeedInitFilter = !enable;
            signal.PrevValue = signal.Value;
        }
    }


    /*
     * ProcLevels вынесен в отдельный модуль
     * ProcFalsity убран, добавлен CheckRanges для проверки ВПД/НПД
     * Убрана задержка снятия недостоверности для имитированного сигнала
     * Расчет K вынесен из модуля LinearFiltration
     * Модуль Choose убран, добавлен ProcState для вывода сообщений о состоянии сигнала
     * Убран ImRange
     */
    public class OipElectric : OipElectricIo
    {
        /// <summary>
        /// Переменная, хранящая данные о токовом значении
        /// </summary>
        private FieldSignal ElectricSignal;
        /// <summary>
        /// Переменная, хранящая данные о измеренном значении
        /// </summary>
        private readonly AnalogSignal RealSignal;
        /// <summary>
        /// Формируемое имитационное значение измеренного сигнала
        /// </summary>
        private readonly AnalogSignal ImitSignal;
        /// <summary>
        /// Переменная, хранящая данные о измеренном значении с прошлого цикла
        /// </summary>
        private readonly AnalogSignal PrevSignal = new AnalogSignal();
        private CpaLocalTimer timer;
        public OipElectric() : base()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
            timer = new CpaLocalTimer();
            InternalTimers = new StArray<ITimer>(1, new []{timer});
            ElectricSignal = new FieldSignal();
            RealSignal = new AnalogSignal();
            ImitSignal = new AnalogSignal();
        }

        public override void Execute()
        {
            //измеренный параметр
            //определяем недостовености
            RealSignal.AlgNdv = (ElRange.Top - ElRange.Bottom) == .0;
            RealSignal.ExtNdv = ExtNdv;
            if (!ExtNdv)//если есть внешняя неисправность, то нет смысла проверять диапазон достоверности
                CheckRanges(RealSignal, ElInput, ElAllowedRange);

            if (RealSignal.AlgNdv || RealSignal.ExtNdv || RealSignal.LTMin || RealSignal.MTMax)
            {
                RealSignal.Ndv = true;
                timer.Stop();
            }
            else
            {
                //восстанавливаем достоверность через Т01
                
                if (!timer.IsStarted && !timer.IsQ && RealSignal.Ndv)
                {
                    timer.Start();
                }
                if (timer.IsQ)
                {
                    RealSignal.Ndv = false;
                }
            }

            if (!RealSignal.AlgNdv)
            {
                RealSignal.Value = LinearDecoding(ElInput, ElRange, ValRange);
            }
            //обработка сигнала с поля
            if (!RealSignal.Ndv)
            {
                ElectricSignal.Value = ElInput;
            }
            var K = dT / (T + dT);
            ElectricSignal.LinearFiltration(EnableFiltering && !RealSignal.Ndv, K);
            ElectricSignal.Value = LimitOfMeasure(ElectricSignal.Value, ElRange);

            if (!RealSignal.AlgNdv)
            {
                RealSignal.VisualValue = LinearDecoding(ElectricSignal.Value, ElRange, ValRange);
            }
            //имитированный параметр
            ImitSignal.Value = ImitInput;
            CheckRanges(ImitSignal, ImitInput, ValRange);
            ImitSignal.Ndv = ImitSignal.LTMin || ImitSignal.MTMax;
            if (!ImitSignal.Ndv)
            {
                ImitSignal.VisualValue = ImitSignal.Value;
            }

            ImitSignal.VisualValue = LimitOfMeasure(ImitSignal.VisualValue, ValRange);

            //выбор выходного сигнала
            Imit = ProcImitCmd(Cmd, Imit);
            if (Imit)
            {
                OutSignal = ImitSignal;
            }
            else
            {
                OutSignal = RealSignal;
            }

            ProcState(OutSignal, PrevSignal);
        }

        public static void CheckRanges(AnalogSignal signal, float input, Range range)
        {
            if (input > range.Top)
            {
                signal.MTMax = true;
                signal.LTMin = false;
            }
            else if (input < range.Bottom)
            {
                signal.MTMax = false;
                signal.LTMin = true;
            }
            else
            {
                signal.MTMax = false;
                signal.LTMin = false;
            }
        }

        public static float LinearDecoding(float Input, Range InRange, Range OutRange)
        {
            return (Input - InRange.Bottom) * (OutRange.Top - OutRange.Bottom) / (InRange.Top - InRange.Bottom) + OutRange.Bottom;
        }

        float LimitOfMeasure(float input, Range limits)
        {
            /* Ограничение измеренного значения диапазоном измерений */

                if (input > limits.Top)
                {
                    return limits.Top;
                }
                else if (input < limits.Bottom)
                {
                    return limits.Bottom;
                }
                else
                {
                    return input;
                }
        }

        bool ProcImitCmd(OipCmds cmd, bool imit)
        {
            /* Обработка команд по снятию и назначению режима имитации */

            if (cmd == OipCmds.SET_IMIT)
            {
                if (!imit)
                {
                    imit = true;
                    Messenger.Send(1); /*назначена имитация*/
                }
                else
                {
                    Messenger.Send(9); /*команда снять имитацию не требуется, имитация отсуствует*/
                }
            }
            if (cmd == OipCmds.DROP_IMIT)
            {
                if (imit)
                {
                    imit = false;
                    Messenger.Send(2); /*имитация снята*/
                }
                else
                {
                    Messenger.Send(10); /*команда назначить имитацию не требуется, наличие имитации	*/
                }
            }

            return imit;
        }

        void ProcState(AnalogSignal signal, AnalogSignal prevSignal)
        {
            if (signal.Ndv)
            {
                if (signal.ExtNdv && !prevSignal.ExtNdv)
                {
                    Messenger.Send(3);
                }

                if (signal.LTMin && !prevSignal.LTMin)
                {
                    Messenger.Send(4);
                }

                if (signal.MTMax && !prevSignal.MTMax)
                {
                    Messenger.Send(5);
                }

                if (signal.AlgNdv && !prevSignal.AlgNdv)
                {
                    Messenger.Send(8);
                }
            }
            else
            {
                if (prevSignal.Ndv)
                {
                    if (Imit)
                    {
                        Messenger.Send(6);
                    }
                    else
                    {
                        Messenger.Send(7);
                    }
                }
            }

            prevSignal.Ndv = signal.Ndv;
            prevSignal.ExtNdv = signal.ExtNdv;
            prevSignal.LTMin = signal.LTMin;
            prevSignal.MTMax = signal.MTMax;
        }
    }
}
