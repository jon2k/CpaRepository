﻿using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarReferenceSource.Mpt.Gpz.GpzFoam;

namespace TarReferenceSource.Mpt.Gpz.GpzWithoutFoamWater
{
    public class GpzWithoutFoamWater : GpzWithoutFoamWaterIo
    {
        /// <summary>
        /// Обобщенный флаг готовности защищаемого резервуара к водоорошению.
        /// </summary>
        private bool _flReady; // Обобщенный флаг готовности защищаемого резервуара к водоорошению.
        /// <summary>
        /// Входной параметр блока ProcGpz.
        /// </summary>
        private bool _procInput; // Входной параметр блока ProcGpz.
        public GpzWithoutFoamWater()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }
        public override void Execute()
        {
            if (Source.IsRem || Source.SuccessfulStart)
            {
                Out = GpzState.NoControl;
                for (int i = 1; i <= Source.ReadinesCount; i++)
                {
                    Output[i] = true;
                }
            }
            else
            {
                _flReady = true;
                for (int i = 1; i <= Source.ReadinesCount; i++)
                { // Цикл по параметрам готовности
                    if (!Source.CfgDisabled[i])
                    {  // Флаг необходимости проверки готовности
                        switch (i)
                        {
                            case 1:
                                _procInput = !Source.SensorsNotEnoughSensors;                                  // НЕДОСТАТОЧНО ИСПРАВНЫХ ПОЖАРНЫХ ИЗВЕЩАТЕЛЕЙ
                                break;
                            case 2:
                                _procInput = true;
                                for (int j = 1; j <= Source.CountProt; j++)
                                {
                                    _procInput = _procInput && !Source.ProtM;                               // МАСКИРОВАНИЕ ЗАЩИТЫ ПО ПОЖАРУ
                                }
                                break;
                        }

                        if (_procInput && !Output[i])
                        {
                            Output[i] = true;
                            Messenger.Send(i * 2 - 1);
                        }
                        else if (!_procInput && Output[i])
                        {
                            Output[i] = false;
                            Messenger.Send(i * 2);
                        }

                        _flReady = _flReady && Output[i]; // Обобщенный флаг tготовности защищаемого сооружения к пенотушению
                    }
                }

                Out = _flReady ? GpzState.Ready : GpzState.NotReady;                // Флаг готовности
            }
        }
    }
}
