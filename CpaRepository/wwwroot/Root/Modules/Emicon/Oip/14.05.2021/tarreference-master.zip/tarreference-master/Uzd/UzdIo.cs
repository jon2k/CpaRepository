﻿using System;
using System.Collections.Generic;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;

namespace TarReferenceSource.Uzd
{
    public abstract class UzdIo:IFunctionBlock
    {
        public UzdIo()
        {
            Description.TimerDescriptions = TimerDescriptions;
        }
        // in
        /// <summary>
        /// input Флаг отсутствия интерфейсного канала
        /// </summary>
        public bool RsOff { get; set; }
        /// <summary>
        /// input Флаг наличия связи по интерфейсному каналу
        /// </summary>
        public bool RsLink { get; set; }
        /// <summary>
        /// input Промежуточная переменная состояния конечного выключателя открытия, полученного по интерфейсному каналу.0-нет сигнала,1-есть сигнал.
        /// </summary>
        public bool IvarKVO { get; set; }
        /// <summary>
        /// input Промежуточная переменная состояния конечного выключателя открытия, полученного по дискретному каналу. 0-нет сигнала,1-есть сигнал.
        /// </summary>
        public bool DvarKVO { get; set; }
        /// <summary>
        /// input Промежуточная переменная состояния конечного выключателя закрытия, полученного по интерфейсному каналу.0-нет сигнала,1-есть сигнал.
        /// </summary>
        public bool IvarKVZ { get; set; }
        /// <summary>
        /// input Промежуточная переменная состояния конечного выключателя закрытия, полученного по дискретному каналу.0-нет сигнала,1-есть сигнал.
        /// </summary>
        public bool DvarKVZ { get; set; }
        /// <summary>
        /// input Промежуточная переменная состояния магнитного пускателя открытия, полученного по интерфейсному каналу.0-нет сигнала,1-есть сигнал.
        /// </summary>
        public bool IvarMPO { get; set; }
        /// <summary>
        /// input Промежуточная переменная состояния магнитного пускателя открытия, полученного по дискретному каналу.0-нет сигнала,1-есть сигнал.
        /// </summary>
        public bool DvarMPO { get; set; }
        /// <summary>
        /// input Промежуточная переменная состояния магнитного пускателя закрытия, полученного по интерфейсному каналу.0-нет сигнала,1-есть сигнал.
        /// </summary>
        public bool IvarMPZ { get; set; }
        /// <summary>
        /// input Промежуточная переменная состояния магнитного пускателя закрытия, полученного по дискретному каналу.0-нет сигнала,1-есть сигнал.
        /// </summary>
        public bool DvarMPZ { get; set; }
        /// <summary>
        /// input Промежуточная переменная состояния переключателя управления «Дистанция/По месту», полученного по интерфейсному каналу.0-нет сигнала,1-есть сигнал.
        /// </summary>
        public bool IvarDist { get; set; }
        /// <summary>
        /// input Промежуточная переменная состояния переключателя управления «Дистанция/По месту», полученного по дискретному каналу.0-нет сигнала,1-есть сигнал.
        /// </summary>
        public bool DvarDist { get; set; }
        /// <summary>
        /// input Промежуточная переменная в зависимости от типа привода это моментный выключатель открытия или срабатывание муфты, полученные по интерфейсному каналу связи.0-нет срабатывания,1-есть срабатывание.
        /// </summary>
        public bool IvarMufta { get; set; }
        /// <summary>
        /// input Промежуточная переменная в зависимости от типа привода это моментный выключатель открытия или срабатывание муфты, полученные по интерфейсному каналу связи.0-нет срабатывания,1-есть срабатывание.
        /// </summary>
        public bool DvarMufta { get; set; }
        /// <summary>
        /// input Промежуточная переменная наличия аварий у БУРа, полученная по дискретному каналу связи.0-нет аварий,1-есть аварии.
        /// </summary>
        public bool IvarErrBUR { get; set; }
        /// <summary>
        /// input Промежуточная переменная наличия аварий у БУРа, полученная по интерфейсному каналу связи.0-нет аварий,1-есть аварии.
        /// </summary>
        public bool DvarErrBUR { get; set; } 
        
        // out
        /// <summary>
        /// output Результирующий набор данных с поля
        /// </summary>
        public ZdNu Nu { get; set; } = new ZdNu();// Данные с поля
        /// <summary>
        /// output  Рассинхронизация даных между физическим и интерфейсным каналом.
        /// </summary>
        public bool ChannelsDesync { get; set; }
        /// <summary>
        /// output Наличие связи по интерфейсному каналу
        /// </summary>
        public bool RsOk { get; set; }


        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {          
            {113, new MessageDescription{Text = "НЕТ ДАННЫХ ПО ИНТЕРФЕЙСНОМУ КАНАЛУ", Type = MessageType.Attention} },
            {114, new MessageDescription{Text = "ЕСТЬ ДАННЫЕ ПО ИНТЕРФЕЙСНОМУ КАНАЛУ", Type = MessageType.Neutral} },        
            {128, new MessageDescription{Text = "ДАННЫЕ ПО ФИЗИЧЕСКОМУ И ИНТЕРФЕЙСНОМУ КАНАЛУ СИНХРОНИЗИРОВАНЫ", Type = MessageType.Neutral} },
            {129, new MessageDescription{Text = "ДАННЫЕ ПО ФИЗИЧЕСКОМУ КАНАЛУ ОТЛИЧАЮТСЯ ОТ ИНТЕРФЕЙСНЫХ", Type = MessageType.Neutral} }
        };
        protected static Dictionary<int, TimerDescription> TimerDescriptions = new Dictionary<int, TimerDescription>
        {         
            {1, new TimerDescription("Время рассогласования между сигналами по физическому и интерфейсному каналу", TimeSpan.FromMilliseconds(3000)) },         
        };

    }
}
