﻿namespace TarReferenceSource.Mpt.Ktprp
{
    public class Ktprp : KtprpIo
    {
		public Ktprp(int i):base(i)
		{
		}

        public override void Execute()
        {
			Result.P = false;
			Result.F = false;
			Result.M = true;
			Result.NP = false;

			for (int i = 1; i <= Input.Count; i++)
			{
				Result.P = Input[i].P || Result.P;
				Result.F = Input[i].F || Result.F;
				Result.M = Input[i].M && Result.M;
				Result.NP = Input[i].NP || Result.NP;					
			}			
		}
	}
}
