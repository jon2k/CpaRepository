﻿namespace TarReferenceSource.Nps
{
    public class NpsStorage
    {
        public bool IsNPSModePsl;
    }
}
