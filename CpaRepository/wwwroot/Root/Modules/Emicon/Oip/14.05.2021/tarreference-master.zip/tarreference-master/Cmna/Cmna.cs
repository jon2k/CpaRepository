﻿using System;
using System.Linq;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.St;
using TarReferenceSource.Common.Timer;
using TarReferenceSource.CommonNa;
using TarReferenceSource.Uzd;

namespace TarReferenceSource.Cmna
{
    /// <summary>
    /// СТруктура даных ЧРП
    /// </summary>
    internal class ChrpStruct
    {
        /// <summary>
        /// Флаг наличия вращения двигателя
        /// </summary>
        public bool SpinForward;
        /// <summary>
        /// Частота вращения вала ЭД больше 30 об/мин
        /// </summary>
        public bool CurFreqMT30;
        /// <summary>
        /// Флаг наличия тока
        /// </summary>
        public bool Tok;
    }
    /// <summary>
    /// Структура состояния Чрп
    /// </summary>
    internal class CmnaStorage
    {
        /// <summary>
        /// Основное состояние ЧРП
        /// </summary>
        public NaState MainState;
        /// <summary>
        /// Дополнительное состояния ЧРП
        /// </summary>
        public NaSubstate SubState;
        /// <summary>
        /// Режим работы ЧРП
        /// </summary>
        public NaMode Mode;
        /// <summary>
        /// Программа пуска ЧРП
        /// </summary>
        public NaProg Prog; /* программа пуска */
        /// <summary>
        /// Флаг включенного контроля по току
        /// </summary>
        public bool UseCTPrev;         /* Включен контроль по току */
        /// <summary>
        /// Номер шага активной задачи, выполняемой НА
        /// </summary>
        public uint TaskStepMpna;          /* Номер шага активной задачи, выполняемой НА */
        /// <summary>
        /// Номер активной задачи, выполняемой НА
        /// </summary>
        public uint ActvTaskMpna;          /* Номер активной задачи, выполняемой НА */
        /// <summary>
        /// структура флагов эталонного состояния сигналов ВВ
        /// </summary>
        public VvStorage VvReference = new VvStorage();      /* структура флагов эталонного состояния сигналов ВВ */
        /// <summary>
        /// структура флагов результирующей недостовернгости сигналов ВВ*//*!!! флаги недостоверности в формате структуры tBB_Bits
        /// </summary>
        public VvStorage VvNdv = new VvStorage();       /* структура флагов результирующей недостовернгости сигналов ВВ*//*!!! флаги недостоверности в формате структуры tBB_Bits*/
        /// <summary>
        /// Флаг факта выполнения управляемой остановки
        /// </summary>
        public bool AlreadyStopped;            /* Флаг факта выполнения управляемой остановки*/
        /// <summary>
        /// Флаг факта выполнения неуправляемой остановки
        /// </summary>
        public bool AlreadyStopped2;           /* Флаг факта выполнения неуправляемой остановки*/
        /// <summary>
        /// Невыполнение программы остановки
        /// </summary>
        public bool StopErr;           /* Невыполнение программы остановки */
        /// <summary>
        /// Невыполнение программы остановки. Примечание: формируется при невыполнении команды отключения ВВ
        /// </summary>
        public bool StopErr2;          /* Невыполнение программы остановки. Примечание: формируется при невыполнении команды отключения ВВ */
        /// <summary>
        /// Несанкционированное отключении ВВ НА
        /// </summary>
        public StopNoCmdState StopNoCmd;   /* Несанкционированное отключении ВВ НА */
        /// <summary>
        /// Несанкционированное включении ВВ НА
        /// </summary>
        public bool StartNoCmd;            /* Несанкционированное включении ВВ НА */
        /// <summary>
        /// Невыполнения программы пуска
        /// </summary>
        public bool StartErr;          /* Невыполнения программы пуска */
        /// <summary>
        /// Невыполнения программы пуска. Примечание: сигнал формируется при определении недостижения частоты вращения двигателя минимальной частоты регулирования
        /// </summary>
        public bool StartErr2;         /* Невыполнения программы пуска. Примечание: сигнал формируется при определении недостижения частоты вращения двигателя минимальной частоты регулирования */
        /// <summary>
        /// Неисправности цепей контроля ВВ НА. Примечание - после установки, сигнал сбрасывается при восстановлении корректного состояния цепей контроля ВВ НА
        /// </summary>
        public bool StateAlarm;            /* Неисправности цепей контроля ВВ НА. Примечание - после установки, сигнал сбрасывается при восстановлении корректного состояния цепей контроля ВВ НА */
        /// <summary>
        /// Неисправности цепей контроля НА. Примечание – после установки, сигнал сбрасывается при восстановлении корректного состояния цепей контроля НА
        /// </summary>
        public bool StateAlarmChrp;           /* Неисправности цепей контроля НА. Примечание – после установки, сигнал сбрасывается при восстановлении корректного состояния цепей контроля НА */
        /// <summary>
        /// Факт невыполнения ЧРП команд регулирования.
        /// </summary>
        public bool ChrpRegError;          /* Факт невыполнения ЧРП команд регулирования. */
        /// <summary>
        /// Программно определенная авария ЧРП
        /// </summary>
        public bool LogicalChrpCrach;          /* Программно определенная авария ЧРП */
        /// <summary>
        /// Невыполнение команды подготовить ЧРП
        /// </summary>
        public bool PrepareFail; /*невыполнение команды подготовить ЧРП*/
        /// <summary>
        /// Программной недостоверности сигналов цепей контроля и значения силы тока ЭД
        /// </summary>
        public bool BlockMsgState;         /* программной недостоверности сигналов цепей контроля и значения силы тока ЭД */
        /// <summary>
        /// Запрет выдачи сообщений состояния силы тока ЭД НА
        /// </summary>
        public bool BlockMsgTok;           /* Запрет выдачи сообщений состояния силы тока ЭД НА */
        /// <summary>
        /// Запрет выдачи сообщений состояния ВВ НА
        /// </summary>
        public bool BlockMsgVv;            /* Запрет выдачи сообщений состояния ВВ НА */
        /// <summary>
        /// Запрет выдачи сообщений состояния сигнала от ЧРП "вращение вперед"
        /// </summary>
        public bool BlockMsgSpinFwd;           /* Запрет выдачи сообщений состояния сигнала от ЧРП "вращение вперед" */
        /// <summary>
        /// Запрет выдачи сообщений состояния сигнала от ЧРП "текущая частота вращени вала ЭД НА"
        /// </summary>
        public bool BlockMsgCurFreq;           /* Запрет выдачи сообщений состояния сигнала от ЧРП "текущая частота вращени вала ЭД НА" */
        /// <summary>
        /// Наличие блокировки закрытия приемной агрегатной задвижки
        /// </summary>
        public bool ZPStateNoClose;            /* Наличие блокировки закрытия приемной агрегатной задвижки */
        /// <summary>
        /// Наличие блокировки закрытия выкидной агрегатной задвижки
        /// </summary>
        public bool ZVStateNoClose;            /* Наличие блокировки закрытия выкидной агрегатной задвижки */
        /// <summary>
        /// Наличие питания в цепях включения ВВ на предыдущем цикле работы программы
        /// </summary>
        public bool X;         /* Наличие питания в цепях включения ВВ на предыдущем цикле работы программы */
        /// <summary>
        /// Наличие питания в цепях включения ВВ на предыдущем цикле работы программы
        /// </summary>
        public bool Y;         /* Наличие питания в цепях включения ВВ на предыдущем цикле работы программы */
        /// <summary>
        /// Наличие питания в цепях включения ВВ на предыдущем цикле работы программы
        /// </summary>
        public bool Y1;            /* Наличие питания в цепях включения ВВ на предыдущем цикле работы программы */
        /// <summary>
        /// Результирующий флаг состояния ВВ (0 - отключен, 1 - включен)
        /// </summary>
        public bool BBResult;          /* Результирующий флаг состояния ВВ (0 - отключен, 1 - включен) *//*!!!*/
        /// <summary>
        /// Имитационный режим работы привода НА
        /// </summary>
        public bool SimAgr;            /* Имитационный режим работы привода НА */
        /// <summary>
        /// Наличие нестационарного режима электродвигателя. Примечание – после установки, сигнал автоматически сбрасывается при срабатывании таймера Т09
        /// </summary>
        public bool HIGHVIB;           /* Наличие нестационарного режима электродвигателя. Примечание – после установки, сигнал автоматически сбрасывается при срабатывании таймера Т09 */
        /// <summary>
        /// Наличие нестационарного режима насоса. Примечание: после установки, сигнал автоматически сбрасывается при срабатывании таймера Т13
        /// </summary>
        public bool HIGHVIBNas;            /* Наличие нестационарного режима насоса. Примечание: после установки, сигнал автоматически сбрасывается при срабатывании таймера Т13 */
        /// <summary>
        /// Состояние ЧРП на предыдущем цикле программы
        /// </summary>
        public ChrpNu ChRP_In_Prev = new ChrpNu();
        /// <summary>
        /// Факт выдачи команды на «Отключить ВВ» НА
        /// </summary>
        public bool StopCmdConfirmed;           /* Факт выдачи команды на «Отключить ВВ» НА */
        /// <summary>
        /// Состояние предыдущей команды управления ВВ НА
        /// </summary>
        public bool prevMPNACmd_Status;            /* Состояние предыдущей команды управления ВВ НА */
        /// <summary>
        /// Необходимость определения состояния ВВ по косвенным признакам
        /// </summary>
        public bool PumpNdvVote;           /* Необходимость определения состояния ВВ по косвенным признакам */
        /// <summary>
        /// Необходимость определения состояния ВВ по косвенным признакам во время процесса запуска и остановки
        /// </summary>
        public bool PumpNdvVoteDynamics;           /* Необходимость определения состояния ВВ по косвенным признакам во время процесса запуска и остановки */
        /// <summary>
        ///  Недостоверность цепей контроля НА
        /// </summary>
        public ChrpStruct Pump_Prog_Ndv = new ChrpStruct();  /* Недостоверность цепей контроля НА */
        /// <summary>
        /// Недостоверность цепей контроля НА вовремя выполнение программы пуска или остановки НА
        /// </summary>
        public ChrpStruct Pump_Prog_Ndv_Dynamics = new ChrpStruct(); /* Недостоверность цепей контроля НА вовремя выполнение программы пуска или остановки НА */
        /// <summary>
        /// Флаг выполнения программы управляемой остановки
        /// </summary>
        public bool flManagedStop;         /* Флаг выполнения программы управляемой остановки */
        /// <summary>
        /// Флаг выдачи повторяемых команд отключения ВВ
        /// </summary>
        public bool flag_PovtorOtkl;           /* Флаг выдачи повторяемых команд отключения ВВ */
        /// <summary>
        /// Флаг выполнения остановки по команде оператора
        /// </summary>
        public bool flStopByCmd;           /* Флаг выполнения остановки по команде оператора */
        /// <summary>
        /// Флаг выполнения отключения ВВ после выполнения программы управляемой остановки
        /// </summary>
        public bool flOfVV;            /* Флаг выполнения отключения ВВ после выполнения программы управляемой остановки */
        /// <summary>
        /// Команда на отключение ВВ НА
        /// </summary>
        public bool StopWork;          /* Команда на отключение ВВ НА */
        /// <summary>
        /// Команда на снижение частоты вращени вала НА
        /// </summary>
        public bool ChrpSpinStop;          /* Команда на снижение частоты вращени вала НА */
        /// <summary>
        /// Флаг выдачи команды "пуск в ЧРП"
        /// </summary>
        public bool flChRP_PuskCmd;            /* Флаг выдачи команды "пуск в ЧРП" */
        /// <summary>
        /// Флаг включенного состояния ВВ на предыдущем цикле программы
        /// </summary>
        public bool BBOn_Prev;
        /// <summary>
        /// Флаг отключенного состояния ВВ на предыдущем цикле программы
        /// </summary>
        public bool BBOff_Prev;
        /// <summary>
        /// Флаг запуска ЧРП по ТМ на предыдущем цикле программы
        /// </summary>
        public bool PuskTM_Prev;
        /// <summary>
        /// Флаг останова ЧРП из ЦСПА на предыдущем цикле программы
        /// </summary>
        public bool StopCSPA_Prev;
        /// <summary>
        /// Флаг останова ЧРП по ТМ на предыдущем цикле программы
        /// </summary>
        public bool StopTM_Prev;
        /// <summary>
        /// Команда на выкидную задвижку
        /// </summary>
        public NaZdCmd ZVCmd;
        /// <summary>
        /// Команда на приемную задвижку
        /// </summary>
        public NaZdCmd ZPCmd;
        /// <summary>
        /// Блокировка выкидной задвижки
        /// </summary>
        public NaZdBlocks ZVBlocks;
        /// <summary>
        /// Блокировка приемной задвижки
        /// </summary>
        public NaZdBlocks ZPBlocks;
        /// <summary>
        /// Состояние ВВ
        /// </summary>
        public int UMPNA_BB_State;
        /// <summary>
        /// Флаг включенного состояния насоса
        /// </summary>
        public bool flPumpOn;
        /// <summary>
        /// Флаг отключенного состояния насоса
        /// </summary>
        public bool flPumpOff;
        /// <summary>
        /// Необходимость определения окончательного оценочного состояния МНА
        /// </summary>
        public bool PumpJudgementNeed;
    }
    /// <summary>
    /// Структура конфигурации модуля Cmna
    /// </summary>
    internal class CmnaCfg
    {
        /// <summary>
        /// Минимальная частота при которой определяется невыполнение команд регулирования
        /// </summary>
        public ushort MaxFreqRegDiff;
    }



    public class Cmna : CmnaIo
    {
        /// <summary>
        /// Структура состояния ЧРП
        /// </summary>
        private CmnaStorage na = new CmnaStorage();
        /// <summary>
        /// Структура конфигурации модуля
        /// </summary>
        private CmnaCfg cfg = new CmnaCfg();



        public Cmna()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
            InternalTimers = new StArray<ITimer>(1, Enumerable.Range(1, 29).Select(i => new CpaLocalTimer()).ToArray());
        }

        public override void Execute()
        {

            /* инициализация состояния/режима/уставок */
            if (na.Mode != NaMode.Osn && na.Mode != NaMode.Tm && na.Mode != NaMode.Rez && na.Mode != NaMode.Rem)
            {
                na.Mode = NaMode.Osn;
            }

            if (na.MainState != NaState.Vkl && na.MainState != NaState.Otkl && na.MainState != NaState.Pusk && na.MainState != NaState.Ostanov)
            {
                na.MainState = NaState.Otkl;
            }
            if (cfg.MaxFreqRegDiff < MinWorkFreq) { cfg.MaxFreqRegDiff = MinWorkFreq; }


            var flStopByCmd = false;



            /*
             * Обработка сигналов ВВ
             */
            var BBOn = false;
            var BBOff = false;
            var flTmp1 = false;
            var flTmp2 = false;
            var BB_Curr = false;

            var diagnoNeed = false;
            if (!vv.SwitchOn1 && vv.SwitchOff1 && !vv.SwitchOn2 && vv.SwitchOff2)
            {
                BBOff = true;
                BB_Curr = false;

            }
            else if (vv.SwitchOn1 && !vv.SwitchOff1 && vv.SwitchOn2 && !vv.SwitchOff2)
            {
                BBOn = true;
                BB_Curr = true;
            }
            else
            {
                diagnoNeed = true;
            }

            if (!diagnoNeed)
            {
                na.VvNdv.SwitchOn1 = false;
                na.VvNdv.SwitchOff1 = false;
                na.VvNdv.SwitchOn2 = false;
                na.VvNdv.SwitchOff2 = false;
                InternalTimers[1].Stop();
                na.StateAlarm = false;
            }
            else
            {
                int Index;
                var vvOnScore = 0;
                var VvOffScore = 0;
                var costTableVkl1 = new StArray<int>(1, new[] { 0, 1, 1, 0, 0, 1, 4, 0 });
                var costTableOtkl1 = new StArray<int>(1, new[] { 1, 0, 0, 1, 1, 0, 0, 4 });
                var costTableVkl2 = new StArray<int>(1, new[] { 0, 1, 1, 0 });
                var costTableOtkl2 = new StArray<int>(1, new[] { 1, 0, 0, 1 });
                /*ВВ включен УСО1*/
                if (!na.VvNdv.SwitchOn1)
                {
                    Index = 1 + (vv.SwitchOn1 ? 1 : 0);
                    vvOnScore = vvOnScore + costTableVkl1[Index];
                    VvOffScore = VvOffScore + costTableOtkl1[Index];
                }

                /*ВВ отключен УСО1*/
                if (!na.VvNdv.SwitchOff1)
                {
                    Index = 3 + (vv.SwitchOff1 ? 1 : 0);
                    vvOnScore = vvOnScore + costTableVkl1[Index];
                    VvOffScore = VvOffScore + costTableOtkl1[Index];
                }

                /*ВВ включен УСО3*/
                if (!na.VvNdv.SwitchOn2)
                {
                    Index = 1 + (vv.SwitchOn2 ? 1 : 0);
                    vvOnScore = vvOnScore + costTableVkl2[Index];
                    VvOffScore = VvOffScore + costTableOtkl2[Index];
                }

                /*ВВ отключен УСО3*/
                if (!na.VvNdv.SwitchOff2)
                {
                    Index = 3 + (vv.SwitchOff2 ? 1 : 0);
                    vvOnScore = vvOnScore + costTableVkl2[Index];
                    VvOffScore = VvOffScore + costTableOtkl2[Index];
                }

                /*команда отключить*/
                if (na.StopCmdConfirmed)
                {
                    Index = 8;
                    vvOnScore = vvOnScore + costTableVkl1[Index];
                    VvOffScore = VvOffScore + costTableOtkl1[Index];
                }

                /*отключен, нет напряжения*/
                if (!(vv.SwitchOn1 || vv.SwitchOff1 || vv.SwitchOn2 || vv.SwitchOff2) && !QF3A)
                {
                    vvOnScore = vvOnScore + 0;
                    VvOffScore = VvOffScore + 1;
                }

                /* эталонные значения сигналов и расчетное состояние ВВ */

                if (vvOnScore >= VvOffScore)
                {
                    na.VvReference.SwitchOn1 = true;
                    na.VvReference.SwitchOff1 = false;
                    na.VvReference.SwitchOn2 = true;
                    na.VvReference.SwitchOff2 = false;
                }
                else
                {
                    na.VvReference.SwitchOn1 = false;
                    na.VvReference.SwitchOff1 = true;
                    na.VvReference.SwitchOn2 = false;
                    na.VvReference.SwitchOff2 = true;
                }

                if (!InternalTimers[1].IsStarted && !InternalTimers[1].IsQ && !na.StateAlarm)
                {
                    InternalTimers[1].Start();
                }

                if (InternalTimers[1].IsQ)
                {
                    if (vv.SwitchOn1 ^ na.VvReference.SwitchOn1)
                    {
                        na.VvNdv.SwitchOn1 = true;
                        Messenger.Send(1); /* ОП. СИГНАЛ ВВ ВКЛЮЧЕН В УСО 1.1 НЕДОСТОВЕРЕН */
                    }

                    if (vv.SwitchOff1 ^ na.VvReference.SwitchOff1)
                    {
                        na.VvNdv.SwitchOff1 = true;
                        Messenger.Send(2); /* ОП. СИГНАЛ ВВ ОТКЛЮЧЕН В УСО 1.1 НЕДОСТОВЕРЕН */
                    }

                    if (vv.SwitchOn2 ^ na.VvReference.SwitchOn2)
                    {
                        na.VvNdv.SwitchOn2 = true;
                        Messenger.Send(3); /* ОП. СИГНАЛ ВВ ВКЛЮЧЕН В УСО 3 НЕДОСТОВЕРЕН */
                    }

                    if (vv.SwitchOff2 ^ na.VvReference.SwitchOff2)
                    {
                        na.VvNdv.SwitchOff2 = true;
                        Messenger.Send(4); /* ОП. СИГНАЛ ВВ ОТКЛЮЧЕН В УСО 3 НЕДОСТОВЕРЕН */
                    }
                }
            }

            if (na.VvNdv.SwitchOn1 || na.VvNdv.SwitchOff1 || na.VvNdv.SwitchOn2 || na.VvNdv.SwitchOff2)
            {
                na.StateAlarm = true;
                BBOn = false;
                BBOff = false;
                if ((vv.SwitchOn1 || na.VvNdv.SwitchOn1) && (!vv.SwitchOff1 || na.VvNdv.SwitchOff1) &&
                    (vv.SwitchOn2 || na.VvNdv.SwitchOn2) && (!vv.SwitchOff2 || na.VvNdv.SwitchOff2))
                {
                    BBOn = true;
                }

                if ((!vv.SwitchOn1 || na.VvNdv.SwitchOn1) && (vv.SwitchOff1 || na.VvNdv.SwitchOff1) &&
                    (!vv.SwitchOn2 || na.VvNdv.SwitchOn2) && (vv.SwitchOff2 || na.VvNdv.SwitchOff2))
                {
                    BBOff = true;
                }

                if (BBOff == BBOn)
                {
                    BBOn = BB_Curr;
                    BBOff = !BB_Curr;
                }
            }

            /*
             * определение достоверности 3х сигналов: частота, вращение вперед и ток
             */

            /*появления сигнала BBOff при наличии BBOn_OUT и т.п.*/
            if (BBOff && na.BBOn_Prev && na.flPumpOn && !InternalTimers[27].IsStarted && ChRP_In.Dist)
            {
                na.flPumpOn = false;
                na.flPumpOff = true;
                InternalTimers[27].Start(); /*задержка на снятие частоты и сигнала вращения, после отключения ВВ*/
            }

            var flTmp = false;

            ChrpStruct PumpRefOnState = new ChrpStruct();
            ChrpStruct PumpRefOffState = new ChrpStruct();
            ChrpStruct PumpCurState = new ChrpStruct();

            PumpRefOnState.Tok = true; PumpRefOnState.SpinForward = true; PumpRefOnState.CurFreqMT30 = true;       /*эталонные значения 3х сигналов (МНА вкл)*/
            PumpRefOffState.Tok = !TokControl; PumpRefOffState.SpinForward = false; PumpRefOffState.CurFreqMT30 = false;       /*эталонные значения 3х сигналов (МНА откл)*/
            PumpCurState.Tok = !TokControl || vv.Tok; PumpCurState.SpinForward = ChRP_In.SpinForward; PumpCurState.CurFreqMT30 = ChRP_In.CurFreq > MinWorkFreq; /*текущее  состояние 3х сигналов*/

            if (PumpCurState.CurFreqMT30 == PumpRefOnState.CurFreqMT30 && PumpCurState.SpinForward == PumpRefOnState.SpinForward && PumpCurState.Tok == PumpRefOnState.Tok && BBOn)
            {
                flTmp = true;
                na.flPumpOn = true;
                na.flPumpOff = false;
            }
            else if (PumpCurState.CurFreqMT30 == PumpRefOffState.CurFreqMT30 && PumpCurState.SpinForward == PumpRefOffState.SpinForward && PumpCurState.Tok == PumpRefOffState.Tok)
            {
                flTmp = true;
                na.flPumpOn = false;
                na.flPumpOff = true;
            }
            else if (na.MainState == NaState.Pusk || na.MainState == NaState.Ostanov)
            {
                InternalTimers[26].Stop();
            }
            else if (InternalTimers[27].IsStarted)
            {
                InternalTimers[26].Stop();
            }
            else if (ChRP_In.Dist && ChRP_Out.GrantMestCmd)
            {
                InternalTimers[26].Stop();
            }
            else if (!InternalTimers[26].IsStarted && !InternalTimers[26].IsQ && !(na.StopNoCmd > StopNoCmdState.None) && !na.StateAlarmChrp)
            {
                InternalTimers[26].Start();
            }
            /*Схема 11.9. Алгоритм контроля параметров НА*/

            if (flTmp)
            {
                /*состояние 3х сигналов однозначно, сброс недостоверностей*/
                InternalTimers[26].Stop();
                InternalTimers[27].Stop();
                na.Pump_Prog_Ndv.SpinForward = false; na.Pump_Prog_Ndv.CurFreqMT30 = false; na.Pump_Prog_Ndv.Tok = false; na.StateAlarmChrp = false;
            }


            var PUMD_ON_COST_TBL = new StArray<int>(1, new[] { 2, 2, 2, -8, 3 });
            var PUMD_OFF_COST_TBL = new StArray<int>(1, new[] { -2, -2, -2, 8, 3 });

            /*расчет оценочного состояния МНА*//*!*/
            var PumpOn = 0;
            var PumpOff = 0;
            if (!na.Pump_Prog_Ndv.CurFreqMT30 && !na.Pump_Prog_Ndv_Dynamics.CurFreqMT30)
            {
                if (PumpCurState.CurFreqMT30)
                {
                    PumpOn = PumpOn + PUMD_ON_COST_TBL[1]; PumpOff = PumpOff + PUMD_OFF_COST_TBL[1];  /*частота>30*/
                }
                else
                {
                    PumpOn = PumpOn - PUMD_ON_COST_TBL[1]; PumpOff = PumpOff - PUMD_OFF_COST_TBL[1];
                }
            }
            if (!na.Pump_Prog_Ndv.SpinForward && !na.Pump_Prog_Ndv_Dynamics.SpinForward)
            {
                if (PumpCurState.SpinForward)
                {
                    PumpOn = PumpOn + PUMD_ON_COST_TBL[2]; PumpOff = PumpOff + PUMD_OFF_COST_TBL[2];  /*вращение вперед*/
                }
                else
                {
                    PumpOn = PumpOn - PUMD_ON_COST_TBL[2]; PumpOff = PumpOff - PUMD_OFF_COST_TBL[2];
                }
            }
            if (!na.Pump_Prog_Ndv.Tok && TokControl)
            {
                if (PumpCurState.Tok)
                {
                    PumpOn = PumpOn + PUMD_ON_COST_TBL[3]; PumpOff = PumpOff + PUMD_OFF_COST_TBL[3];  /*ток*/
                }
                else
                {
                    PumpOn = PumpOn - PUMD_ON_COST_TBL[3]; PumpOff = PumpOff - PUMD_OFF_COST_TBL[3];
                }
            }
            /*Схема 11.10. Алгоритм контроля параметров НА. Часть 2*/
            if (!BBOn) { PumpOn = PumpOn + PUMD_ON_COST_TBL[4]; PumpOff = PumpOff + PUMD_OFF_COST_TBL[4]; }  /*состояние ВВ*/
            if (SpinStopCmd) { PumpOn = PumpOn - PUMD_ON_COST_TBL[5]; PumpOff = PumpOff + PUMD_OFF_COST_TBL[5]; }  /*команда снижения частоты*/
            if (na.flChRP_PuskCmd) { PumpOn = PumpOn + PUMD_ON_COST_TBL[5]; PumpOff = PumpOff - PUMD_OFF_COST_TBL[5]; }  /*команда пуск (в ЧРП)*/


            var PumpCur = PumpOn >= PumpOff;           /*оценочное состояние МНА*//*!*/




            var PumpNdvVote = false;
            /*сработали таймера на формирование недостоверности Т01 (но без отключения ВВ) или Т26*/
            if (InternalTimers[1].IsQ && !InternalTimers[27].IsStarted || InternalTimers[26].IsQ)
            {
                InternalTimers[26].Stop();
                PumpNdvVote = true;
                na.PumpJudgementNeed = true;
                //в случае ошибки 3х сигналов "в статике" формирование недостоверности происходит интересно: методом постоянного перезапуска Т26
            }


            /*принять "оценочное" состояние МНА как действительное*/
            if (na.PumpJudgementNeed)
            {
                na.PumpJudgementNeed = false;
                na.flPumpOn = PumpCur;
                na.flPumpOff = !PumpCur;
            }
            /*Схема 11.11. Алгоритм контроля параметров НА. Часть 3*/

            ChrpStruct CurrentReferenceState;
            /*формирование недостоверности 3х сигналов в статике (таймер Т26)*/
            if (PumpNdvVote)
            {
                if (PumpCur)
                {
                    CurrentReferenceState = PumpRefOnState;    /*эталонные значения 3х сигналов*/
                }
                else
                {
                    CurrentReferenceState = PumpRefOffState;
                }
                if (CurrentReferenceState.CurFreqMT30 != PumpCurState.CurFreqMT30 && !(na.Pump_Prog_Ndv.CurFreqMT30 || na.Pump_Prog_Ndv_Dynamics.CurFreqMT30))
                {
                    na.Pump_Prog_Ndv.CurFreqMT30 = true;
                    Messenger.Send(151);  /* ОП. СИГНАЛ ОТ ЧРП "ТЕКУЩАЯ ЧАСТОТА ВРАЩЕНИЯ ВАЛА ЭД" НЕДОСТОВЕРЕН */
                }
                if (CurrentReferenceState.SpinForward != PumpCurState.SpinForward && !(na.Pump_Prog_Ndv.SpinForward || na.Pump_Prog_Ndv_Dynamics.SpinForward))
                {
                    na.Pump_Prog_Ndv.SpinForward = true;
                    Messenger.Send(152);  /* ОП. СИГНАЛ ОТ ЧРП "ВРАЩЕНИЕ ВПЕРЕД" НЕДОСТОВЕРЕН */
                }
                if (CurrentReferenceState.Tok != PumpCurState.Tok && !na.Pump_Prog_Ndv.Tok)
                {
                    na.Pump_Prog_Ndv.Tok = true;
                    Messenger.Send(5);    /* ОП. ЗНАЧЕНИЕ СИЛЫ ТОКА НЕДОСТОВЕРНО */
                }
            }
            /*Схема 11.12. Алгоритм контроля параметров НА. Часть 4*/

            /*формирование недостоверности 3х сигналов во время останова (таймер Т19)*/
            if (na.PumpNdvVoteDynamics)
            {
                if (PumpCur)
                {
                    CurrentReferenceState = PumpRefOnState;    /*эталонные значения 3х сигналов*/
                }
                else
                {
                    CurrentReferenceState = PumpRefOffState;
                }
                if (CurrentReferenceState.CurFreqMT30 != PumpCurState.CurFreqMT30 && !na.Pump_Prog_Ndv_Dynamics.CurFreqMT30)
                {
                    na.Pump_Prog_Ndv_Dynamics.CurFreqMT30 = true;
                }
                if (CurrentReferenceState.SpinForward != PumpCurState.SpinForward && !na.Pump_Prog_Ndv_Dynamics.SpinForward)
                {
                    na.Pump_Prog_Ndv_Dynamics.SpinForward = true;
                }
                if (CurrentReferenceState.Tok != PumpCurState.Tok && !na.Pump_Prog_Ndv.Tok)
                {
                    na.Pump_Prog_Ndv.Tok = true;
                    Messenger.Send(5);  /* ОП. ЗНАЧЕНИЕ СИЛЫ ТОКА НЕДОСТОВЕРНО */
                }
            }

            na.StateAlarmChrp = na.Pump_Prog_Ndv.CurFreqMT30 || na.Pump_Prog_Ndv.SpinForward || na.Pump_Prog_Ndv.Tok;
            var logicalChRpCrach = na.PrepareFail || na.Pump_Prog_Ndv_Dynamics.CurFreqMT30 || na.Pump_Prog_Ndv_Dynamics.SpinForward;
            /*Схема 11.13. Алгоритм контроля параметров НА. Часть 5*/

            if (logicalChRpCrach)
            {
                if (na.Pump_Prog_Ndv_Dynamics.CurFreqMT30 && !PumpCurState.CurFreqMT30)
                {
                    Messenger.Send(110);  /* ОП. ЧАСТОТА ВРАЩЕНИЯ ВАЛА ЭД МЕНЕЕ 30 ОБ/МИН */
                    na.Pump_Prog_Ndv_Dynamics.CurFreqMT30 = false;
                }
                if (na.Pump_Prog_Ndv_Dynamics.SpinForward && !PumpCurState.SpinForward)
                {
                    Messenger.Send(111);  /* ОП. СИГНАЛ ОТ ЧРП "ВРАЩЕНИЕ ВПЕРЕД" СБРОШЕН */
                    na.Pump_Prog_Ndv_Dynamics.SpinForward = false;
                }
            }

            na.PumpNdvVoteDynamics = false;
            /*Схема 11.14. Алгоритм контроля параметров НА. Окончание*/





            /*
             * контроль доставки команды отключения в ЗРУ
             */
            if (InternalTimers[11].IsStarted)
            {
                if (!vv.ECx03 && na.Y || !vv.ECx03_1 && na.Y1)
                {
                    Messenger.Send(19);  /* ОП. КОМАНДА НА ОТКЛЮЧЕНИЕ ВВ В ЯЧЕЙКУ ЗРУ ДОСТАВЛЕНА */
                    na.StopCmdConfirmed = true;
                }
                //закончились переходные процессы (в том числе формирование недостоверности при наличии ошибок), флаг доставленной команды снимается
            }
            else if (!InternalTimers[12].IsStarted && !InternalTimers[17].IsStarted && !InternalTimers[18].IsStarted && !InternalTimers[19].IsStarted && !InternalTimers[1].IsStarted)
            {
                na.StopCmdConfirmed = false;
            }

            na.Y = vv.ECx03;
            na.Y1 = vv.ECx03_1;

            /* ------------------------------------------------------------ контроль режима ДИСТ/МЕСТ ЧРП ------------------------------------------------------------ */
            if (!ChRP_In.Dist && na.ChRP_In_Prev.Dist)
            {
                Messenger.Send(143);      /* ОП. СИГНАЛ ОТ ЧРП "ДИСТАНЦИОННОЕ УПРАВЛЕНИЕ" СНЯТ */
                if (ChRP_In.TaskFreq > MinWorkFreq)
                {
                    Messenger.Send(131);  /* ОП. КОМАНДА - СНИЗИТЬ ЧАСТОТУ ВРАЩЕНИЯ ВАЛА ЭД ДО НУЛЯ */
                    if (!na.SimAgr)
                    {
                        SpinStopCmd = true;
                    }
                }
            }
            else if (ChRP_In.Dist && !na.ChRP_In_Prev.Dist)
            {
                Messenger.Send(148);  /* ОП. СИГНАЛ ОТ ЧРП "ДИСТАНЦИОННОЕ УПРАВЛЕНИЕ" УСТАНОВЛЕН */
            }

            /*принудительное снятие команды снижения частоты (в ЧРП), если режим ЧРП МЕСТ и уставка <= 30*/
            if (!ChRP_In.Dist && ChRP_In.TaskFreq <= MinWorkFreq)
            {
                SpinStopCmd = false;
            }
            /*Схема 11.17. Алгоритм контроля режима управления ЧРП*/





            /* ------------------------------------------------------------ подготовка ЧРП к пуску ------------------------------------------------------------ */
            if (Cmd == NaCmd.SET_PREPARE_CHRP)
            {
                flTmp = true;
                Messenger.Send(127);      /* ОП. КОМАНДА - ПОДГОТОВИТЬ ЧРП К ПУСКУ */

                if (ChRP_Out.PrepareCmd) { flTmp = false; Messenger.Send(123); } /* ОП. ИДЕТ ПОДГОТОВКА ЧРП К ПУСКУ. КОМАНДА НЕ ТРЕБУЕТСЯ */
                if (ChRP_In.Ready) { flTmp = false; Messenger.Send(124); } /* ОП. ЧРП ГОТОВ К ПУСКУ. КОМАНДА НЕ ТРЕБУЕТСЯ */
                if (ChRP_In.Crach) { flTmp = false; Messenger.Send(125); } /* ОП. ПОДГОТОВКА ЧРП К ПУКСУ НЕВОЗМОЖНА. АВАРИЯ ЧРП */
                if (na.MainState != NaState.Otkl)
                {
                    flTmp = false; Messenger.Send(126);         /* ОП. ПОДГОТОВКА ЧРП К ПУКСУ НЕВОЗМОЖНА. АГРЕГАТ НЕ ОСТАНОВЛЕН */
                }
                else if (na.ActvTaskMpna == 1) { flTmp = false; Messenger.Send(158); } /* ОП. ПОДГОТОВКА ЧРП К ПУСКУ НЕВОЗМОЖНА. ИДЕТ ОТКЛЮЧЕНИЕ ВВ ПО ПРОГРАММЕ УПРАВЛЯЕМОЙ ОСТАНОВКИ С ПОСЛЕДУЮЩИМ ОТКЛЮЧЕНИЕМ ВВ */
                if (!ChRP_In.Dist) { flTmp = false; Messenger.Send(149); } /* ОП. ПОДГОТОВКА ЧРП К ПУСКУ НЕВОЗМОЖНА. ЧРП НЕ В ДИСТАНЦИОННОМ РЕЖИМЕ УПРАВЛЕНИЯ */
                if (StopAuto || ManagesStopWithOffVv || na.Mode == NaMode.Rem) { flTmp = false; Messenger.Send(150); } /* ПОДГОТОВКА ЧРП К ПУСКУ НЕВОЗМОЖНА. ТРЕБОВАНИЕ ОТКЛЮЧЕНИЯ ВВ */

                if (flTmp)
                {
                    if (na.SimAgr)
                    {
                        Messenger.Send(128); /* ОП. ГОТОВНОСТЬ ЧРП К ПУСКУ УСТАНОВЛЕНА */
                    }
                    else
                    {
                        InternalTimers[23].Start();
                        ChRP_Out.PrepareCmd = true;
                    }
                }
            }
            /*Схема 11.19. Алгоритм выдачи команды «подготовить ЧРП к пуску». Окончание*/

            if (ChRP_Out.PrepareCmd)
            {
                if (ChRP_In.Ready)
                {
                    ChRP_Out.PrepareCmd = false;
                }
                else if (ChRP_In.Crach)
                {
                    InternalTimers[23].Stop();
                    ChRP_Out.PrepareCmd = false;
                    Messenger.Send(129);  /* ОП. ГОТОВНОСТЬ ЧРП К ПУСКУ НЕ ПОЛУЧЕНА. АВАРИЯ ЧРП */
                }
                else if (!InternalTimers[23].IsStarted)
                {
                    na.PrepareFail = true;
                    ChRP_Out.PrepareCmd = false;
                    Messenger.Send(130);  /* ОП. ГОТОВНОСТЬ ЧРП К ПУСКУ НЕ ПОЛУЧЕНА ЗА ЗАДАННОЕ ВРЕМЯ */
                }
            }

            if (ChRP_In.Ready && !na.ChRP_In_Prev.Ready)
            {
                na.PrepareFail = false;
                InternalTimers[23].Stop();
                Messenger.Send(128);      /* ОП. ГОТОВНОСТЬ ЧРП К ПУСКУ УСТАНОВЛЕНА */
            }
            /*Схема 11.20. Алгоритм контроля выполнения команды «подготовить ЧРП к пуску»*/





            /* ------------------------------------------------------- контроль разрешения на пуск в местном режиме ------------------------------------------------------- */
            if (Cmd == NaCmd.ALLOW_LOCAL)
            {
                var allowLocal = true;
                Messenger.Send(137);  /* ОП. КОМАНДА - ВЫДАТЬ РАЗРЕШЕНИЕ НА ПУСК ДВИГАТЕЛЯ В МЕСТНОМ РЕЖИМЕ УПРАВЛЕНИЯ */

                if (ChRP_In.Dist) { allowLocal = false; Messenger.Send(138); } /* ОП. ЧРП В ДИСТАНЦИОННОМ РЕЖИМЕ УПРАВЛЕНИЯ. КОМАНДА НЕ ТРЕБУЕТСЯ */
                if (ChRP_Out.GrantMestCmd) { allowLocal = false; Messenger.Send(156); } /* ОП. РАЗРЕШЕНИЕ НА ПУСК В МЕСТНОМ РЕЖИМЕ УПРАВЛЕНИЯ УСТАНОВЛЕНО. КОМАНДА НЕ ТРЕБУЕТСЯ */
                if (!ReadyToStart) { allowLocal = false; Messenger.Send(139); } /* ОП. ВЫДАТЬ РАЗРЕШЕНИЕ НЕВОЗМОЖНО. АГРЕГАТ НЕ ГОТОВ К ПУСКУ */

                /*Схема 11.21. Алгоритм установки разрешения на пуск двигателя в местном режиме управления*/
                if (allowLocal)
                {
                    Messenger.Send(140);  /* ОП. РАЗРЕШЕНИЕ НА ПУСК ДВИГАТЕЛЯ В МЕСТНОМ РЕЖИМЕ УПРАВЛЕНИЯ ВЫДАНО */
                    if (!na.SimAgr) { ChRP_Out.GrantMestCmd = true; }
                }
            }

            var disallowLocal = false;
            if (Cmd == NaCmd.DISALLOW_LOCAL)
            {
                Messenger.Send(141); /* ОП. КОМАНДА - CНЯТЬ РАЗРЕШЕНИЕ НА ПУСК ДВИГАТЕЛЯ В МЕСТНОМ РЕЖИМЕ УПРАВЛЕНИЯ */
                if (ChRP_Out.GrantMestCmd)
                {
                    disallowLocal = true;
                }
                else
                {
                    Messenger.Send(144); /* ОП. РАЗРЕШЕНИЕ ОТСУТСТВУЕТ. КОМАНДА НЕ ТРЕБУЕТСЯ */
                }
            }

            if (ChRP_Out.GrantMestCmd && ChRP_In.Dist)
            {
                disallowLocal = true;
            }

            if (ChRP_Out.GrantMestCmd && na.MainState == NaState.Otkl && !ReadyToStart)
            {
                disallowLocal = true;
            }

            if (disallowLocal)
            {
                Messenger.Send(142); /* ОП. РАЗРЕШЕНИЕ НА ПУСК ДВИГАТЕЛЯ В МЕСТНОМ РЕЖИМЕ УПРАВЛЕНИЯ СНЯТО */
                if (!na.SimAgr)
                {
                    ChRP_Out.GrantMestCmd = false;
                    if (na.MainState == NaState.Vkl || na.MainState == NaState.Pusk)
                    {
                        //не соответствует текущей карте проверок, но лучше чем было
                        na.ActvTaskMpna = 1;
                        na.TaskStepMpna = 1;
                        na.flManagedStop = true;
                        flStopByCmd = true;
                    }
                }
            }
            /*Схема 11.22. Алгоритм снятия разрешения на пуск двигателя в местном режиме управления*/



            if (ChRP_In.Crach && !na.ChRP_In_Prev.Crach) { Messenger.Send(135); } /* ОП. КРИТИЧЕСКИЙ ОТКАЗ ЧРП */
            if (ChRP_In.Err && !na.ChRP_In_Prev.Err) { Messenger.Send(136); } /* ОП. НЕИСПРАВНОСТЬ ЧРП */
            if (!ChRP_In.Err && na.ChRP_In_Prev.Err) { Messenger.Send(157); } /* ОП. СИГНАЛ "НЕИСПРАВНОСТЬ ЧРП" СНЯТ */





            /* -------------------------------------------------- контроль выполнения регулирования частоты -------------------------------------------------- */
            if (na.MainState == NaState.Vkl && ChRP_In.Dist && !InternalTimers[25].IsStarted && !na.SimAgr)
            {
                var regDiff = Math.Abs(ChRP_In.TaskFreq - ChRP_In.CurFreq);

                if (InternalTimers[24].IsQ && regDiff > cfg.MaxFreqRegDiff)
                {
                    na.ChrpRegError = true;
                }
                else if (!na.ChrpRegError && !InternalTimers[24].IsStarted && regDiff > cfg.MaxFreqRegDiff)
                {                   //по хорошему нужно учесть наличие ChRPRegError.. иначе таймер будет постоянно перезапускаться
                    InternalTimers[24].Start();
                }
                else if (regDiff <= cfg.MaxFreqRegDiff)
                {
                    InternalTimers[24].Stop();
                    na.ChrpRegError = false;
                }
            }
            else
            {
                InternalTimers[24].Stop();
                na.ChrpRegError = false;
            }
            /*Схема 11.23. Алгоритм контроля выполнения ЧРП команд регулирования*/





            /* ------------------------------------------------------ Контроль агрегата в местном режиме ------------------------------------------------------ */
            if (!ChRP_In.Dist && ChRP_Out.GrantMestCmd && na.MainState == NaState.Otkl && na.ActvTaskMpna == 0 && BBOn)
            {
                var mestStart = false;
                if (TokControl && vv.Tok) { mestStart = true; Messenger.Send(6); } /* ОП. ТОК ДВИГАТЕЛЯ НАБРАН */
                if (ChRP_In.SpinForward) { mestStart = true; Messenger.Send(117); } /* ОП. СИГНАЛ ОТ ЧРП "ВРАЩЕНИЕ ВПЕРЕД" ПОЛУЧЕН */
                if (ChRP_In.CurFreq > MinWorkFreq) { mestStart = true; Messenger.Send(118); } /* ОП. ЧАСТОТА ВРАЩЕНИЯ ВАЛА ЭД БОЛЕЕ 30 ОБ/МИН */

                if (mestStart)
                {
                    na.ActvTaskMpna = 2;
                    na.TaskStepMpna = 1;
                }
            }
            /*Схема 11.24. Контроль состояния НА в местном режиме управления.*/


            if (!ChRP_In.Dist && !na.StartNoCmd && na.MainState == NaState.Vkl && na.ActvTaskMpna == 0 && !na.SimAgr)
            {
                var mestStop = false;
                if (TokControl && !vv.Tok) { mestStop = true; Messenger.Send(7); } /* ОП. ТОК СБРОШЕН */
                if (!ChRP_In.SpinForward) { mestStop = true; Messenger.Send(111); } /* ОП. СИГНАЛ ОТ ЧРП "ВРАЩЕНИЕ ВПЕРЕД" СБРОШЕН */
                if (ChRP_In.CurFreq <= MinWorkFreq) { mestStop = true; Messenger.Send(110); } /* ОП. ЧАСТОТА ВРАЩЕНИЯ ВАЛА ЭД МЕНЕЕ 30 ОБ/МИН */
                if (BBOff) { mestStop = true; }

                if (mestStop)
                {
                    na.ActvTaskMpna = 1;
                    na.TaskStepMpna = 1;
                    na.flManagedStop = true;
                }
            }
            /*Схема 11.25. Контроль состояния агрегата в местном режиме управления. Окончание*/





            /* -------------------------------------------------------------- ............... ----------------------------------------------------------------- */
            if (!(na.ActvTaskMpna == 1 && (!na.flManagedStop || na.flOfVV)))
            {
                if (BBOn && na.BBOff_Prev)
                {
                    Messenger.Send(14);  /* ОП. ВВ ВКЛЮЧЕН */
                }
                else if (BBOff && na.BBOn_Prev)
                {
                    Messenger.Send(18);  /* ОП. ВВ ОТКЛЮЧЕН */
                }
            }


            if (!StopElectric)
            {
                InternalTimers[29].Start();
            }/* --------------------------------------------------------- Селектор команд на останов ------------------------------------------------------------ */

            StopAuto = StopAuto || StopAvarChrp;//TODO: не стоит трогать входные переменные


            var flCanStop = ManageStop && !StopAuto && !na.StopErr || StopAuto && !na.StopErr2 || ManagesStopWithOffVv && !(na.StopErr || na.StopErr2) || RepeatedStop && !na.flag_PovtorOtkl;
            var flNeedStop = na.ActvTaskMpna != 1 ||
                             na.flManagedStop && !na.flOfVV && ManagesStopWithOffVv ||
                             na.flManagedStop && (StopAuto || RepeatedStop);
            var flNotBlockStop = ManageStop && !(na.AlreadyStopped || na.AlreadyStopped2) || (ManagesStopWithOffVv || StopAuto || RepeatedStop) && !na.AlreadyStopped2;

            if (flCanStop && flNeedStop && flNotBlockStop)
            {
                if (na.MainState == NaState.Vkl || na.MainState == NaState.Pusk || BBOn && (StopAuto || ManagesStopWithOffVv || RepeatedStop) && !(na.ActvTaskMpna == 1 && !na.flManagedStop) || na.StopNoCmd > StopNoCmdState.None && na.StateAlarm)
                {
                    Messenger.Send(59);  /* ОП. КОМАНДА ОТКЛЮЧИТЬ АВТОМАТИЧЕСКИ */
                }

                na.flOfVV = false;
                na.flManagedStop = false;

                if (RepeatedStop)
                {
                    na.flag_PovtorOtkl = true;
                    na.flOfVV = true;
                    na.ActvTaskMpna = 1;
                    na.TaskStepMpna = 1;
                    flStopByCmd = true;
                }
                else if (StopAuto)
                {
                    na.ActvTaskMpna = 1;
                    na.TaskStepMpna = 1;
                    flStopByCmd = true;
                }
                else if (ManagesStopWithOffVv)
                {
                    na.flOfVV = true;
                    na.flManagedStop = true;
                    na.ActvTaskMpna = 1;
                    na.TaskStepMpna = 1;
                    flStopByCmd = true;
                }
                else if (ManageStop)
                {
                    na.flManagedStop = true;
                    na.ActvTaskMpna = 1;
                    na.TaskStepMpna = 1;
                    flStopByCmd = true;
                }
            }
            else if (StopElectric && (na.StopNoCmd > StopNoCmdState.None || !InternalTimers[29].IsStarted))
            {//яннп
                if (na.ActvTaskMpna != 1 && (!BBOff && na.BBOn_Prev || na.StopNoCmd > StopNoCmdState.None))
                {
                    na.ActvTaskMpna = 1;
                    na.TaskStepMpna = 1;
                    flStopByCmd = true;
                }
            }
            else
            {
                if (!(StopAuto || ManagesStopWithOffVv)) { na.AlreadyStopped2 = false; }
                if (!(ManageStop || ManagesStopWithOffVv)) { na.AlreadyStopped = false; }

                if (na.ActvTaskMpna == 0)
                {
                    if (!ManagesStopWithOffVv) { na.flOfVV = false; }
                    if (!ManageStop) { na.flManagedStop = false; }
                    if (!RepeatedStop) { na.flag_PovtorOtkl = false; }
                }

            }
            /*Схема 11.26. Принятие команд на автоматическое отключение НА*/





            /* --------------------------------------------------------- контроль работающего агрегата --------------------------------------------------------- */
            if (na.ActvTaskMpna == 0 && na.MainState == NaState.Vkl && ChRP_In.Dist)
            {
                if (na.flPumpOff && !na.SimAgr)
                {
                    if (!na.StartNoCmd && !(na.StopNoCmd > StopNoCmdState.None))
                    {
                        Messenger.Send(154);  /* ОП. МНА ОТКЛЮЧИЛСЯ ПО НЕУСТАНОВЛЕННОЙ ПРИЧИНЕ */
                        InternalTimers[28].Start();
                        na.StopNoCmd = StopNoCmdState.Phase1;
                        if (!InternalTimers[28].IsStarted)
                        {
                            InternalTimers[28].Start();
                        }
                    }
                    else if (na.StartNoCmd)
                    {
                        Messenger.Send(154);  /* ОП. МНА ОТКЛЮЧИЛСЯ ПО НЕУСТАНОВЛЕННОЙ ПРИЧИНЕ */
                        na.StartNoCmd = false;
                    }
                    na.MainState = NaState.Otkl;
                }
            }

            if (na.StopNoCmd == StopNoCmdState.Phase1 && !InternalTimers[28].IsStarted)
            {
                na.StopNoCmd = StopNoCmdState.Phase2;
            }
            else if (na.StopNoCmd == StopNoCmdState.None)
            {
                InternalTimers[28].Stop();
            }/*Схема 11.27. Алгоритм определения несанкционированной остановки*/

            /* --------------------------------------------------------- контроль отключенного агрегата --------------------------------------------------------- */
            if (na.MainState == NaState.Otkl && (ChRP_In.Dist || !ChRP_Out.GrantMestCmd))
            {
                if (PumpCur && !na.SimAgr)
                {
                    if (!na.StartNoCmd && !(na.StopNoCmd > StopNoCmdState.None) && (na.ActvTaskMpna != 1 || StopElectric))
                    {
                        na.StartNoCmd = true;
                        Messenger.Send(155);      /* ОП. МНА ВКЛЮЧИЛСЯ ПО НЕУСТАНОВЛЕННОЙ ПРИЧИНЕ */
                    }
                    else if (na.StopNoCmd > StopNoCmdState.None)
                    {
                        na.StopNoCmd = StopNoCmdState.None;
                        InternalTimers[28].Stop();
                        Messenger.Send(155);  /* ОП. МНА ВКЛЮЧИЛСЯ ПО НЕУСТАНОВЛЕННОЙ ПРИЧИНЕ */
                    }
                    na.MainState = NaState.Vkl;
                    na.AlreadyStopped = false;
                    na.AlreadyStopped2 = false;
                    na.flPumpOn = true;
                    na.flPumpOff = false;
                }
            }


            /*сброс флага StartNoCmd, если агрегат однозначно отключен*/
            if (na.MainState == NaState.Otkl && !PumpCur)
            {
                na.StartNoCmd = false;
            }



            /*
             * Команды на остановку
             */
            var StopAccepted = false;
            if (StopTmCmd && !na.StopTM_Prev)
            {
                StopAccepted = true;
                Messenger.Send(73);/* ОП. КОМАНДА - ОТКЛЮЧИТЬ ПО ТМ */
            }
            na.StopTM_Prev = StopTmCmd;

            if (Cmd == NaCmd.STOP)
            {
                StopAccepted = true;
                Messenger.Send(72);/* ОП. КОМАНДА - ОТКЛЮЧИТЬ С АРМ */
            }

            if (StopCspaCmd && !na.StopCSPA_Prev)
            {
                StopAccepted = true;
                Messenger.Send(161);/* ОП. КОМАНДА - ОТКЛЮЧИТЬ ОТ ЦСПА */
            }
            na.StopCSPA_Prev = StopCspaCmd;

            if (StopAccepted)
            {
                na.StopErr = false;
                na.StartErr = false;
                na.StartErr2 = false;
                if (na.MainState == NaState.Otkl)
                {
                    Messenger.Send(100); /* ОП. ОСТАНОВЛЕН. КОМАНДА НЕ ТРЕБУЕТСЯ */
                }
                else if (na.MainState == NaState.Ostanov && na.ActvTaskMpna == 1)
                {
                    Messenger.Send(102); /* ОП. ОСТАНАВЛИВАЕТСЯ. КОМАНДА НЕ ТРЕБУЕТСЯ */
                }
                else
                {
                    na.flOfVV = false;
                    flStopByCmd = true;
                    na.flManagedStop = true;
                    na.ActvTaskMpna = 1;
                    na.TaskStepMpna = 1;
                }
            }

            /*
             * Команды на запуск
             */
            if (StartRez && na.ActvTaskMpna == 0)
            {
                na.ActvTaskMpna = 2;
                na.TaskStepMpna = 1;
                Messenger.Send(56);  /* ОП. ВКЛЮЧЕНИЕ РЕЗЕРВА */
            }
            if (StartAuto && na.ActvTaskMpna == 0)
            {
                na.ActvTaskMpna = 2;
                na.TaskStepMpna = 1;
                Messenger.Send(104);  /* ОП. АВТОМАТИЧЕСКОЕ ВКЛЮЧЕНИЕ */
            }

            var startAccepted = false;
            if (PuskTmCmd && !na.PuskTM_Prev)
            {
                startAccepted = true;
                Messenger.Send(71); /* ОП. КОМАНДА - ЗАПУСК ПО ТМ */
                if (na.Mode != NaMode.Tm)
                {
                    startAccepted = false;
                    Messenger.Send(31);
                } /* ОП. ПУСК НЕВОЗМОЖЕН. РЕЖИМ ТМ НЕ ВЫБРАН */

                if (!ChRP_In.Dist)
                {
                    startAccepted = false;
                    Messenger.Send(145);
                } /* ОП. ПУСК НЕВОЗМОЖЕН. ЧРП НЕ В ДИСТАНЦИОННОМ РЕЖИМЕ УПРАВЛЕНИЯ */
            }

            na.PuskTM_Prev = PuskTmCmd;
            if (Cmd == NaCmd.PUSK)
            {
                startAccepted = true;
                Messenger.Send(70); /* ОП. КОМАНДА - ЗАПУСК С АРМ */
                if (na.Mode != NaMode.Osn)
                {
                    startAccepted = false;
                    Messenger.Send(30); /* ОП. ПУСК НЕВОЗМОЖЕН. РЕЖИМ ОСН НЕ ВЫБРАН */
                }

                if (!(ChRP_In.Dist || na.SimAgr))
                {
                    startAccepted = false;
                    Messenger.Send(145); /* ОП. ПУСК НЕВОЗМОЖЕН. ЧРП НЕ В ДИСТАНЦИОННОМ РЕЖИМЕ УПРАВЛЕНИЯ */
                }

            }

            if (startAccepted)
            {
                if (na.MainState == NaState.Vkl)
                {
                    Messenger.Send(101); /* ОП. В РАБОТЕ. КОМАНДА НЕ ТРЕБУЕТСЯ */
                }
                else if (na.MainState == NaState.Pusk)
                {
                    Messenger.Send(103); /* ОП. ЗАПУСКАЕТСЯ. КОМАНДА НЕ ТРЕБУЕТСЯ */
                }
                else if (na.MainState == NaState.Ostanov || na.StopNoCmd == StopNoCmdState.Phase1)
                {
                    Messenger.Send(102); /* ОП. ОСТАНАВЛИВАЕТСЯ. КОМАНДА НЕ ТРЕБУЕТСЯ */
                }
                else if (na.ActvTaskMpna != 0)
                {
                    Messenger.Send(162); /* ОП. ПУСК НЕВОЗМОЖЕН. АГРЕГАТ НЕ ОСТАНОВЛЕН */
                }
                else if (!ReadyToStart)
                {
                    Messenger.Send(29); /* ОП. ПУСК НЕВОЗМОЖЕН. АГРЕГАТ НЕ ГОТОВ К ПУСКУ */
                }
                else
                {
                    na.ActvTaskMpna = 2;
                    na.TaskStepMpna = 1;
                }
            }

            /*
             * Смена режимов
             */

            var SetOsnAuto = AutoOsn;
            if (!ChRP_In.Dist && (na.Mode == NaMode.Rez || na.Mode == NaMode.Tm))
            {
                SetOsnAuto = true;
            }

            if (na.Mode == NaMode.Tm && !NpsDist)
            {
                SetOsnAuto = true;
            }

            if (na.Mode == NaMode.Rez && NoOsnForRez)
            {
                SetOsnAuto = true;
            }

            flTmp1 = false;
            if (SetOsnAuto && na.Mode != NaMode.Osn)
            {
                flTmp1 = true; Messenger.Send(77);     /* ОП. КОМАНДА - НАЗНАЧИТЬ РЕЖИМ ОСНОВНОЙ АВТОМАТИЧЕСКИ */
            }
            else if (Cmd == NaCmd.SET_OSN)
            {
                flTmp1 = true; Messenger.Send(76);     /* ОП. КОМАНДА - НАЗНАЧИТЬ РЕЖИМ ОСНОВНОЙ С АРМ */
            }
            else if (Cmd == NaCmd.SET_TM)
            {
                flTmp1 = true; Messenger.Send(78);     /* ОП. КОМАНДА - НАЗНАЧИТЬ РЕЖИМ ТЕЛЕМЕХАНИЧЕСКИЙ С АРМ */
            }
            else if (Cmd == NaCmd.SET_REZ)
            {
                flTmp1 = true; Messenger.Send(79);     /* ОП. КОМАНДА - НАЗНАЧИТЬ РЕЖИМ РЕЗЕРВНЫЙ С АРМ */
            }
            else if (Cmd == NaCmd.SET_REM)
            {
                flTmp1 = true; Messenger.Send(80);     /* ОП. КОМАНДА - НАЗНАЧИТЬ РЕЖИМ РЕМОНТНЫЙ С АРМ */
            }
            else if (Cmd == NaCmd.SET_SIM)
            {
                flTmp1 = true; Messenger.Send(81);     /* ОП. КОМАНДА - НАЗНАЧИТЬ РЕЖИМ ИМИТАЦИИ С АРМ */
            }
            else if (Cmd == NaCmd.UNSET_SIM)
            {
                flTmp1 = true; Messenger.Send(82);     /* ОП. КОМАНДА - СНЯТЬ РЕЖИМ ИМИТАЦИИ С АРМ */
            }
            if (flTmp1)
            {
                if (Cmd == NaCmd.SET_SIM)
                {/* 12 - команда оператора на установку имитационного режима работы НА */
                    if (na.MainState == NaState.Otkl)
                    {
                        Messenger.Send(46); na.SimAgr = true;  /* ОП. НАЗНАЧЕН РЕЖИМ ИМИТАЦИИ */
                    }
                    else
                    {
                        Messenger.Send(50);               /* ОП. НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. АГРЕГАТ НЕ ОСТАНОВЛЕН */
                    }

                }
                else if (Cmd == NaCmd.UNSET_SIM)
                {/* 13 - команда оператора на снятие имитационного режима работы НА */
                    if (na.MainState == NaState.Otkl)
                    {
                        Messenger.Send(47); na.SimAgr = false;  /* ОП. РЕЖИМ ИМИТАЦИИ СНЯТ */
                    }
                    else
                    {
                        Messenger.Send(50);               /* ОП. НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. АГРЕГАТ НЕ ОСТАНОВЛЕН */
                    }
                    /*Схема 11.32. Алгоритм принятия команд на установку режима управления НА. Окончание*/

                }
                else if (Cmd == NaCmd.SET_OSN || SetOsnAuto)
                {/* case 7:8 - команды на установку режима НА "ОСНОВНОЙ" */
                    if (na.Mode == NaMode.Osn)
                    {
                        Messenger.Send(48);  /* ОП. НАЗНАЧЕНИЕ НЕ ТРЕБУЕТСЯ. РЕЖИМ УЖЕ НАЗНАЧЕН */
                    }
                    else
                    {
                        na.Mode = NaMode.Osn;
                        Messenger.Send(42);  /* ОП. НАЗНАЧЕН РЕЖИМ ОСНОВНОЙ */
                    }
                    /*Схема 11.33. Алгоритм назначения режима «основной»*/

                }
                else if (Cmd == NaCmd.SET_TM)
                {
                    /* 9 - команда оператора на установку режима НА "ТЕЛЕМЕХАНИЧЕСКИЙ" */
                    if (na.Mode == NaMode.Tm)
                    {
                        Messenger.Send(48); /* ОП. НАЗНАЧЕНИЕ НЕ ТРЕБУЕТСЯ. РЕЖИМ УЖЕ НАЗНАЧЕН */
                    }
                    else if (!ChRP_In.Dist)
                    {
                        Messenger.Send(159); /* ОП. НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. АГРЕГАТ НЕ В ДИСТАНЦИОННОМ РЕЖИМЕ УПРАВЛЕНИЯ */
                    }
                    else if (!NpsDist)
                    {
                        Messenger.Send(49); /* ОП. НАЗНАЧЕНИЕ РЕЖИМА ТМ НЕВОЗМОЖНО. СТАНЦИЯ В МЕСТНОМ РЕЖИМЕ УПРАВЛЕНИЯ */
                    }
                    else
                    {
                        na.Mode = NaMode.Tm;
                        Messenger.Send(43); /* ОП. НАЗНАЧЕН РЕЖИМ ТЕЛЕМЕХАНИЧЕСКИЙ */
                    }
                }
                else if (Cmd == NaCmd.SET_REZ)
                {
                    /*    10 - команда оператора на установку режима НА "РЕЗЕРВНЫЙ"   */
                    if (na.Mode == NaMode.Rez)
                    {
                        Messenger.Send(48); /* ОП. НАЗНАЧЕНИЕ НЕ ТРЕБУЕТСЯ. РЕЖИМ УЖЕ НАЗНАЧЕН */
                    }
                    else if (!ChRP_In.Dist)
                    {
                        Messenger.Send(159); /* ОП. НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. АГРЕГАТ НЕ В ДИСТАНЦИОННОМ РЕЖИМЕ УПРАВЛЕНИЯ */
                    }
                    else
                    {
                        flTmp = ZpState == ZdState.Opened;
                        flTmp1 = ZvState == ZdState.Opened;
                        flTmp2 = na.MainState == NaState.Otkl && na.StopNoCmd != StopNoCmdState.Phase1;
                        if (!flTmp || !flTmp1 || !flTmp2)
                        {
                            if (!flTmp)
                            {
                                Messenger.Send(51); /* ОП. НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ПРИЕМНАЯ ЗАДВИЖКА НЕ ОТКРЫТА */
                            }

                            /*Схема 11.35. Алгоритм назначения ражима «резервный»*/
                            if (!flTmp1)
                            {
                                Messenger.Send(52); /* ОП. НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ВЫХОДНАЯ ЗАДВИЖКА НЕ ОТКРЫТА */
                            }

                            if (!flTmp2)
                            {
                                Messenger.Send(50); /* ОП. НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. АГРЕГАТ НЕ ОСТАНОВЛЕН */
                            }
                        }
                        else if (DoRez)
                        {
                            na.Mode = NaMode.Rez;
                            Messenger.Send(44); /* ОП. НАЗНАЧЕН РЕЖИМ РЕЗЕРВНЫЙ */
                        }
                        else if (RezExist)
                        {
                            Messenger.Send(54); /* ОП. НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. В ПЛЕЧЕ УЖЕ ИМЕЕТСЯ МНА В РЕЖИМЕ РЕЗ */
                        }
                        else if (NoOsnForRez)
                        {
                            Messenger.Send(55); /* ОП. НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. НЕТ АГРЕГАТОВ В РЕЖИМЕ ОСН ИЛИ ТМ */
                        }

                    }
                }
                else if (Cmd == NaCmd.SET_REM)
                {
                    /*    11 - команда оператора на установку режима НА "РЕМОНТ"  */
                    if (na.Mode == NaMode.Rem)
                    {
                        Messenger.Send(48); /* ОП. НАЗНАЧЕНИЕ НЕ ТРЕБУЕТСЯ. РЕЖИМ УЖЕ НАЗНАЧЕН */
                    }
                    else if (na.MainState != NaState.Otkl)
                    {
                        Messenger.Send(50); /* ОП. НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. АГРЕГАТ НЕ ОСТАНОВЛЕН */
                    }
                    else
                    {
                        na.Mode = NaMode.Rem;
                        na.flOfVV = true;
                        na.ActvTaskMpna = 1;
                        na.TaskStepMpna = 4;
                        Messenger.Send(45); /* ОП. НАЗНАЧЕН РЕЖИМ РЕМОНТНЫЙ */
                    }
                }

            }
            /*Схема 11.37. Алгоритм назначения режима «ремонтный»*/

            /* обработка вкл/откл контроля по току */
            if (TokControl ^ na.UseCTPrev)
            {
                if (TokControl)
                {
                    Messenger.Send(94);         /* ОП. КОМАНДА - УСТАНОВИТЬ КОНТРОЛЬ ТОКА */
                    Messenger.Send(66);         /* ОП. КОНТРОЛЬ ТОКА УСТАНОВЛЕН */
                }
                else
                {
                    Messenger.Send(95);         /* ОП. КОМАНДА - СНЯТЬ КОНТРОЛЬ ТОКА */
                    Messenger.Send(67);         /* ОП. КОНТРОЛЬ ТОКА СНЯТ */
                }
                na.UseCTPrev = TokControl;
            }
            /*Схема 11.38. Алгоритм назначения интервала подач*/





            /* -------------------------------------------------------------------- Останов агрегата -------------------------------------------------------------------- */
            if (na.ActvTaskMpna == 1)
            {

                if (na.TaskStepMpna == 1)
                {
                    na.PrepareFail = false;
                    if (na.SimAgr)
                    {
                        na.MainState = NaState.Ostanov;
                        na.SubState = 0;
                        na.BlockMsgState = true;
                        Messenger.Send(26);  /* ОП. ИДЕТ ПРОГРАММНАЯ ОСТАНОВКА */
                        Messenger.Send(64);  /* ОП. АГРЕГАТ ОТКЛЮЧЕН В РЕЖИМЕ ИМИТАЦИИ */
                        na.TaskStepMpna = 6;
                        na.HIGHVIB = false;
                        na.HIGHVIBNas = false;
                        na.AlreadyStopped = true;
                        na.AlreadyStopped2 = true;
                    }
                    else
                    {
                        if (na.MainState == NaState.Pusk)
                        {
                            Messenger.Send(21);  /* ОП. ПРОЦЕСС ЗАПУСКА ОТМЕНЕН */
                        }
                        na.SubState = NaSubstate.Po;

                        flTmp = !na.flag_PovtorOtkl && (na.MainState == NaState.Vkl || na.MainState == NaState.Pusk || na.StopNoCmd > StopNoCmdState.None || BBOn && (!na.flManagedStop || na.flOfVV));
                        if (flTmp)
                        {
                            if (na.flManagedStop)
                            {
                                Messenger.Send(115);  /* ОП. ИДЕТ УПРАВЛЯЕМАЯ ОСТАНОВКА */
                            }
                            else
                            {
                                Messenger.Send(116);  /* ОП. ИДЕТ НЕУПРАВЛЯЕМАЯ ОСТАНОВКА */
                            }
                            //IF StopNoCmd==StopNoCmdState.None || na.StateAlarm || StateAlarm_ChRP THEN
                            na.MainState = NaState.Ostanov;
                            //}
                        }

                        if (!ChRP_In.Dist && na.flManagedStop && !flStopByCmd)
                        {
                            na.TaskStepMpna = 3;
                            InternalTimers[17].Start();
                        }
                        else
                        {
                            na.TaskStepMpna = 2;
                            InternalTimers[16].Start();
                        }
                    }
                    /*Схема 11.39. Алгоритм остановки. Анализ состояния НА*/

                    na.StopErr = false;
                    na.StartErr = false;
                    na.StartErr2 = false;
                    na.StopNoCmd = StopNoCmdState.None;
                    InternalTimers[28].Stop();
                    na.StartNoCmd = false;

                    InternalTimers[11].Stop();
                    InternalTimers[27].Stop();
                    na.BlockMsgTok = !vv.Tok && TokControl || na.Pump_Prog_Ndv.Tok;
                    na.BlockMsgVv = BBOff;
                    na.BlockMsgCurFreq = !(ChRP_In.CurFreq > MinWorkFreq);
                    na.BlockMsgSpinFwd = !ChRP_In.SpinForward;
                    if (na.flManagedStop)
                    {
                        na.BlockMsgState = na.flPumpOff;
                    }
                    else
                    {
                        na.BlockMsgState = BBOff;
                    }
                }


                if (na.TaskStepMpna == 2)
                {
                    if (ChRP_In.Dist && ChRP_In.TaskFreq > MinWorkFreq && !SpinStopCmd)
                    {
                        SpinStopCmd = true;
                        Messenger.Send(131);  /* ОП. КОМАНДА - СНИЗИТЬ ЧАСТОТУ ВРАЩЕНИЯ ВАЛА ЭД ДО НУЛЯ */
                    }

                    if (ChRP_Out.StartDistCmd)
                    {
                        ChRP_Out.StartDistCmd = false;
                        Messenger.Send(132);  /* ОП. КОМАНДА - СТОП В ЧРП */
                    }

                    if (ChRP_Out.GrantMestCmd)
                    {
                        ChRP_Out.GrantMestCmd = false;
                        Messenger.Send(133);  /* ОП. РАЗРЕШЕНИЕ ЧРП НА ПУСК ДВИГАТЕЛЯ В МЕСТНОМ РЕЖИМЕ УПРАВЛЕНИЯ СНЯТО */
                    }

                    if (na.flManagedStop)
                    {
                        na.TaskStepMpna = 3;
                        InternalTimers[16].Stop();
                        InternalTimers[17].Start();
                    }
                    else
                    {
                        if (!InternalTimers[16].IsStarted)
                        {
                            na.TaskStepMpna = 4;
                        }
                    }
                }
                /*Схема 11.40. Алгоритм остановки. Выдача команд остановки*/


                if (na.TaskStepMpna == 3)
                {
                    /*снижение частоты*/
                    if (InternalTimers[17].IsQ || InternalTimers[17].IsStarted && ChRP_In.CurFreq <= MinWorkFreq)
                    {
                        InternalTimers[17].Stop();
                        InternalTimers[18].Start();
                    }
                    /*снижение тока*/
                    if (InternalTimers[18].IsStarted && (!vv.Tok && ChRP_In.CurFreq <= MinWorkFreq || !TokControl))
                    {
                        if (!na.BlockMsgTok)
                        {
                            if (TokControl)
                            {
                                Messenger.Send(7);  /* ОП. ТОК СБРОШЕН */
                            }
                            else
                            {
                                Messenger.Send(60);  /* ОП. КОНТРОЛЬ ПО ТОКУ НЕ ВЕДЁТСЯ */
                            }
                            na.BlockMsgTok = true;
                        }
                        InternalTimers[18].Stop();
                        InternalTimers[19].Start();
                    }
                    if (InternalTimers[18].IsQ)
                    {
                        InternalTimers[18].Stop();
                        InternalTimers[19].Start();
                    }
                    /*Схема 11.41. Алгоритм остановки. Контроль состояния НА*/
                    /*вращение вперед*/
                    if (!ChRP_In.SpinForward && !(TokControl && vv.Tok) && ChRP_In.CurFreq <= MinWorkFreq && InternalTimers[19].IsStarted)
                    {
                        if (!na.BlockMsgTok)
                        {
                            if (TokControl)
                            {
                                Messenger.Send(7);  /* ОП. ТОК СБРОШЕН */
                            }
                            na.BlockMsgTok = true;
                        }
                        InternalTimers[19].Stop();
                    }
                    //что-то пошло не так..
                    if (InternalTimers[19].IsQ)
                    {
                        if (!na.BlockMsgCurFreq)
                        {
                            if (ChRP_In.CurFreq > MinWorkFreq) { Messenger.Send(112); }    /* ОП. ЧАСТОТА ВРАЩЕНИЯ ВАЛА ЭД НЕ СНИЖЕНА ДО 30 ОБ/МИН */
                            na.BlockMsgCurFreq = true;
                        }
                        /*Схема 11.42 Алгоритм остановки. Контроль состояния НА. Часть 2*/
                        if (!na.BlockMsgTok)
                        {
                            if (TokControl)
                            {
                                if (!vv.Tok)
                                {
                                    Messenger.Send(7);           /* ОП. ТОК СБРОШЕН */
                                }
                                else
                                {
                                    Messenger.Send(57);           /* ОП. ТОК НЕ СБРОШЕН */
                                }
                            }
                            else if (!na.BlockMsgState)
                            {
                                Messenger.Send(60);           /* ОП. КОНТРОЛЬ ПО ТОКУ НЕ ВЕДЁТСЯ */
                            }
                            na.BlockMsgTok = true;
                        }
                        if (!na.BlockMsgSpinFwd)
                        {
                            if (ChRP_In.SpinForward)
                            {
                                Messenger.Send(113);
                            }  /* ОП. СИГНАЛ ОТ ЧРП "ВРАЩЕНИЕ ВПЕРЕД" НЕ СБРОШЕН */
                            na.BlockMsgSpinFwd = true;
                        }
                        if (!ChRP_In.Dist)
                        {
                            na.StopErr = true;
                            Messenger.Send(58);  /* ОП. НЕ ПОЛУЧЕНО СОСТОЯНИЕ "ОСТАНОВЛЕН" ЗА ЗАДАННОЕ ВРЕМЯ *///!!!добавил сообщение
                        }
                        else
                        {
                            na.PumpJudgementNeed = true;
                            na.PumpNdvVoteDynamics = true;
                        }
                    }

                    if (!InternalTimers[17].IsStarted && !InternalTimers[18].IsStarted && !InternalTimers[19].IsStarted && !na.PumpJudgementNeed)
                    {
                        if (na.flPumpOn)
                        {
                            na.StopErr = true;
                            Messenger.Send(58);  /* ОП. НЕ ПОЛУЧЕНО СОСТОЯНИЕ "ОСТАНОВЛЕН" ЗА ЗАДАННОЕ ВРЕМЯ */
                        }
                        if (!na.StopErr)
                        {
                            na.TaskStepMpna = 6;
                            na.AlreadyStopped = true;
                        }
                        else
                        {
                            na.TaskStepMpna = 7;
                        }
                        SpinStopCmd = false;
                    }
                }
                /*Схема 11.43. Алгоритм остановки. Контроль состояния НА. Окончание*/


                if (na.TaskStepMpna == 4)
                {
                    if (ChRP_Out.PrepareCmd || BBOn)
                    {
                        na.StopWork = true;
                        if (ChRP_Out.PrepareCmd)
                        {
                            ChRP_Out.PrepareCmd = false;
                            Messenger.Send(114);   /* ОП. ОТМЕНИТЬ ПОДГОТОВКУ ЧРП К ПУСКУ */
                        }
                        Messenger.Send(17);        /* ОП. КОМАНДА - ОТКЛЮЧИТЬ ВВ АВТОМАТИЧЕСКИ */
                    }
                    InternalTimers[11].Start();
                    na.TaskStepMpna = 5;
                }
                /*Схема 11.44. Алгоритм остановки. Выдача команды отключения ВВ НА*/


                if (na.TaskStepMpna == 5)
                {
                    if (BBOff && InternalTimers[11].IsStarted)
                    {
                        InternalTimers[11].Stop();
                        na.StopWork = false;
                        if (!na.BlockMsgVv)
                        {
                            Messenger.Send(18);   /* ОП. ВВ ОТКЛЮЧЕН */
                        }
                        if (TokControl)
                        {
                            if (na.flManagedStop)
                            {
                                na.TaskStepMpna = 6;
                            }
                            else
                            {
                                InternalTimers[12].Start();
                            }
                        }
                        else
                        {
                            na.TaskStepMpna = 6;
                            //na.BlockMsgTok = true;
                            na.StopErr2 = false;
                        }
                        na.BlockMsgVv = true;
                    }
                    //ВВ не отключился
                    if (InternalTimers[11].IsQ)
                    {
                        if (TokControl && !na.flManagedStop)
                        {
                            InternalTimers[12].Start();
                        }
                        else
                        {
                            na.BlockMsgVv = true;
                            if (BBOn)
                            {
                                Messenger.Send(22);  /* ОП. ВВ НЕ ОТКЛЮЧИЛСЯ */
                            }
                            else
                            {
                                Messenger.Send(18);  /* ОП. ВВ ОТКЛЮЧИЛСЯ */
                            }
                            if (!na.flManagedStop && !na.BlockMsgTok)
                            {
                                Messenger.Send(60);  /* ОП. КОНТРОЛЬ ПО ТОКУ НЕ ВЕДЁТСЯ */
                                na.BlockMsgTok = true;
                            }
                            na.StopErr2 = true;
                        }
                        InternalTimers[11].Stop();
                    }
                    /*Схема 11.45. Алгоритм остановки. Контроль параметров ВВ НА*/

                    if (InternalTimers[12].IsStarted && BBOff && !(vv.Tok && TokControl))
                    {
                        if (!na.BlockMsgVv)
                        {
                            Messenger.Send(18);  /* ОП. ВВ ОТКЛЮЧЕН */
                        }
                        if (!na.BlockMsgTok)
                        {
                            Messenger.Send(7);  /* ОП. ТОК СБРОШЕН */
                        }
                        InternalTimers[12].Stop();
                        na.StopErr2 = false;
                    }

                    if (InternalTimers[12].IsQ)
                    {
                        if (!BBOff)
                        {
                            na.StopErr2 = true;
                        }
                        if (!na.BlockMsgVv)
                        {
                            if (BBOff)
                            {
                                Messenger.Send(18);  /* ОП. ВВ ОТКЛЮЧЕН */
                            }
                            else
                            {
                                Messenger.Send(22);  /* ОП. ВВ НЕ ОТКЛЮЧИЛСЯ */
                            }
                        }
                        if (vv.Tok && TokControl && !na.BlockMsgTok)
                        {
                            Messenger.Send(57);       /* ОП. ТОК НЕ СБРОШЕН */
                            if (BBOff && !na.Pump_Prog_Ndv.Tok && vv.Tok)
                            {
                                Messenger.Send(5);    /* ОП. ЗНАЧЕНИЕ СИЛЫ ТОКА НЕДОСТОВЕРНО */
                                na.Pump_Prog_Ndv.Tok = true;
                                na.StateAlarmChrp = true;
                            }
                        }
                        else
                        {
                            if (!na.BlockMsgTok && TokControl)
                            {
                                Messenger.Send(7);    /* ОП. ТОК СБРОШЕН */
                            }
                        }
                        InternalTimers[12].Stop();
                    }
                    /*Схема 11.46. Алгоритм остановки. Контроль параметров ВВ НА. Часть 2*/

                    if (!InternalTimers[11].IsStarted && !InternalTimers[12].IsStarted)
                    {
                        if (!na.StopErr2)
                        {
                            na.SubState = 0;
                            na.AlreadyStopped2 = true;
                            if (!na.flManagedStop)
                            {
                                InternalTimers[27].Start();
                            }
                            if (na.flOfVV)
                            {
                                na.flOfVV = false;
                                na.flManagedStop = false;
                                na.flag_PovtorOtkl = false;
                            }
                            na.TaskStepMpna = 6;
                        }
                        else
                        {
                            if (na.flag_PovtorOtkl)
                            {
                                InternalTimers[10].Start();
                            }
                            else if (!na.flOfVV)
                            {
                                if (PumpCur)
                                {
                                    na.MainState = NaState.Vkl;
                                    na.SubState = NaSubstate.None;
                                }
                                Messenger.Send(58); /* ОП. НЕ ПОЛУЧЕНО СОСТОЯНИЕ "ОСТАНОВЛЕН" ЗА ЗАДАННОЕ ВРЕМЯ */
                            }
                            na.TaskStepMpna = 8;
                        }
                    }
                }
                /*Схема 11.47. Алгоритм остановки. Контроль параметров ВВ НА. Окончание*/


                if (na.TaskStepMpna == 6)
                {
                    na.SubState = NaSubstate.None;
                    na.StopErr2 = false;
                    na.ZPBlocks = NaZdBlocks.None;                  /* Команда на снятие запрета закрытия приемной задвижки */
                    na.ZVBlocks = NaZdBlocks.None;                  /* Команда на снятие запрета закрытия выходной задвижки */
                    na.HIGHVIB = false;
                    na.HIGHVIBNas = false;
                    if (!na.BlockMsgState)
                    {
                        if (!TokControl && !na.BlockMsgTok)
                        {
                            Messenger.Send(60);  /* ОП. КОНТРОЛЬ ПО ТОКУ НЕ ВЕДЁТСЯ */
                        }
                        na.BlockMsgState = true;
                        Messenger.Send(28);  /* ОП. ОСТАНОВЛЕН */
                    }
                    if (na.MainState != NaState.Otkl)
                    {
                        na.MainState = NaState.Otkl;
                        Messenger.Send(27);  /* ОП. ПРОГРАММНАЯ ОСТАНОВКА ЗАВЕРШЕНА */
                    }
                    if (!na.flOfVV || na.SimAgr)
                    {
                        na.ActvTaskMpna = 0;
                        na.TaskStepMpna = 0;
                        na.flManagedStop = false;
                        na.flag_PovtorOtkl = false;
                    }
                    else
                    {
                        na.TaskStepMpna = 4;
                    }
                }
                /*Схема 11.48. Алгоритм остановки. Успешное завершение*/


                if (na.TaskStepMpna == 7)
                {
                    na.ActvTaskMpna = 0;
                    na.TaskStepMpna = 0;
                    na.flOfVV = false;
                    na.flManagedStop = false;
                    na.flag_PovtorOtkl = false;
                }


                if (na.TaskStepMpna == 8)
                {
                    if (InternalTimers[10].IsQ)
                    {
                        na.TaskStepMpna = 1;
                    }
                    else if (!InternalTimers[10].IsStarted)
                    {
                        na.ActvTaskMpna = 0;
                        na.TaskStepMpna = 0;
                    }
                    na.flManagedStop = false;
                    na.flOfVV = false;
                }

            }
            /*Схема 11.49. Алгоритм остановки. Обработка ошибок*/





            /* ---------------------------------------------------------------------- Запуск агрегата ---------------------------------------------------------------------- */
            if (na.ActvTaskMpna == 2)
            {

                if (na.TaskStepMpna == 1)
                {
                    na.StopWork = false;
                    SpinStopCmd = false;
                    na.PrepareFail = false;
                    na.StopNoCmd = StopNoCmdState.None;
                    InternalTimers[10].Stop();
                    InternalTimers[11].Stop();
                    InternalTimers[12].Stop();
                    InternalTimers[16].Stop();
                    InternalTimers[17].Stop();
                    InternalTimers[18].Stop();
                    InternalTimers[27].Stop();
                    InternalTimers[28].Stop();
                    na.BlockMsgVv = BBOn;
                    na.BlockMsgTok = TokControl && vv.Tok;
                    na.BlockMsgCurFreq = ChRP_In.CurFreq > MinWorkFreq;
                    na.BlockMsgSpinFwd = ChRP_In.SpinForward;
                    na.BlockMsgState = false;
                    if (StartRez)
                    {
                        na.TaskStepMpna = 2;
                    }
                    else
                    {
                        na.TaskStepMpna = 3;
                    }
                }


                /* Запуск резервного агрегата */
                if (na.TaskStepMpna == 2)
                {
                    if (na.Mode == NaMode.Rez)
                    {
                        if (ReadyToStart)
                        {
                            na.Mode = NaMode.Osn;
                            Messenger.Send(42);  /* ОП. НАЗНАЧЕН РЕЖИМ ОСНОВНОЙ */
                            Messenger.Send(23);  /* ОП. ИДЕТ ПРОГРАММНЫЙ ПУСК */
                            na.SubState = NaSubstate.Pp;
                            /*Схема 11.50. Алгоритм пуска. Анализ состояния НА*/
                            if (na.SimAgr)
                            {
                                na.MainState = NaState.Vkl;
                                Messenger.Send(65);  /* ОП. В РАБОТЕ В РЕЖИМЕ ИМИТАЦИИ */
                                na.TaskStepMpna = 6;
                                na.HIGHVIB = true;
                                na.HIGHVIBNas = true;
                                na.SubState = 0;
                            }
                            else
                            {
                                ChRP_Out.StartDistCmd = true;
                                na.flChRP_PuskCmd = true;
                                na.MainState = NaState.Pusk;
                                na.HIGHVIB = true;
                                na.HIGHVIBNas = true;
                                InternalTimers[7].Start();
                                na.TaskStepMpna = 4;
                                Messenger.Send(134);  /* ОП. КОМАНДА - ПУСК В ЧРП */
                            }
                        }
                        else
                        {
                            Messenger.Send(29);  /* ОП. ПУСК НЕВОЗМОЖЕН. АГРЕГАТ НЕ ГОТОВ К ПУСКУ */
                            na.TaskStepMpna = 6;
                        }
                    }
                    else
                    {
                        na.TaskStepMpna = 6;
                    }
                }
                /*Схема 11.51. Алгоритм пуска. АВР*/


                /* Запуск агрегата в основном или ТУ */
                if (na.TaskStepMpna == 3)
                {
                    if (ReadyToStart)
                    {
                        if (na.SimAgr)
                        {
                            na.MainState = NaState.Vkl;
                            na.SubState = 0;
                            Messenger.Send(23);  /* ОП. ИДЕТ ПРОГРАММНЫЙ ПУСК */
                            na.ZVBlocks = NaZdBlocks.NoClose;                        /* Установл запрет закр выкид задв */
                            na.ZPBlocks = NaZdBlocks.NoClose;
                            Messenger.Send(65);  /* ОП. В РАБОТЕ В РЕЖИМЕ ИМИТАЦИИ */
                            na.TaskStepMpna = 6;
                            na.HIGHVIB = true;
                            na.HIGHVIBNas = true;
                        }
                        else
                        {
                            Messenger.Send(23);  /* ОП. ИДЕТ ПРОГРАММНЫЙ ПУСК */
                            na.MainState = NaState.Pusk;
                            na.SubState = NaSubstate.Pp;
                            na.ZVBlocks = NaZdBlocks.NoClose;                        /* Установл запрет закр выкид задв */
                            na.ZPBlocks = NaZdBlocks.NoClose;
                            na.HIGHVIB = true;
                            na.HIGHVIBNas = true;
                            if (ChRP_In.Dist)
                            {
                                ChRP_Out.StartDistCmd = true;
                                na.flChRP_PuskCmd = true;
                                Messenger.Send(134);  /* ОП. КОМАНДА - ПУСК В ЧРП */
                            }
                            na.TaskStepMpna = 4;
                            InternalTimers[7].Start();
                        }
                    }
                    else
                    {
                        na.SubState = 0;
                        na.MainState = NaState.Otkl;
                        na.HIGHVIB = false;
                        na.HIGHVIBNas = false;
                        na.TaskStepMpna = 6;
                        Messenger.Send(29);  /* ОП. ПУСК НЕВОЗМОЖЕН. АГРЕГАТ НЕ ГОТОВ К ПУСКУ */
                    }
                }
                /*Схема 11.52. Алгоритм пуска. Выдача команд на включение НА*/


                if (na.TaskStepMpna == 4)
                {
                    if ((!TokControl || vv.Tok) && InternalTimers[7].IsStarted)
                    {
                        if (!na.BlockMsgTok)
                        {
                            if (TokControl)
                            {
                                Messenger.Send(6);  /* ОП. ТОК ДВИГАТЕЛЯ НАБРАН */
                            }
                            else
                            {
                                Messenger.Send(60);  /* ОП. КОНТРОЛЬ ПО ТОКУ НЕ ВЕДЁТСЯ */
                            }
                        }
                        na.BlockMsgTok = true;
                        InternalTimers[7].Stop();
                        InternalTimers[20].Start();
                    }
                    if (InternalTimers[7].IsQ)
                    {
                        InternalTimers[7].Stop();
                        InternalTimers[20].Start();
                    }
                    if (ChRP_In.SpinForward && (!TokControl || vv.Tok) && InternalTimers[20].IsStarted)
                    {
                        if (!na.BlockMsgTok)
                        {
                            Messenger.Send(6);  /* ОП. ТОК ДВИГАТЕЛЯ НАБРАН */
                            na.BlockMsgTok = true;
                        }
                        InternalTimers[20].Stop();
                        InternalTimers[21].Start();
                    }
                    /*Схема 11.53. Алгоритм пуска. Контроль параметров НА.*/
                    if (InternalTimers[20].IsQ)
                    {
                        InternalTimers[20].Stop();
                        InternalTimers[21].Start();
                    }
                    if (ChRP_In.CurFreq > MinWorkFreq && ChRP_In.SpinForward && (!TokControl || vv.Tok) && InternalTimers[21].IsStarted)
                    {
                        if (!na.BlockMsgTok)
                        {
                            Messenger.Send(6);  /* ОП. ТОК ДВИГАТЕЛЯ НАБРАН */
                            na.BlockMsgTok = true;
                        }
                        InternalTimers[21].Stop();
                    }
                    //что-то пошло не так..
                    if (InternalTimers[21].IsQ)
                    {
                        InternalTimers[21].Stop();
                        if (ChRP_In.Dist)
                        {
                            na.PumpJudgementNeed = true;
                        }
                        else
                        {
                            na.StartErr = true;
                        }
                        /*Схема 11.54. Алгоритм пуска. Контроль параметров НА. Часть 2*/
                        if (!vv.Tok && TokControl) { na.StartErr = true; Messenger.Send(98); } /* ОП. ТОК ДВИГАТЕЛЯ НЕ НАБРАН */
                        if (!ChRP_In.SpinForward) { na.StartErr = true; Messenger.Send(119); } /* ОП. СИГНАЛ ОТ ЧРП "ВРАЩЕНИЕ ВПЕРЕД" НЕ ПОЛУЧЕН */
                        if (ChRP_In.CurFreq <= MinWorkFreq) { na.StartErr = true; Messenger.Send(120); } /* ОП. ЧАСТОТА ВРАЩЕНИЯ ВАЛА ЭД НЕ ПРЕВЫСИЛА 30 ОБ/МИН */
                    }

                    if (!InternalTimers[21].IsStarted && !InternalTimers[20].IsStarted && !InternalTimers[7].IsStarted)
                    {
                        if (na.StartErr || na.flPumpOff)
                        {
                            na.StartErr = true;
                            Messenger.Send(16);  /* ОП. НЕ ПОЛУЧЕНО СОСТОЯНИЕ "В РАБОТЕ" ЗА ЗАДАННОЕ ВРЕМЯ */
                        }
                        na.flChRP_PuskCmd = false;
                        if (na.StartErr)
                        {
                            na.TaskStepMpna = 6;
                        }
                        else
                        {
                            if (!ChRP_In.Dist)
                            {
                                na.TaskStepMpna = 6;
                                na.MainState = NaState.Vkl;
                                Messenger.Send(25);  /* ОП. В РАБОТЕ */
                            }
                            else
                            {
                                na.TaskStepMpna = 5;
                                na.MainState = NaState.Vkl;
                                InternalTimers[22].Start();
                                InternalTimers[25].Start();
                                Messenger.Send(25);  /* ОП. В РАБОТЕ */
                            }
                        }
                    }
                }
                /*Схема 11.55. Алгоритм пуска. Контроль параметров НА. Окончание*/


                if (na.TaskStepMpna == 5)
                {
                    if (!ChRP_In.Dist)
                    {
                        na.TaskStepMpna = 6;
                    }
                    else
                    {
                        if (InternalTimers[22].IsStarted && ChRP_In.CurFreq >= MinRegFreq)
                        {
                            InternalTimers[22].Stop();
                            na.TaskStepMpna = 6;
                        }
                        if (InternalTimers[22].IsQ)
                        {
                            Messenger.Send(122);  /* ОП. ЧАСТОТА ВРАЩЕНИЯ ВАЛА ЭД НЕ ПРЕВЫСИЛА МИНИМАЛЬНОЙ ЧАСТОТЫ РЕГУЛИРОВАНИЯ */
                            na.StartErr2 = true;
                            na.TaskStepMpna = 6;
                        }
                    }
                }


                if (na.TaskStepMpna == 6)
                {
                    if (!na.StartErr && !na.StartErr2)
                    {
                        if (na.flPumpOn)
                        {
                            InternalTimers[25].Start();
                        }
                        if (na.SubState == NaSubstate.Pp)
                        {
                            Messenger.Send(24);  /* ОП. ПРОГРАММНЫЙ ПУСК ЗАВЕРШЕН */
                        }
                    }

                    na.SubState = 0;
                    na.ActvTaskMpna = 0;
                    na.TaskStepMpna = 0;
                }

            }
            /*Схема 11.56. Алгоритм пуска. Окончание*/


            if (na.HIGHVIB && !InternalTimers[9].IsStarted && !InternalTimers[9].IsQ &&
                na.HIGHVIBNas && !InternalTimers[14].IsStarted && !InternalTimers[14].IsQ)
            {
                Messenger.Send(33); /* ОП. НАЧАЛО НЕСТАЦИОНАРНОГО РЕЖИМА */
            }


            if (InternalTimers[9].IsQ || InternalTimers[9].IsStarted && !na.HIGHVIB)
            {
                InternalTimers[9].Stop();
                na.HIGHVIB = false;
                Messenger.Send(34);  /* ОП. НЕСТАЦИОНАРНЫЙ РЕЖИМ ДВИГАТЕЛЯ ЗАКОНЧЕН */
            }
            else if (na.HIGHVIB && !InternalTimers[9].IsStarted)
            {
                InternalTimers[9].Start();
            }

            if (InternalTimers[14].IsQ || InternalTimers[14].IsStarted && !na.HIGHVIBNas)
            {
                InternalTimers[14].Stop();
                na.HIGHVIBNas = false;
                Messenger.Send(35);  /* ОП. НЕСТАЦИОНАРНЫЙ РЕЖИМ НАСОСА ЗАКОНЧЕН */
            }
            else if (na.HIGHVIBNas && !InternalTimers[14].IsStarted)
            {
                InternalTimers[14].Start();
            }
            /*Схема 11.57 Алгоритм проверки начала и окончания нестационарного режима насоса и ЭД*/

            if (InternalTimers[03].IsQ)
            {
                na.StopWork = false;
            }
            else if (!na.StopWork)
            {
                InternalTimers[03].Stop();
            }
            else if (!InternalTimers[03].IsStarted)
            {
                InternalTimers[03].Start();
            }


            /*
             * Установка доп состояния на отключенном агрегате
             */
            if (na.ActvTaskMpna == 0)
            {
                if (ReadyToStart && na.MainState == NaState.Otkl && na.StopNoCmd != StopNoCmdState.Phase1)
                {
                    if (na.Mode == NaMode.Rez)
                    {
                        na.SubState = NaSubstate.HotRez;
                    }
                    else
                    {
                        na.SubState = NaSubstate.Ready;
                    }
                }
                else if (na.MainState == NaState.Otkl)
                {
                    na.SubState = NaSubstate.None;
                }
            }


            if (na.ActvTaskMpna == 1)
            {
                na.flChRP_PuskCmd = false;         /*Останов агрегата*/
            }
            else if (na.ActvTaskMpna == 2)
            {
                SpinStopCmd = false;         /*Запуск агрегата*/
            }
            else
            {                                                    /*статичное состояние*/
                na.flChRP_PuskCmd = false;
                if (!logicalChRpCrach)
                {
                    SpinStopCmd = false;     /*без программной аварии*/
                }
            }

            /*таймер, флаг состояния и флаг события несанкционированного отключения ВВ*//*!!!*/

            /*сброс флагов неисправностей*//*!!!*/
            if (na.MainState == NaState.Otkl && !PumpCur)
            {
                na.StopErr = false;
                na.StartErr = false;
                na.StartErr2 = false;
            }
            if (BBOff) { na.StopErr2 = false; }

            /*постоянная команда на закрытие задвижек в режиме РЕМ*//*!!!*/
            switch (na.Mode)
            {
                case NaMode.Rem:
                    if (ZvState != ZdState.Closed)
                    {
                        na.ZVCmd = NaZdCmd.Close;
                    }
                    else
                    {
                        na.ZVCmd = NaZdCmd.None;
                    }

                    if (ZpState != ZdState.Closed)
                    {
                        na.ZPCmd = NaZdCmd.Close;
                    }
                    else
                    {
                        na.ZPCmd = NaZdCmd.None;
                    }

                    na.ZPBlocks = NaZdBlocks.NoOpen;
                    na.ZVBlocks = NaZdBlocks.NoOpen;

                    break;
                case NaMode.Rez:
                    na.ZPBlocks = NaZdBlocks.NoClose;
                    na.ZVBlocks = NaZdBlocks.NoClose;

                    na.ZVCmd = NaZdCmd.None;
                    na.ZPCmd = NaZdCmd.None;
                    break;
                case NaMode.Tm:
                case NaMode.Osn:

                    if (na.SubState != NaSubstate.Pp && na.SubState != NaSubstate.Po)
                    {
                        if (na.MainState == NaState.Otkl && !(InternalTimers[28].IsStarted || InternalTimers[28].IsQ))
                        {
                            na.ZPBlocks = NaZdBlocks.None;
                            na.ZVBlocks = NaZdBlocks.None;
                            na.ZVCmd = NaZdCmd.None;
                            na.ZPCmd = NaZdCmd.None;
                        }

                        if (na.MainState == NaState.Vkl && !na.StartNoCmd)
                        {
                            na.ZPBlocks = NaZdBlocks.NoClose;
                            na.ZVBlocks = NaZdBlocks.NoClose;

                            na.ZVCmd = NaZdCmd.None;
                            na.ZPCmd = NaZdCmd.None;

                        }

                    }

                    break;
            } /*----------------------------------------------- инициализация полей структуры NA локальными переменными -----------------------------------------------*/




            if (BBOn != BBOff)
            {
                na.BBOn_Prev = BBOn;
                na.BBOff_Prev = BBOff;
            }
            na.ChRP_In_Prev = ChRP_In;

            StopErrOut = na.StopErr;
            StopErr2Out = na.StopErr2;
            StopNoCmdOut = na.StopNoCmd;
            StartNoCmdOut = na.StartNoCmd;
            StartErrOut = na.StartErr;
            StartErr2Out = na.StartErr2;
            ModeOut = na.Mode;
            MainStateOut = na.MainState;
            SubstateOut = na.SubState;
            IsImitOut = na.SimAgr;
            //UseCTOut = TokControl;
            HighVibrEngOut = na.HIGHVIB;
            HighVibrPumpOut = na.HIGHVIBNas;
            NeNomIntervalPodach = NeNomIntervalPodach;
            StateAlarmVVOut = na.StateAlarm && !na.SimAgr;
            StateAlarmChrp = na.StateAlarmChrp && !na.SimAgr;
            ChrpRegError = na.ChrpRegError;
            LogicalChrpError = logicalChRpCrach;
            OffVvCmdOut = na.StopWork;
            SpinStopCmd = SpinStopCmd;
            ZvCmdOut = na.ZVCmd;
            ZpCmdOut = na.ZPCmd;
            ZvBlockOut = na.ZVBlocks;
            ZpBlockOut = na.ZPBlocks;

            SwitchOnOut = BBOn;
            SwitchOffOut = BBOff;

        }
    }
}
