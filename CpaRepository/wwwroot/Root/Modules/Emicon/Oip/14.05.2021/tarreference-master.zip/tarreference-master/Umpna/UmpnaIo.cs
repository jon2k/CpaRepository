﻿using System;
using System.Collections.Generic;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarReferenceSource.CommonNa;

namespace TarReferenceSource.Umpna
{
    public abstract class UmpnaIo : NaIo
    {
        //public NaProg ProgOut;
        /// <summary>
        /// input Флаг типа насоса. 1 – насос типа НМ, иначе – 0 
        /// </summary>
        public bool IsNM;
        /// <summary>
        /// input Тип насосного агрегата. 1 – МНА, 0 – ПНА
        /// </summary>
        public bool MpnaType;
        /// <summary>
        /// input Команда на автоматическое отключение НА от защиты «Невыполнение команды отключения МНА»
        /// </summary>
        public bool StopAuto2;
        /// <summary>
        /// input Состояние МНС. 1 – МНС в работе. 0 – МНС остановлен
        /// </summary>
        public bool MnsInWork;
        /// <summary>
        /// input Флаг определяемый условием AgrNum = KRMPN.MNA_TO_MNA.To. AgrNum - номер управляемого насосного агрегата; KRMPN.MNA_TO_MNA.To – номер МНА, назначенного на запуск при автоматизированном переходе с МНА на МНА.
        /// </summary>
        public bool IsMnaTo;
        /// <summary>
        /// input Авария выходной агрегатной задвижки 
        /// </summary>
        public bool ZvStateCrash;
        /// <summary>
        /// 
        /// </summary>
        public bool SardRampOut;
        /// <summary>
        /// output Невыполнения программы пуска. Примечание– сигнал формируется при неполучении включенного состояния ВВ НА и значении силы тока ЭД ниже уставки холостого хода после выдачи команды «Включить ВВ». После установки, сигнал сбрасывается при успешном выполнении программы остановки НА
        /// </summary>
        public bool StartErr3Out;
        /// <summary>
        /// output Команда на включение воздушного выключателя
        /// </summary>
        public bool OnVvCmdOut;
        /// <summary>
        /// input Необходимость контроля дискретного сигнала ВВ включен
        /// </summary>
        public bool UseBBB1;
        /// <summary>
        /// input Необходимость контроля дискретного сигнала ВВ включен (дублирующий сигнал)
        /// </summary>
        public bool UseBBB2;
        /// <summary>
        /// input Необходимость контроля дискретного сигнала ВВ отключен
        /// </summary>
        public bool UseBBO1;
        /// <summary>
        /// input Необходимость контроля дискретного сигнала ВВ отключен (дублирующий сигнал)
        /// </summary>
        public bool UseBBO2;

        public UmpnaIo()
        {
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
            UseBBB1 = true;
            UseBBB2 = true;
            UseBBO1 = true;
            UseBBO2 = true;
            Description.TimerDescriptions = TimerDescriptions;
        }

        public override void AfterCall()
        {
            Cmd = NaCmd.none;
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
            {
                {1, new MessageDescription{Text = "СИГНАЛ ВВ ВКЛЮЧЕН В УСО 1.1 НЕДОСТОВЕРЕН", Type = MessageType.Attention} },
                {2, new MessageDescription{Text = "СИГНАЛ ВВ ОТКЛЮЧЕН В УСО 1.1 НЕДОСТОВЕРЕН", Type = MessageType.Attention} },
                {3, new MessageDescription{Text = "СИГНАЛ ВВ ВКЛЮЧЕН В УСО 3 НЕДОСТОВЕРЕН", Type = MessageType.Attention} },
                {4, new MessageDescription{Text = "СИГНАЛ ВВ ОТКЛЮЧЕН В УСО 3 НЕДОСТОВЕРЕН", Type = MessageType.Attention} },
                {5, new MessageDescription{Text = "ЗНАЧЕНИЕ СИЛЫ ТОКА НЕДОСТОВЕРНО", Type = MessageType.Attention} },
                {6, new MessageDescription{Text = "ТОК ДВИГАТЕЛЯ НАБРАН", Type = MessageType.Neutral} },
                {7, new MessageDescription{Text = "ТОК СБРОШЕН", Type = MessageType.Neutral} },
                {14, new MessageDescription{Text = "ВВ ВКЛЮЧЕН", Type = MessageType.Neutral} },
                {15, new MessageDescription{Text = "ВВ ВКЛЮЧЕН ПО НЕУСТАНОВЛЕННОЙ ПРИЧИНЕ", Type = MessageType.Alarm} },
                {16, new MessageDescription{Text = "НЕ ПОЛУЧЕНО СОСТОЯНИЕ \"В РАБОТЕ\" ЗА ЗАДАННОЕ ВРЕМЯ", Type = MessageType.Alarm} },
                {17, new MessageDescription{Text = "КОМАНДА - ОТКЛЮЧИТЬ ВВ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
                {18, new MessageDescription{Text = "ВВ ОТКЛЮЧЕН", Type = MessageType.Neutral} },
                {19, new MessageDescription{Text = "КОМАНДА НА ОТКЛЮЧЕНИЕ ВВ В ЯЧЕЙКУ ЗРУ ДОСТАВЛЕНА", Type = MessageType.Neutral} },
                {20, new MessageDescription{Text = "ВВ ОТКЛЮЧИЛСЯ ПО НЕУСТАНОВЛЕННОЙ ПРИЧИНЕ", Type = MessageType.Alarm} },
                {21, new MessageDescription{Text = "ПРОЦЕСС ЗАПУСКА ОТМЕНЕН", Type = MessageType.Neutral} },
                {22, new MessageDescription{Text = "ВВ НЕ ОТКЛЮЧИЛСЯ", Type = MessageType.Alarm} },
                {23, new MessageDescription{Text = "ИДЕТ ПРОГРАММНЫЙ ПУСК", Type = MessageType.Neutral} },
                {24, new MessageDescription{Text = "ПРОГРАММНЫЙ ПУСК ЗАВЕРШЕН", Type = MessageType.Neutral} },
                {25, new MessageDescription{Text = "В РАБОТЕ", Type = MessageType.Neutral} },
                {26, new MessageDescription{Text = "ИДЕТ ПРОГРАММНАЯ ОСТАНОВКА", Type = MessageType.Neutral} },
                {27, new MessageDescription{Text = "ПРОГРАММНАЯ ОСТАНОВКА ЗАВЕРШЕНА", Type = MessageType.Neutral} },
                {28, new MessageDescription{Text = "ОСТАНОВЛЕН", Type = MessageType.Neutral} },
                {29, new MessageDescription{Text = "ПУСК НЕВОЗМОЖЕН. АГРЕГАТ НЕ ГОТОВ К ПУСКУ", Type = MessageType.Neutral} },
                {30, new MessageDescription{Text = "ПУСК НЕВОЗМОЖЕН. РЕЖИМ ОСН НЕ ВЫБРАН", Type = MessageType.Neutral} },
                {31, new MessageDescription{Text = "ПУСК НЕВОЗМОЖЕН. РЕЖИМ ТМ НЕ ВЫБРАН", Type = MessageType.Neutral} },
                {32, new MessageDescription{Text = "ПУСК НЕВОЗМОЖЕН. ПРОГРАММА ПУСКА УЖЕ НАЧАТА", Type = MessageType.Neutral} },
                {33, new MessageDescription{Text = "НАЧАЛО НЕСТАЦИОНАРНОГО РЕЖИМА", Type = MessageType.Neutral} },//TODO: ПУСКОВОЙ
                {34, new MessageDescription{Text = "НЕСТАЦИОНАРНЫЙ РЕЖИМ ДВИГАТЕЛЯ ЗАКОНЧЕН", Type = MessageType.Neutral} },//TODO: ПУСКОВОЙ
                {35, new MessageDescription{Text = "НЕСТАЦИОНАРНЫЙ РЕЖИМ НАСОСА ЗАКОНЧЕН", Type = MessageType.Neutral} },//TODO: ПУСКОВОЙ
                {36, new MessageDescription{Text = "НАЗНАЧЕНА ПРОГРАММА ПУСКА №1", Type = MessageType.Neutral} },
                {37, new MessageDescription{Text = "НАЗНАЧЕНА ПРОГРАММА ПУСКА №2", Type = MessageType.Neutral} },
                {38, new MessageDescription{Text = "НАЗНАЧЕНИЕ НЕВОЗМОЖНО. ИДЕТ ПРОГРАММА ПУСКА", Type = MessageType.Neutral} },
                {39, new MessageDescription{Text = "ИЗМЕНЕНИЕ ПРОГРАММЫ ПУСКА НЕВОЗМОЖНО. РЕЗЕРВНЫЙ РЕЖИМ", Type = MessageType.Neutral} },
                {40, new MessageDescription{Text = "НАЗНАЧЕНИЕ НЕВОЗМОЖНО. ИДЕТ ПРОГРАММА ОСТАНОВКИ", Type = MessageType.Neutral} },
                {41, new MessageDescription{Text = "НАЗНАЧЕНИЕ НЕ ТРЕБУЕТСЯ. ПРОГРАММА УЖЕ НАЗНАЧЕНА", Type = MessageType.Neutral} },
                {42, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ ОСНОВНОЙ", Type = MessageType.Neutral} },
                {43, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ ТЕЛЕМЕХАНИЧЕСКИЙ", Type = MessageType.Neutral} },
                {44, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ РЕЗЕРВНЫЙ", Type = MessageType.Neutral} },
                {45, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ РЕМОНТНЫЙ", Type = MessageType.Neutral} },
                {46, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ ИМИТАЦИИ", Type = MessageType.Neutral} },
                {47, new MessageDescription{Text = "РЕЖИМ ИМИТАЦИИ СНЯТ", Type = MessageType.Neutral} },
                {48, new MessageDescription{Text = "НАЗНАЧЕНИЕ НЕ ТРЕБУЕТСЯ. РЕЖИМ УЖЕ НАЗНАЧЕН", Type = MessageType.Neutral} },
                {49, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА ТМ НЕВОЗМОЖНО. СТАНЦИЯ В МЕСТНОМ РЕЖИМЕ УПРАВЛЕНИЯ", Type = MessageType.Neutral} },
                {50, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. АГРЕГАТ НЕ ОСТАНОВЛЕН", Type = MessageType.Neutral} },
                {51, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ПРИЕМНАЯ ЗАДВИЖКА НЕ ОТКРЫТА", Type = MessageType.Neutral} },
                {52, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ВЫХОДНАЯ ЗАДВИЖКА НЕ ОТКРЫТА", Type = MessageType.Neutral} },
                {53, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. НЕТ ПРОГРАММЫ ПУСКА №1", Type = MessageType.Neutral} },
                {54, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. В ПЛЕЧЕ УЖЕ ИМЕЕТСЯ МНА В РЕЖИМЕ РЕЗ", Type = MessageType.Neutral} },
                {55, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. НЕТ АГРЕГАТОВ В РЕЖИМЕ ОСН ИЛИ ТМ", Type = MessageType.Neutral} },
                {56, new MessageDescription{Text = "ВКЛЮЧЕНИЕ РЕЗЕРВА", Type = MessageType.Neutral} },
                {57, new MessageDescription{Text = "ТОК НЕ СБРОШЕН", Type = MessageType.Alarm} },
                {58, new MessageDescription{Text = "НЕ ПОЛУЧЕНО СОСТОЯНИЕ \"ОСТАНОВЛЕН\" ЗА ЗАДАННОЕ ВРЕМЯ", Type = MessageType.Alarm} },
                {59, new MessageDescription{Text = "КОМАНДА ОТКЛЮЧИТЬ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
                {60, new MessageDescription{Text = "КОНТРОЛЬ ПО ТОКУ НЕ ВЕДЁТСЯ", Type = MessageType.Neutral} },
                {61, new MessageDescription{Text = "ВЫХОДНАЯ ЗАДВИЖКА НЕ ОТКРЫЛАСЬ ПРИ ПУСКЕ ПО ПРОГРАММЕ №2", Type = MessageType.Alarm} },
                {62, new MessageDescription{Text = "ВЫХОДНАЯ ЗАДВИЖКА НЕ НАЧАЛА ОТКРЫВАТЬСЯ ПРИ ПУСКЕ ПО ПРОГРАММЕ №2", Type = MessageType.Alarm} },
                {63, new MessageDescription{Text = "НЕВЫПОЛНЕНИЕ ЗАКРЫТИЯ ЗАДВИЖКИ ПО ПРОГРАММЕ ОСТАНОВКИ", Type = MessageType.Attention} },
                {64, new MessageDescription{Text = "АГРЕГАТ ОТКЛЮЧЕН В РЕЖИМЕ ИМИТАЦИИ", Type = MessageType.Neutral} },
                {65, new MessageDescription{Text = "В РАБОТЕ В РЕЖИМЕ ИМИТАЦИИ", Type = MessageType.Neutral} },
                {66, new MessageDescription{Text = "КОНТРОЛЬ ТОКА УСТАНОВЛЕН ", Type = MessageType.Neutral} },
                {67, new MessageDescription{Text = "КОНТРОЛЬ ТОКА СНЯТ", Type = MessageType.Neutral} },
                {68, new MessageDescription{Text = "КОМАНДА - ВКЛЮЧИТЬ ВВ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
                {69, new MessageDescription{Text = "КОМАНДА НА ВКЛЮЧЕНИЕ ВВ В ЯЧЕЙКУ ЗРУ ДОСТАВЛЕНА", Type = MessageType.Neutral} },
                {70, new MessageDescription{Text = "КОМАНДА - ЗАПУСК С АРМ", Type = MessageType.Information} },
                {71, new MessageDescription{Text = "КОМАНДА - ЗАПУСК ПО ТМ", Type = MessageType.Information} },
                {72, new MessageDescription{Text = "КОМАНДА - ОТКЛЮЧИТЬ С АРМ", Type = MessageType.Information} },
                {73, new MessageDescription{Text = "КОМАНДА - ОТКЛЮЧИТЬ ПО ТМ", Type = MessageType.Information} },
                {74, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ ПРОГРАММУ ПУСКА №1", Type = MessageType.Information} },
                {75, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ ПРОГРАММУ ПУСКА №2", Type = MessageType.Information} },
                {76, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ РЕЖИМ ОСНОВНОЙ С АРМ", Type = MessageType.Information} },
                {77, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ РЕЖИМ ОСНОВНОЙ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
                {78, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ РЕЖИМ ТЕЛЕМЕХАНИЧЕСКИЙ С АРМ", Type = MessageType.Information} },
                {79, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ РЕЖИМ РЕЗЕРВНЫЙ С АРМ", Type = MessageType.Information} },
                {80, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ РЕЖИМ РЕМОНТНЫЙ С АРМ", Type = MessageType.Information} },
                {81, new MessageDescription{Text = "КОМАНДА - НАЗНАЧИТЬ РЕЖИМ ИМИТАЦИИ С АРМ", Type = MessageType.Information} },
                {82, new MessageDescription{Text = "КОМАНДА - СНЯТЬ РЕЖИМ ИМИТАЦИИ С АРМ", Type = MessageType.Information} },
                {83, new MessageDescription{Text = "КОМАНДА - ОТКРЫТЬ ЗАДВИЖКУ НА ВЫХОДЕ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
                {84, new MessageDescription{Text = "КОМАНДА - ЗАКРЫТЬ ЗАДВИЖКУ НА ВЫХОДЕ", Type = MessageType.Information} },
                {94, new MessageDescription{Text = "КОМАНДА - УСТАНОВИТЬ КОНТРОЛЬ ТОКА", Type = MessageType.Information} },
                {92, new MessageDescription{ Text = "КОМАНДА - СНЯТЬ КОНТРОЛЬ ТОКА", Type = MessageType.Information} },
                {96, new MessageDescription{Text = "КОМАНДУ ПРИКРЫТИЯ РЕГУЛИРУЮЩИХ ЗАСЛОНОК ПРИ ПУСКЕ ПЕРВОГО ПО СЧЁТУ МНА УСТАНОВИТЬ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
                {97, new MessageDescription{Text = "КОМАНДУ ПРИКРЫТИЯ РЕГУЛИРУЮЩИХ ЗАСЛОНОК ПРИ ПУСКЕ ПЕРВОГО ПО СЧЁТУ МНА СНЯТЬ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
                {98, new MessageDescription{Text = "ТОК ДВИГАТЕЛЯ НЕ НАБРАН", Type = MessageType.Alarm} },
                {99, new MessageDescription{Text = "ВВ НЕ ВКЛЮЧИЛСЯ", Type = MessageType.Alarm} },
                {101, new MessageDescription{Text = "В РАБОТЕ. КОМАНДА НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
                {102, new MessageDescription{Text = "ОСТАНАВЛИВАЕТСЯ. КОМАНДА НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
                {103, new MessageDescription{Text = "ЗАПУСКАЕТСЯ. КОМАНДА НЕ ТРЕБУЕТСЯ", Type = MessageType.Neutral} },
                {104, new MessageDescription{Text = "АВТОМАТИЧЕСКОЕ ВКЛЮЧЕНИЕ", Type = MessageType.Information} },
                {105, new MessageDescription{Text = "ПУСК НЕВОЗМОЖЕН. АГРЕГАТ НАЗНАЧЕН НА ЗАПУСК ПРИ  ПЕРЕХОДЕ", Type = MessageType.Neutral} },
                {106, new MessageDescription{Text = "КОМАНДА – ОТКЛЮЧИТЬ ОТ ЦСПА", Type = MessageType.Information} },
            };
        protected static Dictionary<int, TimerDescription> TimerDescriptions = new Dictionary<int, TimerDescription>
        {
            {1, new TimerDescription("Время на проверку корректности состояния цепей контроля ВВ", TimeSpan.FromMilliseconds(600),"Значение уставки данного таймера может быть увеличено по результатам наладочных работ при эксплуатации НА с включенным контролем значения силы тока ЭД") },
            {2, new TimerDescription("Время удержания команды «Включить ВВ», при получении включенного состояния ВВ", TimeSpan.FromMilliseconds(0)) },
            {3, new TimerDescription("Максимальное время удержания команды «Отключить ВВ»", TimeSpan.FromMilliseconds(2500)) },
            {4, new TimerDescription("Время, до выдачи команды «Включить ВВ», необходимое для отработки исполнительного механизма САР во время работы рамповой функции", TimeSpan.FromMilliseconds(3000)) },
            {5, new TimerDescription("Время на открытие выкидной задвижки перед выдачей команды на включение НА по программе пуска №2", TimeSpan.FromMilliseconds(7000)) },
            {6, new TimerDescription("Контрольное время на выполнение процесса отключения ВВ НА", TimeSpan.FromMilliseconds(3000)) },
            {7, new TimerDescription("Время подъема силы тока ЭД после включения ВВ НА", TimeSpan.FromMilliseconds(6000)) },
            {8, new TimerDescription("Время полного хода выкидной задвижки НА (используется в алгоритме включения и отключения НА по программе пуска №2)", TimeSpan.FromMilliseconds(20000)) },
            {9, new TimerDescription("Время нестационарного режима работы ЭД при пуске", TimeSpan.FromMilliseconds(40000)) },
            {10, new TimerDescription("Время, перед выдачей команды повторного отключения ВВ при невыполнении программы остановки", TimeSpan.FromMilliseconds(3000)) },
            {11, new TimerDescription("Контрольное время на выполнение процесса включения ВВ НА;", TimeSpan.FromMilliseconds(3000)) },
            {12, new TimerDescription("Время снижения силы тока ЭД после отключения ВВ НА", TimeSpan.FromMilliseconds(6000)) },
            {13, new TimerDescription("Время фильтрации сигналов цепей включения и отключения", TimeSpan.FromMilliseconds(2000)) },
            {14, new TimerDescription("Длительность нестационарного режима работы насоса", TimeSpan.FromMilliseconds(41000)) },
            {15, new TimerDescription("Длительность выдачи команды САР (рамповая функция)", TimeSpan.FromMilliseconds(1000)) },
            {16, new TimerDescription("Время на выполнение АВР при получении сигнала «электрозащита» после получения состояния «ВВ отключен»", TimeSpan.FromMilliseconds(3000)) },
            {17, new TimerDescription("Время, через которое будет выдана команда стоп при отсутствии электрозащиты", TimeSpan.FromMilliseconds(3000)) }
        };
    }
}
