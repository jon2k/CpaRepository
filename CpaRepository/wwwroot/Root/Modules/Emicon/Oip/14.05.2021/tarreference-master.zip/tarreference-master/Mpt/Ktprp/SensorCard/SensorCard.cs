﻿namespace TarReferenceSource.Mpt.Gpz.SensorCard
{
    public class SensorCard: SensorCardIo
    {
        /// <summary>
        /// Кол-во сработавших пожарных извещателей
        /// </summary>
        private uint _countTriggered;
        /// <summary>
        /// Кол-во исправных пожарных извещателей
        /// </summary>
        private uint _countNotFail;

        public SensorCard(int countSensor):base(countSensor)
        {
            
        }

        public override void Execute()
        {
            _countTriggered = 0;
            _countNotFail = SensorsCount;
            if (!InRem)
            {
                for (int i = 1; i <= SensorsCount; i++)
                {
                    if (Sensors[i].Triggered)
                    {
                        _countTriggered = _countTriggered + 1;
                    }

                    if (Sensors[i].Failure)
                    {
                        _countNotFail = _countNotFail - 1;
                    }
                }
            }

            NotEnoughtSensors = _countNotFail < EnoughtSensorsCount;
            OneSensorsTriggered = _countTriggered >= 1;
            TwoSensorsTriggered = _countTriggered >= 2;
        }
    }
}
