﻿using TarFoundation.St;

namespace TarReferenceSource.Sard.Generic
{
    /// <summary>
    /// Данные о режиме руулирования
    /// </summary>
    public class ModeParametr
    {
        /// <summary>
        /// Тип регулирования
        /// </summary>
        public SardRegulationMode EnteredMode;
        /// <summary>
        /// Команда подтверждения 
        /// </summary>
        public bool ConfirmCmd;
        /// <summary>
        /// Флаг необходимости подтверждения
        /// </summary>
        public bool NeedConfirm;
    }

    public abstract class ModeConfirmIo : IFunctionBlock
    {
        //in
        /// <summary>
        /// input Источник задания уставки
        /// </summary>
        public SardControlSource Mode;
        /// <summary>
        /// input Данные о режиме регулирования с панели оператора
        /// </summary>
        public ModeParametr PanelSetting = new ModeParametr();
        /// <summary>
        /// input Данные о режиме регулирования от внешнего источника
        /// </summary>
        public ModeParametr ExternalSetting = new ModeParametr();
        //out
        /// <summary>
        /// output Тип регулирования
        /// </summary>
        public SardRegulationMode CurrentSetting;

        public override void AfterCall()
        {
            PanelSetting.ConfirmCmd = false;
            ExternalSetting.ConfirmCmd = false;
        }
    }
    //TODO: не ясно что делать при первом запуске
    //TODO: добавить сообщения для переключения режимов
    public class ModeConfirm : ModeConfirmIo
    {
        /// <summary>
        /// Тип регулирования
        /// </summary>
        private SardRegulationMode currentMode;

        public override void Execute()
        {
            if (PanelSetting.ConfirmCmd)
            {
                Messenger.Send(1); //команда задать уставку с панели
                if (Mode == SardControlSource.external)
                {
                    Messenger.Send(2);//задание уставки невозможно. режим управление "внешний"
                }
                else if (PanelSetting.EnteredMode == currentMode)
                {
                    Messenger.Send(7);//не требуется режим уже задан
                }
                else
                {
                    Messenger.Send(3);//значение изменено с дисплейной панели
                    currentMode = PanelSetting.EnteredMode;
                }
            }

            PanelSetting.NeedConfirm = PanelSetting.EnteredMode != currentMode && Mode == SardControlSource.panel;

            if (ExternalSetting.ConfirmCmd)
            {
                Messenger.Send(4); //команда задать уставку от МПСА
                if (Mode == SardControlSource.panel)
                {
                    Messenger.Send(5);//задание уставки невозможно. режим управление "с дисплейной панели"
                }
                else if (ExternalSetting.EnteredMode == currentMode)
                {
                    Messenger.Send(7);//не требуется
                }
                else
                {
                    Messenger.Send(6);//значение изменено с МПСА
                    currentMode = ExternalSetting.EnteredMode;
                }
            }

            ExternalSetting.NeedConfirm = ExternalSetting.EnteredMode != currentMode && Mode == SardControlSource.external;
            CurrentSetting = currentMode;
        }
    }
}
