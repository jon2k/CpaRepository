﻿using System;
using System.Collections.Generic;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.Description;
using TarFoundation.Messenger;
using TarFoundation.St;
using TarReferenceSource.Uzd;

namespace TarReferenceSource.Mpt.Ubd.ProcUbd
{
    public enum UbdCmd : ushort
    {
        none = 0,
        SetOsnCmd = 1,
        SetRezCmd = 2,
        SetRemCmd = 3
    }

    public enum UbdState : ushort
    {
        unknown = 0,
        closed = 1,
        opened = 2,
        middle = 3
    }

    public enum UbdMode : ushort
    {
        osn = 1,
        rez = 2,
        rem = 3,
    }
    /// <summary>
    /// Входные даные для модуля ProcUbd
    /// </summary>
    public struct structUbdInput
    {
        /// <summary>
        /// Команда с АРМ оператора
        /// </summary>
        public UbdCmd cmd;//Команда с АРМ оператора (1- установ. реж. АВТ., 2-установ. реж. РЕЗ.)
        /// <summary>
        /// Состояние аварий входной задвижки БД
        /// </summary>
        public ZdOut ZdStateIn; //Состояние аварий входной задвижки БД
        /// <summary>
        /// Состояние аварий выходной задвижки БД
        /// </summary>
        public ZdOut ZdStateOut; //Состояние аварий выходной задвижки БД
        /// <summary>
        /// Бак пуст
        /// </summary>
        public bool empty; //Пуст
        /// <summary>
        /// Бак полон
        /// </summary>
        public bool full; //Полон
        /// <summary>
        /// Аварийный запас
        /// </summary>
        public bool low; //Аварийный запас
    }
    /// <summary>
    /// Выходные данные модуля ProcUbd
    /// </summary>
    public struct structUbdOutput
    {
        /// <summary>
        /// Команды управления входной задвижки БД
        /// </summary>
        public ZdControl ZDCtrlIn; //Команды управления входной задвижки БД
        /// <summary>
        /// Команды управления выходной задвижки БД
        /// </summary>
        public ZdControl ZDCtrlOut; //Команды управления выходной задвижки БД
    }
    public abstract class ProcUbdIo : IFunctionBlock
    {
        public ProcUbdIo()
        {
            Description.TimerDescriptions = TimerDescriptions;
        }
        private readonly ProcUzdIo _inZd;
        private readonly ProcUzdIo _outZd;

        public ProcUbdIo(ProcUzdIo inZd, ProcUzdIo outZd)
        {
            _inZd = inZd;
            _outZd = outZd;
            input.ZdStateIn = inZd.CommonData;
            input.ZdStateOut = outZd.CommonData;

            output.ZDCtrlIn = new ZdControl();
            output.ZDCtrlOut = new ZdControl();
            input.ZdStateIn = _inZd.CommonData;
            input.ZdStateOut = _outZd.CommonData;
            Messenger = new CpaLocalMessageBuffer(new MessageDecoder(messages));
        }
        /// <summary>
        /// input Входные данные модуля
        /// </summary>
        public structUbdInput input;
        /// <summary>
        /// output Выходные данные модуля для управления задвижками бака
        /// </summary>
        public structUbdOutput output;

        /// <summary>
        /// output Состояние
        /// </summary>
        public UbdState state; //0-неопред, 1 - бак-дозатор закрыт, 2 - открыт, 3 промежуточное
        /// <summary>
        /// output Авария
        /// </summary>
        public bool isCrashed;//авария
        /// <summary>
        /// output Режим
        /// </summary>
        public UbdMode mode;  //0- режим "Аварийный", 1 - режим "Автоматический", 2-"Резервный"
        /// <summary>
        /// output Нужен резерв
        /// </summary>
        public bool needRezOn;
        /// <summary>
        /// output Может быть резервным
        /// </summary>
        public bool canBeRez;
        /// <summary>
        /// output Несиправность бака
        /// </summary>
        public bool err;   //Неисправность
        /// <summary>
        /// output Бак пуст
        /// </summary>
        public bool empty; //Пуст
        /// <summary>
        /// output Бак полон
        /// </summary>
        public bool full; //Полон
        /// <summary>
        /// output Аварийный запас
        /// </summary>
        public bool low; //Аварийный запас
        /// <summary>
        /// outputКоманда на открытие задвижек БД
        /// </summary>
        public bool openCmd; //Команда на открытие задвижек БД
        /// <summary>
        /// output Команда на закрытие задвижек БД
        /// </summary>
        public bool closeCmd; //Команда на закрытие задвижек БД
        /// <summary>
        /// output Готовость бака
        /// </summary>
        public bool ready;

        public override void AfterCall()
        {
            _inZd.nlClose = output.ZDCtrlIn.nlClose;
            _inZd.nlOpen = output.ZDCtrlIn.nlOpen;

            _outZd.nlClose = output.ZDCtrlOut.nlClose;
            _outZd.nlOpen = output.ZDCtrlOut.nlOpen;

            input.cmd = UbdCmd.none;
        }

        public static Dictionary<uint, MessageDescription> messages = new Dictionary<uint, MessageDescription>
        {
            {1, new MessageDescription{Text = "ОТКРЫТ", Type = MessageType.Neutral} },
            {2, new MessageDescription{Text = "ЗАКРЫТ", Type = MessageType.Neutral} },
            {3, new MessageDescription{Text = "НЕ ОТКРЫТ", Type = MessageType.Neutral} },
            {4, new MessageDescription{Text = "НЕОПРЕДЕЛЕННОЕ СОСТОЯНИЕ", Type = MessageType.Neutral} },
            {5, new MessageDescription{Text = "КОМАНДА НАЗНАЧИТЬ РЕЖИМ «ОСН»", Type = MessageType.Information} },
            {6, new MessageDescription{Text = "КОМАНДА НАЗНАЧИТЬ РЕЖИМ «РЕЗ»", Type = MessageType.Information} },
            {7, new MessageDescription{Text = "КОМАНДА НАЗНАЧИТЬ РЕЖИМ «РЕМ»", Type = MessageType.Information} },
            {8, new MessageDescription{Text = "ОТКРЫТЬ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
            {9, new MessageDescription{Text = "ЗАКРЫТЬ АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
            {10, new MessageDescription{Text = "НЕ ОТКРЫЛСЯ", Type = MessageType.Alarm} },
            {11, new MessageDescription{Text = "БАК ПУСТ", Type = MessageType.Alarm} },
            {12, new MessageDescription{Text = "НЕИСПРАВНОСТЬ ЗАДВИЖЕК", Type = MessageType.Attention} },
            {14, new MessageDescription{Text = "АВТОМАТИЧЕСКОЕ ОТКРЫТИЕ РЕЗЕРВА", Type = MessageType.Information} },
            {13, new MessageDescription{Text = "ИСПРАВЕН", Type = MessageType.Neutral} },
            {17, new MessageDescription{Text = "БАК ПОЛОН", Type = MessageType.Neutral} },
            {18, new MessageDescription{Text = "НАЗНАЧЕНИЕ НЕВОЗМОЖНО. БАК НЕ ЗАКРЫТ", Type = MessageType.Neutral} },
            {19, new MessageDescription{Text = "НАЗНАЧЕНИЕ НЕВОЗМОЖНО. БАК НЕИСПРАВЕН", Type = MessageType.Neutral} },
            {20, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ «ОСН»", Type = MessageType.Neutral} },
            {21, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ «РЕЗ»", Type = MessageType.Neutral} },
            {22, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ «РЕМ»", Type = MessageType.Neutral} },
            {23, new MessageDescription{Text = "НАЗНАЧЕНИЕ РЕЖИМА НЕ ТРЕБУЕТСЯ. РЕЖИМ УЖЕ НАЗНАЧЕН", Type = MessageType.Neutral} },
            {25, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ «ОСН» АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
            {26, new MessageDescription{Text = "НАЗНАЧЕН РЕЖИМ «РЕМ» АВТОМАТИЧЕСКИ", Type = MessageType.Information} },
            {27, new MessageDescription{Text = "АВАРИЯ", Type = MessageType.Neutral} },
            {28, new MessageDescription{Text = "НАЗНАЧЕНИЕ НЕВОЗМОЖНО. НЕТ БАКОВ В РЕЖИМЕ «ОСН»", Type = MessageType.Neutral} },
        };
        protected static Dictionary<int, TimerDescription> TimerDescriptions = new Dictionary<int, TimerDescription>
        {
            {1, new TimerDescription("Задержка на установку ремонтного режима при обесточенности задвижек.", TimeSpan.FromMilliseconds(100)) }         
        };
    }
}
