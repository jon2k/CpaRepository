﻿using System.Linq;
using Friday.Helpers;
using Friday.Runtime.CpaLocal;
using TarFoundation.St;
using TarReference.InteractionStorages;
using TarReferenceSource.Common.Timer;

namespace TarReferenceSource.Uvs
{

    public partial class ProcAvs : ProcAvsIo
    {
        /// <summary>
        /// Внутренее состояние агрегата
        /// </summary>
        private AvsStorage storage = new AvsStorage();

        public ProcAvs()
        {
            
            InternalTimers = new StArray<ITimer>(1, Enumerable.Range(1, 8).Select(i => new CpaLocalTimer()).ToArray());
        }

        public override void Execute()
        {
            /*КОНТРОЛЬ КОРРЕКТНОСТИ РЕЖИМА*/
            if (storage.Mode == 0 || storage.Mode > VsMode.repair)
            {
                storage.SetMode = VsMode.osn;
            }

            if (!PcUse)
            {
                Nu.Pc = Nu.Mp;
            }

            /*АВТОМАТИЧЕСКАЯ СМЕНА РЕЖИМОВ*/

            if (AutoCmd.SetMode != storage.Mode)
            {
                if (AutoCmd.SetMode == VsMode.osn)
                {
                    Messenger.Send(40); /* Msg: УСТАНОВИТЬ РЕЖИМ ОСНОВНОЙ АВТОМАТИЧЕСКИ */
                    Messenger.Send(34); /* Msg: УСТАНОВЛЕН РЕЖИМ ОСНОВНОЙ  */
                    storage.Mode = AutoCmd.SetMode;
                }
                else if (AutoCmd.SetMode == VsMode.rez)
                {
                    Messenger.Send(41); /* Msg: НАЗНАЧИТЬ РЕЖИМ РЕЗЕРВНЫЙ АВТОМАТИЧЕСКИ */
                    Messenger.Send(35); /* Msg: НАЗНАЧЕН РЕЖИМ РЕЗЕРВНЫЙ  */
                    storage.Mode = AutoCmd.SetMode;
                }
                else if (AutoCmd.SetMode == VsMode.manual)
                {
                    Messenger.Send(45); /* Msg: НАЗНАЧИТЬ РЕЖИМ РУЧНОЙ АВТОМАТИЧЕСКИ */
                    Messenger.Send(36); /* Msg: НАЗНАЧЕН РЕЖИМ РУЧНОЙ  */
                    storage.Mode = AutoCmd.SetMode;
                }
                storage.SetMode = storage.Mode;
            }

            #region blocks processing

            if (AutoCmd.BlockApv)
            {
                storage.BlockApv = true;
            }

            if (AutoCmd.ResetBlocksApvCmd)
            {
                storage.BlockApv = false;
            }

            if (storage.WaitingForApv && !AutoCmd.SilentStop && AutoCmd.SetMode != VsMode.rez)
            {
                if (!storage.BlockApv)
                {
                    if (Nu.Ec && Nu.SecEc)
                    {
                        storage.DoApv = true;
                        storage.WaitingForApv = false;
                    }
                }
            }
            else
            {
                storage.DoApv = false;
            }

            if (AutoCmd.ResetBlocksCmd)
            {
                storage.BlockStop = false;
                storage.BlockWork = false;
            }

            if (AutoCmd.BlockStop)
            {
                storage.BlockStop = true;
            }

            if (AutoCmd.BlockWork)
            {
                storage.BlockWork = true;
            }


            #endregion

            #region Opc Control

            var OpcStatus = Nu.Opc || storage.BlockWork || storage.Mode == VsMode.repair || !Nu.SecEc || !Nu.Ec;

            if (storage.State == VsState.off && UseOpc && OpcStatus != storage.PrevOpc)
            {
                if (OpcStatus)
                {
                    InternalTimers[8].Stop();
                    if (Nu.Opc)
                    {
                        Messenger.Send(57);
                    }
                    storage.PrevOpc = Nu.Opc;
                }
                else if (InternalTimers[8].IsQ)
                {
                    Messenger.Send(56); /*ЦЕПИ ВКЛЮЧЕНИЯ НЕИСПРАВНЫ*/
                    storage.PrevOpc = Nu.Opc;
                    if (storage.Mode == VsMode.osn || storage.Mode == VsMode.rez)
                    {
                        //storage.SetMode = VsMode.repair;
                        storage.DoNeispravStop = true;
                    }
                }
                else if (!InternalTimers[8].IsStarted)
                {
                    InternalTimers[8].Start();
                }
            }
            else
            {
                InternalTimers[8].Stop();
            }
            #endregion

            #region Ec fall processing


            if (Nu.Ec != storage.PrevEc)
            {
                if (!Nu.Ec)
                {
                    if (storage.State == VsState.off)
                    {
                        Messenger.Send(55); /*Msg: НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ*/
                        if (!InternalTimers[6].IsStarted && !storage.Avar.EcFall)
                        {
                            InternalTimers[6].Start();
                        } /*ТАЙМЕР НА РЕМОНТ ПРИ ОТСУТСТВТИИ Ec*/
                    }
                    else if (storage.State == VsState.stopping)
                    {
                        if (!InternalTimers[6].IsStarted && !storage.Avar.EcFall)
                        {
                            InternalTimers[6].Start();
                        } /*ТАЙМЕР НА РЕМОНТ ПРИ ОТСУТСТВТИИ Ec*/
                    }
                }
                else
                {
                    InternalTimers[6].Stop(); /*ТАЙМЕР НА РЕМОНТ ПРИ ОТСУТСТВТИИ Ec*/
                    if (storage.State == VsState.off)
                    {
                        storage.Avar.EcFall = false;
                        Messenger.Send(54); /*Msg: ЕСТЬ НАПРЯЖЕНИЕ В СХЕМЕ УПРАВЛЕНИЯ*/
                    }
                    else if (storage.State == VsState.stopping)
                    {
                        if (!(storage.AState == 407 || storage.AState == 401 || storage.AState == 402))
                        {
                            Messenger.Send(54); /*Msg: ЕСТЬ НАПРЯЖЕНИЕ В СХЕМЕ УПРАВЛЕНИЯ*/
                        }
                    }
                }
                storage.PrevEc = Nu.Ec;
            }

            #endregion


            var FireStart = AutoCmd.FireProtectProcessing && storage.BlockStop;


            #region Accepting commands

            var acceptStartCommand = true;
            if (Cmd == VsCmds.CmdPusk)
            {
                Messenger.Send(46); /* Msg: КОМАНДА - ВКЛЮЧИТЬ С АРМ */
            }
            else if (AutoCmd.AutoStart || storage.DoSelfStart)
            {
                if (storage.Mode == VsMode.rez)
                {
                    Messenger.Send(18); /* Msg: КОМАНДА - ВКЛЮЧИТЬ РЕЗЕРВ КАК ДОПОЛНИТЕЛЬНЫЙ */
                }
                else
                {
                    Messenger.Send(1); /* Msg: КОМАНДА - ВКЛЮЧИТЬ АВТОМАТИЧЕСКИ */
                }
                storage.DoSelfStart = false;
            }
            else if (AutoCmd.ResStart)
            {
                if (Nu.Ec && Nu.SecEc)
                {
                    Messenger.Send(8); /* Msg: КОМАНДА - ВКЛЮЧИТЬ РЕЗЕРВ АВТОМАТИЧЕСКИ */
                }
                else
                {
                    storage.DoFuturePusk = true;
                }
            }
            else if (storage.DoApv)
            {
                Messenger.Send(43); /* Msg: КОМАНДА АВТОМАТИЧЕСКОГО ПОВТОРНОГО ВКЛЮЧЕНИЯ */
                storage.DoApv = false;
            }
            else
            {
                acceptStartCommand = false;
            }
            #endregion

            #region Start ready checks

            var readyToStart = false;
            if (acceptStartCommand)
            {
                if (storage.Mode == VsMode.repair || storage.Mode == VsMode.manual)
                {
                    Messenger.Send(2); /* Msg: ПУСК НЕВОЗМОЖЕН. ЗАПРЕТ ПО РЕЖИМУ */
                }
                else if (storage.State == VsState.starting)
                {
                    Messenger.Send(14); /* Msg: ЗАПУСКАЕТСЯ. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ*/
                }
                else if (storage.BlockWork)
                {
                    Messenger.Send(15); /* Msg: КОМАНДА ВКЛЮЧИТЬ ЗАПРЕЩЕНА ПО ЗАЩИТЕ.*/
                }
                else if (storage.State == VsState.@on)
                {
                    Messenger.Send(3); /* Msg: ВКЛЮЧЕН. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ */
                }
                //else if (AutoCmd.ResStart && storage.Mode != VsMode.rez)
                //{
                //    Messenger.Send(70); /* Msg: ВКЛЮЧЕНИЕ НЕВОЗМОЖНО.АГРЕГАТ НЕ В РЕЗЕРВЕ */
                //}
                else if (!Nu.SecEc)
                {
                    Messenger.Send(16); /* Msg: ПУСК НЕВОЗМОЖЕН. НЕТ НАПРЯЖЕНИЯ НА СШ ЩСУ */
                    if (storage.DoFuturePusk)
                    {
                        storage.SetMode = VsMode.osn;
                        Messenger.Send(72); /* Msg: ВКЛЮЧЕНИЕ ПРОЦЕДУРЫ ОТЛОЖЕННОГО ПУСКА */
                    }
                }
                else if (!Nu.Ec)
                {
                    Messenger.Send(7); /* Msg: ПУСК НЕВОЗМОЖЕН. НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ */
                    if (storage.DoFuturePusk)
                    {
                        storage.SetMode = VsMode.osn;
                        Messenger.Send(72); /* Msg: ВКЛЮЧЕНИЕ ПРОЦЕДУРЫ ОТЛОЖЕННОГО АВР */
                    }
                }
                else
                {
                    readyToStart = true;
                }
            }
            #endregion


            /*--------2-5 --------------*/
            if (acceptStartCommand && readyToStart)
            {
                if (storage.Mode == VsMode.rez)
                {
                    storage.SetMode = VsMode.osn;
                }

                storage.WaitingForApv = false;
                storage.AState = 300;
            }



            /*ВНЕШНЯЯ АВАРИЯ*/
            var activateAvr = false;
            if (Nu.ExternalCrash && !storage.Avar.External)
            {
                storage.Avar.External = true;
                Messenger.Send(30); /* Msg: НЕИСПРАВЕН. ВНЕШНЯЯ АВАРИЯ */
                storage.Crash = true;
                if (storage.State == VsState.on || storage.State == VsState.starting)
                {
                    storage.DoNeispravStop = true;
                    if (storage.Mode == VsMode.osn)
                    {
                        activateAvr = true;
                    }
                }
            }

            if (!Nu.ExternalCrash && AutoCmd.FireProtectProcessing)
            {
                storage.Avar.External = false;
            }
            /*ОБРАБОТКА КОМАНД НА ОСТАНОВКУ*/

            #region Accepting stop commands

            if (AutoCmd.SilentStop)
            {
                storage.NeedAvr = false;
                storage.WaitingForApv = false;
                storage.DoFuturePusk = false;
            }

            var stopAccepted = true;
            if (storage.DoNeispravStop)//TODO эта команда формируется по результатам работы автомата, возможно имеет смысл обрабатывать ее сразу после него + перенести из storage на стек
            {
                storage.DoNeispravStop = false;
                if (AutoCmd.FireProtectProcessing)
                {
                    //TODO поменять механизм остановки при АВР
                    if (AutoCmd.ReserveStatus == ReserveGroupStatus.ResExist && storage.State != VsState.off)
                    {
                        Messenger.Send(10); /* Msg: КОМАНДА - ОТКЛЮЧИТЬ АВТОМАТИЧЕСКИ */
                    }
                    else if (!Nu.Mp && !(Nu.Pc && PcUse))
                    {
                        storage.AState = 200;
                        stopAccepted = false;
                    }
                    else
                    {
                        storage.AState = 113;
                        stopAccepted = false;
                    }
                }
            }
            else if (AutoCmd.AutoStop || storage.DoSelfStop)
            {
                storage.DoSelfStop = false;
                Messenger.Send(10); /* Msg: КОМАНДА - ОТКЛЮЧИТЬ АВТОМАТИЧЕСКИ */
            }
            else if (Cmd == VsCmds.CmdStop)
            {
                Messenger.Send(47); /* Msg: КОМАНДА - ОТКЛЮЧИТЬ С АРМ */
                if (storage.BlockStop)
                {
                    Messenger.Send(24); /* Msg: ОТКЛЮЧЕНИЕ НЕВОЗМОЖНО. АВТОМАТИЧЕСКАЯ БЛОКИРОВКА */
                    stopAccepted = false;
                }
            }
            else
            {
                stopAccepted = false;
            }

            #endregion




            #region Stop ready checks

            if (stopAccepted)
            {
                if (storage.State == VsState.off)
                {
                    Messenger.Send(12); /* Msg: ОТКЛЮЧЕН. ВЫПОЛНЕНИЕ КОМАНДЫ НЕ ТРЕБУЕТСЯ */
                    stopAccepted = false;
                }
            }

            #endregion

            if (stopAccepted)
            {
                storage.AState = 400;
            }

            var Stop = storage.BlockWork || storage.Mode == VsMode.repair;

            #region Sec ec fall processing

            /*2-9*/
            /*Фиксация исчезновения напряжения на секции шин для АПВ*/
            if (!Nu.SecEc && storage.PrevSecEc)
            {
                storage.SecEcFall = true;
                InternalTimers[7].Start(); /*ТАЙМЕР НА ЗАПАЗДЫВАНИЕ НАПРЯЖЕНИЯ НА СШ*/
            }
            else if (!InternalTimers[7].IsStarted && Nu.SecEc)
            {
                storage.SecEcFall = !Nu.SecEc;
            }

            storage.PrevSecEc = Nu.SecEc;



            #endregion

            if (!Nu.Ec && InternalTimers[6].IsQ && !storage.Avar.EcFall)
            {
                /*ТАЙМЕР НА РЕМОНТ ПРИ ОТСУТСТВТИИ Ec*/
                Messenger.Send(28); /*Msg: НЕИСПРАВЕН. НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ*/
                if (storage.Mode != VsMode.manual)
                {
                    storage.Crash = true;
                    storage.Avar.EcFall = true;
                    if (storage.DoFuturePusk)
                    {
                        storage.DoFuturePusk = false;
                        Messenger.Send(73); /*Msg:  ОТМЕНА ПРОЦЕДУРЫ ОТЛОЖЕННОГО ПУСКА*/
                    }
                }
            }
            else if (Nu.Ec && Nu.SecEc)
            {
                if (storage.DoFuturePusk)
                {
                    storage.DoFuturePusk = false;
                    if (storage.Mode == VsMode.osn || storage.Mode == VsMode.rez)
                    {
                        storage.DoSelfStart = true;
                    }
                }
            }

            if (Nu.Ec && storage.Avar.EcFall && storage.Mode == VsMode.manual)
            {
                storage.Avar.EcFall = false;
            }

            /*ОБРАБОТКА СОСТОЯНИЙ */
            /*3*/
            switch (storage.AState)
            {
                case 000: /*ОПРЕДЕЛЕНИЕ СОСТОЯНИЯ ПРИ ПЕРВОМ ПУСКЕ ПРОЕКТА*/
                    if (Nu.Mp && (PcUse && Nu.Pc || !PcUse))
                    {
                        storage.AState = 100;
                    }
                    else
                    {
                        storage.AState = 200;
                    }

                    if (storage.Mode == 0)
                    {
                        storage.SetMode = VsMode.osn;
                    }

                    storage.PrevEc = true;
                    storage.PrevSecEc = true;
                    storage.PrevOpc = true;
                    break;
                case 100: /*ВКЛЮЧЕН*/
                    /*ПРОСАДКА ДАВЛЕНИЯ ИЛИ НЕИСПРАВНОСТЬ ДАТЧИКА ДАВЛЕНИЯ*/
                    if ((!Nu.Pc || Nu.PcNeisprav) && PcUse && !storage.Avar.PcControlRuch)
                    {
                        storage.AState = 101;
                        InternalTimers[5].Start(); /*ТАЙМЕР НА КОНТРОЛЬ ДАВЛЕНИЯ*/
                    }
                    else if (Nu.Pc && !Nu.PcNeisprav && storage.Avar.PcControlRuch)
                    {
                        storage.Avar.PcControlRuch = false;
                        Messenger.Send(61); /*Msg: ДАВЛЕНИЕ НА ВЫКИДЕ АГРЕГАТА УСТАНОВИЛОСЬ*/
                    }

                    /*ИСЧЕЗНОВЕНИЕ МП*/
                    if (!Nu.Mp && !storage.Avar.MpControlRuch)
                    {
                        storage.AState = 103;
                        InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                    }
                    else if (Nu.Mp && storage.Avar.MpControlRuch)
                    {
                        storage.Avar.MpControlRuch = false;
                        Messenger.Send(5); /*Msg: МАГНИТНЫЙ ПУСКАТЕЛЬ ВКЛЮЧЕН. РУЧНОЙ РЕЖИМ*/
                    }

                    /*ИСЧЕЗНОВЕНИЕ Ec 3-4 */
                    if (!Nu.Ec && !(storage.Avar.EcControlRuch || storage.Avar.EcControl))
                    {
                        InternalTimers[1].Start(); /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                        InternalTimers[4].Start(); /*ТАЙМЕР НА СТОП ПО МЕСТУ*/
                        InternalTimers[6].Start(); /*ТАЙМЕР НА РЕМОНТ ПРИ ОТСУТСТВТИИ Ec*/
                        storage.AState = 102;
                    }
                    else if (storage.Avar.EcControlRuch && Nu.Ec)
                    {
                        storage.Avar.EcControlRuch = false;
                        Messenger.Send(75); /*Msg: ЦЕПИ КОНТРОЛЯ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ ИСПРАВНЫ*/
                    }

                    break;
                case 101: /*ПРОСЕЛО ДАВЛЕНИЕ НА РАБОТАЮЩЕМ АГРЕГАТЕ*/
                    /*ДАВЛЕНИЕ ВОССТАНОВИЛОСЬ*/
                    if (Nu.Pc && !Nu.PcNeisprav)
                    {
                        InternalTimers[5].Stop(); /*ТАЙМЕР НА КОНТРОЛЬ ДАВЛЕНИЯ*/
                        storage.AState = 100;
                    }
                    else if (!InternalTimers[5].IsStarted)
                    {
                        /*ТАЙМЕР НА КОНТРОЛЬ ДАВЛЕНИЯ*/
                        if (Nu.Mp)
                        {
                            /*3-5*/
                            if (storage.Mode != VsMode.manual)
                            {
                                storage.Crash = true;
                                storage.NeedAvr = true;
                                //PuskAvr= true ;                                       
                                storage.DoNeispravStop = true;
                                if (!Nu.Pc && !Nu.PcNeisprav)
                                {
                                    storage.Avar.PcFall = true;
                                    Messenger.Send(60); /* Msg: ДАВЛЕНИЕ НА ВЫКИДЕ АГРЕГАТА СНИЗИЛОСЬ */
                                }
                                else if (Nu.PcNeisprav)
                                {
                                    storage.Avar.PcControl = true;
                                    ;
                                    Messenger.Send(31); /*Msg: НЕИСПРАВЕН. ДАТЧИК ДАВЛЕНИЯ НЕИСПРАВЕН */
                                }
                            }
                            else
                            {
                                storage.Avar.PcControlRuch = true;
                                if (!Nu.Pc)
                                {
                                    Messenger.Send(60); /*Msg: ДАВЛЕНИЕ НА ВЫКИДЕ АГРЕГАТА СНИЗИЛОСЬ...*/
                                }

                                if (Nu.PcNeisprav)
                                {
                                    Messenger.Send(31); /*Msg: ДАТЧИК ДАВЛЕНИЯ НЕИСПРАВЕН...*/
                                }

                                Messenger.Send(5); /*Msg: МАГНИТНЫЙ ПУСКАТЕЛЬ ВКЛЮЧЕН. РУЧНОЙ РЕЖИМ*/
                                storage.AState = 100;
                            }
                        }
                        else
                        {
                            /*3-6*/
                            if (storage.Mode != VsMode.manual)
                            {
                                storage.Crash = true;
                                storage.NeedAvr = true;
                                storage.Avar.MpcFall = true;
                                Messenger.Send(26); /*Msg: НЕИСПРАВЕН. МАГНИТНЫЙ ПУСКАТЕЛЬ НЕИСПРАВЕН;*/
                                storage.AState = 200;
                            }
                            else
                            {
                                if (storage.Avar.MpControlRuch)
                                {
                                    storage.Avar.MpControlRuch = false;
                                    Messenger.Send(60); /*НЕИСПРАВЕН. ДАВЛЕНИЕ НА  ВЫКИДЕ АГРЕГАТА СНИЗИЛОСЬ*/
                                    storage.AState = 200;
                                }
                                else
                                {
                                    storage.Avar.MpcFall = true;
                                    Messenger.Send(26); /*Msg: НЕИСПРАВЕН. МАГНИТНЫЙ ПУСКАТЕЛЬ НЕИСПРАВЕН;*/
                                    storage.AState = 200;
                                }
                            }
                        }
                    }

                    break;
                case 102:
                case 407: /*ИСЧЕЗ Ec НА РАБОТАЮЩЕМ АГРЕГАТЕ - СТОП ПО МЕСТУ ИЛИ ИСЧЕЗНОВЕНИЕ НАПРЯЖЕНИЯ - ИЛИ  ЛОЖНЫЙ СИГНАЛ ОТСУТСТВИЯ НАПРЯЖЕНИЯ */
                    /*ОЖИДАНИЕ ИСЧЕЗНОВЕНИЯ МП*/
                    if (!Nu.Mp)
                    {
                        InternalTimers[1].Stop(); /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                        if (storage.SecEcFall)
                        {
                            Messenger.Send(55); /* Msg: НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ*/
                            Messenger.Send(25); /* Msg: ОСТАНАВЛИВАЕТСЯ. НЕТ НАПРЯЖЕНИЯ НА СШ ЩСУ*/
                            /*ЗАПУСКАЕМ ТАЙМЕР НА ОТПУСКАНИЕ МП И ИДЕМ НА ПРИНУДИТЕЛЬНОЕ ОТКЛЮЧЕНИЕ*/
                            if (storage.Mode == VsMode.osn)
                            {
                                storage.AState = 410;
                                InternalTimers[1].Start(); /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                                //WorkNeed= true ;                                                                  
                                storage.WaitingForApv = true;
                            }
                            else
                            {
                                storage.AState = 402;
                                InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                            }
                        }
                        else if (Nu.Ec)
                        {
                            Messenger.Send(17); /* Msg: ВЫПОЛНЕН СТОП ПО МЕСТУ */
                            InternalTimers[4].Stop(); /*ТАЙМЕР НА СТОП ПО МЕСТУ*/
                            InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                            storage.AState = 402;
                            /*3-8*/
                        }
                        else if (!InternalTimers[4].IsStarted)
                        {
                            /*ТАЙМЕР НА СТОП ПО МЕСТУ*/
                            storage.AState = 402;
                            InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                            storage.Avar.EcFall = true;
                            InternalTimers[6].Stop(); /*ТАЙМЕР НА РЕМОНТ ПРИ ОТСУТСТВТИИ Ec*/
                            Messenger.Send(28); /*Msg: НЕИСПРАВЕН. НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ*/
                            if (storage.Mode != VsMode.manual)
                            {
                                storage.Crash = true;
                                storage.NeedAvr = true;
                            }
                        }

                        /*3-7*/
                    }
                    else if (!InternalTimers[1].IsStarted)
                    {
                        /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                        InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        if (!InternalTimers[4].IsStarted)
                        {
                            /*ТАЙМЕР НА СТОП ПО МЕСТУ*/
                            if (!Nu.Ec)
                            {
                                storage.AState = 105;
                            }
                            else
                            {
                                storage.AState = 104;
                            }
                        }
                        else
                        {
                            storage.AState = 106;
                        }
                    }
                    else if (!InternalTimers[4].IsStarted)
                    {
                        /*ТАЙМЕР НА СТОП ПО МЕСТУ*/
                        if (!Nu.Ec)
                        {
                            storage.AState = 107;
                        }
                        else
                        {
                            storage.AState = 108;
                        }
                    }
                    else if (storage.SecEcFall)
                    {
                        /*Пропадала секция шин, пускатель не отвалился*/
                        if ((Nu.Ec && Nu.SecEc && storage.AState / 100 == 1))
                        {
                            /*секция и напряжение вернулись, пока только на работающем агрегате*/
                            if (Nu.Mp && (PcUse && Nu.Pc || !PcUse))
                            {
                                /*все в норме - секция кратковременно мигнула без последствий*/
                                storage.AState = 100;
                                InternalTimers[1].Stop(); /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                                InternalTimers[4].Stop(); /*ТАЙМЕР НА СТОП ПО МЕСТУ*/
                                InternalTimers[6].Stop(); /*ТАЙМЕР НА РЕМОНТ ПРИ ОТСУТСТВТИИ Ec*/
                            }
                        }
                    }

                    break;
                case 103:
                case 406: /*САМОПРОИЗВОЛЬНОЕ ОТКЛЮЧЕНИЕ МП ИЛИ ЛОЖНЫЙ СИГНАЛ ОТСУТСТВИЯ МП*/
                    /*ОЖИДАНИЕ СПАДА ДАВЛЕНИЯ*/
                    if (storage.SecEcFall)
                    {
                        Messenger.Send(25); /* Msg: ОСТАНАВЛИВАЕТСЯ. НЕТ НАПРЯЖЕНИЯ НА СШ ЩСУ*/
                        storage.AState = 402;
                        InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        if (storage.Mode == VsMode.osn)
                        {
                            //WorkNeed= true ;                                                                  
                            storage.WaitingForApv = true;
                        }
                    }
                    else if (!Nu.Pc || !PcUse)
                    {
                        InternalTimers[3].Stop(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        if (!Stop)
                        {
                            if (storage.Mode != VsMode.manual)
                            {
                                storage.Crash = true;
                                storage.NeedAvr = true;
                                storage.Avar.MpcFall = true;
                            }

                            Messenger.Send(26); /*Msg: НЕИСПРАВЕН. МАГНИТНЫЙ ПУСКАТЕЛЬ НЕИСПРАВЕН;*/
                        }

                        storage.AState = 200;
                        /*3-9*/ /*3-21*/
                    }
                    else if (!InternalTimers[3].IsStarted)
                    {
                        /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        if (storage.Mode != VsMode.manual)
                        {
                            storage.Crash = true;
                            storage.NeedAvr = true;
                            storage.Avar.MpcControl = true;
                            storage.DoNeispravStop = true;
                            Messenger.Send(23); /*Msg:  НЕИСПРАВЕН. ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ*/
                        }
                        else
                        {
                            storage.Avar.MpControlRuch = true;
                            Messenger.Send(23); /*Msg:  НЕИСПРАВЕН. ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ*/
                            Messenger.Send(83); /*Msg: ДАВЛЕНИЕ ЕСТЬ. РУЧНОЙ РЕЖИМ*/
                            storage.AState = 100;
                        }
                    }


                    break;
                case 104: /*БЫЛ СТОП ПО МЕСТУ МП НЕ ИСЧЕЗ*/
                    if (!Nu.Pc)
                    {
                        InternalTimers[3].Stop(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        Messenger.Send(17); /* Msg: ВЫПОЛНЕН СТОП ПО МЕСТУ */
                        storage.AState = 200;
                        if (storage.Mode != VsMode.manual)
                        {
                            storage.Crash = true;
                            storage.Avar.MpcControl = true;
                            Messenger.Send(23); /* Msg: ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ*/
                        }
                        else
                        {
                            storage.Avar.MpControlRuch = true; /* ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ*/
                            Messenger.Send(23); /* Msg: ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ*/
                        }

                        /*3-10*/
                    }
                    else if (!InternalTimers[3].IsStarted)
                    {
                        /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        if (storage.Mode != VsMode.manual)
                        {
                            storage.AState = 404;
                            InternalTimers[1].Start(); /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                        }
                        else
                        {
                            storage.AState = 100;
                            Messenger.Send(17); /* Msg: ВЫПОЛНЕН СТОП ПО МЕСТУ */
                            Messenger.Send(29); /* Msg: НЕИСПРАВЕН. МАГНИТНЫЙ ПУСКАТЕЛЬ НЕ ОТКЛЮЧИЛСЯ*/
                        }
                    }

                    break;
                case 105: /*ИСЧЕЗ Ec - МП НЕ ИСЧЕЗ*/
                    if (!Nu.Pc)
                    {
                        storage.Avar.EcFall = true;
                        InternalTimers[3].Stop(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        Messenger.Send(28); /* Msg: НЕИСПРАВЕН. НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ*/
                        Messenger.Send(23); /* Msg: ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ*/
                        storage.AState = 200;
                        if (storage.Mode != VsMode.manual)
                        {
                            storage.Avar.EcFall = true;
                            storage.Avar.MpcControl = true;
                            storage.Crash = true;
                            storage.NeedAvr = true;
                        }
                        else
                        {
                            //storage.Avar.EcControlRuch = true;
                            storage.Avar.MpControlRuch = true;
                        }
                    }
                    else if (!InternalTimers[3].IsStarted)
                    {
                        /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        Messenger.Send(71); /* Msg: НЕИСПРАВЕН. ЦЕПИ КОНТРОЛЯ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ НЕИСПРАВНЫ*/
                        InternalTimers[6].Stop();
                        storage.AState = 100;
                        if (storage.Mode != VsMode.manual)
                        {
                            storage.Avar.EcControl = true;
                            storage.Crash = true;
                            storage.NeedAvr = true;
                            storage.DoNeispravStop = true;
                        }
                        else
                        {
                            storage.Avar.EcControlRuch = true;
                        }
                    }

                    break;
                case 106: /*МП НЕ ИСЧЕЗ ТО ЛИ СТОП ПО МЕСТУ, ТО ЛИ ИСЧЕЗНОВЕНИЕ Ec, ТО ЛИ ЦЕПИ КОНТРОЛЯ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ НЕИСПРАВНЫ*/
                    if (Nu.Ec)
                    {
                        InternalTimers[4].Stop(); /*ТАЙМЕР НА СТОП ПО МЕСТУ*/
                        storage.AState = 104;
                    }
                    else if (!InternalTimers[4].IsStarted)
                    {
                        /*ТАЙМЕР НА СТОП ПО МЕСТУ*/
                        storage.AState = 105;
                    }

                    break;
                case 107: /*ТО ЛИ ИСЧЕЗНОВЕНИЕ Ec (ВЫШЛО ВРЕМЯ НА СТОП ПО МЕСТУ), ТО ЛИ ЦЕПИ КОНТРОЛЯ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ НЕИСПРАВНЫ*/
                    if (!Nu.Mp)
                    {
                        InternalTimers[1].Stop(); /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                        InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        storage.Avar.EcFall = true;
                        Messenger.Send(28); /* Msg: НЕИСПРАВЕН. НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ*/
                        if (storage.Mode != VsMode.manual)
                        {
                            storage.Crash = true;
                            storage.NeedAvr = true;
                        }

                        storage.AState = 402;
                    }
                    else if (!InternalTimers[1].IsStarted)
                    {
                        /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                        InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        storage.AState = 105;
                    }

                    /*НАПРЯЖЕНИЕ ВЕРНУЛОСЬ ЗА ВРЕМЯ НА СТОП ПО МЕСТУ, ПУСКАТЕЛЬ НЕ ОТКЛЮЧИЛСЯ*/
                    break;
                case 108:
                    if (!Nu.Mp)
                    {
                        InternalTimers[1].Stop(); /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                        Messenger.Send(17); /* Msg: ВЫПОЛНЕН СТОП ПО МЕСТУ */
                        storage.AState = 402;
                        InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                    }
                    else if (!InternalTimers[1].IsStarted)
                    {
                        /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                        InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        storage.AState = 104;
                    }

                    break;
                case 113: /*ЧТО-ТО НЕ ТАК С ПОЖНАСОСОМ, МП ВКЛЮЧЕН*/
                    storage.Crash = false;
                    if (!AutoCmd.FireProtectProcessing)
                    {
                        storage.DoNeispravStop = true;
                        storage.Crash = true;
                        //If storage.Neisprav == VsCrash.NoErrorAVR Then
                        //  storage.Neisprav = VsCrash.NoErrorAVR
                        //  bkjhgkjh;
                        //}}
                    }

                    if ((!Nu.Pc || Nu.PcNeisprav) && !(storage.Avar.PcFall || storage.Avar.PcControl))
                    {
                        storage.AState = 101;
                        InternalTimers[5].Start(); /*ТАЙМЕР НА КОНТРОЛЬ ДАВЛЕНИЯ*/
                    }
                    else if ((Nu.Pc && !Nu.PcNeisprav) && (storage.Avar.PcFall || storage.Avar.PcControl))
                    {
                        storage.Avar.PcFall = false;
                        storage.Avar.PcControl = false;
                    }

                    if (!Nu.Mp && !(storage.Avar.MpcFall || storage.Avar.MpcControl))
                    {
                        storage.AState = 103;
                        InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                    }
                    else if (Nu.Mp && (storage.Avar.MpcFall || storage.Avar.MpcControl))
                    {
                        storage.Avar.MpcFall = false;
                        storage.Avar.MpcControl = false;
                    }


                    break;
                case 200: /*ОТКЛЮЧЕН*/

                    /*3-10.1*/
                    if (Nu.Mp && !storage.Avar.MpControlRuch && !storage.Avar.MpcControl)
                    {
                        if (PcUse)
                        {
                            storage.AState = 310;
                            InternalTimers[2].Start(); /*ТАЙМЕР НА НАБОР ДАВЛЕНИЯ*/
                        }
                        else
                        {
                            if (Stop)
                            {
                                Messenger.Send(76); /*Msg: ВКЛЮЧИЛСЯ ПРИ НАЛИЧИИ БЛОКИРОВКИ*/
                                if (storage.Mode != VsMode.manual)
                                {
                                    storage.Crash = true;
                                }

                                storage.Avar.MpCepiOtkl = true;
                                storage.AState = 100;
                                Messenger.Send(38); /*Msg: НЕИСПРАВЕН. НЕИСПРАВНЫ ЦЕПИ ОТКЛЮЧЕНИЯ МАГНИТНОГО ПУСКАТЕЛЯ */
                            }
                            else
                            {
                                storage.AState = 100;
                                Messenger.Send(82); /* Msg: ВЫПОЛНЕН ПУСК ПО МЕСТУ */
                                if (storage.Mode == VsMode.rez)
                                {
                                    storage.SetMode = VsMode.osn;
                                }
                            }

                        }
                    }
                    else if (!Nu.Mp)
                    {
                        if (storage.Avar.MpControlRuch)
                        {
                            storage.Avar.MpControlRuch = false;
                        }

                        if (storage.Avar.MpcControl && !storage.Crash)
                        {
                            storage.Avar.MpcControl = false;
                        }
                    }

                    /*ПОЯВЛЕНИЕ Pc ИЛИ ПУСК ПО МЕСТУ ИЛИ КЗ - Pc*/
                    /*3-11*/
                    if (Nu.PcNeisprav && !storage.Avar.PcControl && InternalTimers[5].IsQ)
                    {
                        Messenger.Send(31); /*Msg: НЕИСПРАВЕН. ДАТЧИК ДАВЛЕНИЯ НЕИСПРАВЕН */
                        storage.Avar.PcControl = true;
                        storage.Crash = true;
                    }

                    if (!Nu.PcNeisprav && InternalTimers[5].IsStarted)
                    {
                        InternalTimers[5].Stop();
                    }

                    if ((Nu.Pc || Nu.PcNeisprav) && PcUse && !storage.Avar.PcControlRuch && !storage.Avar.PcControl)
                    {
                        //добавлено || Nu.PcNeisprav
                        if (!Stop)
                        {
                            if (storage.Mode != VsMode.manual)
                            {
                                if (Nu.PcNeisprav)
                                {
                                    if (!storage.Avar.PcControl && !InternalTimers[5].IsStarted)
                                    {
                                        InternalTimers[5].Start();
                                    }
                                }
                                else if (AutoCmd.ReserveStatus == ReserveGroupStatus.ResExist || !FireStart)
                                {
                                    storage.AState = 312;
                                    InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                                }
                            }
                            else
                            {
                                if (Nu.PcNeisprav)
                                {
                                    //добавлена ветка
                                    storage.Avar.PcControlRuch = true;
                                    Messenger.Send(31); /*Msg: НЕИСПРАВЕН. ДАТЧИК ДАВЛЕНИЯ НЕИСПРАВЕН */
                                }
                                else
                                {
                                    Messenger.Send(82); /* Msg: ВЫПОЛНЕН ПУСК ПО МЕСТУ */
                                    storage.Avar.MpControlRuch = true;
                                    Messenger.Send(23); /*Msg: НЕИСПРАВЕН. ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ */
                                    storage.AState = 100;
                                }
                            }
                        }
                        else
                        {
                            storage.AState = 200;
                            if (storage.Mode != VsMode.manual)
                            {
                                storage.Crash = true;
                                storage.Avar.PcControl = true;
                                if (Nu.Pc)
                                {
                                    Messenger.Send(20); /*Msg: ЛОЖНЫЙ СИГНАЛ НАЛИЧИЯ ДАВЛЕНИЯ*/
                                }

                                Messenger.Send(31); /*Msg: НЕИСПРАВЕН. ДАТЧИК ДАВЛЕНИЯ НЕИСПРАВЕН */
                            }
                            else
                            {
                                storage.Avar.PcControlRuch = true;
                                ;
                                Messenger.Send(20); /*Msg: ЛОЖНЫЙ СИГНАЛ НАЛИЧИЯ ДАВЛЕНИЯ*/
                                Messenger.Send(31); /*Msg: НЕИСПРАВЕН. ДАТЧИК ДАВЛЕНИЯ НЕИСПРАВЕН */
                            }
                        }

                        /*3-12*/
                    }
                    else if (!(Nu.Pc || Nu.PcNeisprav))
                    {
                        //добавлено || Nu.PcNeisprav
                        if (storage.Avar.PcControlRuch)
                        {
                            storage.Avar.PcControlRuch = false;
                        }

                        if (storage.Avar.PcControl && !storage.Crash)
                        {
                            storage.Avar.PcControl = false;
                        }
                    }

                    break;
                case 300: /*ЗАПУСКАЕТСЯ*/
                    if (storage.NeedAvr)
                    {
                        storage.NeedAvr = false;
                    }

                    storage.AState = 301;
                    InternalTimers[1].Start(); /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                    InternalTimers[2].Stop();
                    InternalTimers[3].Stop();

                    break;
                case 301: /*ОЖИДАНИЕ ВКЛЮЧЕНИЯ МП*/
                    if (Nu.Mp)
                    {
                        InternalTimers[1].Stop(); /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                        if (PcUse)
                        {
                            storage.AState = 302;
                            InternalTimers[2].Start(); /*ТАЙМЕР НА НАБОР ДАВЛЕНИЯ*/
                        }
                        else
                        {
                            storage.AState = 100;
                        }
                    }
                    else if (!InternalTimers[1].IsStarted)
                    {
                        /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                        if (PcUse)
                        {
                            storage.AState = 303;
                            InternalTimers[2].Start(); /*ТАЙМЕР НА НАБОР ДАВЛЕНИЯ*/
                        }
                        else
                        {
                            storage.AState = 200;
                            storage.Crash = true;
                            storage.NeedAvr = true;
                            storage.Avar.MpNotUp = true; /*МАГНИТНЫЙ ПУСКАТЕЛЬ НЕ ВКЛЮЧИЛСЯ*/
                            Messenger.Send(27); /*Msg: НЕИСПРАВЕН. МАГНИТНЫЙ ПУСКАТЕЛЬ НЕ ВКЛЮЧИЛСЯ */
                        }
                    }
                    else if (!Nu.Ec)
                    {
                        InternalTimers[1].Start(); /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                        InternalTimers[4].Start(); /*ТАЙМЕР НА СТОП ПО МЕСТУ*/
                        InternalTimers[6].Start(); /*ТАЙМЕР НА РЕМОНТ ПРИ ОТСУТСТВТИИ Ec*/
                        storage.AState = 407;
                    }

                    break;
                case 302: /*ОЖИДАНИЕ РОСТА ДАВЛЕНИЯ*/
                    if (Nu.Pc)
                    {
                        InternalTimers[2].Stop(); /*ТАЙМЕР НА НАБОР ДАВЛЕНИЯ*/
                        storage.AState = 100;
                    }
                    else if (!InternalTimers[2].IsStarted)
                    {
                        /*ТАЙМЕР НА НАБОР ДАВЛЕНИЯ*/
                        storage.Crash = true;
                        storage.NeedAvr = true;
                        storage.Avar.PcNotUp = true; /*НЕИСПРАВЕН. НЕ НАБРАЛ ДАВЛЕНИЕ*/
                        Messenger.Send(77); /*Msg: НЕИСПРАВЕН. НЕ НАБРАЛ ДАВЛЕНИЕ */
                        storage.DoNeispravStop = true;
                    }
                    else if (!Nu.Ec)
                    {
                        storage.AState = 407;
                        InternalTimers[1].Start(); /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                        InternalTimers[4].Start(); /*ТАЙМЕР НА СТОП ПО МЕСТУ*/
                        InternalTimers[6].Start(); /*ТАЙМЕР НА РЕМОНТ ПРИ ОТСУТСТВТИИ Ec*/
                        InternalTimers[2].Stop(); /*ТАЙМЕР НА НАБОР ДАВЛЕНИЯ*/
                    }
                    else if (!Nu.Mp)
                    {
                        storage.AState = 406;
                        InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        InternalTimers[2].Stop(); /*ТАЙМЕР НА НАБОР ДАВЛЕНИЯ*/
                    }

                    break;
                case 303: /*ОЖИДАНИЕ РОСТА ДАВЛЕНИЯ ПРИ ОТСУТСТВИИ СИГНАЛА МП*/
                    if (Nu.Pc)
                    {
                        InternalTimers[2].Stop(); /*ТАЙМЕР НА НАБОР ДАВЛЕНИЯ*/
                        storage.Crash = true;
                        storage.NeedAvr = true;
                        storage.Avar.MpcControl = true;
                        ; /*ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ*/
                        Messenger.Send(23); /*Msg: НЕИСПРАВЕН. ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ */
                        storage.DoNeispravStop = true;
                    }
                    else if (!InternalTimers[2].IsStarted)
                    {
                        /*ТАЙМЕР НА НАБОР ДАВЛЕНИЯ*/
                        storage.AState = 200;
                        storage.Crash = true;
                        storage.NeedAvr = true;
                        storage.Avar.MpNotUp = true; /*МАГНИТНЫЙ ПУСКАТЕЛЬ НЕ ВКЛЮЧИЛСЯ*/
                        Messenger.Send(27); /*Msg: НЕИСПРАВЕН. МАГНИТНЫЙ ПУСКАТЕЛЬ НЕ ВКЛЮЧИЛСЯ */
                    }

                    break;
                case 310: /*ОЖИДАНИЕ ДАВЛЕНИЯ ПОСЛЕ ВЕРОЯТНОГО ПУСКА ПО МЕСТУ*/
                    /*ВЫПОЛНЕН ПУСК ПО МЕСТУ*/
                    if (Nu.Pc && Nu.Mp)
                    {
                        InternalTimers[2].Stop(); /*ТАЙМЕР НА НАБОР ДАВЛЕНИЯ*/
                        Messenger.Send(82); /* Msg: ВЫПОЛНЕН ПУСК ПО МЕСТУ */
                        storage.AState = 100;
                        if (Stop)
                        {
                            Messenger.Send(76); /*Msg: ВКЛЮЧИЛСЯ ПРИ НАЛИЧИИ БЛОКИРОВКИ*/
                            if (storage.Mode != VsMode.manual)
                            {
                                storage.Crash = true;
                            }

                            storage.Avar.MpCepiOtkl = true;
                            Messenger.Send(38); /*Msg: НЕИСПРАВЕН. НЕИСПРАВНЫ ЦЕПИ ОТКЛЮЧЕНИЯ МАГНИТНОГО ПУСКАТЕЛЯ */
                        }
                        else if (storage.Mode == VsMode.rez)
                        {
                            storage.SetMode = VsMode.osn;
                        }
                    }
                    else if (!Nu.Ec)
                    {
                        storage.AState = 407;
                        Messenger.Send(82); /* Msg: ВЫПОЛНЕН ПУСК ПО МЕСТУ */
                        InternalTimers[1].Start(); /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                        InternalTimers[4].Start(); /*ТАЙМЕР НА СТОП ПО МЕСТУ*/
                        InternalTimers[6].Start(); /*ТАЙМЕР НА РЕМОНТ ПРИ ОТСУТСТВТИИ Ec*/
                        /*3-18*/
                    }
                    else if (!InternalTimers[2].IsStarted)
                    {
                        /*ТАЙМЕР НА НАБОР ДАВЛЕНИЯ*/
                        if (Stop)
                        {
                            storage.AState = 200;
                            if (storage.Mode != VsMode.manual)
                            {
                                storage.Crash = true;
                                storage.Avar.MpcControl = true;
                                ;
                            }
                            else
                            {
                                storage.Avar.MpControlRuch = true;
                            }

                            Messenger.Send(19); /*Msg: ЛОЖНЫЙ СИГНАЛ МП ВКЛЮЧЕН*/
                            Messenger.Send(23); /*Msg: НЕИСПРАВЕН. ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ */
                            /*3-19*/
                        }
                        else if (Nu.Mp)
                        {
                            if (storage.Mode != VsMode.manual)
                            {
                                storage.AState = 311;
                                InternalTimers[1].Start(); /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                            }
                            else
                            {
                                storage.Avar.PcControlRuch = true;
                                Messenger.Send(82); /* Msg: ВЫПОЛНЕН ПУСК ПО МЕСТУ */
                                Messenger.Send(77); /*Msg: НЕИСПРАВЕН. НЕ НАБРАЛ ДАВЛЕНИЕ */
                                storage.AState = 100;
                            }

                            /*3-20*/
                        }
                        else
                        {
                            if (storage.Mode != VsMode.manual)
                            {
                                storage.Crash = true;
                                storage.Avar.MpcControl = true;
                                if (Nu.Pc)
                                {
                                    Messenger.Send(82); /* Msg: ВЫПОЛНЕН ПУСК ПО МЕСТУ */
                                    storage.DoNeispravStop = true;
                                }
                                else
                                {
                                    Messenger.Send(19); /*Msg: ЛОЖНЫЙ СИГНАЛ МП ВКЛЮЧЕН*/
                                }

                                Messenger.Send(23); /*Msg: НЕИСПРАВЕН. ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ */
                            }
                            else
                            {
                                storage.Avar.MpControlRuch = true;
                                Messenger.Send(19); /*Msg: ЛОЖНЫЙ СИГНАЛ МП ВКЛЮЧЕН*/
                                Messenger.Send(23); /*Msg: НЕИСПРАВЕН. ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ */
                            }

                            storage.AState = 200;
                        }
                    }

                    break;
                case 311: /*БУДЕМ ОПРЕДЕЛЯТЬ КЗ МП ИЛИ НЕ НАБРАЛ ДАВЛЕНИЕ - ДАЕМ СТОП*/
                    if (!Nu.Mp)
                    {
                        InternalTimers[1].Stop(); /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/

                        storage.Crash = true;
                        storage.NeedAvr = true;
                        storage.Avar.PcNotUp = true;
                        storage.AState = 200;
                        Messenger.Send(82); /* Msg: ВЫПОЛНЕН ПУСК ПО МЕСТУ */
                        Messenger.Send(77); /*Msg: НЕИСПРАВЕН. НЕ НАБРАЛ ДАВЛЕНИЕ */
                    }
                    else if (!InternalTimers[1].IsStarted)
                    {
                        /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                        storage.Crash = true;
                        storage.Avar.MpcControl = true;
                        storage.AState = 200;
                        Messenger.Send(19); /*Msg: ЛОЖНЫЙ СИГНАЛ МП ВКЛЮЧЕН*/
                        Messenger.Send(23); /*Msg: НЕИСПРАВЕН. ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ */
                    }

                    break;
                case 312: /*БУДЕМ ОПРЕДЕЛЯТЬ ПУСК ПО МЕСТУ ИЛИ НЕИСПРАВНОСТЬ ДАТЧИКА - ДАЕМ СТОП*/
                    if (!Nu.Pc)
                    {
                        InternalTimers[3].Stop(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        storage.Crash = true;
                        storage.NeedAvr = true;
                        storage.Avar.MpcControl = true;
                        storage.AState = 200;
                        Messenger.Send(82); /* Msg: ВЫПОЛНЕН ПУСК ПО МЕСТУ */
                        Messenger.Send(23); /*Msg: НЕИСПРАВЕН. ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ */
                    }
                    else if (!InternalTimers[3].IsStarted)
                    {
                        /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        storage.Crash = true;
                        storage.Avar.PcControl = true;
                        storage.AState = 200;
                        Messenger.Send(20); /*Msg: ЛОЖНЫЙ СИГНАЛ НАЛИЧИЯ ДАВЛЕНИЯ*/
                        Messenger.Send(31); /*Msg: НЕИСПРАВЕН. ДАТЧИК ДАВЛЕНИЯ НЕИСПРАВЕН */

                    }

                    break;
                case 400: /*ОСТАНАВЛИВАЕТСЯ - ВЫДАЧА КОМАНДЫ НА ОТКЛЮЧЕНИЕ*/
                    if (Nu.Mp)
                        storage.AState = 401;
                    else
                        storage.AState = 411;

                    storage.NeedAvr = false;
                    InternalTimers[1].Start(); /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                    InternalTimers[2].Stop();
                    InternalTimers[3].Stop();

                    break;
                case 401: /*ОЖИДАНИЕ ОТКЛЮЧЕНИЯ МП*/
                case 411:
                    if (!Nu.Mp && (storage.AState != 411 || !InternalTimers[1].IsStarted))
                    {
                        InternalTimers[1].Stop(); /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                        if (PcUse)
                        {
                            storage.AState = 402;
                            InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        }
                        else
                        {
                            storage.AState = 200;
                        }
                    }
                    else if (!InternalTimers[1].IsStarted)
                    {
                        /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                        if (PcUse)
                        {
                            storage.AState = 403;
                            InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        }
                        else
                        {
                            storage.AState = 100;
                            if (storage.Mode != VsMode.manual)
                            {
                                storage.Crash = true;
                                storage.Avar.MpNotFall = true;
                            }

                            Messenger.Send(29); /*Msg: НЕИСПРАВЕН. МАГНИТНЫЙ ПУСКАТЕЛЬ НЕ ОТКЛЮЧИЛСЯ */
                        }
                    }

                    break;
                case 402: /*ОЖИДАНИЕ СПАДА ДАВЛЕНИЯ*/
                    if (!Nu.Pc || storage.Avar.PcControl)
                    {
                        InternalTimers[3].Stop(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        storage.AState = 200;
                    }
                    else if (!InternalTimers[3].IsStarted)
                    {
                        /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        storage.AState = 200;
                        if (storage.Mode != VsMode.manual)
                        {
                            storage.Crash = true;
                            if (storage.WaitingForApv)
                            {
                                storage.WaitingForApv = false;
                                storage.NeedAvr = true;
                            }

                            storage.Avar.PcControl = true;
                            Messenger.Send(31); /*Msg: НЕИСПРАВЕН. ДАТЧИК ДАВЛЕНИЯ НЕИСПРАВЕН */
                        }
                        else
                        {
                            storage.Avar.PcControlRuch = true;
                            Messenger.Send(31); /*Msg: НЕИСПРАВЕН. ДАТЧИК ДАВЛЕНИЯ НЕИСПРАВЕН */
                        }
                    }
                    else if (Nu.Mp)
                    {
                        InternalTimers[3].Stop(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        storage.AState = 310;
                        InternalTimers[2].Start(); /*ТАЙМЕР НА НАБОР ДАВЛЕНИЯ*/
                    }

                    break;
                case 403: /*ОЖИДАНИЕ СПАДА ДАВЛЕНИЯ ПРИ НАЛИЧИИ СИГНАЛА МП*/
                    if (!Nu.Pc)
                    {
                        InternalTimers[3].Stop(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        storage.AState = 200;
                        if (storage.Mode != VsMode.manual)
                        {
                            storage.Crash = true;
                            storage.Avar.MpcControl = true;
                            Messenger.Send(23); /*Msg: НЕИСПРАВЕН. ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ */
                        }
                        else
                        {
                            storage.Avar.MpControlRuch = true;
                            Messenger.Send(23); /*Msg: НЕИСПРАВЕН. ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ */
                        }

                        /*3-23*/
                    }
                    else if (!InternalTimers[3].IsStarted)
                    {
                        /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        storage.AState = 100;
                        Messenger.Send(29); /*Msg: НЕИСПРАВЕН. МАГНИТНЫЙ ПУСКАТЕЛЬ НЕ ОТКЛЮЧИЛСЯ */
                        if (storage.Mode != VsMode.manual)
                        {
                            storage.Crash = true;
                            storage.Avar.MpNotFall = true;
                        }
                    }

                    break;
                case 404: /*НАПРЯЖЕНИЕ МИГНУЛО, КАК ПРИ СТОПЕ ПО МЕСТУ, НО НИЧЕГО НЕ ОТКЛЮЧИЛОСЬ - ДАЕМ СТОП*/
                    if (!Nu.Mp)
                    {
                        storage.Crash = true;
                        storage.NeedAvr = true;
                        storage.Avar.EcControl = true;
                        Messenger.Send(71); /* Msg: НЕИСПРАВЕН. ЦЕПИ КОНТРОЛЯ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ НЕИСПРАВНЫ*/
                        //PuskAvr= true ;                                           
                        storage.AState = 402;
                        InternalTimers[6].Stop(); /*ТАЙМЕР НА РЕМОНТ ПРИ ОТСУТСТВТИИ Ec*/
                        InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                    }
                    else if (!InternalTimers[1].IsStarted)
                    {
                        /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                        if (PcUse)
                        {
                            storage.AState = 405;
                            InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        }
                        else
                        {
                            storage.AState = 100;
                            storage.Crash = true;
                            storage.Avar.MpNotFall = true;
                            Messenger.Send(17); /* Msg: ВЫПОЛНЕН СТОП ПО МЕСТУ */
                            Messenger.Send(29); /* Msg: НЕИСПРАВЕН. МАГНИТНЫЙ ПУСКАТЕЛЬ НЕ ОТКЛЮЧИЛСЯ*/
                        }
                    }

                    break;
                case 405:
                    if (!Nu.Pc)
                    {
                        //PuskAvr= true ;                                                                               
                        InternalTimers[3].Stop(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        InternalTimers[6].Stop(); /*ТАЙМЕР НА РЕМОНТ ПРИ ОТСУТСТВТИИ Ec*/
                        storage.Crash = true;
                        storage.NeedAvr = true;
                        storage.Avar.EcControl = true;
                        Messenger.Send(71); /* Msg: НЕИСПРАВЕН. ЦЕПИ КОНТРОЛЯ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ НЕИСПРАВНЫ*/
                        storage.Avar.MpcControl = true;
                        storage.AState = 200;
                        Messenger.Send(23); /*Msg: НЕИСПРАВЕН. ЦЕПИ КОНТРОЛЯ МАГНИТНОГО ПУСКАТЕЛЯ НЕИСПРАВНЫ */
                    }
                    else if (!InternalTimers[3].IsStarted)
                    {
                        /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        storage.Crash = true;
                        Messenger.Send(17); /* Msg: ВЫПОЛНЕН СТОП ПО МЕСТУ */
                        Messenger.Send(29); /*Msg: НЕИСПРАВЕН. МАГНИТНЫЙ ПУСКАТЕЛЬ НЕ ОТКЛЮЧИЛСЯ */
                        storage.AState = 100;
                    }

                    break;
                case 410: /*ИСЧЕЗНОВЕНИЕ НАПРЯЖЕНИЯ НА СЕКЦИИ ШИН И ВСЕ СВЯЗАННЫЕ С ЭТИМ ПРОЦЕССЫ*/
                    /*ПРИНУДИТЕЛЬНОЕ ОТКЛЮЧЕНИЕ*/
                    if (!InternalTimers[1].IsStarted)
                    {
                        /*ТАЙМЕР НА ВКЛ/ОТКЛ МП*/
                        if (!Nu.Mp)
                        {
                            if (PcUse)
                            {
                                storage.AState = 402;
                                InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                            }
                            else
                            {
                                storage.AState = 200;
                            }
                        }
                        else
                        {
                            storage.AState = 403;
                            InternalTimers[3].Start(); /*ТАЙМЕР НА СБРОС ДАВЛЕНИЯ*/
                        }
                    }

                    break;
                default:
                    {
                        storage.AState = 0;
                        break;
                    }
            }




            /*Проверка, что авр пришло не с рем и руч*/

            if (storage.Mode == VsMode.manual || storage.Mode == VsMode.repair)
            {
                storage.NeedAvr = false;
            }

            if (storage.Crash)
            {
                if (AutoCmd.FireProtectProcessing && storage.Mode != VsMode.repair)
                {
                    storage.Crash = false;
                }
                else
                {
                    storage.WaitingForApv = false;
                    storage.SetMode = VsMode.repair;
                }
            }

            if (storage.SetMode != storage.Mode)
            {
                if (storage.SetMode == VsMode.osn)
                {
                    Messenger.Send(40); /* Msg: УСТАНОВИТЬ РЕЖИМ ОСНОВНОЙ АВТОМАТИЧЕСКИ */
                    Messenger.Send(34); /* Msg: УСТАНОВЛЕН РЕЖИМ ОСНОВНОЙ  */
                    storage.Mode = storage.SetMode;
                }
                else if (storage.SetMode == VsMode.rez)
                {
                    Messenger.Send(41); /* Msg: НАЗНАЧИТЬ РЕЖИМ РЕЗЕРВНЫЙ АВТОМАТИЧЕСКИ */
                    Messenger.Send(35); /* Msg: НАЗНАЧЕН РЕЖИМ РЕЗЕРВНЫЙ  */
                    storage.Mode = storage.SetMode;
                }
                else if (storage.SetMode == VsMode.repair)
                {
                    Messenger.Send(39); /* Msg: НАЗНАЧИТЬ РЕЖИМ РЕМОНТНЫЙ АВТОМАТИЧЕСКИ */
                    Messenger.Send(37); /* Msg: НАЗНАЧЕН РЕЖИМ РЕМОНТНЫЙ  */
                    storage.Mode = storage.SetMode;
                }
                else if (storage.SetMode == VsMode.manual)
                {
                    Messenger.Send(45); /* Msg: НАЗНАЧИТЬ РЕЖИМ РУЧНОЙ АВТОМАТИЧЕСКИ */
                    Messenger.Send(36); /* Msg: НАЗНАЧЕН РЕЖИМ РУЧНОЙ  */
                    storage.Mode = storage.SetMode;
                }
            }

            /*ТОЧКА 5*/
            /*УСТАНОВКА СОСТОЯНИЙ ПО РД*/
            var newState = storage.AState / 100;
            if ((byte)storage.State != newState)
            {
                switch (newState)
                {
                    case 1:
                        storage.State = VsState.on;
                        Messenger.Send(21); /* Msg: ВКЛЮЧЕН */
                        break;
                    case 2:
                        storage.State = VsState.off;
                        Messenger.Send(22); /* Msg: ОТКЛЮЧЕН */
                        break;
                    case 3:
                        storage.State = VsState.starting;
                        break;
                    case 4:
                        storage.State = VsState.stopping;
                        break;
                }
            }
            /*УСТАНОВКА СОСТОЯНИЙ ПО РД*/

            /*ТОЧКА 6*/
            var OtklNorm = storage.State == VsState.off && !Nu.Mp && !Nu.Pc && !Nu.PcNeisprav && (Nu.Ec || !Nu.Ec && InternalTimers[6].IsStarted) && (storage.PrevOpc || !UseOpc) && !Nu.ExternalCrash; /*ТАЙМЕР НА РЕМОНТ ПРИ ОТСУТСТВТИИ Ec*/
            var VklNorm = storage.State == VsState.on && Nu.Mp && (PcUse && Nu.Pc && !Nu.PcNeisprav || !PcUse) && Nu.Ec && !Stop;

            /*ТОЧКА 6.1*/
            /*ПРИНЯТИЕ КОМАНД С ВУ*/
            VsMode vuSetMode = VsMode.none;

            #region Accepting change mode commands

            if (Cmd == VsCmds.CmdOsn)
            {
                vuSetMode = VsMode.osn;
                Messenger.Send(65); /*Msg: КОМАНДА - НАЗНАЧИТЬ РЕЖИМ ОСНОВНОЙ С АРМ */
            }
            else if (Cmd == VsCmds.CmdRez)
            {
                vuSetMode = VsMode.rez;
                Messenger.Send(66); /*Msg: КОМАНДА - НАЗНАЧИТЬ РЕЖИМ РЕЗЕРВНЫЙ С АРМ */
            }
            else if (Cmd == VsCmds.CmdRuch)
            {
                vuSetMode = VsMode.manual;
                Messenger.Send(68); /*Msg: КОМАНДА - НАЗНАЧИТЬ РЕЖИМ РУЧНОЙ С АРМ */
            }
            else if (Cmd == VsCmds.CmdRem)
            {
                vuSetMode = VsMode.repair;
                Messenger.Send(69); /*Msg: КОМАНДА - НАЗНАЧИТЬ РЕЖИМ РЕМОНТНЫЙ С АРМ */
            }

            #endregion


            #region Change mode checks


            if (vuSetMode != 0)
            {
                var allowSetMode = false;
                if (storage.Mode == vuSetMode)
                {
                    Messenger.Send(87); /* Msg:  НАЗНАЧЕНИЕ РЕЖИМА НЕ ТРЕБУЕТСЯ. РЕЖИМ УЖЕ НАЗНАЧЕН */
                    vuSetMode = 0;
                }
                else if (storage.Crash)
                {
                    Messenger.Send(11); /* Msg: НЕИСПРАВЕН. НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО */
                }
                else if (vuSetMode == VsMode.repair)
                {
                    storage.Mode = vuSetMode;
                    storage.SetMode = vuSetMode;
                }
                else if (storage.State == VsState.starting)
                {
                    Messenger.Send(63); /* Msg:ЗАПУСКАЕТСЯ.НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО*/
                }
                else if (storage.State == VsState.stopping)
                {
                    Messenger.Send(67); /* Msg: ОСТАНАВЛИВАЕТСЯ.НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО*/
                }
                else if (storage.State == VsState.off)
                {
                    if (vuSetMode != VsMode.rez || AutoCmd.ReserveStatus == ReserveGroupStatus.AllowSetRez)
                    {
                        allowSetMode = true;
                    }
                    else if (AutoCmd.ReserveStatus == ReserveGroupStatus.ResExist)
                    {
                        Messenger.Send(81); /* Msg: НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ЕСТЬ АГРЕГАТ В РЕЗЕРВЕ */
                    }
                    else if (AutoCmd.ReserveStatus == ReserveGroupStatus.NotEnoughOsn)
                    {
                        Messenger.Send(44); /* Msg: НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. НЕТ АГРЕГАТОВ В ОСНОВНОМ РЕЖИМЕ.*/
                    }
                    else if (storage.Mode == VsMode.osn && AutoCmd.ReserveStatus == ReserveGroupStatus.AllowSetForNotOsn)
                    {
                        Messenger.Send(44); /* Msg: НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. НЕТ АГРЕГАТОВ В ОСНОВНОМ РЕЖИМЕ.*/
                    }
                    else
                    {
                        allowSetMode = true;
                    }

                    if (allowSetMode)
                    {
                        if (OtklNorm || vuSetMode == VsMode.manual)
                        {
                            storage.Mode = vuSetMode;
                            storage.SetMode = vuSetMode;
                        }
                        else
                        {
                            if (Nu.Mp)
                            {
                                Messenger.Send(85); /* Msg: НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ЦЕПИ КОНТРОЛЯ МАГНИТНОГО  ПУСКАТЕЛЯ НЕИСПРАВНЫ*/
                            }

                            if (Nu.Pc || Nu.PcNeisprav)
                            {
                                Messenger.Send(86); /* Msg: НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ДАТЧИК ДАВЛЕНИЯ НЕИСПРАВЕН*/
                            }

                            if (!Nu.Ec && (!InternalTimers[6].IsStarted))
                            {
                                /*ТАЙМЕР НА РЕМОНТ ПРИ ОТСУТСТВТИИ Ec*/
                                Messenger.Send(84); /* Msg: НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. НЕТ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ*/
                            }

                            if (!storage.PrevOpc)
                            {
                                Messenger.Send(88); /* Msg: НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ЦЕПИ ВКЛЮЧЕНИЯ НЕИСПРАВНЫ*/
                            }

                            if (Nu.ExternalCrash)
                            {
                                Messenger.Send(89); /* Msg: НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ВНЕШНЯЯ НЕИСПРАВНОСТЬ*/
                            }
                        }
                    }
                }
                else if (storage.State == VsState.@on)
                {
                    if (vuSetMode == VsMode.rez)
                    {
                        Messenger.Send(6); /* Msg: ВКЛЮЧЕН. НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО */
                    }
                    else if (VklNorm || vuSetMode == VsMode.manual)
                    {
                        storage.Mode = vuSetMode;
                        storage.SetMode = vuSetMode;
                    }
                    else
                    {
                        if (!Nu.Mp)
                        {
                            Messenger.Send(85); /* Msg: НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ЦЕПИ КОНТРОЛЯ МАГНИТНОГО  ПУСКАТЕЛЯ НЕИСПРАВНЫ*/
                        }

                        if (!Nu.Pc || Nu.PcNeisprav)
                        {
                            Messenger.Send(86); /* Msg: НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ДАТЧИК ДАВЛЕНИЯ НЕИСПРАВЕН*/
                        }

                        if (!Nu.Ec)
                        {
                            Messenger.Send(78); /* Msg: НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ЦЕПИ КОНТРОЛЯ НАПРЯЖЕНИЯ В СХЕМЕ УПРАВЛЕНИЯ НЕИСПРАВНЫ*/
                        }

                        if (Nu.ExternalCrash)
                        {
                            Messenger.Send(89); /* Msg: НАЗНАЧЕНИЕ РЕЖИМА НЕВОЗМОЖНО. ВНЕШНЯЯ НЕИСПРАВНОСТЬ*/
                        }
                    }

                }
            }

            #endregion

            if (storage.Mode == vuSetMode)
            {
                if (storage.Mode == VsMode.osn)
                {
                    Messenger.Send(34); /* Msg: НАЗНАЧЕН РЕЖИМ ОСНОВНОЙ */
                }
                else if (storage.Mode == VsMode.rez)
                {
                    Messenger.Send(35); /* Msg: НАЗНАЧЕН РЕЖИМ РЕЗЕРВНЫЙ */
                }
                else if (storage.Mode == VsMode.manual)
                {
                    Messenger.Send(36); /* Msg: НАЗНАЧЕН РЕЖИМ РУЧНОЙ */
                }
                else if (storage.Mode == VsMode.repair)
                {
                    Messenger.Send(37); /* Msg: НАЗНАЧЕН РЕЖИМ РЕМОНТНЫЙ */
                    if (storage.State != VsState.off && storage.State != VsState.stopping)
                    {
                        storage.DoSelfStop = true;
                    }
                }
            }

            /*6.6*/

            #region Deblock cmd

            if (Cmd == VsCmds.CmdDebl)
            {
                Messenger.Send(64); /*Msg: КОМАНДА - ДЕБЛОКИРОВАТЬ НЕИСПРАВНОСТЬ С АРМ */
                if (!storage.Crash)
                {
                    ;
                }
                else if (storage.State != VsState.off)
                {
                    Messenger.Send(80); /* Msg: НЕ ОТКЛЮЧЕН. ДЕБЛОКИРОВКА НЕИСПРАВНОСТИ НЕВОЗМОЖНА.*/
                }
                else if (Nu.ExternalCrash)
                {
                    Messenger.Send(74); /* Msg: АВАРИЙНЫЙ СИГНАЛ НЕ СНЯТ. ДЕБЛОКИРОВКА НЕИСПРАВНОСТИ НЕВОЗМОЖНА*/
                }
                else
                {
                    Messenger.Send(79); /* Msg: НЕИСПРАВНОСТЬ ДЕБЛОКИРОВАНА*/
                    storage.Crash = false;
                    storage.Avar.MpcFall = false;
                    storage.Avar.PcFall = false;
                    storage.Avar.EcFall = false;
                    storage.Avar.MpNotFall = false;
                    storage.Avar.External = false;
                    storage.Avar.PcNotUp = false;
                    storage.Avar.MpNotUp = false;
                    storage.Avar.MpCepiOtkl = false;
                    storage.Avar.EcControl = false;
                    if (!Nu.Mp)
                    {
                        storage.Avar.MpcControl = false;
                    }

                    if (!Nu.Pc && !Nu.PcNeisprav)
                    {
                        storage.Avar.PcControl = false;
                    }
                }

            }

            #endregion

            if (storage.Mode == VsMode.manual && storage.State == VsState.off)
            {
                storage.Avar.MpCepiOtkl = false;
            }

            if (storage.Mode != VsMode.manual)
            {
                storage.Avar.MpControlRuch = false;
                storage.Avar.PcControlRuch = false;
                storage.Avar.EcControlRuch = false;
            }

            if (!FireStart)
            {
                /*при тушении стоп только в ручном режиме*/
                StopCmd = storage.AState == 400 || storage.AState == 401 || storage.AState == 411 || storage.AState == 403 || storage.AState == 404 || storage.AState == 405 || storage.AState == 410 || storage.AState == 311 || storage.AState == 312 || Stop;
            }
            else
            {
                StopCmd = Stop;
            }

            storage.NeedAvr = storage.NeedAvr || activateAvr;
            StartCmd = storage.AState == 300 || storage.AState == 301 || storage.AState == 303;

            //складываем результаты работы
            Crashes = storage.Avar;

            OuterState.State = storage.State;
            OuterState.Crash = storage.Crash;
            OuterState.NeedAvr = storage.NeedAvr;
            OuterState.Mode = storage.Mode;
            OuterState.WorkBlocked = storage.BlockWork;
            OuterState.StopBlocked = storage.BlockStop;
            OuterState.WaitFutureStart = storage.DoFuturePusk;
            OuterState.WaitApv = storage.WaitingForApv;
            OuterState.StartedAsDop = AutoCmd.MarkAsDop;
        }  
    }
    /// <summary>
    /// Структура внутреннего состояния агрегата
    /// </summary>
    internal class AvsStorage
    {
        /// <summary>
        /// Состояние агрегата ВС в кодах
        /// </summary>
        public uint AState; /*Состояние агрегата ВС в кодах*/
        /// <summary>
        /// Флаг фиксации пропадания напряжения на секции шин
        /// </summary>
        public bool SecEcFall;  /*Фиксация пропадания напряжения на секции шин*/
        /// <summary>
        /// 
        /// </summary>
        public bool PrevSecEc;
        /// <summary>
        /// Флаг фиксации пропадания напряжения в схеме
        /// </summary>
        public bool PrevEc; /*Фиксация пропадания напряжения в схеме*/
        /// <summary>
        /// Флаг фиксации исправности цепей контроля включения
        /// </summary>
        public bool PrevOpc;    /*Фиксация исправности цепей контроля включения*/
        /// <summary>
        /// Установка режима
        /// </summary>
        public VsMode SetMode;    /*Установка режима TODO вроде как должна быть на стеке*/
        /// <summary>
        /// Флаг выполнения АПВ
        /// </summary>
        public bool DoApv;  /*Выполнить АПВ*/
        /// <summary>
        /// Флаг отложенного запуска
        /// </summary>
        public bool DoFuturePusk;   /*Отложенный пуск*/
        /// <summary>
        /// Флаг отключения по несиправности
        /// </summary>
        public bool DoNeispravStop; /*Отключить по неисправности*/
        /// <summary>
        /// 
        /// </summary>
        public bool DoSelfStart;
        /// <summary>
        /// 
        /// </summary>
        public bool DoSelfStop;
        /// <summary>
        /// Флаг запрета выполнения АПВ
        /// </summary>
        public bool BlockApv;   /* ЗАПРЕТ ВЫПОЛНЕНИЯ АПВ*/
        /// <summary>
        /// Флаг блокировки отключения
        /// </summary>
        public bool BlockStop;  /*ФЛАГ БЛОКИРОВКИ ОТКЛЮЧЕНИЯ*/
        /// <summary>
        /// Флаг блокировки работы
        /// </summary>
        public bool BlockWork;  /*ФЛАГ БЛОКИРОВКИ РАБОТЫ*/
        /// <summary>
        /// Флаг состояния агрегата ВС по РД
        /// </summary>
        public VsState State;   /*Состояние агрегата ВС по РД*/
        /// <summary>
        /// Структура аварий
        /// </summary>
        public AvsCrashes Avar = new AvsCrashes();
        //public VsCrash Neisprav;   /*Неисправность ВС*/
        /// <summary>
        /// Флаг аварии
        /// </summary>
        public bool Crash;
        /// <summary>
        /// Флаг необходимости АВР
        /// </summary>
        public bool NeedAvr;
        /// <summary>
        /// Режим управления
        /// </summary>
        public VsMode Mode;   /*Режим управления*/
        /// <summary>
        /// 
        /// </summary>
        public bool NeedHoldStop;
        /// <summary>
        /// Флаг ожидания АПВ
        /// </summary>
        public bool WaitingForApv;      /*ФЛАГ ОЖИДАНИЯ АПВ*/
    }
}
